# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: bound-recovery-browser.spec.mjs >> schema3-6 recovery gates and immutable cache at 1366
- Location: ..\..\graph-bound-draft-recovery-evidence-20261020\bound-recovery-browser.spec.mjs:3:62

# Error details

```
Error: expect(locator).toHaveValue(expected) failed

Locator: getByLabel('本机草稿 video-1 · 参数（只读）')
Timeout: 5000ms
- Expected  - 5
+ Received  + 5

  {
    "operation_id": "m7.video.t2v",
    "provider_id": "",
    "model_id": "",
-   "allow_cloud": true,
-   "bind_shot": true,
-   "prompt": "镜头 video-1 的独立提示词",
-   "license_note": "授权 video-1",
+   "prompt": "镜头 video-1 的独立提示词",
    "parameters": {
      "seed": 1,
      "duration_seconds": 2,
      "frame_rate": 24,
      "negative_prompt": "独立排除 video-1"
-   }
+   },
+   "allow_cloud": true,
+   "license_note": "授权 video-1",
+   "bind_shot": true
  }

Call log:
  - Expect "toHaveValue" with timeout 5000ms
  - waiting for getByLabel('本机草稿 video-1 · 参数（只读）')
    14 × locator resolved to <textarea readonly>{↵  "operation_id": "m7.video.t2v",↵  "provider_i…</textarea>
       - unexpected value "{
  "operation_id": "m7.video.t2v",
  "provider_id": "",
  "model_id": "",
  "prompt": "镜头 video-1 的独立提示词",
  "parameters": {
    "seed": 1,
    "duration_seconds": 2,
    "frame_rate": 24,
    "negative_prompt": "独立排除 video-1"
  },
  "allow_cloud": true,
  "license_note": "授权 video-1",
  "bind_shot": true
}"

```

```yaml
- textbox "本机草稿 video-1 · 参数（只读）": "{ \"operation_id\": \"m7.video.t2v\", \"provider_id\": \"\", \"model_id\": \"\", \"prompt\": \"镜头 video-1 的独立提示词\", \"parameters\": { \"seed\": 1, \"duration_seconds\": 2, \"frame_rate\": 24, \"negative_prompt\": \"独立排除 video-1\" }, \"allow_cloud\": true, \"license_note\": \"授权 video-1\", \"bind_shot\": true }"
```

# Test source

```ts
  1  | import {createRequire}from'node:module';import fs from'node:fs';const require=createRequire('<TASK_ROOT>/task/studio-v2-graph-bound-draft-recovery/frontend/package.json');const{test,expect}=require('@playwright/test');
  2  | async function mount(page,schema,seed=true){await page.goto('/ui-fixture?module=NOVEL');await page.emulateMedia({reducedMotion:'reduce'});await page.evaluate(async({schema,seed})=>{await document.fonts.ready;const f=await import('/.runtime/bound-recovery-component.tsx');f.mount(document.querySelector('.main-workspace'),schema,seed);},{schema,seed});}
  3  | for(const[width,height]of[[1366,768],[1440,900],[1920,1080]])test(`schema3-6 recovery gates and immutable cache at ${width}`,async({page},info)=>{const errors=[];page.on('pageerror',e=>errors.push(e.message));await page.setViewportSize({width,height});const proofs=[];
> 4  |  for(const schema of[3,4,5,6]){await mount(page,schema);await expect(page.getByRole('heading',{name:'发现本机创作图草稿',exact:true})).toBeVisible();await page.getByText('查看待恢复的作者输入',{exact:true}).click();const raw=await page.evaluate(()=>JSON.parse(localStorage.getItem(window.__boundKey)));const node=raw.definition.nodes.find(n=>n.definition_id===(schema===6?'local_subgraph':schema===5?'video_generate':schema===4?'image_generate':'media_generate'));await expect(page.getByLabel(`本机草稿 ${node.id} · 参数（只读）`)).toHaveValue(JSON.stringify(node.parameters,null,2));
     |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ^ Error: expect(locator).toHaveValue(expected) failed
  5  |  await page.getByRole('button',{name:'核对并恢复本机图草稿'}).click();await expect(page.getByText(/GATE_DISABLED|缓存来源、版本或读取权限未能确认/).first()).toBeVisible();expect(await page.evaluate(()=>window.__boundState.schema)).toBe(1);await page.evaluate(()=>window.__boundGate=true);await page.getByRole('button',{name:'核对并恢复本机图草稿'}).click();await expect(page.getByLabel(`已恢复 ${node.id} · 参数（只读）`)).toBeVisible();const state=await page.evaluate(()=>({state:window.__boundState,cache:JSON.parse(localStorage.getItem(window.__boundKey)),calls:window.__boundCalls}));expect(state.state.schema).toBe(schema);expect(state.cache.request_id).toBe(raw.request_id);expect(state.state.definition).toEqual(raw.definition);expect(state.calls.some(c=>c.action==='UNEXPECTED_WRITE')).toBe(false);if(schema<6)expect(state.state.definition.nodes.find(n=>n.id===node.id).parameters.provider_id).toBe('');
  6  |  const geometry=await page.evaluate(()=>({page:document.documentElement.scrollWidth,viewport:innerWidth,main:{client:document.querySelector('.main-workspace').clientWidth,scroll:document.querySelector('.main-workspace').scrollWidth},inspector:document.querySelector('.workspace-inspector').getBoundingClientRect().width}));expect(geometry.page).toBeLessThanOrEqual(width);expect(geometry.main.scroll).toBeLessThanOrEqual(geometry.main.client);expect(geometry.inspector).toBe(340);await page.screenshot({path:info.outputPath(`schema-${schema}-local-only.png`)});proofs.push({schema,geometry,calls:state.calls,request:raw.request_id});
  7  |  if(schema===6){await mount(page,schema,false);await expect(page.getByRole('heading',{name:'发现本机创作图草稿',exact:true})).toBeVisible();await page.evaluate(()=>{window.__boundGate=true;window.__boundChild.execution_digest='f'.repeat(64);});await page.getByRole('button',{name:'核对并恢复本机图草稿'}).click();await expect(page.getByText(/缓存来源、版本或读取权限未能确认/)).toBeVisible();expect(await page.evaluate(()=>window.__boundState.schema)).toBe(1);const kept=await page.evaluate(()=>JSON.parse(localStorage.getItem(window.__boundKey)));expect(kept.request_id).toBe(raw.request_id);expect(kept.definition.nodes.find(n=>n.definition_id==='local_subgraph').parameters.execution_digest).toBe(node.parameters.execution_digest);await page.screenshot({path:info.outputPath('schema-6-stale-pin-not-adopted.png')});}
  8  |  }
  9  |  expect(errors).toEqual([]);fs.writeFileSync(info.outputPath('component-proof.json'),JSON.stringify({mode:'actual localStorage reload with mocked original readonly APIs/captured catalog; NOT live Host/PG/full E2E',width,height,proofs,errors},null,2));});
  10 | 
```