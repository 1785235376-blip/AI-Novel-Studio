import {createRequire} from 'node:module';const require=createRequire('<TASK_ROOT>/task/studio-v2-graph-bound-draft-recovery/frontend/package.json');const {defineConfig,devices}=require('@playwright/test');
export default defineConfig({testDir:'<TASK_ROOT>/task/graph-bound-draft-recovery-evidence-20261020',testMatch:'bound-recovery-browser.spec.mjs',
 outputDir:'<TASK_ROOT>/task/graph-bound-draft-recovery-evidence-20261020/bound-recovery-browser-results',workers:1,retries:0,timeout:60000,
 reporter:[['list'],['junit',{outputFile:'<TASK_ROOT>/task/graph-bound-draft-recovery-evidence-20261020/bound-recovery-browser.junit.xml'}]],
 expect:{toHaveScreenshot:{maxDiffPixelRatio:0.015,animations:'disabled'}},use:{baseURL:'http://127.0.0.1:5332',locale:'zh-CN',timezoneId:'Asia/Shanghai',colorScheme:'light',deviceScaleFactor:1,screenshot:'only-on-failure',trace:'off',launchOptions:{executablePath:'<USER_HOME>/AppData/Local/ms-playwright/chromium_headless_shell-1234/chrome-headless-shell-win64/chrome-headless-shell.exe'}},
 projects:[{name:'chromium',use:{...devices['Desktop Chrome'],viewport:{width:1440,height:900},deviceScaleFactor:1}}]});
