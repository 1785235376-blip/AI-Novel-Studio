# GRAPH-08 schema 3–6 authoring draft recovery — local delivery

**Result: LOCAL_COMMIT_COMPLETE.** Consolidated schemas 3–6 slice; schema7 remains on its existing path. No code blocker, rejected approval, model/quota limit or uncertain write. No task-owned background job remains.

- Base: `7883878ae862326ff3ca256d9a111d8462920fe0`.
- Commit: `a8ac7dff36c94e3b58d2edc7116708ef4e42f742`.
- Tree: `bdee896c0e48891af0484eb3569571909b49faa1`.
- Worktree: `<TASK_ROOT>\task\studio-v2-graph-bound-draft-recovery`.
- Branch: `work/v2-graph-bound-draft-recovery-788-20261020`.
- 9 files, 380 insertions / 23 deletions. Clean final Git status and diff check. Local commit only: no push, main merge, tag or Release.

## Concrete requirement and original contracts

`AI_NOVEL_STUDIO_V2_FEATURE_MATRIX.md:140` GRAPH-08 §7.2 requires visible autosaved drafts and recovery across reload/disconnect; the matrix still marks the larger requirement PARTIAL. At base788, the original local draft decoder admitted schemas1/2/7 and rejected3–6. The palette in `useStudioGraphEditorController.ts:652–658` emits exactly empty provider/model IDs; `storyboard_prompt` also starts without a selected shot. These original incomplete states are legitimate authoring drafts but fail the strict Save DTO decoder. This shared slice preserves their author input without weakening Save or inventing runnable authority.

## Changed behavior and protection

1. Extend the existing bounded/owner-scoped cache to typed schemas3–6; preserve original request ID, CAS baseline, both digests, UNKNOWN state and project incarnation. Only known exactly-empty palette fields use temporary syntax placeholders inside the authoring decoder; placeholders are removed before return. Save decoder/transport remain unchanged.
2. Explicit recovery reads the original schema catalog and source owners twice, then rereads the catalog and original overview/incarnation/edit grant. Verify exact current asset, planning, Storyboard shot and Graph timeline pins; reject stale, foreign, deleted or unreadable sources without rewriting pins.
3. Schema6 preserves child ID/version/definition digest/execution digest/interface and original permission/scope/node limits. Reuse the original pure-child inspector and saved-topology guard. Unsaved parents retain the original three-node chain.
4. Reuse the existing owner/source/permission/busy ABA fence, pending mutex, old-callback/late-result guards, duplicate protection, cross-tab comparison and capacity limits. No source migration, flag enabling, provider discovery, model invocation, automatic Save, timeline operation, run or approval occurs.
5. Expose cached parameters readonly so failed source verification leaves author input inspectable. No NLE/Timeline/DSH owner, design tokens or shared shell were modified.

The original schema7 recovery tests remain included and passing. The schema7 path/read counts were not expanded with the schemas3–6 source checks.

## Actual verification history

All original outputs and exact command/exit JSON files are retained; names that contain “green”/“final” do not imply their run passed.

| Evidence label | Actual result | Interpretation / correction |
|---|---:|---|
| shared-reproduction-red | 7 failed | Before implementation: valid3–6 plus original empty route authoring all rejected. |
| decoder-first-green | 27 passed / 3 failed | New fixture compared signed -0 to JSON 0; one old test encoded superseded schema3 exclusion. |
| bound-sources-first | 51 passed / 4 failed | New saved-UNKNOWN assertions incorrectly expected blind PUT retry; schema6 raw File fixture param ordering did not match the real public decoder. Original retry/topology guards retained. |
| consolidated-recovery-final | 86 passed / 6 failed | Same expectation issues, real reload mock ordering and old notes test excluding3–5. Fixed fixtures/expectations to original contracts. |
| consolidated-original-contracts | **96 passed / 5 files** | 55 consolidated new tests +41 adjacent decoder/schema7/recovery/notes regressions; 4.94s. |
| typescript-final | **exit0; one tsc -b** | Final type check. |
| production-build-final | **exit0; one Vite build** | 5.24s. Existing >500kB chunk-size warning retained. |
| design-tokens-final | **exit0** | Token guard. |
| bound-recovery-browser | 3 failed | Fixture compared pretty-printed JSON key order as text; values already matched. |
| bound-recovery-browser-final | **3 passed; 4.4s** | Semantic JSON comparison retains every value; three widths1366/1440/1920, all four schemas, disabled gates and stale schema6 digest rejection. |

Focused tests cover actual open/edit/autosave/unmount/restore, explicit original create, saved UNKNOWN no-PUT + readback, unsaved UNKNOWN same-key create, immutable source pins, exact child permission/interface/digests, source changes on second read, stale/deleted/foreign assets, Director/Storyboard pins and unapproved authoring, conservative timeline references, incarnation checks, old callbacks/permission and busy ABA, duplicate recovery and other-tab cache edits. No original execution safety guard was weakened to pass tests.

Browser evidence uses the original controller/component and real localStorage, captured original catalog/source fixtures and controlled readonly transport mocks. It is **not live Host/PostgreSQL or full application E2E acceptance**. All screenshots/proofs and both failed/final JUnit outputs are retained. A final schema6 screenshot at1440 was visually inspected; all widths checked page/main overflow and the unchanged340px inspector. No screenshot claims real PostgreSQL merely because the shared fixture footer displays that label.

## Remaining acceptance and safe boundaries

- **NOT_RUN:** real Host, real PostgreSQL, full app E2E, backend suites and any model/provider execution. No current legitimate Host/PG target was established or used in this slice; do not mark the whole GRAPH-08 DONE.
- Stale or unavailable references remain cached/readonly but are not adopted. No silent repinning. Recovery can require resolving the source through its original owner before adoption.
- Timeline checks are conservative: even a snapshot asset that an unapplied edit would remove must still be current/readable. This Graph reader does not replay edits or modify the Timeline owner.
- Original unapplied Timeline/execution side forms remain outside serialized Graph definition recovery via the existing `formDirty`/`executionDirty` persistence guards. This slice does not claim to preserve those separate owners' form state.
- Empty provider/model/shot selection can survive as author input; original explicit Save/preflight still reject incomplete requests. Read catalog presence is not provider/model verification or execution permission.
- Saved UNKNOWN PUT uses the existing explicit readback/adoption path and cannot blindly retry. Unsaved UNKNOWN create preserves exact request/payload for the original explicit same-key retry.
- Frontend source reads are observations, not a distributed transaction or execution certificate; original Save/preflight/run/review owners revalidate independently.

## Delivery and cleanup

`a8ac7dff-graph-bound-draft-recovery.bundle` is an incremental Git bundle verified by `git bundle verify`; it requires base788 and contains the verified named local branch. `a8ac7dff-graph-bound-draft-recovery.patch` is the corresponding full-index binary-safe one-commit patch. Do not apply both. `source-file-hashes.json` lists committed blob and working-file hashes (LF/CRLF differences are explicit). `review-handoff.json` contains machine-readable scope/results. `SHA256SUMS.json` covers all evidence files except itself.

Initial bundle export using a raw SHA range refused an empty bundle; no bundle was created. Corrected to the verified named branch with the exact base excluded, then verified successfully. Source commit was unchanged. This packaging error is retained in `bundle-export-initial-error.txt`.

Task-only Vite PID142860/port5332 was stopped after exact command/creation/PID verification; zero remaining5332 listeners. The first cleanup guard correctly stopped nothing because redundant parsing of an already-parsed DateTime discarded fractions; exact timestamp comparison corrected it, recorded in the stop evidence. Removed only explicit generated paths inside this isolated worktree, rejecting any reparse point:342 files /8,778,850 bytes. The existing `node_modules` junction and its shared target were untouched. Other project services/worktrees were untouched.

Repository AGENTS/UI skill/design-system constraints were followed. `graphflow_context` was not exposed by this executor, so no setup was changed and manual original source/matrix anchors were used. No agents were spawned.

Parent-progress interface limitation: one authorized `send_message_to_thread` to `01a13f51-1aa1-74a2-b55e-b37aad0580e4` returned **“Some requested entity was not found: thread not found”**; the progress message was not sent. This is a reporting-route failure, not a code, approval or execution blocker. No retry/background dispatch is pending. This final response automatically notifies the parent and includes the actual delivery inline rather than relying only on this disk report.
