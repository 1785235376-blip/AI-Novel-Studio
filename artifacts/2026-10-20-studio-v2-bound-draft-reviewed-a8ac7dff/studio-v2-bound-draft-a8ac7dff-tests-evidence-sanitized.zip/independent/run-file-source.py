from pathlib import Path
import json
import os
import subprocess
import sys

sys.stdout.reconfigure(encoding='utf-8')
evidence = Path(__file__).parent
author = evidence.parent.parent / 'task/studio-v2-graph-bound-draft-recovery'
target = 'a8ac7dff36c94e3b58d2edc7116708ef4e42f742'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=author, text=True).strip() == target
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=author).strip()
profile = evidence / 'runtime/profile'
env = {k: v for k, v in os.environ.items() if not k.endswith(('_API_KEY', '_TOKEN', '_SECRET')) and k not in {'DATABASE_URL', 'TEST_POSTGRES_DATABASE_URL', 'E2E_DATABASE_URL', 'COLLABORATION_DEV_SESSIONS_JSON', 'PACKAGED_CONTROL_PIPE'}}
env.update(PROJECT_ROOT=str(author), PYTHONPATH=os.pathsep.join([str(author), str(author / 'tests')]), NOVEL_DATA_PATH=str(profile / 'data'),
    LOCALAPPDATA=str(profile / 'Local'), APPDATA=str(profile / 'Roaming'), USERPROFILE=str(profile / 'user'),
    XDG_DATA_HOME=str(profile / 'xdg-data'), XDG_CONFIG_HOME=str(profile / 'xdg-config'), XDG_CACHE_HOME=str(profile / 'xdg-cache'),
    CREDENTIAL_VAULT_BACKEND='memory', STORAGE_BACKEND='file', PYTHONDONTWRITEBYTECODE='1', PYTHONUTF8='1', PYTHONIOENCODING='utf-8',
    ENABLE_PACKAGED_RUNTIME='false', ENABLE_COLLABORATION_RUNTIME='false', MOCK_PROVIDER='true', ENABLE_CLOUD='false',
    EXPERIMENTAL_FEATURES='narrative_production_v2,asset_lineage_v2', HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
command = [sys.executable, str(evidence / 'file-source.py')]
result = subprocess.run(command, cwd=author, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(evidence / 'file-source.log').write_bytes(result.stdout)
(evidence / 'file-source-command.json').write_text(json.dumps({'command': command, 'cwd': str(author), 'target': target, 'exit_code': result.returncode, 'scope': 'original File owner; no real Host session or credentials'}, indent=2), encoding='utf-8')
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=author).strip()
print(result.stdout.decode('utf-8', 'replace'))
sys.exit(result.returncode)
