from pathlib import Path
from uuid import uuid4
import json

from app.config import Settings
from app.repositories.factory import create_repository_bundle
from app.services import NovelService, ChapterService
from app.creative.graph import CreativeGraphService
from test_v2_independent_workspace import services
from test_v2_local_subgraph import child_definition, parent_definition

evidence = Path(__file__).parent
root = evidence / 'runtime/file-source'
root.mkdir(parents=True, exist_ok=True)
bundle = create_repository_bundle(Settings(storage_backend='file', database_url='', novel_data=root, enable_cloud=False, mock_provider=True), data_root=root)
novels, chapters = NovelService(bundle.novels, bundle.chapters), ChapterService(bundle.chapters)
nid = novels.create({'id': 'bound-review-' + uuid4().hex, 'title': 'Independent source review'})['id']
scope, actor = {'mode': 'local', 'novel_id': nid}, 'independent-source-reviewer'
workspace = services(root, 'file', '', novels, chapters)
workspace.activate(nid, scope, actor)
graph = CreativeGraphService(workspace.store, workspace)
catalog = graph.catalog(nid, scope, actor, include_local_subgraph=True)
child = graph.create(nid, scope, actor, {'request_id': uuid4().hex, 'definition': child_definition()})
parent = graph.create(nid, scope, actor, {'request_id': uuid4().hex, 'definition': parent_definition(child)})
fresh_workspace = services(root, 'file', '', novels, chapters)
fresh = CreativeGraphService(fresh_workspace.store, fresh_workspace)
reopened = fresh.get(nid, scope, actor, child['id'])
assert all(reopened[k] == child[k] for k in ['id', 'version', 'definition', 'definition_digest', 'execution_digest'])
class Revoked(PermissionError): pass
def denied(): raise Revoked('source read authority revoked')
try: fresh.get(nid, scope, actor, child['id'], denied)
except Revoked: pass
else: raise AssertionError('original source owner ignored read guard')
changed = fresh.save(nid, scope, actor, child['id'], {'expected_version': child['version'], 'definition': {**child['definition'], 'title': 'New child source revision'}})
assert changed['version'] == child['version'] + 1 and changed['definition_digest'] != child['definition_digest']
cached_pin = next(n for n in parent['definition']['nodes'] if n['definition_id'] == 'local_subgraph')['parameters']
assert cached_pin['expected_version'] == child['version'] and cached_pin['definition_digest'] == child['definition_digest']
assert chapters.list(nid) == []
owner = {'projectId': nid, 'incarnation': workspace.store.incarnation(nid), 'actorId': actor, 'actorWorkspaceId': '', 'mode': 'local', 'workspaceId': '', 'storylineId': '', 'branchId': ''}
(evidence / 'file-source.json').write_text(json.dumps({'owner': owner, 'catalog': catalog, 'child': child, 'parent': parent,
    'changed_child': changed, 'source_reopened': True, 'read_guard_denied': True, 'parent_pin_unchanged': True,
    'scope': 'real original File owner, no HTTP/Host or model execution'}, ensure_ascii=False, indent=2), encoding='utf-8')
print('Original File child saved/reopened; revoked read guard rejected; version/digest changed; parent pin retained; no chapters or execution.')
