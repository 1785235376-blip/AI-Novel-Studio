// @vitest-environment jsdom
import { act, cleanup, renderHook, waitFor } from '@testing-library/react';
import { afterEach, beforeAll, beforeEach, expect, it, vi } from 'vitest';
import { createStudioGraphClient, checkedStudioGraphDraft } from '../../../task/studio-v2-graph-bound-draft-recovery/frontend/src/creative/studioGraphClient';
import { readStudioGraphLocalDraft, checkedLocalGraphDefinition, studioGraphDraftKey } from '../../../task/studio-v2-graph-bound-draft-recovery/frontend/src/creative/studioGraphLocalDraft';
import { useStudioGraphEditorController } from '../../../task/studio-v2-graph-bound-draft-recovery/frontend/src/creative/useStudioGraphEditorController';
import { boundDefinition, boundCatalog, boundSaved } from '../../../task/studio-v2-graph-bound-draft-recovery/frontend/src/creative/graphBoundDraftRecovery.testFixtures';
import { buildConditionalStarter } from '../../../task/studio-v2-graph-bound-draft-recovery/frontend/src/creative/graphConditionContract';
import source from '../../bound-draft-recovery-independent-review-20261020/file-source.json';

const owner: any = source.owner, key = studioGraphDraftKey(owner), request = 'graph_' + 'd'.repeat(32);
const copy = <T,>(value: T): T => structuredClone(value);
let fileCatalog: any, fileChild: any, fileParent: any;
beforeAll(async () => {
  const transport: any = { json: async (url: string) => copy(url.includes('/catalog') ? source.catalog : url.endsWith('/' + source.parent.id) ? source.parent : source.child) };
  const client = createStudioGraphClient(owner.projectId, {} as any, transport);
  fileCatalog = await client.localSubgraphCatalog(); fileChild = await client.get(source.child.id); fileParent = await client.get(source.parent.id);
});
beforeEach(() => localStorage.clear()); afterEach(() => { cleanup(); localStorage.clear(); vi.restoreAllMocks(); });
const definition = (schema: 3 | 4 | 5 | 6) => schema === 6 ? copy(fileParent.definition) : boundDefinition(schema);
function snapshot(schema: 3 | 4 | 5 | 6): any { return { schema_version: 1, owner, request_id: request, saved_at: '2026-10-20T03:00:00Z', base: null, uncertain: false, definition: definition(schema) }; }
function seed(value: any) { const raw = JSON.stringify(value); localStorage.setItem(key, raw); return raw; }
function setup(schema: 3 | 4 | 5 | 6) {
  const graph: any = schema === 6 ? copy(fileParent) : { ...boundSaved(schema), project_id: owner.projectId, scope: { mode: 'local', novel_id: owner.projectId } };
  const assets = new Map<string, any>();
  for (const node of graph.definition.nodes) if (node.definition_id === 'asset_reference') assets.set(node.parameters.asset_id, {
    id: node.parameters.asset_id, novel_id: owner.projectId, branch_id: null, version: node.parameters.version, sha256: node.parameters.digest, kind: node.parameters.kind, deleted_at: null });
  const overview = () => ({ project: { id: owner.projectId, incarnation: owner.incarnation }, capabilities: { can_mutate: true } });
  const client: any = { overview: vi.fn(async () => overview()), asset: vi.fn(async (id: string) => copy(assets.get(id))), graphs: {
    catalog: vi.fn(async () => boundCatalog(3)), imageCatalog: vi.fn(async () => boundCatalog(4)), productionCatalog: vi.fn(async () => boundCatalog(4, true)),
    videoCatalog: vi.fn(async () => boundCatalog(5)), localSubgraphCatalog: vi.fn(async () => copy(fileCatalog)), list: vi.fn(async () => ({ items: [] })),
    get: vi.fn(async (id: string) => copy(id === fileChild.id ? fileChild : graph)), create: vi.fn(async (body: any) => ({ ...graph, id: 'review-created', version: 1, definition: checkedStudioGraphDraft(body.definition) })),
    save: vi.fn(), preflight: vi.fn(), createRun: vi.fn(), action: vi.fn(), runs: vi.fn(async () => ({ items: [] })) } };
  const props: any = { active: true, denied: false, identity: 'independent-bound-review', client, draftOwner: owner, canMutate: true, canReview: true,
    busy: false, externalDirty: false, isCurrent: () => true, read: (work: any) => work(), mutate: (work: any) => work() };
  return { graph, client, props, assets };
}
async function mount(props: any) { const hook = renderHook(value => useStudioGraphEditorController(value), { initialProps: props }); await waitFor(() => expect(hook.result.current.localRecovery).toBeTruthy()); return hook; }
function noExecution(client: any) { expect(client.graphs.preflight).not.toHaveBeenCalled(); expect(client.graphs.createRun).not.toHaveBeenCalled(); expect(client.graphs.action).not.toHaveBeenCalled(); }

it('group 1: restores schemas3-6 authoring and preserves empty model routes while strict Save still rejects before transport', async () => {
  for (const schema of [3, 4, 5, 6] as const) {
    localStorage.clear(); const value = snapshot(schema);
    if (schema !== 6) { const node = value.definition.nodes.find((n: any) => ['media_generate', 'image_generate', 'video_generate'].includes(n.definition_id)); node.parameters.provider_id = ''; node.parameters.model_id = ''; }
    const raw = seed(value), state = setup(schema), hook = await mount(state.props);
    await act(async () => hook.result.current.recoverLocalDraft());
    expect(hook.result.current.draft).toEqual(readStudioGraphLocalDraft(raw, owner).definition);
    expect(state.client.overview).toHaveBeenCalledTimes(2); expect(state.client.graphs.create).not.toHaveBeenCalled(); expect(state.client.graphs.save).not.toHaveBeenCalled(); noExecution(state.client);
    if (schema !== 6) {
      const node = hook.result.current.draft.nodes.find(n => ['media_generate', 'image_generate', 'video_generate'].includes(n.definition_id))!;
      expect(node.parameters.provider_id).toBe(''); expect(node.parameters.model_id).toBe('');
      const json = vi.fn(), strict = createStudioGraphClient(owner.projectId, {} as any, { json } as any);
      await expect(Promise.resolve().then(() => strict.create({ request_id: request, expected_version: 0, definition: hook.result.current.draft }))).rejects.toThrow(); expect(json).not.toHaveBeenCalled();
    } else expect(state.client.graphs.get.mock.calls.filter(([id]: any[]) => id === fileChild.id)).toHaveLength(2);
    hook.unmount();
  }
});

it('group 2: stale deleted denied and second-read-changed asset sources refuse adoption without losing author cache', async () => {
  for (const failure of ['stale', 'deleted', 'denied', 'late-change']) {
    localStorage.clear(); const value = snapshot(4), raw = seed(value), state = setup(4), asset = copy(state.assets.get('source'));
    if (failure === 'stale') asset.version++;
    if (failure === 'deleted') asset.deleted_at = '2026-10-20T03:00:00Z';
    if (failure === 'denied') state.client.asset.mockRejectedValue(new Error('SOURCE_READ_DENIED'));
    else if (failure === 'late-change') state.client.asset.mockResolvedValueOnce(copy(asset)).mockResolvedValueOnce({ ...asset, sha256: '0'.repeat(64) });
    else state.client.asset.mockResolvedValue(asset);
    const hook = await mount(state.props); await act(async () => hook.result.current.recoverLocalDraft());
    expect(hook.result.current.draft.schema_version).toBe(1); expect(hook.result.current.recoveryError).toBeTruthy(); expect(localStorage.getItem(key)).toBe(raw);
    expect(state.client.graphs.create).not.toHaveBeenCalled(); expect(state.client.graphs.save).not.toHaveBeenCalled(); noExecution(state.client); hook.unmount();
  }
});

it('group 3: File child pins interface permissions and UNKNOWN keep exact source and original request boundaries', async () => {
  expect(source.source_reopened && source.read_guard_denied && source.parent_pin_unchanged).toBe(true);
  for (const failure of ['real-version', 'definition_digest', 'execution_digest', 'interface', 'can_edit']) {
    localStorage.clear(); const value = snapshot(6), raw = seed(value), state = setup(6), changed: any = copy(failure === 'real-version' ? source.changed_child : fileChild);
    if (failure.endsWith('_digest')) changed[failure] = '0'.repeat(64);
    if (failure === 'can_edit') changed.can_edit = false;
    if (failure === 'interface') { const old = changed.definition.nodes[0].id; changed.definition.nodes[0].id = 'changed-entry'; changed.definition.edges.forEach((e: any) => { if (e.source_node_id === old) e.source_node_id = 'changed-entry'; }); }
    state.client.graphs.get.mockImplementation(async (id: string) => copy(id === fileChild.id ? changed : state.graph));
    const hook = await mount(state.props); await act(async () => hook.result.current.recoverLocalDraft());
    expect(hook.result.current.draft.schema_version).toBe(1); expect(hook.result.current.recoveryError).toBeTruthy(); expect(localStorage.getItem(key)).toBe(raw); expect(state.client.graphs.save).not.toHaveBeenCalled(); hook.unmount();
  }
  for (const saved of [true, false]) {
    localStorage.clear(); const value = snapshot(6), state = setup(6); value.uncertain = true;
    if (saved) value.base = { id: state.graph.id, version: state.graph.version, definition_digest: state.graph.definition_digest, execution_digest: state.graph.execution_digest };
    const raw = seed(value), hook = await mount(state.props); await act(async () => hook.result.current.recoverLocalDraft()); expect(hook.result.current.blocked).toBe(true);
    await act(async () => hook.result.current.save()); expect(state.client.graphs.create).not.toHaveBeenCalled(); expect(state.client.graphs.save).not.toHaveBeenCalled();
    await act(async () => hook.result.current.save(true)); expect(state.client.graphs.save).not.toHaveBeenCalled();
    if (saved) { expect(state.client.graphs.create).not.toHaveBeenCalled(); state.client.graphs.get.mockClear(); await act(async () => hook.result.current.checkServer()); expect(state.client.graphs.get.mock.calls[0][0]).toBe(state.graph.id); expect(typeof state.client.graphs.get.mock.calls[0][1].aborted).toBe('boolean'); }
    else { expect(state.client.graphs.create).toHaveBeenCalledTimes(1); expect(state.client.graphs.create).toHaveBeenCalledWith({ request_id: request, expected_version: 0, definition: readStudioGraphLocalDraft(raw, owner).definition }); }
    noExecution(state.client); hook.unmount();
  }
});

it('group 4: stale callback ABA and duplicate recovery cannot adopt twice; legacy schemas remain decodable', async () => {
  const raw = seed(snapshot(6)), state = setup(6), hook = await mount(state.props), retired = hook.result.current.recoverLocalDraft;
  hook.rerender({ ...state.props, canMutate: false }); hook.rerender(state.props);
  await act(async () => retired()); expect(state.client.overview).not.toHaveBeenCalled();
  let resolve!: (value: any) => void; state.client.graphs.localSubgraphCatalog.mockImplementationOnce(() => new Promise(done => { resolve = done; }));
  let first!: Promise<void>, second!: Promise<void>;
  act(() => { const recover = hook.result.current.recoverLocalDraft; first = recover(); second = recover(); });
  await waitFor(() => expect(resolve).toBeTypeOf('function')); expect(state.client.graphs.localSubgraphCatalog).toHaveBeenCalledTimes(1);
  hook.rerender({ ...state.props, busy: true }); hook.rerender(state.props);
  await act(async () => { resolve(copy(fileCatalog)); await Promise.all([first, second]); });
  expect(hook.result.current.draft.schema_version).toBe(1); expect(localStorage.getItem(key)).toBe(raw);
  await act(async () => hook.result.current.recoverLocalDraft()); expect(hook.result.current.draft.schema_version).toBe(6);
  const reads = state.client.overview.mock.calls.length; await act(async () => hook.result.current.recoverLocalDraft()); expect(state.client.overview).toHaveBeenCalledTimes(reads);
  expect(state.client.graphs.create).not.toHaveBeenCalled(); noExecution(state.client); hook.unmount();
  for (const schema of [1, 2, 7] as const) {
    const value = snapshot(6); value.definition = schema === 7 ? buildConditionalStarter() : { ...copy(fileChild.definition), schema_version: schema };
    expect(readStudioGraphLocalDraft(JSON.stringify(value), owner).definition).toEqual(checkedLocalGraphDefinition(value.definition));
  }
});
