from pathlib import Path
import os,subprocess,json
root=Path.cwd();out=root.parent/'graph-condition-draft-recovery-evidence-20261020';env=os.environ.copy()
for key in list(env):
 if key.endswith(('_API_KEY','_TOKEN','_SECRET')) or key in {'DATABASE_URL','TEST_POSTGRES_DATABASE_URL','COLLABORATION_DEV_SESSIONS_JSON','PACKAGED_CONTROL_PIPE'}:env.pop(key,None)
node_temp=root/'.runtime/node-temp';node_temp.mkdir(exist_ok=True);env.update(TEMP=str(node_temp),TMP=str(node_temp),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
args=[r'C:\Program Files\nodejs\node.exe','node_modules/vite/bin/vite.js','--host','127.0.0.1','--port','5330','--strictPort']
with (out/'ui-server.stdout.log').open('wb')as stdout,(out/'ui-server.stderr.log').open('wb')as stderr:p=subprocess.Popen(args,cwd=root/'frontend',env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
(out/'ui-server.json').write_text(json.dumps({'pid':p.pid,'args':args,'cwd':str(root/'frontend'),'purpose':'task-owned fixed fixture UI tests; no Host credentials or model calls'},indent=2),encoding='utf-8');print('task UI PID',p.pid)
