# GRAPH-08 — schema7 作者草稿恢复

已完成并冻结独立本地切片。默认条件门禁保持 OFF，不推送。

- 基线：`b3e5c546da946bb3557cc1122f7ecd0808f57223`
- 提交：`d58ef8a97bdfe3bc1380ef5eceb929f6b66e4b99`；tree `6529c151e986a4156c808f600099b8b4f057b2d4`
- 分支：`work/v2-graph-condition-draft-recovery-b3e-20261020`
- 工作区：`<TASK_ROOT>\task\studio-v2-graph-condition-draft-recovery`；Git 干净。

## 实际缺口、出处与边界

最新矩阵 `AI_NOVEL_STUDIO_V2_FEATURE_MATRIX.md` 的 **GRAPH-08 §7.2** 要求图版本、本机草稿与刷新/断连恢复。历史行仍为 PARTIAL；`CURRENT_EXECUTION_STATE.md` 也只记载 schema1/2 恢复。实际 b3e5c546 源码的 `studioGraphLocalDraft.ts` 拒绝所有 schema >2，原恢复控制器同样只接受 <=2，且不为条件图读取门禁目录。因此原 schema7 画布未保存的文本与条件值不能跨刷新保留。

先加入两项定向复现，实际均失败（解码拒绝、localStorage 始终为空）。修复只涉及原 Graph 草稿解码、恢复控制器和恢复面板，另加一个测试文件和一个需求说明，共 **5 文件，176 insertions / 17 deletions**。没有重做执行器、运行恢复或执行缓存；NLE、Timeline、DSH 六组件、DS 原语/样式和后端 owners 未修改。归档条件画布源码未编辑。

## 最终行为

原 schema1/2 流程保留。schema7 通过已有严格类型/拓扑解码保留作者输入、有限布尔/A-B 条件、位置、原请求 ID 和 UNKNOWN 状态；schemas3–6、外部绑定与非法结构仍拒绝。

刷新只显示待恢复作者草稿与只读条件预览；**必须明确恢复**。恢复前后重新读取原 overview 校验项目 incarnation / 编辑权限，并读取原受条件门禁保护的 catalog。已保存图还要求原 schema7 ID、版本、definition/execution 双摘要和编辑权限完全一致，不升级旧图。晚到结果、旧回调、权限/忙碌 ABA、重复恢复和其他页面更新均不覆盖输入。恢复只应用本机作者草稿；没有服务端 Save、预检、运行、人审或模型调用。下一次明确 Save 继续使用原 CAS、容量、历史和原请求/UNKNOWN 恢复路径。

## 已执行检查

| 检查 | 实际结果 | 原始证据 |
|---|---|---|
| RED 复现 | 2 failed；1 因 -t 过滤 | recovery-reproduction-red.log |
| 第一轮新链路 + 旧恢复 | 27 passed | recovery-first-green.log |
| 最终定向恢复、便笺、原条件入口 | **45 passed / 5 files**，其中 17 个新条件恢复案例 | recovery-guards-final.log |
| TypeScript | **1 次，exit 0** | typescript-final.log / -command.json |
| 生产构建 | **1 次，exit 0，5.05s** | production-build-final.log / -command.json |
| 设计令牌 | PASS | design-tokens-final.log |
| 三宽度恢复面板 | **3 passed**，1366×768 / 1440×900 / 1920×1080 | recovery-browser-first.log / recovery-browser.junit.xml |

浏览器确实通过本机缓存编辑 → reload → 只读条件/文本检查 → 门禁拒绝 → 明确再次恢复，核对原 request_id 不变且无写入/执行调用。目录取自已验收 File/API 捕获，传输与门禁切换为模拟，**不是 live Host 或完整 E2E**。页面无横向溢出，原 inspector 340px；已人工查看截图并对照原 NOVEL 参考。由于未改变共用 shell/样式，本次不重复整套跨模块验收。构建保留 Vite >500kB chunk 提示，未拆分模块或更改构建配置。

没有弱化旧测试；本轮除预期 RED 外没有其他失败。未重复全量测试或旧 File/API 大套件。

## 未运行与父任务协调

**NOT_RUN**：真实合法 Host 的刷新恢复 → 明确原 Save 验收，以及 PostgreSQL 同路径验收。本切片未验证/使用 live Host 或激活 PG 测试目标；未创建凭据、绕过授权或发起不确定真实写入。没有动作被授权系统拒绝，也没有后台等待任务。可执行的本地代码切片已完成，剩余为上述真实环境验收。

没有 provider/GPU/模型执行、新付费 API、额度购买或系统/账户/密钥/计费修改。GraphFlow skill 已读取，但本会话仍无 `graphflow_context` 可调用工具；采用限定矩阵/源码入口手工核对，没有安装或伪造图谱结果。

## 交付与清理

- `d58ef8a9-local-slice.patch`：仅此独立本地提交。
- `requirement-source.json`：b3e5c546 的矩阵和原代码行。
- `review-handoff.json`、`source-file-hashes.json`、`sha256-manifest.json`：交接与实际字节校验。
- `recovery-browser-results/`：截图及组件读取/缓存证明；`recovery-component.tsx` 和 browser config/spec 保留复现。

本任务 5330 UI 服务（PID 124832）已在核对 PID、创建时间和完整命令后停止。仅清理已解析在新工作区内、无 reparse 的可复现 build/test 白名单，回收 338 个文件、8,728,179 字节；共享依赖 junction 目标未清理，旧源码、其他任务与用户服务保持。父任务可独立审核/整合此提交；本分支此后冻结，不推送、不合 main。
