from pathlib import Path
import subprocess,json,hashlib
from datetime import datetime,timezone
root=Path.cwd();out=root.parent/'graph-condition-draft-recovery-evidence-20261020';base='b3e5c546da946bb3557cc1122f7ecd0808f57223'
def git(*args):return subprocess.check_output(['git','-c','core.longpaths=true',*args],cwd=root)
head=git('rev-parse','HEAD').decode().strip();tree=git('rev-parse','HEAD^{tree}').decode().strip();branch=git('branch','--show-current').decode().strip();status=git('status','--porcelain=v1').decode();assert head=='d58ef8a97bdfe3bc1380ef5eceb929f6b66e4b99' and git('rev-parse','HEAD^').decode().strip()==base and not status
files=git('diff-tree','--no-commit-id','--name-only','-r','HEAD').decode().splitlines();assert len(files)==5 and all(p.startswith(('frontend/src/creative/','docs/graph_condition_draft_recovery.md'))for p in files)
(out/'d58ef8a9-local-slice.patch').write_bytes(git('format-patch','-1','--stdout','HEAD'))
anchors=[]
for p,phrase in [('AI_NOVEL_STUDIO_V2_FEATURE_MATRIX.md','| GRAPH-08'),('CURRENT_EXECUTION_STATE.md','schema 1/2 文本图本地恢复'),('frontend/src/creative/studioGraphLocalDraft.ts','definition.schema_version > 2'),('frontend/src/creative/useStudioGraphEditorController.ts','draft.schema_version <= 2')]:
 lines=git('show',base+':'+p).decode('utf-8').splitlines();matches=[{'line':i+1,'text':l}for i,l in enumerate(lines)if phrase in l];assert matches;anchors.append({'source_commit':base,'path':p,'matches':matches[:3]})
(out/'requirement-source.json').write_text(json.dumps(anchors,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
hashes=[{'path':p,'git_blob':git('rev-parse','HEAD:'+p).decode().strip(),'git_content_sha256':hashlib.sha256(git('show','HEAD:'+p)).hexdigest(),'worktree_bytes_sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()}for p in files]
(out/'source-file-hashes.json').write_text(json.dumps(hashes,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
cleanup=json.loads((out/'cleanup-manifest.json').read_text(encoding='utf-8-sig'));removed_bytes=sum(int(r['bytes']or 0)for r in cleanup);removed_files=sum(r['files']for r in cleanup);runtime=json.loads((out/'runtime-final.json').read_text(encoding='utf-8-sig'));assert runtime['listenerCount']==0 and runtime['dependencyJunctionPresent']
commands={p.name:json.loads(p.read_text(encoding='utf-8'))for p in out.glob('*-command.json')};assert commands['typescript-final-command.json']['exit']==0 and commands['production-build-final-command.json']['exit']==0 and commands['recovery-browser-first-command.json']['exit']==0
info={'status':'completed_local_bounded_slice_frozen','source':{'root':str(root),'base':base,'branch':branch,'commit':head,'tree':tree,'clean':True,'changed_files':files},'requirement':'GRAPH-08 §7.2 loss-resistant local graph drafts; prior code rejected schema7 so unsaved condition inputs/predicate disappeared on reload','implementation':'Extend the original authoring-only decoder, gated explicit recovery/controller and read-only predicate preview; retain request ID/UNKNOWN, owner/incarnation, exact saved pins, history/capacity, late/ABA and other-tab protections','bounds':{'default_gate_off':True,'backend_engine_unchanged':True,'runtime_cache_unchanged_and_disabled_for_schema7':True,'no_automatic_remote_save_execution_or_review':True,'schemas3_to_6_recovery_not_enabled':True,'NLE_Timeline_DSH_DS_owners_unchanged':True,'no_archive_source_edits':True,'no_push_main_tag_release':True},'tests':{'red_reproduction':{'failed':2,'filtered':1,'log':'recovery-reproduction-red.log'},'first_green':{'passed':27,'log':'recovery-first-green.log'},'final_targeted':{'passed':45,'files':5,'new_condition_recovery_cases':17,'log':'recovery-guards-final.log'},'typescript':{'runs':1,'exit':0,'log':'typescript-final.log'},'production_build':{'runs':1,'exit':0,'seconds':5.05,'log':'production-build-final.log'},'token_guard':{'exit':0,'log':'design-tokens-final.log'},'browser_component':{'passed':3,'widths':[1366,1440,1920],'mode':'actual localStorage authoring/reload with original recovery component/controller + captured File/API catalog and mocked transport; NOT live Host/full E2E','log':'recovery-browser-first.log'}},'remaining_acceptance_gaps':[{'action':'Real legitimate Host browser refresh/recover then explicit original Save','target':'schema7 Graph authoring draft on this isolated branch','status':'NOT_RUN; no denied/uncertain real write and no background pending task','reason':'No live Host session was verified/used in this slice; no credential creation or authorization bypass was attempted.'},{'action':'PostgreSQL acceptance','target':'same recovery/read/Save path against PG owner','status':'NOT_RUN','reason':'No PG target was activated; backend owners were unchanged.'}],'no_provider_GPU_models_or_new_paid_API':True,'cleanup':{'files':removed_files,'bytes':removed_bytes,'task_ui_pid':runtime['pid'],'task_ui_port':5330,'stopped':runtime['state'],'dependency_target_not_cleaned':True},'created_utc':datetime.now(timezone.utc).isoformat()}
(out/'review-handoff.json').write_text(json.dumps(info,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
report=f'''# GRAPH-08 — schema7 作者草稿恢复

已完成并冻结独立本地切片。默认条件门禁保持 OFF，不推送。

- 基线：`{base}`
- 提交：`{head}`；tree `{tree}`
- 分支：`{branch}`
- 工作区：`{root}`；Git 干净。

## 实际缺口、出处与边界

最新矩阵 `AI_NOVEL_STUDIO_V2_FEATURE_MATRIX.md` 的 **GRAPH-08 §7.2** 要求图版本、本机草稿与刷新/断连恢复。历史行仍为 PARTIAL；`CURRENT_EXECUTION_STATE.md` 也只记载 schema1/2 恢复。实际 b3e5c546 源码的 `studioGraphLocalDraft.ts` 拒绝所有 schema >2，原恢复控制器同样只接受 <=2，且不为条件图读取门禁目录。因此原 schema7 画布未保存的文本与条件值不能跨刷新保留。

先加入两项定向复现，实际均失败（解码拒绝、localStorage 始终为空）。修复只涉及原 Graph 草稿解码、恢复控制器和恢复面板，另加一个测试文件和一个需求说明，共 **5 文件，176 insertions / 17 deletions**。没有重做执行器、运行恢复或执行缓存；NLE、Timeline、DSH 六组件、DS 原语/样式和后端 owners 未修改。归档条件画布源码未编辑。

## 最终行为

原 schema1/2 流程保留。schema7 通过已有严格类型/拓扑解码保留作者输入、有限布尔/A-B 条件、位置、原请求 ID 和 UNKNOWN 状态；schemas3–6、外部绑定与非法结构仍拒绝。

刷新只显示待恢复作者草稿与只读条件预览；**必须明确恢复**。恢复前后重新读取原 overview 校验项目 incarnation / 编辑权限，并读取原受条件门禁保护的 catalog。已保存图还要求原 schema7 ID、版本、definition/execution 双摘要和编辑权限完全一致，不升级旧图。晚到结果、旧回调、权限/忙碌 ABA、重复恢复和其他页面更新均不覆盖输入。恢复只应用本机作者草稿；没有服务端 Save、预检、运行、人审或模型调用。下一次明确 Save 继续使用原 CAS、容量、历史和原请求/UNKNOWN 恢复路径。

## 已执行检查

| 检查 | 实际结果 | 原始证据 |
|---|---|---|
| RED 复现 | 2 failed；1 因 -t 过滤 | recovery-reproduction-red.log |
| 第一轮新链路 + 旧恢复 | 27 passed | recovery-first-green.log |
| 最终定向恢复、便笺、原条件入口 | **45 passed / 5 files**，其中 17 个新条件恢复案例 | recovery-guards-final.log |
| TypeScript | **1 次，exit 0** | typescript-final.log / -command.json |
| 生产构建 | **1 次，exit 0，5.05s** | production-build-final.log / -command.json |
| 设计令牌 | PASS | design-tokens-final.log |
| 三宽度恢复面板 | **3 passed**，1366×768 / 1440×900 / 1920×1080 | recovery-browser-first.log / recovery-browser.junit.xml |

浏览器确实通过本机缓存编辑 → reload → 只读条件/文本检查 → 门禁拒绝 → 明确再次恢复，核对原 request_id 不变且无写入/执行调用。目录取自已验收 File/API 捕获，传输与门禁切换为模拟，**不是 live Host 或完整 E2E**。页面无横向溢出，原 inspector 340px；已人工查看截图并对照原 NOVEL 参考。由于未改变共用 shell/样式，本次不重复整套跨模块验收。构建保留 Vite >500kB chunk 提示，未拆分模块或更改构建配置。

没有弱化旧测试；本轮除预期 RED 外没有其他失败。未重复全量测试或旧 File/API 大套件。

## 未运行与父任务协调

**NOT_RUN**：真实合法 Host 的刷新恢复 → 明确原 Save 验收，以及 PostgreSQL 同路径验收。本切片未验证/使用 live Host 或激活 PG 测试目标；未创建凭据、绕过授权或发起不确定真实写入。没有动作被授权系统拒绝，也没有后台等待任务。可执行的本地代码切片已完成，剩余为上述真实环境验收。

没有 provider/GPU/模型执行、新付费 API、额度购买或系统/账户/密钥/计费修改。GraphFlow skill 已读取，但本会话仍无 `graphflow_context` 可调用工具；采用限定矩阵/源码入口手工核对，没有安装或伪造图谱结果。

## 交付与清理

- `d58ef8a9-local-slice.patch`：仅此独立本地提交。
- `requirement-source.json`：b3e5c546 的矩阵和原代码行。
- `review-handoff.json`、`source-file-hashes.json`、`sha256-manifest.json`：交接与实际字节校验。
- `recovery-browser-results/`：截图及组件读取/缓存证明；`recovery-component.tsx` 和 browser config/spec 保留复现。

本任务 5330 UI 服务（PID {runtime['pid']}）已在核对 PID、创建时间和完整命令后停止。仅清理已解析在新工作区内、无 reparse 的可复现 build/test 白名单，回收 {removed_files} 个文件、{removed_bytes:,} 字节；共享依赖 junction 目标未清理，旧源码、其他任务与用户服务保持。父任务可独立审核/整合此提交；本分支此后冻结，不推送、不合 main。
'''
(out/'REPORT.md').write_text(report,encoding='utf-8')
manifest=[{'path':p.relative_to(out).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in sorted(out.rglob('*'))if p.is_file()and p.name!='sha256-manifest.json']
(out/'sha256-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');assert all(hashlib.sha256((out/r['path']).read_bytes()).hexdigest()==r['sha256']for r in manifest)
print(json.dumps({'commit':head,'base':base,'clean':True,'files_changed':len(files),'evidence_files_verified':len(manifest),'cleanup_files':removed_files,'cleanup_bytes':removed_bytes,'ui_listener_count':runtime['listenerCount']},ensure_ascii=False))
