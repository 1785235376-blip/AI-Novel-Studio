from pathlib import Path
import os,json,subprocess,sys
ROOT=Path(r'<TASK_ROOT>\task\studio-v2-graph-condition-draft-recovery');OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT));from scripts.run_v2_checks import isolated_environment
label,kind=sys.argv[1:3];assert label.replace('-','').isalnum();assert kind in {'python','node'}
env=os.environ.copy()
for key in list(env):
    if key.endswith(('_API_KEY','_TOKEN','_SECRET')) or key in {'DATABASE_URL','TEST_POSTGRES_DATABASE_URL','E2E_DATABASE_URL','COLLABORATION_DEV_SESSIONS_JSON','PACKAGED_CONTROL_PIPE'}:env.pop(key,None)
if kind=='python':env.update(isolated_environment(ROOT,ROOT/'.runtime/recovery-profile'))
else:
    temporary=ROOT/'.runtime/node-temp';temporary.mkdir(parents=True,exist_ok=True)
    env.update(TEMP=str(temporary),TMP=str(temporary),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
env.update(PYTHONIOENCODING='utf-8',CI='1',ENABLE_PROVIDER_FALLBACK='false')
args=[sys.executable if kind=='python' else r'C:\Program Files\nodejs\node.exe',*sys.argv[3:]]
cwd=ROOT if kind=='python' else ROOT/'frontend';assert not (OUT/(label+'.log')).exists()
with (OUT/(label+'.log')).open('wb')as log:r=subprocess.run(args,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
(OUT/(label+'-command.json')).write_text(json.dumps({'args':args,'cwd':str(cwd),'exit':r.returncode,'runs':1},indent=2)+'\n',encoding='utf-8')
print(label+' exit='+str(r.returncode));raise SystemExit(r.returncode)
