// @vitest-environment jsdom
import { act, cleanup, renderHook, waitFor } from '@testing-library/react';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { buildConditionalStarter } from '../../../task/studio-v2-graph-condition-draft-recovery/frontend/src/creative/graphConditionContract';
import { readStudioGraphLocalDraft, studioGraphDraftKey, graphDraftRecoverable } from '../../../task/studio-v2-graph-condition-draft-recovery/frontend/src/creative/studioGraphLocalDraft';
import { useStudioGraphEditorController } from '../../../task/studio-v2-graph-condition-draft-recovery/frontend/src/creative/useStudioGraphEditorController';
import { modelCatalog } from '../../../task/studio-v2-graph-condition-draft-recovery/frontend/src/creative/studioGraphModel.testFixtures';
import actual from '../../../task/studio-v2-graph-condition-draft-recovery/frontend/src/creative/fixtures/conditions.file-api.json';

const owner: any = { projectId: 'independent-condition-recovery', incarnation: 'file:review-original', actorId: 'review-author', actorWorkspaceId: '', mode: 'local', workspaceId: '', storylineId: '', branchId: '' };
const key = studioGraphDraftKey(owner), request = 'graph_' + 'c'.repeat(32);
const copy = <T,>(value: T): T => structuredClone(value);
const overview = () => ({ project: { id: owner.projectId, incarnation: owner.incarnation }, capabilities: { can_mutate: true } });
const record = () => ({ ...copy(actual.graph), project_id: owner.projectId, scope: { mode: 'local', novel_id: owner.projectId } });
const snapshot = (): any => ({ schema_version: 1, owner, saved_at: '2026-10-20T01:00:00Z', request_id: request, base: null, uncertain: false,
  definition: buildConditionalStarter('Independent schema7 author draft') });
function seed(value = snapshot()) { const raw = JSON.stringify(value); localStorage.setItem(key, raw); return raw; }
function setup() {
  const client: any = { overview: vi.fn(async () => overview()), graphs: {
    catalog: vi.fn(async () => modelCatalog(false)), list: vi.fn(async () => ({ items: [] })), conditionsCatalog: vi.fn(async () => copy(actual.catalog)),
    conditionsList: vi.fn(async () => ({ items: [] })), get: vi.fn(async () => record()),
    create: vi.fn(async (body: any) => ({ ...record(), id: 'review-created', version: 1, definition: body.definition })),
    save: vi.fn(async (_id: string, body: any) => ({ ...record(), version: 3, definition: body.definition })),
    createRun: vi.fn(), preflight: vi.fn(), action: vi.fn(), runs: vi.fn(async () => ({ items: [] })) } };
  const props: any = { active: true, denied: false, identity: 'independent-recovery-author', client, draftOwner: owner, canMutate: true,
    canReview: true, busy: false, externalDirty: false, isCurrent: () => true, read: (work: any) => work(), mutate: (work: any) => work() };
  return { client, props };
}
beforeEach(() => localStorage.clear());
afterEach(() => { cleanup(); localStorage.clear(); vi.restoreAllMocks(); });

it('persists actual author edits through the original localStorage owner, then restores only on explicit action', async () => {
  const { client, props } = setup();
  const first = renderHook(value => useStudioGraphEditorController(value), { initialProps: props });
  await waitFor(() => expect(first.result.current.catalog).toBeTruthy());
  await act(async () => first.result.current.loadConditions()); act(() => first.result.current.createConditions());
  act(() => first.result.current.updateCondition({ kind: 'enum', value: 'B', equals: 'A' }));
  act(() => first.result.current.change({ ...first.result.current.draft, title: 'Unsaved schema7 review draft',
    nodes: first.result.current.draft.nodes.map(node => node.id === 'input' ? { ...node, parameters: { text: '\ufeff作者文本\nsecond line' } } : node) }));
  await waitFor(() => expect(JSON.parse(localStorage.getItem(key) || '{}').definition?.title).toBe('Unsaved schema7 review draft'));
  const cached = readStudioGraphLocalDraft(localStorage.getItem(key)!, owner); first.unmount();
  const reload = renderHook(value => useStudioGraphEditorController(value), { initialProps: props });
  await waitFor(() => expect(reload.result.current.localRecovery).toBeTruthy());
  expect(reload.result.current.draft.schema_version).toBe(1); expect(client.graphs.create).not.toHaveBeenCalled();
  await act(async () => reload.result.current.recoverLocalDraft());
  expect(reload.result.current.draft).toEqual(cached.definition);
  expect(client.overview).toHaveBeenCalledTimes(2);
  expect(client.graphs.create).not.toHaveBeenCalled(); expect(client.graphs.save).not.toHaveBeenCalled();
  await act(async () => reload.result.current.save());
  expect(client.graphs.create).toHaveBeenCalledTimes(1);
  expect(client.graphs.create).toHaveBeenCalledWith({ request_id: cached.request_id, expected_version: 0, definition: cached.definition });
  expect(client.graphs.preflight).not.toHaveBeenCalled(); expect(client.graphs.createRun).not.toHaveBeenCalled(); expect(client.graphs.action).not.toHaveBeenCalled();
});

it('rejects disabled gate, replaced incarnation and mismatched saved version or either digest without consuming the cache', async () => {
  for (const failure of ['gate', 'incarnation', 'version', 'definition_digest', 'execution_digest']) {
    localStorage.clear(); const value = snapshot(), saved = record();
    if (!['gate', 'incarnation'].includes(failure)) value.base = { id: saved.id, version: saved.version, definition_digest: saved.definition_digest, execution_digest: saved.execution_digest };
    const raw = seed(value), { client, props } = setup();
    if (failure === 'gate') client.graphs.conditionsCatalog.mockRejectedValue(new Error('CREATIVE_GRAPH_CONDITIONS_DISABLED'));
    else if (failure === 'incarnation') client.overview.mockResolvedValueOnce(overview()).mockResolvedValueOnce({ ...overview(), project: { ...overview().project, incarnation: 'file:replacement' } });
    else { const changed: any = record(); if (failure === 'version') changed.version++; else changed[failure] = '0'.repeat(64); client.graphs.get.mockResolvedValue(changed); }
    const hook = renderHook(current => useStudioGraphEditorController(current), { initialProps: props });
    await waitFor(() => expect(hook.result.current.localRecovery).toBeTruthy()); await act(async () => hook.result.current.recoverLocalDraft());
    expect(hook.result.current.recoveryError).toBeTruthy(); expect(hook.result.current.draft.schema_version).toBe(1);
    expect(localStorage.getItem(key)).toBe(raw); expect(client.graphs.create).not.toHaveBeenCalled(); expect(client.graphs.save).not.toHaveBeenCalled(); hook.unmount();
  }
  const raw = JSON.stringify(snapshot());
  expect(() => readStudioGraphLocalDraft(raw, { ...owner, actorId: 'other-author' })).toThrow();
  expect(() => readStudioGraphLocalDraft(raw, { ...owner, incarnation: 'file:different' })).toThrow();
});

it('retires recovery callbacks and late replies after ABA while UNKNOWN permits only explicit original-request reconciliation', async () => {
  const value = snapshot(); value.uncertain = true; value.definition.nodes[1].parameters.predicate = { kind: 'boolean', value: false };
  const raw = seed(value), { client, props } = setup();
  const hook = renderHook(current => useStudioGraphEditorController(current), { initialProps: props });
  await waitFor(() => expect(hook.result.current.localRecovery).toBeTruthy());
  const retired = hook.result.current.recoverLocalDraft;
  hook.rerender({ ...props, canMutate: false }); hook.rerender(props);
  await act(async () => retired()); expect(client.overview).not.toHaveBeenCalled();
  let resolve!: (value: any) => void;
  client.graphs.conditionsCatalog.mockImplementationOnce(() => new Promise(done => { resolve = done; }));
  let pending!: Promise<void>; act(() => { pending = hook.result.current.recoverLocalDraft(); });
  await waitFor(() => expect(resolve).toBeTypeOf('function'));
  hook.rerender({ ...props, busy: true }); hook.rerender(props);
  await act(async () => { resolve(copy(actual.catalog)); await pending; });
  expect(hook.result.current.draft.schema_version).toBe(1); expect(localStorage.getItem(key)).toBe(raw); expect(client.graphs.create).not.toHaveBeenCalled();
  await act(async () => hook.result.current.recoverLocalDraft()); expect(hook.result.current.blocked).toBe(true);
  await act(async () => hook.result.current.save()); expect(client.graphs.create).not.toHaveBeenCalled();
  await act(async () => hook.result.current.save(true));
  expect(client.graphs.create).toHaveBeenCalledTimes(1);
  expect(client.graphs.create).toHaveBeenCalledWith({ request_id: request, expected_version: 0, definition: value.definition });
  expect(client.graphs.createRun).not.toHaveBeenCalled(); expect(client.graphs.action).not.toHaveBeenCalled();
});

it('preserves schema1 and schema2 original recovery without consulting the condition gate', async () => {
  for (const schema of [1, 2] as const) {
    localStorage.clear(); const value = snapshot(), starter = buildConditionalStarter();
    value.definition = { ...starter, schema_version: schema, title: 'Legacy local recovery', nodes: starter.nodes.filter(node => ['input', 'yes', 'yes_review'].includes(node.id)),
      edges: [{ id: 'source', source_node_id: 'input', source_port: 'text', target_node_id: 'yes', target_port: 'text' },
        { id: 'review', source_node_id: 'yes', source_port: 'draft', target_node_id: 'yes_review', target_port: 'draft' }] };
    seed(value); expect(readStudioGraphLocalDraft(JSON.stringify(value), owner).definition.schema_version).toBe(schema);
    const { client, props } = setup(); client.graphs.conditionsCatalog.mockRejectedValue(new Error('CREATIVE_GRAPH_CONDITIONS_DISABLED'));
    const hook = renderHook(current => useStudioGraphEditorController(current), { initialProps: props });
    await waitFor(() => expect(hook.result.current.localRecovery).toBeTruthy()); await act(async () => hook.result.current.recoverLocalDraft());
    expect(hook.result.current.draft.schema_version).toBe(schema); expect(client.graphs.conditionsCatalog).not.toHaveBeenCalled();
    expect(client.graphs.create).not.toHaveBeenCalled(); expect(client.graphs.save).not.toHaveBeenCalled(); hook.unmount();
  }
  for (const schema of [3, 4, 5, 6]) expect(graphDraftRecoverable({ ...buildConditionalStarter(), schema_version: schema } as any)).toBe(false);
});
