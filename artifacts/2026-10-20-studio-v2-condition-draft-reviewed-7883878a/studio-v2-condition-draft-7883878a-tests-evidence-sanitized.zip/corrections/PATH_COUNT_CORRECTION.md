# Linked trim restore path-count correction

Recorded UTC: 2026-10-20T01:49:39.059118+00:00

Product: `503e4a207de487eb8d6879790713c29f805a71ca`; base: `b3e5c546da946bb3557cc1122f7ecd0808f57223`.
Archive: `28ff2fdbea9cb9b64040aa24dbce284f3b146a81`; artifact directory: `artifacts/2026-10-20-studio-v2-linked-trim-reviewed-503e4a20`.

The retained original `local-restore-proof.json` contains a metadata typo: `paths: 10`. The correct count is **11 changed paths**. This correction changes no product, test result, published bytes, hashes, commit or historical record. The original file is preserved unchanged.

Evidence:
- `git diff --name-only b3e5c546da946bb3557cc1122f7ecd0808f57223 503e4a207de487eb8d6879790713c29f805a71ca` returns the 11 paths listed below.
- Published `MANIFEST.json` has 11 `file_mapping` entries, exactly matching that Git diff: https://github.com/1785235376-blip/AI-Novel-Studio/blob/28ff2fdbea9cb9b64040aa24dbce284f3b146a81/artifacts/2026-10-20-studio-v2-linked-trim-reviewed-503e4a20/MANIFEST.json
- `linked-trim-combined-evidence/public-restore-proof.json` records `paths: 11` and `status: PASS` after direct public restore.

Evidence file snapshots (SHA256; originals retained):
- `local-restore-proof.json`: `b59aade32b8d4dde2eda89ff83bd01c502d1d3ba56a21c2585e75a1442a6f6d4` (648 bytes)
- `MANIFEST.json`: `ab0c4ea50055628b0d20341e7ebdc20a67f46e02ff65a57ddd14172db1bc2556` (12659 bytes)
- `public-restore-proof.json`: `62aa1da33a7be9aaffa31bcc2ee57c2df0f807af273690620661f0b07aab3efa` (452 bytes)

Exact changed paths:
- `app/services/studio_timeline_edit.py`
- `app/services/studio_timeline_links.py`
- `docs/TIMELINE_LINKED_TRIM_HANDOFF.md`
- `frontend/src/creative/StudioTimelineEditor.tsx`
- `frontend/src/creative/StudioTimelineLinkedTrim.additive.test.tsx`
- `frontend/src/creative/studioTimelineClipLinks.ts`
- `frontend/src/creative/studioTimelineLinkedSplit.ts`
- `frontend/src/creative/studioTimelineLinkedTrim.ts`
- `frontend/src/creative/useStudioTimelineEditor.ts`
- `frontend/src/nle/LinkedClipTrimPanel.tsx`
- `tests/test_timeline_linked_trim_additive.py`

No tests/build rerun, package rebuild or push was performed for this correction. Retain this standalone note for inclusion with the next archive batch.
