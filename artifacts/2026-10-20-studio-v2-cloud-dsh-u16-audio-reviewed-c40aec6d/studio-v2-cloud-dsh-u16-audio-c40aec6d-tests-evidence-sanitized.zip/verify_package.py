"""Verify an incremental DSH archive against a restored product Git database."""
import argparse, hashlib, json, pathlib, struct, subprocess, zipfile
p=argparse.ArgumentParser();p.add_argument('artifact');p.add_argument('repository');a=p.parse_args()
root=pathlib.Path(a.artifact).resolve();repo=pathlib.Path(a.repository).resolve()
def git(*args):return subprocess.check_output(['git','-C',str(repo),*args])
def text(*args):return git(*args).decode().strip()
def sha(b):return hashlib.sha256(b).hexdigest()
def blob_at(commit,path):return git('show',commit+':'+path)
for line in (root/'SHA256SUMS').read_text().splitlines():
 h,name=line.split(None,1);name=name.lstrip('*');assert pathlib.PurePosixPath(name).name==name;assert sha((root/name).read_bytes())==h,name
m=json.loads((root/'MANIFEST.json').read_text());tip=m['product_tip'];base=m['product_base']
assert text('rev-parse',tip+'^{tree}')==m['product_tree']
assert int(text('rev-list','--count',tip,'^'+base))==m['bundle_commit_count']
assert subprocess.run(['git','-C',str(repo),'merge-base','--is-ancestor',base,tip]).returncode==0
for o in m['new_object_inventory']:
 typ=text('cat-file','-t',o['oid']);data=git('cat-file',typ,o['oid'])
 assert typ==o['type'] and len(data)==o['bytes'] and sha(data)==o['sha256'],o['oid']
 assert hashlib.sha1(typ.encode()+b' '+str(len(data)).encode()+b'\0'+data).hexdigest()==o['oid']
expected={o['oid'] for o in m['new_object_inventory']};actual={line.split()[0] for line in text('rev-list','--objects',tip,'^'+base).splitlines()};assert expected==actual
for f in m['file_mapping']:
 line=text('ls-tree',tip,'--',f['path']);meta,path=line.split('\t');mode,typ,oid=meta.split();data=git('cat-file','blob',oid)
 assert path==f['path'] and mode==f['mode'] and oid==f['blob'] and len(data)==f['bytes'] and sha(data)==f['sha256'],path
files=set(text('diff','--name-only',base,tip).splitlines());assert files=={f['path'] for f in m['file_mapping']}
for payload in m['payload_hashes']:
 data=(root/payload['path']).read_bytes();assert len(data)==payload['bytes'] and sha(data)==payload['sha256']
bundle=(root/m['bundle_filename']).read_bytes();header,pack=bundle.split(b'\n\n',1)
prereqs=[x.split()[0][1:].decode() for x in header.splitlines() if x.startswith(b'-')];assert prereqs==[base]
assert pack[:4]==b'PACK';assert struct.unpack('>I',pack[8:12])[0]==len(expected)
bindings=json.loads(blob_at(tip,m['source_binding_path']));postimages=0
with zipfile.ZipFile(root/m['evidence_zip']) as z:
 idx=json.loads(z.read('evidence-index.json'));assert set(z.namelist())=={'evidence-index.json'}|{x['path'] for x in idx['files']}
 for x in idx['files']:
  data=z.read(x['path']);assert len(data)==x['bytes'] and sha(data)==x['sha256'],x['path']
 for f in m['file_mapping']:assert z.read('source/'+f['path'])==blob_at(tip,f['path'])
 for p in bindings['patches']:
  data=z.read('patches/'+p['patch']);assert len(data)==p['bytes'] and sha(data)==p['sha256'];assert data.startswith(('From '+p['source_commit']+' ').encode())
  assert subprocess.run(['git','-C',str(repo),'merge-base','--is-ancestor',p['integrated_commit'],tip]).returncode==0
  assert text('rev-parse',p['integrated_commit']+'^{tree}')==p['integrated_tree']
  for f in p['postimages']:
   oid=text('rev-parse',p['integrated_commit']+':'+f['path']);assert oid==f['verified_full_blob'] and oid.startswith(f['patch_postimage_prefix']);postimages+=1
 for path in bindings['preserved_cloud_files']:assert text('rev-parse',tip+':'+path)==text('rev-parse',base+':'+path)
 for path,f in bindings['corrective_sources'].items():
  assert text('rev-parse',tip+':'+path)==f['git_blob'];assert sha(blob_at(tip,path))==f['sha256']
 for path,h in bindings['evidence_sha256'].items():assert sha(blob_at(tip,path))==h
 r=json.loads(z.read('author/runner-receipts/cloud-dsh-final-file-api.json'));assert r['status']=='PASS' and r['exit_code']==0 and not r['sources_changed_during_check']
 assert r['source_sha256']==r['source_sha256_before'];assert len(r['source_sha256'])==bindings['validation_source_count']
 # Batch reads avoid invoking Git once per source path.
 q=subprocess.Popen(['git','-C',str(repo),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
 for path,h in r['source_sha256'].items():
  q.stdin.write((tip+':'+path+'\n').encode());q.stdin.flush();meta=q.stdout.readline().split();assert len(meta)==3 and meta[1]==b'blob',path
  data=q.stdout.read(int(meta[2]));assert q.stdout.read(1)==b'\n';assert sha(data)==h,path
 q.stdin.close();q.wait();assert q.returncode==0
 reviewer=json.loads(z.read('independent/receipt.json'));assert reviewer['head']==tip and reviewer['exit_code']==0 and not reviewer['git_status_before'] and not reviewer['git_status_after']
 # Original log hash is retained in evidence-index when local paths were normalized.
 logrec=next(x for x in idx['files'] if x['path']=='independent/checks.log');assert logrec['original_sha256']==reviewer['log_sha256']
 assert b'7 passed' in z.read('independent/checks.log')
assert postimages==29
fsck=subprocess.run(['git','-C',str(repo),'fsck','--strict','--no-dangling'],capture_output=True,text=True);assert fsck.returncode==0,fsck.stderr
print(json.dumps({'status':'PASS','product_tip':tip,'product_tree':m['product_tree'],'commits':m['bundle_commit_count'],'replayed_patch_commits':6,'original_commit_identity_proven':False,'per_patch_postimages':postimages,'preserved_prior_cloud_paths':len(bindings['preserved_cloud_files']),'final_test_source_hashes':len(r['source_sha256']),'file_mappings':len(m['file_mapping']),'new_objects':len(expected),'pack_objects':struct.unpack('>I',pack[8:12])[0],'payloads':len(m['payload_hashes']),'evidence_entries':len(idx['files'])+1,'fsck':'PASS'},indent=2))
