from pathlib import Path
import os
import subprocess
import sys
import json
import hashlib
root = Path('<CLOUD_WORKSPACE>/studio-cloud-dsh-integrated-20261020')
review = Path(__file__).resolve().parent
sys.path.insert(0, str(root))
from scripts.run_v2_checks import isolated_environment
before = subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True)
env = {k: v for k, v in os.environ.items() if not k.endswith(('_API_KEY','_TOKEN','_SECRET')) and k not in ('DATABASE_URL','TEST_POSTGRES_DATABASE_URL','E2E_DATABASE_URL','COLLABORATION_DEV_SESSIONS_JSON','PACKAGED_CONTROL_PIPE')}
env.update(isolated_environment(root, review / 'profile'))
env['PYTHONPATH'] = str(root) + ':' + str(root / 'tests')
command = [str(root.parent / 'studio-overnight/.venv/bin/python'), '-m', 'pytest', '-q', '-s', '-c', str(root / 'pyproject.toml'), str(review / 'test_independent_dsh.py'), '--basetemp', str(review / 'pytest-data'), '-p', 'no:cacheprovider', '--maxfail=1']
result = subprocess.run(command, cwd=root, env=env, capture_output=True, text=True)
log = result.stdout + result.stderr
(review / 'checks.log').write_text(log)
after = subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True)
receipt = {'head': subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(), 'command':command, 'exit_code':result.returncode, 'git_status_before':before, 'git_status_after':after, 'log_sha256':hashlib.sha256(log.encode()).hexdigest()}
(review / 'receipt.json').write_text(json.dumps(receipt,indent=2))
print(log)
print(json.dumps(receipt,indent=2))
sys.exit(result.returncode)
