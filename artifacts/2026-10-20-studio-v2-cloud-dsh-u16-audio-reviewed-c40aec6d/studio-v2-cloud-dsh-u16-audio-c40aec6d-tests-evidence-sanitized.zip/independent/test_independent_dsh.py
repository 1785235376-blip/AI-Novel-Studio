"""Independent adversarial File checks; all source/asset data is disposable."""
import base64
from copy import deepcopy
from threading import Event, Thread
from uuid import uuid4
import struct
import zlib

import pytest
from fastapi import HTTPException
from app.actor_context import SessionContext
from app.experimental.flags import FLAGS
from app.services.image_job_service import ImageJobService
from test_r3_mounted_contracts import mounted
from test_v2_independent_workspace_api import client

pytestmark = pytest.mark.parametrize('mounted', ['file'], indirect=True)

@pytest.fixture
def prefix(): return '/api'

def checked(response, status=200):
    assert response.status_code == status, response.text
    return response.json()

def post(e, suffix, body):
    return e.client.post(e.batch_base + suffix, headers=e.headers, json=body)

def read(e):
    rows = checked(e.client.get(e.batch_base, headers=e.headers))['items']
    return next(row for row in rows if row['id'] == e.review_batch_id)

def dispatch(e, row): return post(e, '/' + row['id'] + '/dispatch-next', {'expected_version': row['version']})

def ready(e, items):
    row = checked(post(e, '/preflight', {'items': items}))
    e.review_batch_id = row['id']
    return checked(post(e, '/' + row['id'] + '/confirm', {'expected_version': row['version'],
        'snapshot_digest': row['snapshot_digest'], 'budget_microusd': 0, 'confirmed': True}))

@pytest.fixture
def owned(client, monkeypatch):
    e = client
    monkeypatch.setenv('EXPERIMENTAL_FEATURES', ','.join([*FLAGS, 'narrative_production_v2']))
    e.host = 'independent-review-' + uuid4().hex
    e.session = SessionContext(e.host, e.host, 'independent-author', 'independent-workspace')
    e.sessions.register(e.host, e.session)
    e.headers = {'X-Session-Token': e.host}
    checked(e.client.post(e.studio_base + '/activate', headers=e.headers))
    def chunk(kind, payload):
        return struct.pack('>I', len(payload)) + kind + payload + struct.pack('>I', zlib.crc32(kind + payload))
    png = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', 64, 64, 8, 6, 0, 0, 0))
    png += chunk(b'IDAT', zlib.compress(b''.join(b'\x00' + bytes((y, 91, 203, 255))*64 for y in range(64)))) + chunk(b'IEND', b'')
    with e.studio._asset_scope(e.nid, e.scope):
        e.source = e.assets.create(e.nid, 'independent-owned.png', base64.b64encode(png).decode(),
            'image/png', 'image', 'independent-owned-source', required_features=('narrative_production_v2',))
    source = {'id': e.source['id'], 'version': e.source['version'], 'digest': e.source['sha256'], 'kind': 'ASSET', 'asset_kind': 'image'}
    e.items = []
    for index, bits in enumerate((bytes([170])*512, bytes([85])*512, bytes([240])*512)):
        mask = checked(e.client.post(e.studio_base + '/assets/' + e.source['id'] + '/mask', headers=e.headers,
            json={'contract': 'manual-binary-mask/1', 'source_version': 1, 'source_sha256': e.source['sha256'],
                  'width': 64, 'height': 64, 'bitplane_base64': base64.b64encode(bits).decode(),
                  'idempotency_key': 'independent-mask-' + str(index)}), 201)['asset']
        e.items.append({'kind': 'STUDIO_IMAGE', 'studio_image': {'image': deepcopy(source),
            'mask': {'id': mask['id'], 'version': mask['version'], 'digest': mask['sha256'], 'kind': 'ASSET', 'asset_kind': 'image'},
            'request_id': 'independent-cutout-' + str(index), 'license_note': 'synthetic owned review pixels'}})
    class NoExternal:
        def __getattr__(self, name): raise AssertionError('External model/provider access: ' + name)
    e.production = e.experimental.studio_production_service
    for name, value in (('workspace', e.studio), ('store', e.studio.store), ('image_jobs', ImageJobService(e.root)),
                        ('image_registry', NoExternal()), ('vault', NoExternal()), ('transport', NoExternal())):
        monkeypatch.setattr(e.production, name, value)
    e.batches = e.experimental.safe_batches_service
    e.batch_base = e.prefix + f'/novels/{e.nid}/experimental/safe-batches'
    e.base = e.studio_base + '/production'
    return e

@pytest.mark.parametrize('change', ['stop', 'revoke_aba'])
def test_scope_order_and_concurrent_cpu_checkpoint(owned, monkeypatch, change):
    e = owned
    row = ready(e, [e.items[0], {'kind': 'PROOF', 'chapter_ids': [e.chapter['id']]}])
    original_read = e.store.read
    reads_under_assets = []
    def ordered(nid, scope):
        if getattr(e.assets._scope, 'binding', None) is not None:
            assert e.store.key(nid, scope) in getattr(e.store._local, 'active', {}), 'Scope lock acquired after asset/project lock'
            reads_under_assets.append(True)
        return original_read(nid, scope)
    monkeypatch.setattr(e.store, 'read', ordered)
    import app.services.studio_image_cutout as pixels
    renderer = pixels.render_cutout
    checkpoint_calls = []
    stop_responses = []
    def render(*args, checkpoint, **kwargs):
        assert e.store.key(e.nid, e.scope) not in getattr(e.store._local, 'active', {})
        assert getattr(e.assets._scope, 'binding', None) is None
        complete = Event()
        errors = []
        def concurrent_change():
            try:
                if change == 'stop':
                    live = e.batches.get(e.nid, e.scope, e.batches.BATCHES, row['id'])
                    response = post(e, '/' + row['id'] + '/stop', {'expected_version': live['version']})
                    stop_responses.append(checked(response)['status'])
                else:
                    e.sessions.revoke(e.host)
                    e.sessions.register(e.host, e.session)
            except BaseException as error: errors.append(error)
            finally: complete.set()
        thread = Thread(target=concurrent_change, daemon=True)
        thread.start()
        assert complete.wait(5), 'Concurrent stop/revocation blocked while CPU owns a broad lease'
        thread.join(timeout=1)
        assert not errors, errors
        def observed():
            checkpoint_calls.append(True)
            assert e.store.key(e.nid, e.scope) not in getattr(e.store._local, 'active', {})
            checkpoint()
        return renderer(*args, checkpoint=observed, **kwargs)
    monkeypatch.setattr(pixels, 'render_cutout', render)
    response = dispatch(e, row)
    assert response.status_code in (401, 403, 404, 409, 422), response.text
    raw = e.batches.get(e.nid, e.scope, e.batches.BATCHES, row['id'])
    assert raw['status'] in ('CANCELLED', 'UNKNOWN')
    assert raw['items'][1]['attempts'] == 0
    assert len(list(e.assets.root.glob('*.bin'))) == 4
    assert reads_under_assets and checkpoint_calls
    if change == 'stop': assert stop_responses == ['CANCELLED']
    print('CHECKPOINT', change, 'scope-first reads', len(reads_under_assets), 'live pixel checkpoints', len(checkpoint_calls), 'candidate published: false')


def test_unknown_lost_ack_with_standalone_and_other_bound_job(owned, monkeypatch):
    e = owned
    from app.experimental.safe_batch_studio_image import StudioImageSelection
    command = StudioImageSelection.model_validate(e.items[2]['studio_image']).command().model_dump(exclude_none=True)
    command['request_id'] = 'independent-unrelated-standalone'
    captured = checked(e.client.post(e.base + '/preview', headers=e.headers, json=command))
    standalone = checked(e.client.post(e.base + '/jobs', headers=e.headers, json={'command': command,
        'reviewed_preview_digest': captured['preview_digest']}), 201)
    unrelated = checked(dispatch(e, ready(e, [e.items[1]])))
    row = ready(e, [e.items[0]])
    original_create = e.production.create
    created = []
    def lost(*args, **kwargs):
        created.append(original_create(*args, **kwargs))
        raise ValueError('INDEPENDENT_LOST_ACK_AFTER_CREATE')
    monkeypatch.setattr(e.production, 'create', lost)
    assert dispatch(e, row).status_code == 422
    unknown = read(e)
    assert unknown['id'] == row['id'] and unknown['status'] == 'UNKNOWN'
    assert not unknown['items'][0].get('image_job_id')
    original_job = e.batches.studio_image.job
    found = []
    def observed(*args, **kwargs):
        value = original_job(*args, **kwargs)
        if args[1]["id"] == row["id"]:
            found.append(value)
        return value
    monkeypatch.setattr(e.batches.studio_image, 'job', observed)
    for _ in range(2):
        current = read(e)
        assert post(e, '/' + row['id'] + '/reconcile', {'expected_version': current['version']}).status_code == 422
    assert [job['id'] for job in found] == [created[0]['id'], created[0]['id']]
    assert all(job['status'] == 'QUEUED' for job in found)
    for suffix in ('dispatch-next', 'retry-failed'):
        current = read(e)
        assert post(e, '/' + row['id'] + '/' + suffix, {'expected_version': current['version']}).status_code == 422
    assert len(created) == 1
    assert created[0]['id'] not in (standalone['id'], unrelated['items'][0]['image_job_id'])
    assert read(e)['status'] == 'UNKNOWN'
    print('RECOVERY: exact original QUEUED receipt found twice beside standalone and other bound job; one create; no resend')

@pytest.mark.parametrize('denial', ['404_middle', 'value_first', '403_middle', 'cancelled'])
def test_three_image_cached_results_are_cleared_before_refresh(owned, monkeypatch, denial):
    e = owned
    row = ready(e, [*e.items, {'kind': 'PROOF', 'chapter_ids': [e.chapter['id']]}])
    for _ in range(3): row = checked(dispatch(e, row))
    ids = [item['image_job_id'] for item in row['items'][:3]]
    assert all(item.get('image_result') for item in row['items'][:3])
    if denial == 'cancelled':
        row = checked(post(e, '/' + row['id'] + '/stop', {'expected_version': row['version']}))
    original_get = e.production.get
    seen = []
    def denied(*args, **kwargs):
        jid = args[4]
        if jid in ids:
            seen.append(jid)
            if denial == 'cancelled': raise AssertionError('Cancelled batch tried to refresh')
            if denial == '404_middle' and jid == ids[1]: raise HTTPException(404, {'code':'INDEPENDENT_GONE'})
            if denial == 'value_first' and jid == ids[0]: raise ValueError('INDEPENDENT_STALE')
            if denial == '403_middle' and jid == ids[1]: raise HTTPException(403, {'code':'INDEPENDENT_READ_DENIED'})
        return original_get(*args, **kwargs)
    monkeypatch.setattr(e.production, 'get', denied)
    response = e.client.get(e.batch_base, headers=e.headers)
    if denial in ('403_middle', 'value_first'):
        # The original Host invoker maps owner ValueError to HTTP 422.
        # Non-404 failures must propagate without any private payload.
        assert response.status_code == (403 if denial == '403_middle' else 422), response.text
        assert 'image_result' not in response.text
        assert not any(jid in response.text for jid in ids)
    else:
        current = checked(response)['items'][-1]
        if denial == 'cancelled':
            assert not seen
            assert all('image_result' not in item for item in current['items'])
        else:
            assert seen == ids
            missing = 1 if denial == '404_middle' else 0
            assert 'image_result' not in current['items'][missing]
            for index in set(range(3)) - {missing}:
                assert current['items'][index]['image_result']['id'] == ids[index]
    print('CACHE', denial, 'owner reads', len(seen), 'stale payload suppressed')
