"""Retain repository process-global cleanup for this external review fixture."""
import importlib.util
from pathlib import Path
source = Path('<CLOUD_WORKSPACE>/studio-cloud-dsh-integrated-20261020/tests/conftest.py')
spec = importlib.util.spec_from_file_location('independent_original_conftest', source)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
restore_global_settings = module.restore_global_settings
