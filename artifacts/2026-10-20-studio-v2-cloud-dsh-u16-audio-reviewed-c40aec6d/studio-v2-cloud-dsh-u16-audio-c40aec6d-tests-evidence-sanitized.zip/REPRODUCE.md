# Reproduce bounded evidence

Restore the product from the incremental bundle and its exact prerequisite chain first. source/ is the exact 34 changed-path snapshot, not a full application. The six patches are retained for source auditing only: do not reapply them over the recovered product. The original source commit objects were not supplied; imported commits retain exact verified patch postimages, not source commit IDs.

Use the restored project's existing scripts/run_v2_checks.py with its documented isolated profile and existing authorized dependencies. author/runner-receipts/cloud-dsh-final-file-api.json records the exact final File/API selection and 3,437 source hashes. Earlier receipts preserve setup failures, duplicate-item fixture rejections and corrected red-to-green findings. The receipt's recorded HEAD predates the correction commit because tests ran against its verified uncommitted contents; its exact source hashes match the final committed product.

Frontend commands and results are in source/docs/delivery/v2-development/. Seven files, 53 tests, token guard and one serial tsc/Vite build were run. PostgreSQL was explicitly deselected. This package does not rerun tests or build.

For the independent seven checks, replace <CLOUD_WORKSPACE> paths in independent/run_checks.py and conftest.py with the local restored product/dependency paths, retain the original isolated environment and run the selected independent/test_independent_dsh.py. Fixtures create synthetic File/Host data. Logs for earlier reviewer instrumentation/list ordering/HTTP-expectation errors remain separate and are not product failures. The final source and test file hashes are indexed.

Evidence-only local path normalization preserves raw diagnostic text and retains original hashes in evidence-index.json. Exact committed source blobs and patch bodies are not normalized. Original evidence files and all source refs remain unchanged. Historical not_pushed and Audio mount-pending statements describe earlier author stages; the outer REPORT/RESTORE identify this archive's final product.

Do not retry or bypass the recorded browser Unix-socket/bwrap restriction. Real Host, PostgreSQL, Windows, real model/GPU, full suite and full E2E are unaccepted. Audio replay/environment reproducibility is unsupported.
