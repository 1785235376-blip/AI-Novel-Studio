"""Two pre-existing immutable-link / legacy-schema checks, without File/media setup."""
from pathlib import Path
import os, sys, subprocess, importlib.util, json
out = Path(__file__).resolve().parent
root = out.parent / 'linked-split'
spec = importlib.util.spec_from_file_location('isolation', root / 'scripts/run_v2_checks.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
env = os.environ.copy()
for key in list(env):
    if key.endswith(('_API_KEY', '_TOKEN', '_SECRET')) or key in {'DATABASE_URL', 'TEST_POSTGRES_DATABASE_URL', 'E2E_DATABASE_URL', 'COLLABORATION_DEV_SESSIONS_JSON', 'PACKAGED_CONTROL_PIPE'}:
        env.pop(key, None)
env.update(mod.isolated_environment(root, root / '.runtime/linked-split/legacy-profile'))
env.update(PYTHONIOENCODING='utf-8', PYTHONUTF8='1', PYTHONPATH=str(root))
cmd = [sys.executable, '-B', '-m', 'pytest', 'tests/test_timeline_clip_links_additive.py::test_legacy_bytes_pair_move_once_and_explicit_unlink', 'tests/test_timeline_clip_links_additive.py::test_whole_dto_cannot_retime_or_redefine_pair_and_legacy_schema_stays_closed', '-q', '--basetemp', str(root / '.runtime/linked-split/legacy-pytest'), f'--junitxml={out / "legacy-guards.xml"}']
r = subprocess.run(cmd, cwd=root, env=env, capture_output=True, text=True, encoding='utf8', errors='replace', creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
(out / 'legacy-guards.log').write_text(r.stdout + r.stderr, encoding='utf8')
(out / 'legacy-guards-command.json').write_text(json.dumps({'command': cmd, 'exit_code': r.returncode}, indent=2))
print(r.stdout + r.stderr)
sys.exit(r.returncode)
