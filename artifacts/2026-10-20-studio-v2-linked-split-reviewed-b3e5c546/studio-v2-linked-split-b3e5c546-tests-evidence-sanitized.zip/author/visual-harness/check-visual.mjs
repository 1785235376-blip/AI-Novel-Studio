import {chromium,expect} from '../../frontend/node_modules/@playwright/test/index.mjs';
import {writeFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
const out=fileURLToPath(new URL('../../../linked-split-evidence/',import.meta.url));
const browser=await chromium.launch({headless:true,args:['--disable-gpu']});
const page=await browser.newPage({viewport:{width:1440,height:900},locale:'zh-CN',reducedMotion:'reduce'});
const errors=[];page.on('pageerror',error=>errors.push(error.message));const geometries=[];
try{
 await page.goto('http://127.0.0.1:5295/.runtime/linked-split/fixture.html');
 await expect(page.getByRole('button',{name:'按已核对切点联动拆分链接'})).toBeEnabled();
 await page.evaluate(()=>document.fonts.ready);
 await page.screenshot({path:out+'linked-split-preview-1440x900.png'});
 await page.getByRole('button',{name:'按已核对切点联动拆分链接'}).click();
 await expect(page.getByRole('status').filter({hasText:'合成草稿已拆分'})).toBeVisible();
 await expect(page.getByText(/picture-tail ↔ sound-tail.*250/)).toBeVisible();
 await expect(page.getByRole('button',{name:'按已核对切点联动拆分链接'})).toBeDisabled();
 for(const size of [{width:1366,height:768},{width:1440,height:900},{width:1920,height:1080}]){
  await page.setViewportSize(size);await page.evaluate(()=>document.fonts.ready);await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
  const geometry=await page.evaluate(()=>({width:innerWidth,scroll:document.documentElement.scrollWidth,header:document.querySelector('.global-header').getBoundingClientRect().height,context:document.querySelector('.context-bar').getBoundingClientRect().height,status:document.querySelector('.status-bar').getBoundingClientRect().height}));
  expect(geometry).toEqual({width:size.width,scroll:size.width,header:56,context:44,status:32});geometries.push({...size,...geometry});
  await page.screenshot({path:out+`linked-split-${size.width}x${size.height}.png`});
 }
 expect(errors).toEqual([]);writeFileSync(out+'visual-result.json',JSON.stringify({passed:true,synthetic_ui_only:true,geometries,errors},null,2));
}finally{await browser.close();}
