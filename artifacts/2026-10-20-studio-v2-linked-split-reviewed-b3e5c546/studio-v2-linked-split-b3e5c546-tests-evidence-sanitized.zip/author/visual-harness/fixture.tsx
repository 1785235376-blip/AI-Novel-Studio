import React, {useState} from 'react';
import {createRoot} from 'react-dom/client';
import {AppShell} from '../../src/ui/AppShell';
import {Button} from '../../src/ui/primitives';
import {LinkedClipSplitPanel} from '../../src/nle/LinkedClipSplitPanel';
import {TimelineClipLinkPanel} from '../../src/nle/TimelineClipLinkPanel';
import {splitLinkedTimeline} from '../../src/creative/studioTimelineLinkedSplit';
import {checkedTimeline} from '../../src/creative/studioTimelineTypes';
import '../../src/ui/ui.css';
import '../../src/ui/fixture.css';
import '../../src/ui/desktop-craft.css';
const snapshot=(kind:'video'|'audio')=>({id:'synthetic-'+kind,kind:'ASSET',asset_kind:kind,version:1,digest:'a'.repeat(64)});
const initial=checkedTimeline({schema_version:2,duration_ms:8000,width:64,height:64,fps:25,captions:[],tracks:[
 {id:'visual',kind:'VIDEO',order:0,muted:false,gain_db:0,clips:[{id:'picture',source_snapshot:snapshot('video'),start_ms:1000,in_ms:100,out_ms:900,x:0,y:0,width:64,height:64}]},
 {id:'voice',kind:'AUDIO',order:1,muted:false,gain_db:0,clips:[{id:'sound',source_snapshot:snapshot('audio'),start_ms:1250,in_ms:50,out_ms:850}]}],
 clip_links:[{video_clip_id:'picture',audio_clip_id:'sound',offset_ms:250}]});
function Fixture(){const[timeline,setTimeline]=useState(initial),changed=timeline!==initial;return <AppShell module="VIDEO" onModuleChange={()=>{}} scope={{workspace:'合成 UI 夹具',project:'EDIT04 / AUDIO09',storyline:'原 Timeline',branch:'有界联动拆分'}} actor="界面检查"
 sidebar={<div className="placeholder-sidebar"><h2>联动拆分</h2><p>合成 UI 夹具：仅验证原 React 控件与壳层几何。真实 File 持久化另有 3 项测试；本页不代表后端保存、媒体生成或渲染验收。</p><p>选择 picture / sound，视频播放头 1400 ms。</p><Button onClick={()=>setTimeline(initial)}>重置合成状态</Button></div>}
 main={<><LinkedClipSplitPanel timeline={timeline} selectedClipIds={['picture','sound']} videoAtMs={1400} ready={!changed} onSplit={()=>setTimeline(value=>checkedTimeline(splitLinkedTimeline(value,['picture','sound'],1400,{video:'picture-tail',audio:'sound-tail'})))}/>
 <TimelineClipLinkPanel timeline={timeline} selectedClipIds={['picture','sound']} editable={false} onLink={()=>{}} onUnlink={()=>{}}/>
 {changed&&<p role="status">合成草稿已拆分：4 片段、2 对链接；两对偏移均为 250 毫秒。实际编辑器请明确保存。</p>}</>}
 inspector={<div className="fixture-inspector"><h2>来源范围核对</h2>{timeline.tracks.flatMap(track=>track.clips.map(clip=><p key={clip.id}>{track.kind} · {clip.id}<br/>时间线 {clip.start_ms} ms<br/>来源 [{clip.in_ms}, {clip.out_ms}) ms</p>))}</div>}
 status={<>合成 UI 夹具 · 未调用后端 · 未调用模型 · File 验收见独立日志</>}/>;}
createRoot(document.getElementById('root')!).render(<Fixture/>);
