# 本地交付：已保存链接联动拆分

- 工作区：`<TASK_ROOT>/task-13/linked-split`
- 基线：`11b53ede67259f7c2d81fb495e1b1dcfdfb7ce9c`
- 独立本地 commit：`d9466d253fa4d8141391fd7295af65ce7276ee56`，未 push / Release。
- 操作与契约：工作区 `docs/TIMELINE_LINKED_SPLIT_HANDOFF.md`。
- 画面：直接打开本目录 `index.html`。4 张图片均显著标为**合成 UI 夹具**；没有冒充真实生成、媒体播放或后端验收。

## 实际验证

`file-checks.xml/log`：16 passed，3 个 PostgreSQL 参数被排除。其中 3 项真实本地 File 测试使用 CPU 生成的短 MP4/WAV，经原素材导入与原 Production owner，覆盖 edit 幂等、重开、两对关系、原 CAS Save/history、重复版本、锁定/失效来源/错误切点不写入。其余 13 项检查偏移为正/负/零的精确来源分区与不支持模式。

`legacy-guards.xml/log`：2 个已有守卫通过。`frontend-checks.xml/log`：新 7 项 + 已有链接 5 项，共 12 passed，包含原编辑器显式选择/播放头/Save 入口、一次 Undo/稳定 Redo ID、重复回调、旧回调、来源失效、不支持模式。

最终 `typecheck-exit.txt` 为 0，`typecheck.log` 无输出。`typecheck-initial-failure.log` 留存初次测试枚举/断言 API 不兼容错误；已在最终检查前修正。`visual-result.json`：3 个尺寸无横向溢出，壳层高为 56/44/32，pageerror 为空；仅新增组件夹具几何检查，未更新共享视觉基线。

## 复现小型验收

在工作区运行以下 PowerShell 命令（依赖复用现有 junction，未安装依赖）。每次只创建本工作区 `.runtime/linked-split` 下的新测试数据：

```powershell
& '<TASK_ROOT>/task-3/evidence/otio-metadata-p2/tools/pytest8-venv/Scripts/python.exe' -B ../linked-split-evidence/run_file_checks.py
& '<TASK_ROOT>/task-3/evidence/otio-metadata-p2/tools/pytest8-venv/Scripts/python.exe' -B ../linked-split-evidence/run_legacy_guards.py
node frontend/node_modules/vitest/vitest.mjs run --config .runtime/linked-split/vitest.config.mjs src/creative/StudioTimelineLinkedSplit.additive.test.tsx src/creative/StudioTimelineClipLinks.additive.test.tsx
```

类型检查在 `linked-split/frontend` 执行 `node node_modules/typescript/bin/tsc -b`。视觉脚本原件仍在 `.runtime/linked-split/`，前端夹具在 `frontend/.runtime/linked-split/`，本目录 `visual-harness/` 保留副本。可独占使用 5295 端口，以 native config loader 启动：

```powershell
node frontend/node_modules/vite/bin/vite.js --config .runtime/linked-split/vite.linked-split.mjs --configLoader native
# 另一个终端，仍在本工作区：
node .runtime/linked-split/check-visual.mjs
```

## 边界与保护

首片只支持 schema 2、一对已保存且干净的 1× 真实 VIDEO/AUDIO 片段，无淡入淡出/转场。共同区间按两成员相同相对经过时长计算；音频绝对切点为视频切点加原偏移。两头保留原 ID，两尾使用两个新 ID，头尾各保留原偏移关系。没有新增 schema 字段或改渲染/播放实现。不支持的路径明确拒绝。

未验证 PostgreSQL、浏览器到真实 HTTP 后端链路、播放/渲染/导出和多对批量拆分。Undo/Redo 在 Save 前复用原本地历史；Save 接受新版本后按原约定清空本地历史，原服务端历史保留先前版本；本片不新增合并或恢复能力。

旧演示 ZIP SHA256：`29589627f5b2f50177d407de69e4e63864b56e9b179fcf0c6ae1db878886b8e8`，571985 字节，未改变；既有链接/移动工作区仍在 `a8d3030215a4975f07045ebdbb71c354dffb8ea2`。清理只涉及本任务 5295 进程与自有 disposable `.runtime/linked-split` 数据，复现脚本和全部证据保留。最终状态见 `final-status.json`。
