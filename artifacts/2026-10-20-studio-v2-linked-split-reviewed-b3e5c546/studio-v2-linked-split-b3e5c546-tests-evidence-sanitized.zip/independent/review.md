# 联动拆分独立审查

目标 `d9466d253fa4d8141391fd7295af65ce7276ee56`，父版本 `11b53ede67259f7c2d81fb495e1b1dcfdfb7ce9c`。已读全部 10 个变更文件。三项独立检查通过，本限定范围内未发现 P1/P2；可按原 owner 上的 schema 2、单对、1×、无淡入淡出／转场切片限定整合。

1. 原 File 服务检查正负偏移 +275/−425ms，距共同相对区间首尾各 1ms 的两个切点。视频来源 [123,943)，音频 [17,617)，拆分后左右来源恰好连续分区、偏移和其他属性不变；无关片段／字幕不变。原 /edit 同请求重放、整表 Save、重开、版本／history 均保留，无新 schema 字段、无渲染任务。
2. 20 个拒绝分支逐次比较所有既有 File JSON 字节，均无半写。包括短成员共同相对区间外、边界、分数、ID、混批、旧单边拆分；五种 schema 本身合法的分区／关系／属性伪造；锁；外部 actor；原两条 CAS；原来源校验之后撤销 guard；真实 Asset 版本变更。整表伪造先通过正常 schema，随后被分区保留边界拒绝。
3. 原 hook/editor 使用第一项产生的真实 File 输入，配合受控客户端/JSDOM。旧草稿／权限／选区／播放头 ABA 回调拒绝；重复回调只接受一次，原 UI 只分配两个新 ID；一次 Undo/Redo 保留新 ID，禁止写入时不能 Undo，Save 用原 CAS 并清空本地 history；UNKNOWN Save 保留四分区并阻止 Undo 和重发。没有自动 Save、/edit 或 render。

这里的共同区间是文档明示的**相对**区间：u∈(0,min(两来源长度))，视频切 V+u、音频切 A+u；不承诺同一绝对时刻切两成员。保留真实 HTTP 浏览器、Timeline 渲染／导出／播放和 PostgreSQL 未验收状态，也不外推多对、变速、淡入淡出、转场、静态图片或完整需求行。

原始审查失败保留：backend1 是自建夹具错误地给未启用视频声音的片段设置非零增益，原 schema 在切片前正确拒绝；移除该无效字段。backend2 的检查 1 通过，检查 2 错误预期外部 actor 返回 PermissionError，实际原 owner 正确隐藏记录为 FileNotFoundError；仅修正审查预期并单独重跑检查 2，backend3 通过。frontend1 首次通过。没有修改产品、边界或配置来通过测试。

目标工作区始终 HEAD=d9466d253fa4d8141391fd7295af65ce7276ee56，git status 为空，10 个变更文件前后 SHA 一致。只复制三份精确测试 helper 共 94,743 字节；产品与依赖零复制，复用原依赖 junction。未重跑作者全套、类型／构建或几何检查；未启动服务、提交、推送或更改任何原证据。自身隔离 File 数据保留于 `.runtime`，可核对真实保存结果。

精确命令、版本和原始日志见 `*-command.json`、`validation-environment.json`、`backend1/2/3.log`、`frontend1.log`；判定与范围见 `review-handoff.json`。
