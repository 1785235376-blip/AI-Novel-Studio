"""Two independent original File checks; no product copies, rendering or models."""
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace
import hashlib
import json
import pytest
from app.experimental.common import StaleSourceError
from app.services.studio_timeline_links import split_linked_pair
from app.services.studio_timeline_render import normalize_studio_timeline
from app.services.v1_capability_service import CapabilityVersionConflict
from test_v2_independent_workspace import rig as original_rig, import_asset, reopened
from test_v2_audio_editing_pipeline import production, source, edit_body, cpu_video, audible_wav

ROOT = Path(__file__).parent

@pytest.fixture
def owner(tmp_path, monkeypatch):
    gen = original_rig.__wrapped__(SimpleNamespace(param='file'), tmp_path, monkeypatch)
    e = next(gen); e.service.activate(e.nid, e.scope, e.actor)
    e.video = import_asset(e, data=cpu_video(tmp_path/'source.mp4'), filename='review-source.mp4', kind='video')
    e.audio = import_asset(e, data=audible_wav(), filename='review-source.wav', kind='audio')
    e.production = production(e)
    yield e
    try: next(gen)
    except StopIteration: pass

def timeline(e, offset):
    return {'schema_version':2, 'duration_ms':8000, 'width':64, 'height':64, 'fps':25,
        'captions':[{'start_ms':0,'end_ms':100,'text':'Unrelated original caption'}], 'tracks':[
        {'id':'visual','kind':'VIDEO','order':0,'clips':[
            {'id':'v','source_snapshot':source(e.video),'start_ms':1300,'in_ms':123,'out_ms':943,'x':2,'y':4,'width':32,'height':32,'opacity':0.75},
            {'id':'unrelated-v','source_snapshot':source(e.video),'start_ms':4000,'in_ms':10,'out_ms':210}]},
        {'id':'voice','kind':'AUDIO','order':1,'clips':[
            {'id':'a','source_snapshot':source(e.audio),'start_ms':1300+offset,'in_ms':17,'out_ms':617,'gain_db':-3}]},
        {'id':'ambience','kind':'AUDIO','order':2,'clips':[
            {'id':'unrelated-a','source_snapshot':source(e.audio),'start_ms':40,'in_ms':0,'out_ms':50}]}],
        'clip_links':[{'video_clip_id':'v','audio_clip_id':'a','offset_ms':offset}]}

def save_new(e, offset):
    return e.production.timeline_save(e.nid,e.scope,e.actor,None,{'title':'Independent linked split','expected_version':0,'timeline':timeline(e,offset)},lambda:None)

def clips(value): return {c['id']:(t['id'],c) for t in value['tracks'] for c in t['clips']}
def op(elapsed, suffix='right'):
    return {'op':'clip.split_linked','video_clip_id':'v','audio_clip_id':'a','at_ms':1300+elapsed,'new_video_clip_id':'v-'+suffix,'new_audio_clip_id':'a-'+suffix}
def edit(e,row,ops,key,guard=lambda:None,actor=None):
    return e.production.timeline_edit(e.nid,e.scope,actor or e.actor,row['id'],edit_body(row,ops,key),guard)
def files(e): return {str(p.relative_to(e.root)):p.read_bytes() for p in e.root.rglob('*.json')}
def partition(before,after,offset,elapsed,suffix='right'):
    old,new=clips(before),clips(after)
    assert set(after)==set(before) and after['schema_version']==2
    assert set(new)==set(old)|{'v-'+suffix,'a-'+suffix}
    assert after['clip_links']==[{'video_clip_id':'v','audio_clip_id':'a','offset_ms':offset},
        {'video_clip_id':'v-'+suffix,'audio_clip_id':'a-'+suffix,'offset_ms':offset}]
    for identity in ['v','a']:
        track,original=old[identity];left_track,left=new[identity];right_track,right=new[identity+'-'+suffix]
        assert track==left_track==right_track
        assert left['in_ms']==original['in_ms'] and left['out_ms']==right['in_ms']==original['in_ms']+elapsed and right['out_ms']==original['out_ms']
        assert left['start_ms']==original['start_ms'] and right['start_ms']==original['start_ms']+elapsed
        assert left['out_ms']-left['in_ms']+right['out_ms']-right['in_ms']==original['out_ms']-original['in_ms']
        for key,value in original.items():
            if key not in {'id','start_ms','in_ms','out_ms'}:assert left[key]==right[key]==value
    for identity in ['unrelated-v','unrelated-a']:assert new[identity]==old[identity]
    assert after['captions']==before['captions']

def test_review1_signed_offset_near_source_boundaries_original_file_edit_save_history_reopen(owner):
    e=owner;records=[]
    for offset in [275,-425]:
        for elapsed in [1,599]:
            row=save_new(e,offset);body=edit_body(row,[op(elapsed)],f'split-{offset}-{elapsed}')
            result=e.production.timeline_edit(e.nid,e.scope,e.actor,row['id'],body,lambda:None)
            partition(row['timeline'],result['timeline'],offset,elapsed);assert result['version']==row['version']+1
            state=files(e)
            assert e.production.timeline_edit(e.nid,e.scope,e.actor,row['id'],body,lambda:None)==result and files(e)==state
            fresh=production(e,reopened(e));assert fresh.timeline_get(e.nid,e.scope,e.actor,row['id'],lambda:None)==result
            history=fresh.timeline_history(e.nid,e.scope,e.actor,row['id'],lambda:None)
            assert len(history['items'])==1 and history['items'][0]['timeline']==row['timeline']
            twin=save_new(e,offset)
            saved=fresh.timeline_save(e.nid,e.scope,e.actor,twin['id'],{'title':twin['title'],'expected_version':twin['version'],'timeline':result['timeline']},lambda:None)
            partition(twin['timeline'],saved['timeline'],offset,elapsed)
            assert production(e,reopened(e)).timeline_get(e.nid,e.scope,e.actor,twin['id'],lambda:None)==saved
            assert fresh.timeline_history(e.nid,e.scope,e.actor,twin['id'],lambda:None)['items'][0]['timeline']==twin['timeline']
            records.append({'offset':offset,'elapsed':elapsed,'before':row,'edited':result,'whole_saved':saved})
    assert e.production.list(e.nid,e.scope,e.actor,lambda:None)['items']==[]
    (ROOT/'case1-file.json').write_text(json.dumps({'cases':records,'assets':[e.video,e.audio],'render_jobs':0,
        'file_json_sha256':{name:hashlib.sha256(raw).hexdigest()for name,raw in files(e).items()}},indent=2),encoding='utf-8')

def test_review2_whole_batch_refusal_locks_permission_sources_cas_and_no_shared_relative_cut(owner,monkeypatch):
    e=owner;row=save_new(e,-275);rejects=[]
    def refused(label,call,expected):
        before=files(e)
        with pytest.raises(expected) as caught:call()
        assert files(e)==before,label
        rejects.append({'case':label,'type':type(caught.value).__name__,'reason':str(caught.value)})
    for index,value in enumerate([op(0),op(600),op(650),{**op(300),'at_ms':1600.5},{**op(300),'new_audio_clip_id':'v'},
            {'op':'clip.split','clip_id':'v','at_ms':1600,'new_clip_id':'unlinked-tail'}]):
        refused(f'invalid-cut-or-identity-{index}',lambda value=value,index=index:edit(e,row,[value],f'invalid-{index}'),ValueError)
    refused('valid-prefix-plus-linked-split',lambda:edit(e,row,[{'op':'caption.insert','caption':{'start_ms':200,'end_ms':250,'text':'must not persist'}},op(300)],'mixed'),ValueError)
    valid=split_linked_pair(row['timeline'],'v','a',1600,'v-right','a-right')
    for fault in ['left-source-gap','right-source-gap','missing-tail-link','tail-time-gap','changed-property']:
        forged=deepcopy(valid);by=clips(forged)
        if fault=='left-source-gap':by['a'][1]['out_ms']-=1
        elif fault=='right-source-gap':by['a-right'][1]['in_ms']+=1
        elif fault=='missing-tail-link':forged['clip_links'].pop()
        elif fault=='tail-time-gap':by['v-right'][1]['start_ms']+=3;by['a-right'][1]['start_ms']+=3
        else:by['v-right'][1]['opacity']=0.5
        assert normalize_studio_timeline(forged)==forged  # each reaches the Save preservation boundary, not schema rejection
        refused(f'whole-save-{fault}',lambda forged=forged:e.production.timeline_save(e.nid,e.scope,e.actor,row['id'],
            {'expected_version':row['version'],'title':row['title'],'timeline':forged},lambda:None),ValueError)
    locked=edit(e,row,[{'op':'track.update','track_id':'voice','changes':{'locked':True}}],'lock-partner')
    refused('locked-edit',lambda:edit(e,locked,[op(300)],'locked'),ValueError)
    locked_payload=deepcopy(valid);next(t for t in locked_payload['tracks']if t['id']=='voice')['locked']=True
    refused('locked-whole-save',lambda:e.production.timeline_save(e.nid,e.scope,e.actor,locked['id'],
        {'expected_version':locked['version'],'title':locked['title'],'timeline':locked_payload},lambda:None),ValueError)
    ready=edit(e,locked,[{'op':'track.update','track_id':'voice','changes':{'locked':False}}],'unlock-partner')
    refused('foreign-actor',lambda:edit(e,ready,[op(300)],'foreign',actor='unrelated-review-actor'),PermissionError)
    refused('stale-edit-cas',lambda:edit(e,row,[op(300)],'stale-edit'),StaleSourceError)
    refused('stale-whole-save-cas',lambda:e.production.timeline_save(e.nid,e.scope,e.actor,row['id'],
        {'expected_version':row['version'],'title':row['title'],'timeline':valid},lambda:None),CapabilityVersionConflict)
    original=e.production._timeline_sources_current;revoked={'value':False,'reached':False}
    def sources_then_revoke(*args,**kwargs):
        result=original(*args,**kwargs);revoked.update(value=True,reached=True);return result
    def guard():
        if revoked['value']:raise PermissionError('independent late authority revocation')
    with monkeypatch.context() as scope:
        scope.setattr(e.production,'_timeline_sources_current',sources_then_revoke)
        refused('late-authority-after-source-check',lambda:edit(e,ready,[op(300)],'late-authority',guard=guard),PermissionError)
    assert revoked['reached']
    with e.service._asset_scope(e.nid,e.scope):e.assets.update_metadata(e.audio['id'],{'scene_id':'changed-before-split'},expected_version=e.audio['version'])
    refused('stale-source-edit',lambda:edit(e,ready,[op(300)],'stale-source'),(ValueError,FileNotFoundError,StaleSourceError))
    refused('stale-source-whole-save',lambda:e.production.timeline_save(e.nid,e.scope,e.actor,ready['id'],
        {'expected_version':ready['version'],'title':ready['title'],'timeline':valid},lambda:None),(ValueError,FileNotFoundError,StaleSourceError))
    assert e.production.timeline_get(e.nid,e.scope,e.actor,ready['id'],lambda:None)==ready
    (ROOT/'case2-rejections.json').write_text(json.dumps({'rejections':rejects,'unchanged':True,'late_guard_reached':True},indent=2),encoding='utf-8')
