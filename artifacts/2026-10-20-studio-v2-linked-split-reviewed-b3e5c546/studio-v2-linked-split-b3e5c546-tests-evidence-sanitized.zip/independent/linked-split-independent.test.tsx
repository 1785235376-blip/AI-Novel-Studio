import { act, cleanup, fireEvent, render, renderHook, screen, waitFor, within } from '@testing-library/react';
import { expect, it, vi } from 'vitest';
import { writeFileSync } from 'node:fs';
import { ApiError } from '<TASK_ROOT>/task-13/linked-split/frontend/src/api';
import { StudioTimelineEditor } from '<TASK_ROOT>/task-13/linked-split/frontend/src/creative/StudioTimelineEditor';
import { useStudioTimelineEditor, type StudioTimelineEditorProps } from '<TASK_ROOT>/task-13/linked-split/frontend/src/creative/useStudioTimelineEditor';
import { checkedTimelineRow, cloneTimeline, type StudioTimelineDraft } from '<TASK_ROOT>/task-13/linked-split/frontend/src/creative/studioTimelineTypes';
import type { StudioProductionClient } from '<TASK_ROOT>/task-13/linked-split/frontend/src/creative/studioProductionClient';
import type { StudioAsset } from '<TASK_ROOT>/task-13/linked-split/frontend/src/creative/studioClient';
import evidence from './case1-file.json';

const input = evidence.cases.find(c => c.offset === 275 && c.elapsed === 1)!.before;
const row = checkedTimelineRow(input), ids = {video:'tail-v',audio:'tail-a'}, cut = 1600;
function setup(panel = false) {
  let saved = cloneTimeline(row);
  const client = { timelineList:vi.fn(async()=>({items:[cloneTimeline(saved)]})), timelineGet:vi.fn(async()=>cloneTimeline(saved)),
    timelineSave:vi.fn(async(_id:string|undefined,body:StudioTimelineDraft&{expected_version:number})=>{
      saved = checkedTimelineRow({...saved,...body,version:body.expected_version+1,timeline_digest:'c'.repeat(64)});return cloneTimeline(saved);
    }), timelineEdit:vi.fn(),timelineRender:vi.fn() };
  const props:StudioTimelineEditorProps = {client:client as unknown as StudioProductionClient,assets:evidence.assets as unknown as StudioAsset[],canMutate:true,busy:false,
    projectId:input.novel_id,isCurrent:()=>true,read:work=>work(),mutate:work=>work(),onDirtyChange:vi.fn(),onJob:vi.fn(),onUnavailable:vi.fn()};
  const hook = panel?undefined:renderHook((value:StudioTimelineEditorProps)=>useStudioTimelineEditor(value),{initialProps:props});
  if(panel)render(<StudioTimelineEditor {...props}/>);return {client,props,hook};
}
async function adopt(state:ReturnType<typeof setup>){const h=state.hook!;await waitFor(()=>expect(h.result.current.rows).toHaveLength(1));
  await act(async()=>h.result.current.checkServer(row.id));act(()=>h.result.current.setAdoptConfirmed(true));act(()=>h.result.current.adoptCandidate(false));}
const noExecution = (s:ReturnType<typeof setup>)=>{expect(s.client.timelineEdit).not.toHaveBeenCalled();expect(s.client.timelineRender).not.toHaveBeenCalled();};
const reactClick = (element:HTMLElement)=>{const key=Object.keys(element).find(k=>k.startsWith('__reactProps$'))!;
  return (element as unknown as Record<string,{onClick:()=>void}>)[key].onClick;};

it('independently fences stale split callbacks, repeated intent, one-step undo, UI selection/playhead ABA and UNKNOWN Save using genuine File inputs',async()=>{
  const state=setup();await adopt(state);const h=state.hook!,before=cloneTimeline(h.result.current.draft);
  const oldDraft=h.result.current.splitLinkedClips;act(()=>h.result.current.change(d=>{d.title+=' temporary';}));act(()=>h.result.current.undo());
  expect(h.result.current.draft).toEqual(before);act(()=>expect(oldDraft(['v'],cut,ids)).toBe(false));
  const oldPermission=h.result.current.splitLinkedClips;h.rerender({...state.props,canMutate:false});h.rerender(state.props);
  act(()=>expect(oldPermission(['v'],cut,ids)).toBe(false));expect(h.result.current.draft).toEqual(before);
  h.rerender({...state.props,assets:state.props.assets.filter(a=>a.kind!=='audio')});
  act(()=>expect(h.result.current.splitLinkedClips(['a'],cut,ids)).toBe(false));expect(h.result.current.draft).toEqual(before);h.rerender(state.props);
  const click=h.result.current.splitLinkedClips;
  act(()=>{expect(click(['a'],cut,ids)).toBe(true);expect(click(['a'],cut,{video:'duplicate-v',audio:'duplicate-a'})).toBe(false);});
  const split=cloneTimeline(h.result.current.draft);expect(split.timeline.tracks.flatMap(t=>t.clips)).toHaveLength(6);
  expect(split.timeline.clip_links).toEqual([{video_clip_id:'tail-v',audio_clip_id:'tail-a',offset_ms:275},{video_clip_id:'v',audio_clip_id:'a',offset_ms:275}]);
  h.rerender({...state.props,canMutate:false});act(()=>h.result.current.undo());expect(h.result.current.draft).toEqual(split);h.rerender(state.props);
  act(()=>h.result.current.undo());expect(h.result.current.draft).toEqual(before);act(()=>h.result.current.undo());expect(h.result.current.draft).toEqual(before);
  act(()=>expect(click(['v'],cut,{video:'stale-v',audio:'stale-a'})).toBe(false));act(()=>h.result.current.redo());expect(h.result.current.draft).toEqual(split);
  expect(state.client.timelineSave).not.toHaveBeenCalled();await act(async()=>h.result.current.save());
  expect(state.client.timelineSave).toHaveBeenCalledTimes(1);expect(state.client.timelineSave).toHaveBeenCalledWith(row.id,{...split,expected_version:row.version});
  act(()=>h.result.current.undo());expect(h.result.current.draft).toEqual(split);noExecution(state);cleanup();

  const ui=setup(true);await waitFor(()=>expect(screen.getByLabelText('读取已保存时间线').querySelector(`option[value="${row.id}"]`)).toBeTruthy());
  fireEvent.change(screen.getByLabelText('读取已保存时间线'),{target:{value:row.id}});const review=await screen.findByLabelText('核对服务端时间线');
  fireEvent.click(within(review).getByLabelText('已核对服务端内容与本地输入，确认以下选择'));fireEvent.click(within(review).getByRole('button',{name:'采用服务端时间线'}));
  const tracks=screen.getByLabelText('轨道头');fireEvent.click(within(tracks).getByRole('button',{name:'v'}));
  const jump=(at:number)=>{fireEvent.change(screen.getByLabelText('播放头（毫秒）'),{target:{value:String(at)}});fireEvent.click(screen.getByRole('button',{name:'跳转到播放头'}));};
  jump(cut);const panel=screen.getByRole('region',{name:'已保存链接联动拆分'}),button=()=>within(panel).getByRole('button',{name:'按已核对切点联动拆分链接'});
  expect((button()as HTMLButtonElement).disabled).toBe(false);expect(within(panel).getByText(/视频切点 1600 毫秒；音频切点 1875 毫秒/)).toBeTruthy();
  const allocation=vi.spyOn(crypto,'randomUUID');allocation.mockClear();const oldPlayhead=reactClick(button());jump(cut+40);jump(cut);
  act(()=>oldPlayhead());expect(allocation).not.toHaveBeenCalled();const oldSelection=reactClick(button());
  fireEvent.click(within(tracks).getByRole('button',{name:'a'}),{ctrlKey:true});fireEvent.click(within(tracks).getByRole('button',{name:'a'}),{ctrlKey:true});
  act(()=>oldSelection());expect(allocation).not.toHaveBeenCalled();const fresh=reactClick(button());act(()=>{fresh();fresh();});
  expect(allocation).toHaveBeenCalledTimes(2);expect((button()as HTMLButtonElement).disabled).toBe(true);expect(ui.client.timelineSave).not.toHaveBeenCalled();noExecution(ui);
  allocation.mockRestore();cleanup();

  const uncertain=setup();await adopt(uncertain);const uh=uncertain.hook!;
  act(()=>expect(uh.result.current.splitLinkedClips(['v','a'],cut,ids)).toBe(true));const retained=cloneTimeline(uh.result.current.draft);
  uncertain.client.timelineSave.mockRejectedValueOnce(new ApiError({status:0,code:'NETWORK_ERROR',message:'independent lost Save response'}));
  await act(async()=>uh.result.current.save());expect(uh.result.current.failure).toBe('UNKNOWN');act(()=>uh.result.current.undo());
  expect(uh.result.current.draft).toEqual(retained);act(()=>expect(uh.result.current.splitLinkedClips(['v'],cut,{video:'repeat-v',audio:'repeat-a'})).toBe(false));
  await act(async()=>uh.result.current.save());expect(uncertain.client.timelineSave).toHaveBeenCalledTimes(1);noExecution(uncertain);cleanup();
  writeFileSync('case3-proof.json',JSON.stringify({status:'passed',scope:'Original hook/editor, genuine File inputs with controlled clients/JSDOM; not live HTTP',
    retired_draft_permission_selection_playhead:true,repeated_ui_callback_uuid_allocations:2,accepted_split_intents:1,undo_before_save:'one step',undo_after_save:'empty history',
    unknown_save_keeps_split_and_blocks_undo_retry:true,render_or_edit_requests:0},null,2));
});
