// @vitest-environment jsdom
import { act, cleanup, renderHook } from '@testing-library/react';
import { afterEach, expect, it, vi } from 'vitest';
import { useStudioTimelinePlayback } from '../../../task-5/half-preview-proxy/frontend/src/creative/useStudioTimelinePlayback';
import { checkedTimelineRow } from '../../../task-5/half-preview-proxy/frontend/src/creative/studioTimelineTypes';
import captured from '../../proxy-independent-review/native-hook-input.json';

afterEach(cleanup);
it('safely retires a valid HALF preview when switching to another valid 30px canvas', async () => {
  const row = checkedTimelineRow(captured.row);
  const preview = structuredClone(captured.half);
  const client = { timelinePlaybackPreview: vi.fn(async () => preview), timelinePlaybackBuild: vi.fn(), timelinePlaybackAttestation: vi.fn() };
  const options: any = { source: row, props: { client, assets: [captured.source], canMutate: true, busy: false,
    isCurrent: () => true, read: (work: any) => work(), mutate: (work: any) => work(), onDirtyChange: vi.fn(), onUnavailable: vi.fn(), onJob: vi.fn() },
    isReady: () => true, onGateChange: vi.fn(), onAuthorityLost: vi.fn() };
  const hook = renderHook(value => useStudioTimelinePlayback(value), { initialProps: options });
  act(() => hook.result.current.changeResolution('HALF'));
  await act(async () => hook.result.current.previewPlayback());
  expect(hook.result.current.previewDimensions).toEqual([48, 32]);
  const small = checkedTimelineRow(captured.small_row);
  expect(small.timeline.width).toBe(30);
  expect(() => hook.rerender({ ...options, source: small })).not.toThrow();
  expect(hook.result.current.preview).toBeUndefined();
  expect(client.timelinePlaybackBuild).not.toHaveBeenCalled();
});
