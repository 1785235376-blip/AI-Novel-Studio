# 固定 1/2 播放预览交接

后续独立审查发现的源切换 P2 已提交最小修复 `609f85d1ce0941150b87135789240da4b48f8dd4`，父版本为原功能提交 `4f46c3287f3a0ed458c2928f89d880a8d13adf30`。当前等待独立复核；红绿与范围见 [P2 修复交接](p2-source-switch/HANDOFF.md)。以下原功能验证均保留其执行版本。

已本地提交 `4f46c3287f3a0ed458c2928f89d880a8d13adf30`，父版本为 Image 冻结提交 `bec46a1f912291627efb5c6b3c7d362a9c2158ec`。独立分支 `work/v2-half-preview-proxy-image-20261019`；工作区干净，未推送。

本次补齐 EDIT-07/08 的限定缺口：原 TimelinePlayback 可明确选择 1/2 输出，沿用原 export/render、任务、私有候选、证明和浏览器缓存。固定策略 `HALF_EVEN_FLOOR_BILINEAR_V1` 在完成原坐标合成后缩放到 `floor(原尺寸 / 4) * 2`，至少 16×16。缺省请求与精确父实现 d9b 的回执相同，四种原导出配置摘要不变；音频 WAV 和波形请求拒绝 HALF。未完成整个 EDIT-07/08，也未作编辑流畅度性能承诺。

真实 CPU / File 检查输出：98×66 原画布得到 48×32、10 帧、1 秒 H.264/AAC；原普通导出仍为 98×66。重开复用同一 Playback 任务，只有一次编码；原候选仍私有，证明的 SHA/字节数与实际媒体一致。源、版本、编码器摘要变化保留原缓存隔离与拒绝边界。输入、两种输出、原始回执、工具精确版本及 SHA 均保留在本目录。

8 个独立后端用例通过，6 个新增前端用例通过，另抽查原 Image 合成解码和播放选项各 1 例。严格 TypeScript 通过；Vite 生产构建仅执行 1 次并通过，保留已有大分块提示。设计 token 检查通过。浏览器使用实际 CPU/File 回执和实际 MP4 的分段 HTTP 夹具：三尺寸、三个原 AppShell 模块标签共 9 组几何检查通过；视频解码 48×32、1 秒，未自动播放；1 次生成、2 次服务端证明、1 次候选下载，第二次载入复用浏览器字节缓存。已单独补查第二次载入后 seek 完成状态。此证据不等于完整浏览器与后端端到端验收。

原始失败保留：native1 的原诊断字段投影断言、frontend2 的测试范围取值、TypeScript 的旧测试控制器夹具字段，以及 browser1/2 的隐式标签精确匹配和 browser3 的异步请求计数。均修正测试/夹具，不降低产品校验。首次 Git 提交因无作者信息未创建提交；随后仅用单次命令的 Codex 作者信息提交，未改配置。

两处共享接线仅叠加在 bec46 版本：`production_execution_models.py` 与 `studioProductionClient.ts`。Image 合成代码保留；未改 `production_execution.py`、`media_files.py`、`app/api.py` 或共享权限核心。两文件现已释放供父任务协调。Image 独立复核尚由父任务处理，未作发布。PostgreSQL、完整实时 E2E、NLE 目标软件验收均未运行。

片段链接 a8d303 的先行独立复核已完成 3 项，无本范围内 P1/P2，见 `../timeline-clip-links-cross-review/review-handoff.json`。其源码、工作区状态及此前禁止清理的证据目录均保留。

回归源码与实际回执夹具已纳入提交；浏览器临时入口保存在 `browser-harness/`。重跑该浏览器夹具时，将三个入口暂放本 worktree 的 frontend，再在该目录运行保存的命令；依赖沿用原 junction，不需要安装。只清理了本线确认可重建的测试临时目录、构建输出和 QA 缓存，精确媒体与原始证据未清理。详见 `handoff.json`、`validation-environment.json`、各 `*-command.json` 和 `cleanup-receipt.json`。
