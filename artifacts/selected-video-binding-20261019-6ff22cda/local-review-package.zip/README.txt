本地审查包，产品源码冻结，未推送。
先读 ACCEPTANCE_REPORT.txt，再核对 MANIFEST.json 与 SHA256SUMS。
payload/selected-video-binding.patch 是不含作者头的精确 Git diff，需要先有明确 BASE 的产品仓库。
source/ 是冻结工作树的 11 个原样文件；其 SHA256 与原交付回执一致。不同平台的 Git 换行规范化仍由原仓库属性处理。
evidence-redacted/ 仅为脱敏副本，不能冒充原始日志字节；原始 SHA256 在 MANIFEST.json 的 original_evidence 中。
verification-tools/ 供独立复核方法；工具原路径布局记录在原回执，运行前由消费者按其本机目录安排，不能假定本机路径在其他执行器存在。
原始 bundle 因包含 Git 账户元数据而未放入此 ZIP；保持在创建执行器本地，身份与哈希已核对。
本包用于归档审查，不是产品正式发布授权；产品代码及独立复核结果已冻结。
