from pathlib import Path
import ast,hashlib,json,os,subprocess,sys
SOURCE=Path(r'D:\codex数据\2026-10-20\task\public-build-c40')
OWN=Path(r'D:\codex数据\2026-10-19\task\studio-v2-independent-c40')
OUT=Path(__file__).parent
BASE='c40aec6d7ccf5162bef7a2a054ff45b6baf2b13b';TIP='16f0e8db40929a2494fe0c0c01255087709afbfb'
def git(*args):return subprocess.check_output(['git','-C',str(SOURCE),*args])
def blob(sha,path):return git('show',sha+':'+path)
assert not git('status','--porcelain').strip()
assert git('rev-parse',TIP+'^').decode().strip()==BASE
changed=git('diff-tree','--no-commit-id','--name-only','-r',TIP).decode().splitlines()
assert set(changed)=={'packaging/public-build.json','tests/test_public_build_c40_closure.py','docs/delivery/v2-development/PUBLIC_BUILD_C40_CLOSURE_20261020.md'}
old=json.loads(blob(BASE,'packaging/public-build.json'));new=json.loads(blob(TIP,'packaging/public-build.json'))
assert old.keys()==new.keys();delta={};reviewed=[]
for key in old:
    if old[key]==new[key]:continue
    assert isinstance(old[key],list) and isinstance(new[key],list)
    assert set(old[key])<=set(new[key]);added=sorted(set(new[key])-set(old[key]));delta[key]=added
    for path in added:
        content=blob(BASE,path);assert content==blob(TIP,path)
        if path.endswith('.py'):ast.parse(content.decode('utf-8-sig'),filename=path)
        assert 'studio_private_extensions' not in path.casefold()
        reviewed.append({'path':path,'sha256':hashlib.sha256(content).hexdigest(),'base_identical':True})
assert len(reviewed)==21 and sum(row['path'].endswith('.py') for row in reviewed)==20
assert next(row for row in reviewed if not row['path'].endswith('.py'))['path']=='contracts/storyboard-video-timeline-v1.md'
guards=['scripts/public_build.py','pyproject.toml','Dockerfile','app/creative/content_policy.py','tests/test_public_build_profile.py','tests/test_public_continued_features_additive.py']
assert all(blob(BASE,p)==blob(TIP,p) for p in guards)
report={'base':BASE,'tip':TIP,'changed':changed,'manifest_delta':delta,'unchanged_guards':guards,'source_reviews':reviewed,'review':'PASS_SCOPE_NO_POLICY_OR_GUARD_RELAXATION','private_surface_runtime_audit':'see independent offline pytest execution','native_symlink':'existing WinError1314 fixture BLOCKED, not rerun or accepted','real_host_pg_e2e':'NOT_RUN'}
(OUT/'fixed-source-review.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
env=os.environ.copy()
for key in list(env):
    if key.endswith(('_API_KEY','_TOKEN','_SECRET')) or key in {'DATABASE_URL','TEST_POSTGRES_DATABASE_URL','E2E_DATABASE_URL','COLLABORATION_DEV_SESSIONS_JSON','PACKAGED_CONTROL_PIPE'}:env.pop(key,None)
temp=OWN/'.runtime/public-review-temp';temp.mkdir(parents=True,exist_ok=True)
env.update(PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',TEMP=str(temp),TMP=str(temp),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',ENABLE_PROVIDER_FALLBACK='false')
commands=[('independent-source-closure',[sys.executable,'-B','scripts/public_build.py','--source','.']),('independent-packaging-tests',[sys.executable,'-B','-m','pytest','--noconftest','tests/test_public_build_profile.py','tests/test_public_continued_features_additive.py','tests/test_public_build_c40_closure.py','-q','-p','no:cacheprovider','-k','not test_symlinks_fail_before_copy','--basetemp',str(OWN/'.runtime/public-review-pytest'),'--junitxml',str(OUT/'independent-packaging-tests.xml')])]
for label,args in commands:
    assert not (OUT/(label+'.log')).exists()
    with (OUT/(label+'.log')).open('wb') as log:r=subprocess.run(args,cwd=SOURCE,env=env,stdout=log,stderr=subprocess.STDOUT)
    (OUT/(label+'.json')).write_text(json.dumps({'args':args,'cwd':str(SOURCE),'exit':r.returncode,'runs':1},indent=2)+'\n',encoding='utf-8')
    print(label+' exit='+str(r.returncode),flush=True)
    if r.returncode:raise SystemExit(r.returncode)
print('Fixed commit source/guard review and independent offline verification PASS.')
