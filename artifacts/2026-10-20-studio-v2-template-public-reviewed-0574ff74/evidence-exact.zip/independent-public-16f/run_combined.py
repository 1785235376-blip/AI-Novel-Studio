from pathlib import Path
import json,os,subprocess,sys
ROOT=Path(r'D:\codex数据\2026-10-19\task\studio-v2-independent-c40');OUT=Path(__file__).parent
tag=sys.argv[1] if len(sys.argv)>1 else '';assert not tag or tag.replace('-','').isalnum()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
head=git('rev-parse','HEAD').decode().strip();parents=git('show','-s','--format=%P','HEAD').decode().split()
assert parents==['3300636a91761f59bb150b9f871327a9574cfe62','16f0e8db40929a2494fe0c0c01255087709afbfb'];assert not git('status','--porcelain').strip()
for tip in parents:
    for path in git('diff-tree','--no-commit-id','--name-only','-r',tip).decode().splitlines():assert git('show','HEAD:'+path)==git('show',tip+':'+path),path
(OUT/'combined-source-proof.json').write_text(json.dumps({'head':head,'parents':parents,'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'original_changed_blobs_preserved':True,'real_host_pg_e2e':'NOT_RUN'},indent=2)+'\n',encoding='utf-8')
env=os.environ.copy()
for key in list(env):
    if key.endswith(('_API_KEY','_TOKEN','_SECRET')) or key in {'DATABASE_URL','TEST_POSTGRES_DATABASE_URL','E2E_DATABASE_URL','COLLABORATION_DEV_SESSIONS_JSON','PACKAGED_CONTROL_PIPE'}:env.pop(key,None)
temp=ROOT/'.runtime/public-combined-temp';temp.mkdir(parents=True,exist_ok=True)
env.update(PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',TEMP=str(temp),TMP=str(temp),CI='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',ENABLE_PROVIDER_FALLBACK='false')
commands=[('combined-source-closure',ROOT,[sys.executable,'-B','scripts/public_build.py','--source','.']),('combined-public-closure',ROOT,[sys.executable,'-B','-m','pytest','--noconftest','tests/test_public_build_c40_closure.py','-q','-p','no:cacheprovider','--basetemp',str(ROOT/'.runtime/public-combined-pytest'),'--junitxml',str(OUT/'combined-public-closure.xml')]),('combined-template-controller',ROOT/'frontend',[r'C:\Program Files\nodejs\node.exe','node_modules/vitest/vitest.mjs','run','src/creative/GraphTextTemplateController.integration.test.tsx'])]
for label,cwd,args in commands:
    label+=tag
    assert not (OUT/(label+'.log')).exists()
    with (OUT/(label+'.log')).open('wb')as log:r=subprocess.run(args,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
    (OUT/(label+'.json')).write_text(json.dumps({'head':head,'args':args,'cwd':str(cwd),'exit':r.returncode},indent=2)+'\n',encoding='utf-8');print(label+' exit='+str(r.returncode),flush=True)
    if r.returncode:raise SystemExit(r.returncode)
