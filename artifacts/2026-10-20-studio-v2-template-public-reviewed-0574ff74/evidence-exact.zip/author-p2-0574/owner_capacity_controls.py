from pathlib import Path
from copy import deepcopy
import hashlib,json
import app.creative.graph_models as owner
SOURCE=Path(r'D:\codex数据\2026-10-19\task\studio-v2-independent-c40\app\creative\graph_models.py')
REVIEW=Path(r'D:\codex数据\2026-10-20\task\graph-template-3300636a-review-20261020')
OUT=Path(__file__).parent
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()=='911e9beaf4ac55f9f164ab4fe1327c905c9db949cbf97d11410c2748b8729b0e'
assert Path(owner.__file__).resolve()==SOURCE.resolve()
payload=json.loads((REVIEW/'boundary-candidate.json').read_text(encoding='utf-8'))['definition']
try:owner.GraphInput.model_validate(payload)
except ValueError as error:
    assert 'CREATIVE_GRAPH_DEFINITION_CAPACITY' in str(error);rejection=str(error)
else:raise AssertionError('Original owner failed to reject the review counterexample')
valid=deepcopy(payload);valid['nodes'][0]['parameters']['text']=valid['nodes'][0]['parameters']['text'][:-16]
accepted=owner.GraphInput.model_validate(valid);size=len(owner.canonical(accepted.model_dump()).encode('utf-8'));assert size==95984,size
plain=deepcopy(payload);del plain['presentation'];plain_size=len(owner.canonical(owner.GraphInput.model_validate(plain).model_dump()).encode('utf-8'));assert plain_size==94851,plain_size
result={'owner_source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'counterexample_wire_bytes':len(json.dumps(payload,ensure_ascii=False,separators=(',',':')).encode('utf-8')),'counterexample':'REJECTED_BY_NORMAL_GRAPHINPUT_VALIDATION','rejection':rejection,'adjacent_control_canonical_bytes':size,'adjacent_control':'ACCEPTED_BY_NORMAL_GRAPHINPUT_VALIDATION','node_only_canonical_bytes':plain_size,'model_construct_used':False,'host_pg_save_model_calls':'NOT_RUN'}
(OUT/'owner-capacity-controls.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');(OUT/'adjacent-valid-definition.json').write_text(json.dumps(valid,ensure_ascii=False,separators=(',',':')),encoding='utf-8');print(json.dumps(result,ensure_ascii=False,indent=2))
