# 0574 模板两项P2独立关闭复核

结论：**专项 PASS，可在隔离组合分支整合**。原330报告两项P2已由faeb4d975c4fb44db39132538371f01658d2ff18和0574ff74e4d0b40472d26a737172bfac7fec7f5f修复；本次未发现新增阻断。不是DSH725、Host/模型、Windows完整E2E或PG验收，也未自行merge/cherry-pick/push。

固定HEAD `0574ff74e4d0b40472d26a737172bfac7fec7f5f`，tree `6c4e7ebd30a1835457ab16787026ad7e7b7fefa1`。历史是3c4dd726→faeb4d97→0574ff74，保留330与16f整合祖先。作者bundle SHA256 `582654d99249f9400e4ba125f82fc97a280d44a2a2b2bce52c4c902cc28286f9`，git bundle verify通过；两修复相对3c4仅10路径，未改后端模型或96,000上限。

## F1 已关闭：整体字节准入与本地原子性

`frontend/src/creative/graphTextTemplates.ts:65`最终完整定义复用原graphNoteDefinitionBytes，包含所有追加节点/边/组/便笺与目标原内容。

- 原31,223汉字反例：纯计划拒绝且target对象不变；实际视图提供的模板组件在确认前显示通用容量/兼容性拒绝，没有Apply入口；目标draft、past/future和selection全部逐值不变。
- 31,207汉字邻近正例：JS wire 95,950，原保守准入95,998；原Python GraphInput.model_validate正常接受，canonical95,984。
- 原31,223汉字去视觉对照：原Python模型接受，canonical94,851；原旧反例定义仍被原Python模型以CREATIVE_GRAPH_DEFINITION_CAPACITY拒绝。没有model_construct或放宽上限。

独立证据：boundary-result.json、actual-view-result.json、backend-controls.json；输入与脚本全部保留。实际后端模型SHA256 `911e9beaf4ac55f9f164ab4fe1327c905c9db949cbf97d11410c2748b8729b0e`，与固定0574逐字节相同。

## F2 已关闭：同批变更不再复活确认

`useStudioGraphEditorController.ts:458–465`以原同步bindingMutationEpoch及insertionCurrent派生模板scope/current；`studioGraphEditorView.tsx:228`真实调用点使用新模板边界。

直接读取固定Git对象，挂原controller，从真实studioGraphEditorView内容中取其提供的GraphTextTemplateTools元素（只渲染该元素，避免无关画布几何）。原反例的同一React act批次：先原change标题，再保留旧Apply回调，标题保留、无导入节点，selection不变，只有作者编辑那一次历史。再次调用旧Apply仍无作用。

同批A→B→原A与重渲染后旧回调同样被拒，past只包含两次作者change。正常含两节点/一边/两组/一便笺的模板追加，双击保留Apply只消费一次，past新增1，原travel一次撤销完全回到原draft，一次重做逐值恢复全部视觉字段与ID。saveCalls=0，runCalls=0。

独立证据：actual-view-result.json（4场景、148固定来源模块）和actual-view-source-hashes.json。未用旧测试中的broad current接线掩盖产品修复；没有继承作者46PASS或历史57PASS。

## 执行与限制

本次只有3个纯计划检查、4个实际调用点/原controller场景、3份原后端模型数据对照；无全量测试/构建/真实provider。原容量反例及正常控制输入保持相同来源和规模，旧330证据没有覆盖。

首次UI审查脚本误等内部详细容量文案，产品实际显示通用“模板读取或兼容性检查失败”。该次失败和输入保存在initial-actual-view.*；只将匹配器修正为真实文案后重跑并通过，未改产品。

仅读取固定Git对象和已存在依赖，未创建worktree/复制node_modules。原主开发工作树的下一切片不读取、不修改。Public16f原生symlink WinError1314限制仍保留，不作为本专项重新测试或验收。DSH725另有独立BLOCKED报告，不能随本专项结论并入。
