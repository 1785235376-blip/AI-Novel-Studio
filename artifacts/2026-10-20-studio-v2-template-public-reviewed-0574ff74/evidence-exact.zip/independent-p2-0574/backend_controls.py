import sys,pathlib,json,hashlib
sys.stdout.reconfigure(encoding='utf-8');sys.path.insert(0,r'D:\codex数据\2026-10-20\task\public-build-c40')
from app.creative.graph_models import GraphInput
from app.experimental.store import canonical
p=pathlib.Path(__file__).parent
old=pathlib.Path(r'D:\codex数据\2026-10-20\task\graph-template-3300636a-review-20261020\boundary-candidate.json');original=json.loads(old.read_text(encoding='utf-8'))['definition'];results=[]
for name,v,expected in [('original-counterexample',original,False),('near-boundary-valid',json.loads((p/'near-boundary-valid.json').read_text(encoding='utf-8')),True),('node-only-valid',json.loads((p/'node-only-valid.json').read_text(encoding='utf-8')),True)]:
 try:
  model=GraphInput.model_validate(v);row={'name':name,'accepted':True,'canonical_bytes':len(canonical(model.model_dump()).encode('utf-8'))}
 except Exception as e:row={'name':name,'accepted':False,'error':str(e)}
 assert row['accepted']==expected,row;results.append(row)
result={'module':sys.modules[GraphInput.__module__].__file__,'source_sha256':hashlib.sha256(pathlib.Path(sys.modules[GraphInput.__module__].__file__).read_bytes()).hexdigest(),'results':results};(p/'backend-controls.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result,ensure_ascii=False))
