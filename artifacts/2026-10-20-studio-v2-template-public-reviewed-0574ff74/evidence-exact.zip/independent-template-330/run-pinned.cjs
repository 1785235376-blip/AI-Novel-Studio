const fs = require('fs');
const path = require('path');
const cp = require('child_process');
const crypto = require('crypto');
const Module = require('module');
const repo = 'D:/codex数据/2026-10-19/task/studio-v2-independent-c40';
const tip = process.env.POEMSEED_REVIEW_COMMIT || '3300636a91761f59bb150b9f871327a9574cfe62';
if (!['3300636a91761f59bb150b9f871327a9574cfe62', 'c40aec6d7ccf5162bef7a2a054ff45b6baf2b13b'].includes(tip)) throw Error('Unexpected review commit');
const deps = 'D:/codex数据/2026-10-19/task/studio-v2-comic-live-handoff-browser/frontend/node_modules';
const req = Module.createRequire(path.join(deps, '..', 'package.json'));
const esbuild = Module.createRequire(req.resolve('vite'))('esbuild');
const { JSDOM } = req('jsdom');
const dom = new JSDOM('<!doctype html><html><body></body></html>', { url: 'http://localhost/' });
for (const key of ['window', 'document', 'navigator', 'Element', 'HTMLElement', 'HTMLInputElement', 'Node', 'Event', 'MouseEvent', 'localStorage']) {
  Object.defineProperty(globalThis, key, { value: dom.window[key], configurable: true });
}
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
const source = new Map();
function read(rel) {
  if (source.has(rel)) return source.get(rel);
  const r = cp.spawnSync('git', ['--no-optional-locks', '-C', repo, 'show', tip + ':' + rel], { encoding: 'utf8', windowsHide: true });
  if (r.status !== 0) return null;
  source.set(rel, r.stdout); return r.stdout;
}
function resolve(rel) {
  for (const candidate of [rel, rel + '.ts', rel + '.tsx', rel + '.js', rel + '.json', rel + '/index.ts', rel + '/index.tsx']) {
    if (read(candidate) !== null) return candidate;
  }
  throw Error('Pinned import not found: ' + rel);
}
async function main() {
  const entry = process.argv[2];
  if (!entry || path.basename(entry) !== entry) throw Error('Expected an audit entry basename');
  const built = await esbuild.build({
    stdin: { contents: fs.readFileSync(path.join(__dirname, entry), 'utf8'), loader: 'tsx', sourcefile: entry },
    bundle: true, write: false, platform: 'node', format: 'cjs', jsx: 'automatic', logLevel: 'silent',
    define: { 'import.meta.env': '{}' },
    plugins: [{ name: 'fixed-git-objects-only', setup(build) {
      build.onResolve({ filter: /^pinned:/ }, args => ({ path: resolve(args.path.slice(7)), namespace: 'fixed-git' }));
      build.onResolve({ filter: /^\./, namespace: 'fixed-git' }, args => ({ path: resolve(path.posix.normalize(path.posix.join(path.posix.dirname(args.importer), args.path))), namespace: 'fixed-git' }));
      build.onResolve({ filter: /.*/ }, args => {
        if (args.namespace === 'fixed-git' && args.path.startsWith('.')) return;
        if (args.path.startsWith('node:') || Module.builtinModules.includes(args.path)) return { path: args.path, external: true };
        return { path: req.resolve(args.path), external: true };
      });
      build.onLoad({ filter: /.*/, namespace: 'fixed-git' }, args => ({
        contents: args.path.endsWith('.css') ? 'export default "";' : read(args.path),
        loader: args.path.endsWith('.tsx') ? 'tsx' : args.path.endsWith('.json') ? 'json' : args.path.endsWith('.css') ? 'js' : 'ts',
      }));
    } }],
  });
  const label = process.argv[3] || path.parse(entry).name;
  if (path.basename(label) !== label) throw Error('Expected an audit output basename');
  fs.writeFileSync(path.join(__dirname, label + '-source-hashes.json'), JSON.stringify([...source].map(([file, content]) => ({ path: file, sha256: crypto.createHash('sha256').update(content).digest('hex') })), null, 2));
  const loaded = new Module(path.join(__dirname, label + '-virtual.cjs'), module);
  loaded.filename = path.join(__dirname, label + '-virtual.cjs');
  loaded.paths = [deps, ...module.paths]; loaded._compile(built.outputFiles[0].text, loaded.filename);
  const result = await loaded.exports.run(__dirname);
  fs.writeFileSync(path.join(__dirname, label + '-result.json'), JSON.stringify({ tip, sourceModules: source.size, ...result }, null, 2));
  console.log(JSON.stringify({ tip, sourceModules: source.size, ...result }));
  dom.window.close();
}
main().catch(error => { console.error(error.stack); process.exitCode = 1; dom.window.close(); });
