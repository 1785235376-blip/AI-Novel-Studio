import React from 'react';
import { act, cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { GraphTextTemplateTools } from 'pinned:frontend/src/creative/GraphTextTemplateTools';
import { blankGraph } from 'pinned:frontend/src/creative/graphDraft';
import { modelCatalog } from 'pinned:frontend/src/creative/studioGraphModel.testFixtures';
import { exportTextGraphTemplate } from 'pinned:frontend/src/creative/graphTextTemplates';
import { useStudioGraphEditorController } from 'pinned:frontend/src/creative/useStudioGraphEditorController';
export async function run() {
  let control: any;
  const initial: any = { active: true, denied: false, identity: 'audit:actor', canMutate: true, canReview: true, busy: false, externalDirty: false, isCurrent: () => true, read: (f: any) => f(), mutate: (f: any) => f(), client: { graphs: { catalog: async () => modelCatalog(), list: async () => ({ items: [] }) } } };
  function Mounted() { const c = useStudioGraphEditorController(initial); control = c; return c.catalog ? <GraphTextTemplateTools definition={c.draft} catalog={c.catalog} owner={c.insertionScope} disabled={!c.editable} isCurrent={c.current} onApply={(d, ids) => { c.change(d); c.setSelected(ids); }} /> : null; }
  render(<Mounted />); await waitFor(() => { if (!control.editable) throw Error('not ready'); });
  const raw = exportTextGraphTemplate({ ...blankGraph(), nodes: [{ id: 'Input', definition_id: 'text_input', definition_version: 1, enabled: true, parameters: { text: 'author' }, position: { x: 0, y: 0 } }] });
  fireEvent.change(screen.getByLabelText('导入文字图模板 JSON'), { target: { files: [{ size: Buffer.byteLength(raw), text: async () => raw }] } }); await screen.findByText(/将新增 1 个节点/); fireEvent.click(screen.getByLabelText('确认仅把模板追加到当前本地草稿'));
  const button = screen.getByText('明确追加模板节点'), key = Object.keys(button).find(k => k.startsWith('__reactProps$'))!, apply = (button as any)[key].onClick;
  act(() => { control.change({ ...control.draft, title: 'Intervening author edit' }); apply(); });
  const result = { expectedTitle: 'Intervening author edit', observedTitle: control.draft.title, importedNodes: control.draft.nodes.length, preserved: control.draft.title === 'Intervening author edit' };
  cleanup(); return { observations: [result] };
}
