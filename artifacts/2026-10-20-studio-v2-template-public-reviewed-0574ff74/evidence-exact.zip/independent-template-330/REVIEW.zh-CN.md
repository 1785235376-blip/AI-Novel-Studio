# 3300636a 固定提交独立审查

**结论：BLOCKED_PENDING_AUTHOR_FIX。** 有1项本切片容量缺陷，另有1项自c40继承且本轮明确复现的确认护栏缺口，均为P2。建议作者修复并提交新的固定HEAD后再整合；本审查未修改产品。

- 固定base：`c40aec6d7ccf5162bef7a2a054ff45b6baf2b13b`。
- 固定HEAD：`3300636a91761f59bb150b9f871327a9574cfe62`，tree `1e3ded4edacefda185d701390e9e61d2d8f3171d`；直接父提交为c40。
- 六文件，201插入/16删除；未涉及Hermia公开清单或DSH互动文件。
- 作者58项证据SHA256全部匹配；6份提交源码OID/大小/SHA256与result.json一致；bundle verify通过。交付.patch与`git diff --binary c40..3300636a`逐字节一致，它是普通diff，不能当format-patch mbox用git am；保留原提交身份应使用bundle。

## F1 / P2：新增视觉追加的容量检查与原后端不一致

位置：`frontend/src/creative/graphTextTemplates.ts:64–65`。

新增检查只计量JavaScript的`JSON.stringify(definition)`，随后调用的前端decoder仍按相同JS数值拼写计量。原`graphCanvasNotesHelpers.ts:10–27`已有数值规范化预留；原Python `GraphInput`在`app/creative/graph_models.py:772–773`按Pydantic规范化后的canonical JSON执行96000字节硬限制。Position/Viewport转换成float后，整数的`.0`增加实际字节。

最小已执行反例：4个目标text_input节点合计31223个汉字；追加2节点/1连接、2分组、1张256汉字便笺。模板计划正常返回，JS整图为95998字节；相同原模型规范化后为96032字节，正常`GraphInput.model_validate`报`CREATIVE_GRAPH_DEFINITION_CAPACITY`。原便笺保守计量为96046。去除视觉内容后，同一批节点的后端计量94851字节且校验通过。因此并非输入节点本身已经超限。

文件：`boundary-candidate.json`保留完整返回定义；`backend-boundary-verdict.json`保留原模型拒绝；`backend-canonical-size.json`保留精确计量和去视觉内容对照。诊断计量对各嵌套模型单独校验后仅用model_construct查看序列化；正常GraphInput拒绝已另外真实执行，不以construct替代验收。

影响：计划可被确认写入本地草稿，但原Save不能接收该整图，未兑现原96000字节整体拒绝。未执行真实Save或持久化。

验收条件：组合全部节点、连接、分组、便笺后复用原保守／canonical兼容的整图字节准入，在onApply前拒绝且目标与history不变。增加“JS未超限而Python规范化超限”反例及紧邻下界的有效对照，不扩大后端限额。

## F2 / P2：同批次草稿变化后，旧确认仍能覆盖整个目标

位置：`frontend/src/creative/GraphTextTemplateTools.tsx:35–38`；原调用点`studioGraphEditorView.tsx:228`。

该护栏依赖React重渲染后变化的props/token与宽泛current检查，原控制器change会先同步更新draftRef。确认后，在同一个React批次先调用原`control.change({...draft,title:'Intervening author edit'})`，再调用保留的Apply，旧整图计划仍被接收：观察标题回到`独立创作图`，新增节点数为1。没有调用Save/run。

这是一个控制层故障注入复现，不宣称真实浏览器手势已经发生持久化丢失。它验证的是作者自身旧回调护栏承诺与用户要求的确认后状态变化边界。普通重渲染后的target替换、disabled ABA均正确拒绝。

在固定c40原组件／原控制器上执行同一反例，结果相同；apply函数块与330完全相同。因此明确归类为继承缺口，不归咎本次新增201行。

文件：`ui-probes-result.json`中的`observations.preserved=false`，以及`same-batch-c40-baseline-result.json`。runner的该项PASS仅表示观察步骤完成，不计为产品通过；本报告总状态仍BLOCKED。

验收条件：在调用原change前，使用原控制器当前draftRef／mutation generation与预览捕获的目标作同步CAS；确认过期时不应用旧整图。回归同批次先修改再旧Apply，保留新输入、拒绝旧计划；继续保证正常追加只消耗一次确认、整份视觉内容一次撤销／重做。

## 本轮确认通过的范围

5项纯函数定向检查：父组晚于子组及源/目标同名ID仍正确映射；成员/内部连接指向新节点；目标原presentation不变；图comment/view不携带且隐藏authority字段拒绝；便笺Unicode/256 codepoint边界；合计12000字符、坐标越界及原始JS超限时均整体拒绝且输入不变。多条断言归为5个场景，不夸大数量。

3项React／原控制器正向检查：HTML形状便笺按原React纯文本显示，没有注入img；重渲染后target替换和disabled ABA使旧确认失效；正常确认一次追加全部分组/便笺，保留的重复Apply无效，一次原undo回到完整先前状态、一次redo精确恢复视觉ID及内容，Save/run调用为0。

便笺“清洗”在此表现为闭合字段、类型/字符/几何限额、排除权限和图级私有上下文，并保留作者原纯文本。没有新HTML解释器或富文本执行。未把保留合法markup字符串误报为XSS。

## 方法与限制

所有项目模块由内存esbuild插件从固定Git对象加载，纯函数35模块、React89模块；基线对照85模块。相应源SHA256表保留。现有Vite/esbuild/jsdom/React依赖只读复用，无新worktree、整库副本、依赖复制、安装、预览服务器或全量构建。Python模型源码与固定330逐字节一致，只执行类型及字节校验，没有启动API或存储owner。

这是受控jsdom／原React控制器与原Python模型的独立定向审查，不是真实Host、PG、原生浏览器/Windows应用E2E或Release验收。作者57PASS、构建和截图仅作为原证据核对，未继承为本审查的全产品PASS。

初始审查runner的pnpm依赖定位、虚拟Module文件名和UTF8打印诊断均在审查目录内纠正，产品未改；`runner-setup-failures-transcription.txt`明确标为转录，未伪装成原始命令日志。初次窄范围字节搜索未找到候选，原始输出保留；随后改为针对同一字节上限的有界二分定位，没有运行全套测试。

本审查未push、merge、修改任何产品文件、提交或作者证据，也没有跨线程发信尝试。由协调线程转发结论及两个验收条件。
