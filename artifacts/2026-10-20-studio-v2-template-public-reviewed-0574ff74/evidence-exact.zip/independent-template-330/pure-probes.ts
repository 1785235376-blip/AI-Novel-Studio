import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { blankGraph } from 'pinned:frontend/src/creative/graphDraft';
import { modelCatalog } from 'pinned:frontend/src/creative/studioGraphModel.testFixtures';
import { exportTextGraphTemplate, readTextGraphTemplate, planTextGraphTemplate } from 'pinned:frontend/src/creative/graphTextTemplates';
import { graphNoteDefinitionBytes } from 'pinned:frontend/src/creative/graphCanvasNotesHelpers';
const node = (id: string, text = 'author') => ({ id, definition_id: 'text_input', definition_version: 1, enabled: true, parameters: { text }, position: { x: 0, y: 0 } });
const source = () => ({ ...blankGraph(), nodes: [node('A'), { id: 'B', definition_id: 'draft_prepare', definition_version: 1, enabled: true, parameters: {}, position: { x: 400, y: 0 } }], edges: [{ id: 'Edge', source_node_id: 'A', source_port: 'text', target_node_id: 'B', target_port: 'text' }], presentation: { groups: [{ id: 'Child', name: 'child', parent_id: 'Parent', node_ids: ['B'] }, { id: 'Parent', name: 'parent', node_ids: ['A'] }], notes: [{ id: 'Note', text: 'author 🐈\n<img src=x onerror=alert(1)>', position: { x: 0, y: 250 } }] } });
export async function run(out: string) {
  const checks: any[] = [];
  function check(name: string, fn: () => void) { try { fn(); checks.push({ name, status: 'PASS' }); } catch (e) { checks.push({ name, status: 'FAIL', error: String(e) }); } }
  check('Reversed parent order and overlapping source/target IDs remap every member without mutation', () => {
    const from = source(), target = { ...blankGraph(), nodes: [node('A')], presentation: { groups: [{ id: 'Parent', name: 'existing', node_ids: ['A'] }], notes: [{ id: 'Note', text: 'existing', position: { x: -30, y: -20 } }] } };
    const before = JSON.stringify([from, target]); const result = planTextGraphTemplate(exportTextGraphTemplate(from), target, modelCatalog()).result;
    assert.equal(JSON.stringify([from, target]), before); const [existing, child, parent] = result.definition.presentation.groups;
    assert.equal(child.parent_id, parent.id); assert.deepEqual(child.node_ids, [result.selected[1]]); assert.deepEqual(parent.node_ids, [result.selected[0]]);
    assert.equal(existing.id, 'Parent'); assert.equal(result.definition.presentation.notes[0].id, 'Note');
    assert.deepEqual(result.definition.edges[0].source_node_id, result.selected[0]); assert.deepEqual(result.definition.edges[0].target_node_id, result.selected[1]);
    const all = [...result.definition.nodes, ...result.definition.edges, ...result.definition.presentation.groups, ...result.definition.presentation.notes].map(x => x.id);
    assert.equal(all.length, new Set(all).size);
  });
  check('Portable visual payload excludes graph comment/view and rejects hidden authority fields', () => {
    const from = source(); Object.assign(from.presentation, { comment: 'private graph context', view: { show_grid: true, snap: true, grid_step: 16, show_minimap: true } });
    const raw = exportTextGraphTemplate(from), read = readTextGraphTemplate(raw); assert.equal(read.presentation.comment, undefined); assert.equal(read.presentation.view, undefined);
    for (const where of ['group', 'note', 'position']) { const data = JSON.parse(raw); const row = where === 'group' ? data.definition.presentation.groups[0] : where === 'note' ? data.definition.presentation.notes[0] : data.definition.presentation.notes[0].position; row.execution_receipt = 'untrusted'; assert.throws(() => readTextGraphTemplate(JSON.stringify(data))); }
    assert.equal(read.presentation.notes[0].text, from.presentation.notes[0].text);
    const data = JSON.parse(raw); data.definition.presentation.notes[0].text = '🐈'.repeat(257); assert.throws(() => readTextGraphTemplate(JSON.stringify(data)));
  });
  check('Combined note text quota rejects atomically', () => {
    const from = source(); from.presentation.notes[0].text = 'x'.repeat(256); const target = { ...blankGraph(), presentation: { notes: Array.from({ length: 47 }, (_, i) => ({ id: 'T' + i, text: 'x'.repeat(250), position: { x: 0, y: 0 } })) } }; const before = JSON.stringify(target);
    assert.throws(() => planTextGraphTemplate(exportTextGraphTemplate(from), target, modelCatalog())); assert.equal(JSON.stringify(target), before);
  });
  check('Translated note outside original coordinate boundary rejects atomically', () => {
    const from = source(); from.presentation.notes[0].position.x = 100000; const target = blankGraph(), before = JSON.stringify(target);
    assert.throws(() => planTextGraphTemplate(exportTextGraphTemplate(from), target, modelCatalog())); assert.equal(JSON.stringify(target), before);
  });
  check('Presentation can cross 96000 even when node-only append fits, without target mutation', () => {
    const from = source(); from.presentation.notes[0].text = '字'.repeat(256); const target = { ...blankGraph(), nodes: Array.from({ length: 4 }, (_, i) => node('T' + i, '字'.repeat(7850))) }, before = JSON.stringify(target); const plain = structuredClone(from); delete plain.presentation;
    planTextGraphTemplate(exportTextGraphTemplate(plain), target, modelCatalog()); assert.throws(() => planTextGraphTemplate(exportTextGraphTemplate(from), target, modelCatalog())); assert.equal(JSON.stringify(target), before);
  });
  let boundary: any = null;
  const from = source(); from.presentation.notes[0].text = '字'.repeat(256); const raw = exportTextGraphTemplate(from);
  const targetFor = (total: number, pad = 0) => ({ ...blankGraph(), nodes: Array.from({ length: 4 }, (_, i) => node('T' + i, '字'.repeat(Math.floor(total / 4) + (i < total % 4 ? 1 : 0)) + (i === 0 ? 'a'.repeat(pad) : ''))) });
  let low = 0, high = 32000, best = 0;
  while (low <= high) { const middle = Math.floor((low + high) / 2); try { planTextGraphTemplate(raw, targetFor(middle), modelCatalog()); best = middle; low = middle + 1; } catch { high = middle - 1; } }
  for (let pad = 0; pad < 3 && !boundary; pad++) {
    try { const next = planTextGraphTemplate(raw, targetFor(best, pad), modelCatalog()).result.definition; const wire = Buffer.byteLength(JSON.stringify(next)); const reserved = graphNoteDefinitionBytes(next); if (wire <= 96000 && reserved > 96000) { boundary = { targetTextCodepoints: best, asciiPad: pad, frontendWireBytes: wire, originalNoteAdmissionBytes: reserved, definition: next }; } } catch {}
  }
  if (boundary) fs.writeFileSync(path.join(out, 'boundary-candidate.json'), JSON.stringify(boundary));
  return { checks, boundaryCandidate: boundary && { targetTextCodepoints: boundary.targetTextCodepoints, asciiPad: boundary.asciiPad, frontendWireBytes: boundary.frontendWireBytes, originalNoteAdmissionBytes: boundary.originalNoteAdmissionBytes }, failures: checks.filter(x => x.status === 'FAIL').length };
}
