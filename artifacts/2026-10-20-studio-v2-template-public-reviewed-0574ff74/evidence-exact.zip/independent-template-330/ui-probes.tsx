import React from 'react';
import assert from 'node:assert/strict';
import { act, cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { GraphTextTemplateTools } from 'pinned:frontend/src/creative/GraphTextTemplateTools';
import { GraphNoteCards } from 'pinned:frontend/src/creative/GraphCanvasNotes';
import { blankGraph } from 'pinned:frontend/src/creative/graphDraft';
import { modelCatalog } from 'pinned:frontend/src/creative/studioGraphModel.testFixtures';
import { exportTextGraphTemplate } from 'pinned:frontend/src/creative/graphTextTemplates';
import { useStudioGraphEditorController } from 'pinned:frontend/src/creative/useStudioGraphEditorController';
const graph = () => ({ ...blankGraph(), nodes: [{ id: 'Input', definition_id: 'text_input', definition_version: 1, enabled: true, parameters: { text: 'author' }, position: { x: 0, y: 0 } }], presentation: { groups: [{ id: 'G', name: 'author group', node_ids: ['Input'] }], notes: [{ id: 'N', text: '<img src=x onerror=alert(1)>\n🐈', position: { x: 0, y: 250 } }] } });
function retained(element: HTMLElement) { const key = Object.keys(element).find(k => k.startsWith('__reactProps$'))!; return (element as any)[key].onClick; }
async function stage() { const raw = exportTextGraphTemplate(graph()); fireEvent.change(screen.getByLabelText('导入文字图模板 JSON'), { target: { files: [{ size: Buffer.byteLength(raw), text: async () => raw }] } }); await screen.findByText(/将新增 1 个节点/); fireEvent.click(screen.getByLabelText('确认仅把模板追加到当前本地草稿')); return retained(screen.getByText('明确追加模板节点')); }
export async function run() {
  const checks: any[] = [], observations: any[] = [];
  async function check(name: string, fn: () => Promise<void> | void) { try { await fn(); checks.push({ name, status: 'PASS' }); } catch (e) { checks.push({ name, status: 'FAIL', error: String(e) }); } finally { cleanup(); } }
  await check('Imported note markup is displayed as literal text, with no injected image', () => {
    render(<GraphNoteCards definition={graph() as any} blocked={false} selected={null} onSelect={() => {}} onChange={() => {}} size={{ width: 1000, height: 900 }} />);
    assert.equal(document.querySelectorAll('img').length, 0); assert.ok(document.body.textContent!.includes('<img src=x onerror=alert(1)>'));
  });
  await check('Confirmed preview expires after target replacement and disabled ABA', async () => {
    let applied = 0; const p = { definition: blankGraph(), catalog: modelCatalog(), owner: {}, disabled: false, isCurrent: () => true, onApply: () => { applied++; } };
    const view = render(<GraphTextTemplateTools {...p} />); const old = await stage(); view.rerender(<GraphTextTemplateTools {...p} definition={{ ...blankGraph(), title: 'changed target' }} />); act(old); assert.equal(applied, 0);
    view.rerender(<GraphTextTemplateTools {...p} />); const second = await stage(); view.rerender(<GraphTextTemplateTools {...p} disabled />); view.rerender(<GraphTextTemplateTools {...p} />); act(second); assert.equal(applied, 0);
  });
  let control: any; let save = 0, run = 0;
  const initial: any = { active: true, denied: false, identity: 'audit:actor', canMutate: true, canReview: true, busy: false, externalDirty: false, isCurrent: () => true, read: (f: any) => f(), mutate: (f: any) => f(), client: { graphs: { catalog: async () => modelCatalog(), list: async () => ({ items: [] }), create: async () => { save++; }, createRun: async () => { run++; } } } };
  function Mounted() { const c = useStudioGraphEditorController(initial); control = c; return <>{c.catalog && <GraphTextTemplateTools definition={c.draft} catalog={c.catalog} owner={c.insertionScope} disabled={!c.editable} isCurrent={c.current} onApply={(d, selected) => { c.change(d); c.setSelected(selected); }} />}<output>{JSON.stringify(c.draft)}</output></>; }
  await check('Original controller commits all visual fields once, with one undo/redo and no Save/run', async () => {
    render(<Mounted />); await waitFor(() => assert.ok(control.editable)); const before = structuredClone(control.draft), apply = await stage(); act(() => { apply(); apply(); });
    const appended = structuredClone(control.draft); assert.equal(appended.nodes.length, 1); assert.equal(appended.presentation.groups.length, 1); assert.equal(appended.presentation.notes.length, 1);
    act(() => control.travel(false)); assert.deepEqual(control.draft, before); act(() => control.travel(true)); assert.deepEqual(control.draft, appended); assert.equal(save, 0); assert.equal(run, 0);
  });
  await check('Observe an intervening original change in the same React batch before retained Apply', async () => {
    render(<Mounted />); await waitFor(() => assert.ok(control.editable)); const apply = await stage();
    act(() => { control.change({ ...control.draft, title: 'Intervening author edit' }); apply(); });
    observations.push({ name: 'same-batch-intervening-edit', expectedTitle: 'Intervening author edit', observedTitle: control.draft.title, importedNodes: control.draft.nodes.length, preserved: control.draft.title === 'Intervening author edit' });
  });
  return { checks, observations, saveCalls: save, runCalls: run, failures: checks.filter(x => x.status === 'FAIL').length };
}
