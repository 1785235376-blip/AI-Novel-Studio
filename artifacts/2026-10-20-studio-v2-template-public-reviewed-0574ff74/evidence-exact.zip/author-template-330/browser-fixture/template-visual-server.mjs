import {createServer} from 'vite';
const server=await createServer({cacheDir:'.runtime/template-vite-cache',optimizeDeps:{entries:['.runtime/template-visual/index.html']},server:{host:'127.0.0.1',port:5336,strictPort:true,proxy:{}}});
await server.listen();console.log('CONTROLLED_TEMPLATE_FIXTURE_READY http://127.0.0.1:5336/.runtime/template-visual/');
const close=async()=>{await server.close();process.exit(0)};process.on('SIGTERM',close);process.on('SIGINT',close);
