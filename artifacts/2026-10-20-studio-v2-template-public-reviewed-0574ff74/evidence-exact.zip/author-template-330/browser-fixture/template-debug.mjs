import { createServer } from 'vite';
const server = await createServer({server: {middlewareMode: true}, appType: 'custom'});
try {
 const {blankGraph} = await server.ssrLoadModule('/src/creative/graphDraft.ts');
 const {modelCatalog} = await server.ssrLoadModule('/src/creative/studioGraphModel.testFixtures.ts');
 const {exportTextGraphTemplate,planTextGraphTemplate} = await server.ssrLoadModule('/src/creative/graphTextTemplates.ts');
 const {checkedLocalGraphDefinition} = await server.ssrLoadModule('/src/creative/studioGraphLocalDraft.ts');
 const {graphSelectionCopy} = await server.ssrLoadModule('/src/creative/graphSelectionCopy.ts');
 const source=blankGraph();source.nodes=[{id:'Input',definition_id:'text_input',definition_version:1,enabled:true,position:{x:0,y:0},parameters:{text:'Author text'}},{id:'Draft',definition_id:'draft_prepare',definition_version:1,enabled:true,position:{x:400,y:0},parameters:{}}];source.edges=[{id:'Edge',source_node_id:'Input',source_port:'text',target_node_id:'Draft',target_port:'text'}];source.presentation={groups:[{id:'Parent',name:'父分组',node_ids:['Input']},{id:'Child',name:'子分组',node_ids:['Draft'],parent_id:'Parent'}],notes:[{id:'Note',text:'字'.repeat(256),position:{x:20,y:280}}]};
 const target=blankGraph();target.nodes=Array.from({length:4},(_,i)=>({...source.nodes[0],id:`Existing_${i}`,parameters:{text:'字'.repeat(7850)}}));
 for(const [name,fn]of [['target',()=>checkedLocalGraphDefinition(target)],['source',()=>exportTextGraphTemplate(source)],['copied',()=>{const result=graphSelectionCopy(source,source.nodes.map(n=>n.id),modelCatalog(),target);console.log('pre-byte',new TextEncoder().encode(JSON.stringify(result.definition)).length);checkedLocalGraphDefinition(result.definition);}],['full',()=>planTextGraphTemplate(exportTextGraphTemplate(source),target,modelCatalog())]])try{fn();console.log(name,'OK')}catch(e){console.log(name,e.stack)}
} finally {await server.close();}
