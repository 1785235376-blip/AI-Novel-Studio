import path from 'node:path';
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {chromium} from '@playwright/test';
const out=process.argv[2];assert(out);
const browser=await chromium.launch({headless:true,executablePath:'C:/Users/admin/AppData/Local/ms-playwright/chromium_headless_shell-1234/chrome-headless-shell-win64/chrome-headless-shell.exe'});
try{const page=await browser.newPage({viewport:{width:1440,height:900},deviceScaleFactor:1,locale:'zh-CN',timezoneId:'Asia/Shanghai',reducedMotion:'reduce'});await page.goto('http://127.0.0.1:5336/.runtime/template-visual/');await page.evaluate(()=>document.fonts.ready);
await page.getByLabel('导入文字图模板 JSON',{exact:true}).setInputFiles({name:'annotated-template.json',mimeType:'application/json',buffer:Buffer.from(await page.evaluate(()=>window.__templateRaw))});await page.getByText(/将新增 2 个节点/).waitFor();await page.getByLabel('确认仅把模板追加到当前本地草稿',{exact:true}).check();await page.getByRole('button',{name:'明确追加模板节点',exact:true}).click();await page.waitForFunction(()=>window.__templateState.draft.nodes.length===2);
await page.locator('.graph-canvas__viewport').scrollIntoViewIfNeeded();await page.locator('[data-graph-note-id]').waitFor();assert.equal(await page.locator('[data-graph-group-id]').count(),2);assert((await page.locator('[data-graph-note-id]').textContent()).includes('保留作者便笺 🐈'));
await page.screenshot({path:path.join(out,'template-canvas-1440.png'),fullPage:false});const state=await page.evaluate(()=>window.__templateState);assert.equal(state.calls.save,0);assert.equal(state.calls.run,0);fs.writeFileSync(path.join(out,'template-canvas-results.json'),JSON.stringify({groupsRendered:2,notesRendered:1,viewport:{width:1440,height:900},calls:state.calls,host:'NOT_RUN'},null,2)+'\n');console.log('Original GraphCanvas: 2 group frames + Unicode note rendered; no Save/run.');}finally{await browser.close()}
