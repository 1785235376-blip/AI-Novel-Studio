import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {chromium} from '@playwright/test';
const out=process.argv[2];assert(out);const results=[];
const browser=await chromium.launch({headless:true,executablePath:'C:/Users/admin/AppData/Local/ms-playwright/chromium_headless_shell-1234/chrome-headless-shell-win64/chrome-headless-shell.exe'});
try{for(const viewport of [{width:1366,height:768},{width:1440,height:900},{width:1920,height:1080}]){
 const context=await browser.newContext({viewport,deviceScaleFactor:1,locale:'zh-CN',timezoneId:'Asia/Shanghai',reducedMotion:'reduce'});const page=await context.newPage(),errors=[],requests=[];
 page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(!r.url().startsWith('http://127.0.0.1:5336/'))requests.push(r.url())});
 await page.goto('http://127.0.0.1:5336/.runtime/template-visual/');await page.evaluate(()=>document.fonts.ready);await page.addStyleTag({content:'*,*::before,*::after{animation:none!important;transition:none!important;caret-color:transparent!important}'});
 await page.getByLabel('导入文字图模板 JSON',{exact:true}).waitFor();const raw=await page.evaluate(()=>window.__templateRaw);
 await page.getByLabel('导入文字图模板 JSON',{exact:true}).setInputFiles({name:'annotated-template.json',mimeType:'application/json',buffer:Buffer.from(raw)});
 await page.getByText(/将新增 2 个节点、1 条内部连接、2 个视觉分组、1 条便笺/).waitFor();
 assert(await page.getByRole('button',{name:'明确追加模板节点',exact:true}).isDisabled());
 const geometry=await page.locator('section[aria-label="文字图模板复用"]').evaluate(el=>{const r=el.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,right:r.right,scrollWidth:el.scrollWidth,clientWidth:el.clientWidth,documentWidth:document.documentElement.scrollWidth}});
 assert(geometry.right<=viewport.width+1);assert(geometry.documentWidth<=viewport.width+1);assert(geometry.scrollWidth<=geometry.clientWidth+1);
 await page.screenshot({path:path.join(out,`template-preview-${viewport.width}.png`),fullPage:false});
 await page.getByLabel('确认仅把模板追加到当前本地草稿',{exact:true}).check();await page.getByRole('button',{name:'明确追加模板节点',exact:true}).click();
 await page.waitForFunction(()=>window.__templateState.draft.nodes.length===2);const applied=await page.evaluate(()=>window.__templateState);
 assert.equal(applied.draft.presentation.groups.length,2);assert.equal(applied.draft.presentation.groups[1].parent_id,applied.draft.presentation.groups[0].id);assert.equal(applied.draft.presentation.notes[0].text,'保留作者便笺 🐈\n第二行');assert(!applied.draft.nodes.some(n=>['Input','Draft'].includes(n.id)));assert.equal(applied.calls.save,0);assert.equal(applied.calls.run,0);
 await page.getByRole('button',{name:'原历史：撤销',exact:true}).click();await page.waitForFunction(()=>window.__templateState.draft.nodes.length===0);assert.equal(await page.evaluate(()=>window.__templateState.draft.presentation),undefined);
 await page.getByRole('button',{name:'原历史：重做',exact:true}).click();await page.waitForFunction(()=>window.__templateState.draft.nodes.length===2);assert.deepEqual(await page.evaluate(()=>window.__templateState.draft.presentation),applied.draft.presentation);
 await page.screenshot({path:path.join(out,`template-applied-${viewport.width}.png`),fullPage:false});assert.deepEqual(errors,[]);assert.deepEqual(requests,[]);results.push({viewport,geometry,groups:2,notes:1,undoRedo:true,calls:applied.calls,pageErrors:errors,externalRequests:requests,host:'NOT_RUN',fixture:'ORIGINAL_REACT_COMPONENTS_WITH_STATIC_CLIENT'});await context.close();
}fs.writeFileSync(path.join(out,'template-browser-results.json'),JSON.stringify(results,null,2)+'\n');console.log(JSON.stringify({passed:results.length,viewports:results.map(r=>r.viewport),host:'NOT_RUN'}));}finally{await browser.close()}
