# 分镜采用关联导演摄影参数：本地交接

已完成限定作者能力及最小实际验证，待父任务独立审查。未推送、合并、自动归档、生成 bundle、Tag 或 Release。

- 提交：`dc69b31728098f07c998474899baa1ec4b83ecfd`
- 直接父版本：`0ec1991024bd1ed4bac57a6ab61c0a3057aa3320`
- tree：`d3371f90301c950d095034e7a636133b2eb995a8`
- 分支：`work/v2-storyboard-director-camera-adoption-20261019`
- 源码 owner：`<local-workspace>\poemseed-v2-storyboard-camera-adoption`，工作树干净。

## 范围与 owner

映射原 Feature Matrix 的 DIR-03（摄影控制）/DIR-08（镜头语言）有限缺口；不把历史 PARTIAL 改成整项完成。输入是当前分镜保留的根级 `director_notes` 来源快照，以及镜头的原 `director_note_ids`；不追随上游最新导演、不新建关联。输出由原 `CreativeCanvas.onChange` 写入 `CreativeInput.shots` 作者草稿；原 CreativeWorkspace/CreativeClient/CreativeService 继续负责脏表单、权限、Save/CAS 与版本历史。

在分镜场景里展开“从关联导演调度采用摄影参数”，选择一条原调度、1–4 个同场景已关联镜头及摄影字段，预览逐镜头旧/新值后明确确认。仅景别、机位角度、运镜、焦距和构图可被选择；空的可选来源会明确预览为清空。时长、画面/视频提示、摄影几何、动作、连续性、来源、素材、原调度及嵌入快照均不复制或改写；不调用任何模型或新增 API，不自动 Save。原保存后的版本及审核规则不变。

一次采用可撤销；后续编辑、保存、离开场景或权限/busy/version 变化使撤销失效，避免覆盖后来输入。来源/绑定/选择 ABA、同一批次取消选择后的旧确认回调、重复采用都被拒绝。纯函数同时拒绝未关联/跨场景/重复/缺失目标、多于四镜头、重复来源 ID、越界或非摄影字段。

只改四文件，249行增加：`CreativeCanvas.tsx` 的 import/挂载2行；新增 `StoryboardDirectorCameraAdoption.tsx`70行、`storyboardDirectorCameraAdoptionHelpers.ts`46行、`StoryboardDirectorCameraAdoption.test.tsx`131行。均在 `frontend/src/creative/`。后端、Graph/client、DSH六保留面板、共享壳、token/CSS、原 Save 或运行 owner 未改。

本分支仍直接基于0ec，未把待审8e修复混入。`8e17abe2262333459bcfd8d59da4b1998ff3d5f7` 原修复工作树 HEAD 与干净状态已核对不变；此功能的 client 文件与0ec字节内容相同。父任务可在审查决定后把四文件增量接入已接受基线，本任务未串行整合。

## 验证：保留原始失败

| 项目 | 原始结果与最终结果 |
|---|---|
| 定向单测 | 首次 `targeted-once.log` 13 failed/3 passed：Windows 下 helper `.ts` 与组件 `.tsx` 名称只差大小写/后缀，导入到了 helper。给 helper 改为独立 `...Helpers.ts` 名称后，`targeted-renamed.log` **16 passed**（13新 +3原 Canvas 回归）。未放松断言。 |
| 类型/构建 | 各两次：同一名称解析错误失败，改名后 `types-renamed` / `build-renamed` **exit0**。保留原大 chunk 警告。恢复执行器后源文件未再改，没有重复全套检查。 |
| 共享壳 | `protected-visual.log` **6 passed**：原 NOVEL/IMAGE/VIDEO 三基准及1366/1440/1920三几何项；未更新快照。 |
| 真实创建/派生/基线 | `browser-first` 经原 UI 创建导演v1、原 derive 得分镜v1，添加/关联镜头后原 Save 到v2。脚本随后因精确 label 定位 select 失败，未产生采用保存；截图/DOM/写入记录保留。 |
| 恢复 | `browser-resumed` grep锚定不当 No tests found，零操作；`browser-resumed2` 因执行通道断连无最终 receipt。恢复时读原日志/进程归属及真实 File：仍v2，旧worker146820已不存在，才继续。`browser-recovered3` 又因原应用已自动恢复唯一项目、脚本仍找首页按钮而失败，无写入。均为保留的 harness/执行故障。 |
| 实际采用/撤销/Save | 修正导航/语义角色定位后，`browser-recovered4` 的 **C通过**。两镜头、两字段共4项差异；预览/确认/撤销/再确认期间无 HTTP 写入，最后点击原 Save 才有一次 PUT v2→v3。完整对照确认第三镜头、全部原调度/场景/source_documents不变。 |
| 全新重开 | 同轮B已看到WIDE/35mm，因含原文的textarea精确label定位失败。改用实际textbox角色后，仅重跑只读B；`browser-reopened5` **B通过**，新上下文读v3、原画面与历史，零写入/零pageerror/零外部请求，3桌面宽度无横向溢出。没有重复采用或保存。 |

实际 File 数据：项目`file`；导演`43816d38-f32c-4a57-a44a-a8f6bbe0fc86`v1；分镜`27dc4f1d-6321-46bd-9b8f-f20f1acd3321`最终v3。`browser-ledger.json`/`real-file-history.json`/`verified-v3-before-readonly-reopen.json`保留原始回包。C与B来自分段成功，不声称一次全绿完整旅程。

最后交接核对的首次原始JSON相等断言失败：PowerShell把created_at/updated_at及history内同名日期从+00:00重新序列化为+08:00。仅对这两个元数据字段按UTC等价归一化后，全结构比较通过，没有排除字段或改变产品/测试断言；原捕获不改，见`capture-format-observation.json`。

可视证据：`adoption-preview-1440.png`、`adoption-reopened-1366.png`、`adoption-reopened-1440.png`、`adoption-reopened-1920.png`。截图已审视，沿用原共享壳和原生表单/共享按钮。

未运行：PG、真实协作撤权浏览器验收、新的服务端CAS冲突浏览器用例、IMAGE/VIDEO Graph交接宿主及完整产品/正式需求验收。实际浏览器使用原 NOVEL 宿主的 V2 作者工作台；没有模型、GPU、云端或新增付费调用。

## 收尾与清理

`browser-stop-receipt.json`证明记录中的backend143532/frontend151936经命令/启动时间核对后关闭，自有19126/5320端口释放；演示18913/5293未触碰。

先生成 `cleanup-plan-before.json` 列出恢复依据、逐文件指纹和保留项，再在源码已提交、服务已停后执行。`cleanup-receipt.json`确认删除 **5,760,541字节（约5.49MiB）/5项**：可重建Vite dist、TS增量文件、本任务临时缓存，以及2张与原Playwright失败PNG完全同SHA的手动截图；原附件图片、唯一失败/日志都保留。全盘空闲量变化可能包含其他任务，不能当成本次清理收益。

保留唯一C源码、单个必要D执行镜像（C父目录权限限制使esbuild需该镜像）、共享node_modules junction、原File最小恢复profile与唯一证据。没有新复制完整源码快照或依赖，不清理任何其他任务/用户目录。原 `PAUSED.json` / `RESUMED.json` 是历史检查点；当前完成状态以 `review-handoff.json` 为准。

请父任务安排独立审查并协调接入8e后的已接受基线。当前无执行阻断；右键菜单继续延期。
