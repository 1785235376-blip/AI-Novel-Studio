// @vitest-environment jsdom
import {useState} from 'react';
import { act, cleanup, fireEvent, render, screen, within } from '@testing-library/react';
import { afterEach, expect, it, vi } from 'vitest';
import { writeFileSync } from 'node:fs';
import { CreativeCanvas } from '<local-workspace>/poemseed-v2-storyboard-camera-adoption/frontend/src/creative/CreativeCanvas';
import { previewStoryboardDirectorCameraAdoption } from '<local-workspace>/poemseed-v2-storyboard-camera-adoption/frontend/src/creative/storyboardDirectorCameraAdoptionHelpers';
import { newDocument, newScene, newShot, type CreativeInput, type DirectorSceneNote } from '<local-workspace>/poemseed-v2-storyboard-camera-adoption/frontend/src/creative/types';
import { emptyCameraGrammar } from '<local-workspace>/poemseed-v2-storyboard-camera-adoption/frontend/src/creative/cameraGrammar';

afterEach(cleanup);
const log = (name: string, data: unknown) => writeFileSync(name,JSON.stringify(data,null,2));
function fixture():CreativeInput {
 const note:DirectorSceneNote={id:'camera-source',number:1,scene_id:'scene-a',duration_seconds:11,note:'source text',blocking:'door',shot_size:'CLOSE_UP',camera_angle:'HIGH_ANGLE',camera_motion:'PAN',lens:'85mm',composition:'foreground left',emotion:'tense',pacing:'quick',performance:'pause'};
 return {...newDocument('STORYBOARD'),title:'Independent preservation probe',source_independent:true,source_chapter_ids:['chapter-pin'],
  scenes:[{...newScene(1),id:'scene-a',action:'Keep scene action'},{...newScene(2),id:'scene-b'}],
  director_notes:[note,{...note,id:'other-scene-note',scene_id:'scene-b',number:2}],
  shots:Array.from({length:6},(_,i)=>({...newShot(i+1,i===5?'scene-b':'scene-a'),id:'shot-'+(i+1),
   director_note_ids:[i===5?'other-scene-note':'camera-source'],duration_seconds:7+i,frame_prompt:'Keep prompt '+i,video_generation_hint:'Keep video '+i,
   lens:'35mm',composition:'center '+i,color:'blue',action:'walk',dialogue:[{speaker:'Actor',text:'Keep line'}],sound:'room tone',
   continuity:{previous_shot_id:i?'shot-'+i:null,next_shot_id:i<5?'shot-'+(i+2):null,characters:'A',outfit:'red',environment:'room',camera:'same',time:'night',lighting:'soft'},
   camera_grammar:emptyCameraGrammar(),director_notes:[{...note,note:'Preserved shot snapshot'}]}))};
}
function canvasProps(draft=fixture()) {return {draft,version:7,dirty:true,canEdit:true,busy:false,selectedSceneId:'scene-a',selectedShotId:'shot-1',onScene:vi.fn(),onShot:vi.fn(),onChange:vi.fn(),onSave:vi.fn(),onNew:vi.fn()};}
const panel=()=>within(screen.getByLabelText('分镜采用导演摄影参数'));
function choose() {
 fireEvent.change(panel().getByLabelText('采用摄影参数的原导演调度'),{target:{value:'camera-source'}});
 fireEvent.click(panel().getByLabelText('采用目标镜头 1 · shot-1'));
 fireEvent.click(panel().getByLabelText('采用镜头与焦距'));
 fireEvent.click(panel().getByText('预览采用导演摄影参数'));
}
function clickHandler(node:HTMLElement):()=>void {
 const key=Object.keys(node).find(key=>key.startsWith('__reactProps$'))!;
 return (node as unknown as Record<string,{onClick:()=>void}>)[key].onClick;
}

it('retires original Canvas approvals across draft/source/scene/version ABA and same-batch field changes',()=>{
 const observed=[];
 for(const mode of ['draft','source','scene','version','same_batch']) {
  const initial=canvasProps(),before=structuredClone(initial.draft),view=render(<CreativeCanvas {...initial}/>);choose();
  const old=clickHandler(panel().getByText('确认采用到分镜草稿（尚未保存）'));
  if(mode==='same_batch')act(()=>{fireEvent.click(panel().getByLabelText('采用镜头与焦距'));old();});
  else {
   const next={...initial};
   if(mode==='draft')next.draft={...initial.draft,shots:initial.draft.shots.map((shot,i)=>i?shot:{...shot,frame_prompt:'new author edit'})};
   if(mode==='source')next.draft={...initial.draft,director_notes:initial.draft.director_notes.map((note,i)=>i?note:{...note,lens:'24mm'})};
   if(mode==='scene')next.selectedSceneId='scene-b';if(mode==='version')next.version=8;
   view.rerender(<CreativeCanvas {...next}/>);expect(panel().queryByText('确认采用到分镜草稿（尚未保存）')).toBeNull();
   view.rerender(<CreativeCanvas {...initial}/>);act(old);
  }
  expect(initial.onChange).not.toHaveBeenCalled();expect(initial.onSave).not.toHaveBeenCalled();expect(initial.draft).toEqual(before);
  observed.push({mode,stale_writes:initial.onChange.mock.calls.length,save_calls:initial.onSave.mock.calls.length});view.unmount();
 }
 log('case1-stale.json',{observed});
});

it('patches exactly two selected fields on four linked shots, preserving every other document value and identity',()=>{
 const input=fixture(),before=structuredClone(input),ids=['shot-4','shot-2','shot-1','shot-3'];
 input.director_notes[0].composition=null;
 const frozen=structuredClone(input),result=previewStoryboardDirectorCameraAdoption(input,'scene-a','camera-source',ids,['lens','composition']);
 const expected=structuredClone(frozen);
 for(const shot of expected.shots)if(ids.includes(shot.id)){shot.lens='85mm';shot.composition='';}
 expect(result.draft).toEqual(expected);expect(input).toEqual(frozen);expect(result.changes).toHaveLength(8);
 expect(result.draft.scenes).toBe(input.scenes);expect(result.draft.director_notes).toBe(input.director_notes);
 for(let i=0;i<4;i++){
  expect(result.draft.shots[i].camera_grammar).toBe(input.shots[i].camera_grammar);
  expect(result.draft.shots[i].continuity).toBe(input.shots[i].continuity);
  expect(result.draft.shots[i].director_notes).toBe(input.shots[i].director_notes);
 }
 for(const i of [4,5])expect(result.draft.shots[i]).toBe(input.shots[i]);
 for(const fields of [['duration_seconds'],['frame_prompt'],['camera_grammar'],['director_note_ids']])
  expect(()=>previewStoryboardDirectorCameraAdoption(input,'scene-a','camera-source',['shot-1'],fields as never)).toThrow();
 expect(input).toEqual(frozen);
 log('case2-preservation.json',{selected_ids:ids,fields:['lens','composition'],changes:result.changes,before:frozen,after:result.draft,nonselected_identity_preserved:true,forbidden_fields_rejected:4});
});

it('keeps ordinary undo local, retires old undo after later edits, permission/busy/version changes and unmount',()=>{
 const observed=[];
 for(const mode of ['ordinary','author_edit','authority','busy','version','unmount']) {
  const initial=canvasProps();let setParent:(value:typeof initial)=>void=()=>{throw Error('parent not ready')};
  function Harness(){
   const [parent,setValue]=useState(initial);setParent=setValue;
   const onChange=(draft:CreativeInput)=>{initial.onChange(draft);setValue(value=>({...value,draft,dirty:true}));};
   return <CreativeCanvas {...parent} onChange={onChange}/>;
  }
  const view=render(<Harness/>);choose();
  const apply=clickHandler(panel().getByText('确认采用到分镜草稿（尚未保存）'));
  act(()=>{apply();apply();});expect(initial.onChange).toHaveBeenCalledTimes(1);
  const adopted=initial.onChange.mock.calls[0][0] as CreativeInput;
  const current={...initial,draft:adopted};
  const undo=clickHandler(panel().getByText('撤销本次导演摄影采用'));
  if(mode==='ordinary'){
   act(()=>{undo();undo();});expect(initial.onChange).toHaveBeenCalledTimes(2);expect(initial.onChange.mock.calls[1][0]).toEqual(initial.draft);
  }else if(mode==='unmount'){
   view.unmount();act(()=>{undo();apply();});expect(initial.onChange).toHaveBeenCalledTimes(1);
  }else{
   const next={...current};
   if(mode==='author_edit')next.draft={...adopted,title:'later title',shots:adopted.shots.map((shot,i)=>i?shot:{...shot,lens:'author 135mm'})};
   if(mode==='authority')next.canEdit=false;if(mode==='busy')next.busy=true;if(mode==='version')next.version=8;
   act(()=>setParent(next));
   expect((panel().getByText('撤销本次导演摄影采用') as HTMLButtonElement).disabled).toBe(true);
   act(()=>{undo();apply();});expect(initial.onChange).toHaveBeenCalledTimes(1);
   act(()=>setParent(current));act(()=>{undo();apply();});expect(initial.onChange).toHaveBeenCalledTimes(1);
   if(mode==='author_edit')expect(next.draft.shots[0].lens).toBe('author 135mm');
  }
  expect(initial.onSave).not.toHaveBeenCalled();observed.push({mode,changes:initial.onChange.mock.calls.length,save_calls:0});view.unmount();
 }
 log('case3-undo-permission.json',{observed});
});
