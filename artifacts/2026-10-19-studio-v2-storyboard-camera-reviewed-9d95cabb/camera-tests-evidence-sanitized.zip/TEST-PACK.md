# Bounded storyboard camera adoption

The product bundle contains the original added camera tests. independent/camera-independent.test.tsx retains the corrected controlled-parent review harness; probe-initial plus correction diff and both logs preserve the initial harness failure. The three unique independent cases passed across the two documented runs, not one all-green run.

Use a disposable worktree with the documented a997 prerequisite and existing offline frontend dependencies. The integration selected only the original Canvas apply/undo/Save mock-host case and existing denoise receipt decoder; full original suites and actual API/browser were not rerun.

Author real original File Save v2-to-v3, interrupted-worker recovery and fresh-browser reopen are retained segmented evidence. GET/Save equality normalized only created_at/updated_at metadata to UTC; raw capture hashes are retained in inventory. No automatic model/API write is introduced by the new draft adoption surface. PG, real collaborative browser revocation and full E2E remain unaccepted.
