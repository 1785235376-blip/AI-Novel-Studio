const fs = require('node:fs');
const path = require('node:path');
const front = path.resolve(__dirname, '../portable-cache-budget/frontend');
const { chromium } = require(path.join(front, 'node_modules/@playwright/test'));
const out = path.join(__dirname, 'visual'); fs.mkdirSync(out, { recursive: true });
const ensure = (value, message) => { if (!value) throw new Error(message); };
(async () => {
  const browser = await chromium.launch({ headless: true });
  const results = [];
  try {
    for (const [width, height] of [[1366, 768], [1440, 900], [1920, 1080]]) {
      const page = await browser.newPage({ viewport: { width, height } }), errors = [];
      page.on('pageerror', error => errors.push(String(error)));
      await page.goto('http://127.0.0.1:5333/.portable-budget-preview.html');
      const budget = page.getByRole('region', { name: '可重建导出缓存预算' });
      await budget.waitFor();
      await budget.evaluate(element => element.scrollIntoView({ block: 'start' }));
      const geometry = await page.evaluate(() => {
        const main = document.querySelector('.main-workspace');
        const rects = ['.workspace-sidebar', '.main-workspace', '.workspace-inspector'].map(selector => {
          const r = document.querySelector(selector).getBoundingClientRect(); return { selector, x: r.x, y: r.y, width: r.width, height: r.height, right: r.right };
        });
        return { viewport: { width: innerWidth, height: innerHeight }, documentWidth: document.documentElement.scrollWidth, mainWidth: main.clientWidth, mainScrollWidth: main.scrollWidth, rects };
      });
      ensure(geometry.documentWidth <= width + 1 && geometry.mainScrollWidth <= geometry.mainWidth + 1, 'Horizontal overflow');
      ensure(geometry.rects.every(r => r.x >= 0 && r.right <= width + 1 && r.width > 0 && r.height > 0), 'Shell geometry outside viewport');
      const input = page.getByLabel('导出缓存预算上限（字节，留空为未配置）');
      await input.fill('5000000'); await input.focus(); await page.keyboard.press('Tab');
      ensure(await page.getByRole('button', { name: '保存导出缓存预算' }).evaluate(el => el === document.activeElement), 'Budget save keyboard order');
      await page.getByRole('button', { name: '放弃预算输入并载入当前策略' }).click();
      await page.getByRole('button', { name: '采用预算回收计划（尚不清理）' }).click();
      const confirm = page.getByLabel('已核对当前预览，只清理列出的可重建缓存'); await confirm.focus(); await page.keyboard.press('Space');
      ensure(await confirm.isChecked(), 'Explicit checkbox keyboard interaction');
      ensure(await page.getByRole('button', { name: '确认清理预览中的缓存' }).isEnabled(), 'Explicit fixture cleanup did not become available');
      const writes = await page.evaluate(() => window.__fixtureWrites);
      ensure(!writes.length && !errors.length, 'Unexpected write or runtime error');
      await budget.evaluate(element => element.scrollIntoView({ block: 'start' }));
      const screenshot = path.join(out, `portable-budget-${width}x${height}.png`); await page.screenshot({ path: screenshot });
      results.push({ width, height, mode: 'isolated AppShell + actual panel, synthetic GET transport', geometry, keyboard: 'PASS', writes, errors, screenshot });
      await page.close();
    }
    const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
    await page.goto('http://127.0.0.1:5333/.portable-budget-preview.html?unknown=1');
    await page.getByText(/不能将未知占用视为零/).waitFor();
    ensure(await page.getByRole('button', { name: '采用预算回收计划（尚不清理）' }).isDisabled(), 'Unknown plan must be unavailable');
    ensure((await page.getByRole('region', { name: '可重建导出缓存预算' }).innerText()).includes('占用：未知'), 'Unknown displayed as zero');
    await page.getByRole('region', { name: '可重建导出缓存预算' }).evaluate(element => element.scrollIntoView({ block: 'start' }));
    const screenshot = path.join(out, 'portable-budget-unknown-1440x900.png'); await page.screenshot({ path: screenshot });
    const writes = await page.evaluate(() => window.__fixtureWrites); ensure(!writes.length, 'Unexpected unknown write');
    results.push({ state: 'UNKNOWN', width: 1440, height: 900, writes, plan: 'disabled', screenshot }); await page.close();
    fs.writeFileSync(path.join(__dirname, 'visual-final.json'), JSON.stringify({ status: 'PASS', real_user_cache: 'NOT_ACCESSED', real_backend_cleanup: 'NOT_RUN', results }, null, 2));
    process.stdout.write(JSON.stringify({ status: 'PASS', viewports: results.length, realBackendCleanup: false }));
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
