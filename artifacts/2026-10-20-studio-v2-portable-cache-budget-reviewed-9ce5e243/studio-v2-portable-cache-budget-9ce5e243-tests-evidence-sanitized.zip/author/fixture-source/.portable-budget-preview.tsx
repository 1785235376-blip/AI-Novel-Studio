import React from 'react';
import { createRoot } from 'react-dom/client';
import './src/ui/ui.css';
import './src/ui/fixture.css';
import './src/ui/desktop-craft.css';
import './src/experimental/experimental.css';
import { AppShell } from './src/ui/AppShell';
import { PortableProjectsPanel } from './src/experimental/PortableProjectsPanel';
import { experimentalClient } from './src/experimental/api';
const unknown = new URLSearchParams(location.search).has('unknown');
const storage = {
  categories: [{ kind: 'MANUSCRIPT', bytes: 3200, cleanable: false }, { kind: 'HISTORY', bytes: 6400, cleanable: false }, { kind: 'REPRODUCIBLE_CACHE', bytes: 10000000, cleanable: true }, { kind: 'TEMPORARY_FAILED_FILES', bytes: 1200, cleanable: false }],
  eligible: [{ id: 'fixture-old', version: 1, bytes: 4000000, sha256: 'b'.repeat(64) }, { id: 'fixture-new', version: 1, bytes: 6000000, sha256: 'c'.repeat(64) }], preview_digest: 'a'.repeat(64),
  cache_budget: { policy: { version: 1, limit_bytes: 6000000 }, scope: 'CURRENT_AUTHOR_SCOPE_REPRODUCIBLE_PORTABLE_EXPORTS_ONLY', advisory_only: true, automatic_cleanup: false,
    state: unknown ? 'UNKNOWN' : 'OVER_BUDGET', excess_bytes: unknown ? null : 4000000,
    measurement: { state: unknown ? 'UNKNOWN' : 'MEASURED', bytes: unknown ? null : 10000000, verified_reproducible_bytes: 10000000, unmeasured_records: unknown ? 1 : 0 },
    plan: { record_ids: unknown ? [] : ['fixture-old'], reclaim_bytes: unknown ? 0 : 4000000, remaining_excess_bytes: unknown ? null : 0, complete: !unknown } },
};
const writes: unknown[] = []; (window as any).__fixtureWrites = writes;
window.fetch = async (input, init) => {
  const url = String(input);
  if (init?.method !== 'GET') { writes.push({ url, init }); return new Response('{}', { status: 503 }); }
  const value = url.endsWith('/storage') ? storage : url.endsWith('/catalog') ? { chapters: [{ id: 'fixture-chapter', title: '合成正文', version: 1 }], missing: [], restore_available: true, limitations: [] } : { items: [] };
  return new Response(JSON.stringify(value), { status: 200 });
};
const client = experimentalClient('fixture-project', { sessionToken: 'fixture-host', scope: { branchId: 'fixture-branch' } as any });
createRoot(document.getElementById('root')!).render(<AppShell module="NOVEL" onModuleChange={() => {}}
  scope={{ workspace: '测试工作区', project: '便携缓存预算', storyline: '主线', branch: '当前分支' }} actor="测试作者"
  sidebar={<div className="placeholder-sidebar"><h2>项目导航</h2><p>项目便携与资源恢复</p></div>}
  main={<div className="experimental-workbench"><PortableProjectsPanel client={client} /></div>}
  inspector={<div className="fixture-inspector"><h2>隔离检查</h2><p>只使用合成缓存记录，未访问用户目录。预算规划无自动清理。</p></div>}
  status="File fixture · 明确确认后清理 · 无真实删除" />);
