import original from '../../portable-cache-budget/frontend/vite.config';
export default { ...original, cacheDir: '<TASK_ROOT>/task-12/portable-cache-budget-evidence/runtime/vite-cache' };
