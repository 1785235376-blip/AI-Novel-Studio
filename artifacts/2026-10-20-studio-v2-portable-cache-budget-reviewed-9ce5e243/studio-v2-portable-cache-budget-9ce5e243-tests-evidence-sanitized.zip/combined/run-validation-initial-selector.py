from pathlib import Path
import os,subprocess,json,time,concurrent.futures,xml.etree.ElementTree as ET
root=Path(__file__).resolve().parent.parent;ev=Path(__file__).resolve().parent;own=root/'portable-budget-combined';front=own/'frontend';profile=own/'.runtime/profile';target=root.parent/'task/studio-v2-impact-decisions/frontend/node_modules';link=front/'node_modules';python=Path(r'<TASK_ROOT>\task-3\evidence\otio-metadata-p2\tools\pytest8-venv\Scripts\python.exe')
assert not link.exists() and target.is_dir();p=subprocess.run(['cmd','/d','/c','mklink','/J',str(link),str(target)],capture_output=True);assert p.returncode==0 and os.path.realpath(link)==os.path.realpath(target)
assert not profile.exists();profile.mkdir(parents=True);assert profile.resolve().is_relative_to(own.resolve())
env={k:v for k,v in os.environ.items() if not any(x in k.upper() for x in ['API_KEY','TOKEN','SECRET','DATABASE_URL','DEV_SESSION']) and k not in ['COLLABORATION_DEV_SESSIONS_JSON','PACKAGED_CONTROL_PIPE']};env.pop('CREATIVE_GRAPH_CONDITIONS_V1',None);env.update(PROJECT_ROOT=str(own),PYTHONPATH=str(own)+';'+str(own/'tests'),NOVEL_DATA_PATH=str(profile/'data'),LOCALAPPDATA=str(profile/'Local'),APPDATA=str(profile/'Roaming'),USERPROFILE=str(profile/'user'),XDG_DATA_HOME=str(profile/'xdg-data'),XDG_CONFIG_HOME=str(profile/'xdg-config'),XDG_CACHE_HOME=str(profile/'xdg-cache'),CREDENTIAL_VAULT_BACKEND='memory',STORAGE_BACKEND='file',PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',PYTHONIOENCODING='utf-8',ENABLE_PACKAGED_RUNTIME='false',ENABLE_COLLABORATION_RUNTIME='false',MOCK_PROVIDER='true',ENABLE_CLOUD='false',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1');results={}
config=ev/'pytest.ini';config.write_text('[pytest]\nmarkers =\n    file_backend_only: isolated File contract\n    postgres_backend_only: PostgreSQL contract\n',encoding='utf-8')
def run(name,cmd,cwd):
 (ev/(name+'-command.json')).write_text(json.dumps(dict(command=cmd,cwd=str(cwd),external_credentials_removed=True,profile_root=str(profile),fixture_only=True,symlink_or_real_user_cleanup=False),ensure_ascii=False,indent=2)+'\n',encoding='utf-8');t=time.time()
 with (ev/(name+'.log')).open('wb') as f:p=subprocess.run(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
 results[name]=dict(exit=p.returncode,seconds=round(time.time()-t,3),log=name+'.log');print(name,json.dumps(results[name]),flush=True);assert p.returncode==0,name+' failed; retained log'
common=[str(python),'-B','-m','pytest','-c',str(config),'-p','no:cacheprovider']
collection=common+['tests/test_v2_portable_cache_policy.py','--collect-only','-q','-m','file_backend_only','-k','test_budget_plans_oldest_verified_cache_without_deletion_then_reuses_original_cleanup or test_unreadable_or_unverified_occupancy_is_unknown_and_no_plan_is_fabricated or test_source_change_at_each_confirmation_guard_is_rechecked_before_unlink']
run('collection',collection,own)
nodes=[line.strip() for line in (ev/'collection.log').read_text(encoding='utf-8').splitlines() if line.startswith('tests/test_v2_portable_cache_policy.py::')];selected=[]
for node in nodes:
 if 'test_source_change_at_each_confirmation_guard' not in node or '3' in node.rsplit('[',1)[-1].rstrip(']').split('-'):selected.append(node)
assert len(selected)==3 and all('file' in n.rsplit('[',1)[-1] and 'postgres' not in n for n in selected);(ev/'selected-backend-nodes.json').write_text(json.dumps(selected,indent=2)+'\n',encoding='utf-8')
backend=common+selected+['-q','--basetemp='+str(own/'.runtime/pytest-portable-budget'),'--junitxml='+str(ev/'backend.xml')]
frontend=['node','node_modules/vitest/vitest.mjs','run','src/experimental/PortableProjectsBudget.test.tsx','-t','renders measured advisory budget|unknown occupancy is shown as unknown','--maxWorkers=1','--minWorkers=1','--no-file-parallelism','--no-cache','--reporter=default','--reporter=junit','--outputFile='+str(ev/'frontend.xml')]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 tasks=[pool.submit(run,'backend',backend,own),pool.submit(run,'frontend',frontend,front)]
 for task in tasks:task.result()
for name,count in [('backend',3),('frontend',2)]:
 cases=ET.parse(ev/(name+'.xml')).getroot().findall('.//testcase');passed=[x for x in cases if x.find('skipped') is None and x.find('failure') is None and x.find('error') is None];assert len(passed)==count
run('typescript',['node','node_modules/typescript/bin/tsc','-b','--pretty','false'],front);run('build',['node','node_modules/vite/bin/vite.js','build'],front)
(ev/'validation-results.json').write_text(json.dumps(dict(status='PASS',combined=json.loads((ev/'setup.json').read_text(encoding='utf-8'))['combined'],backend_isolated_File_passed=3,frontend_JSDOM_Mock_panel_passed=2,frontend_other_cases_skipped=6,typescript_runs=1,vite_build_runs=1,results=results,profile_root=str(profile),all_backend_data_below_owned_runtime=True,Windows_symlink_case='NOT_RUN / NOT_ACCEPTED; original1314 remains',real_user_cache_cleanup=False,permissions_or_privileges_changed=False,real_Host=False,PostgreSQL=False,full_E2E=False,models_GPU=False,Audio_U16_not_included=True,schema7_default='OFF',dependency_junction_target=str(target)),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
