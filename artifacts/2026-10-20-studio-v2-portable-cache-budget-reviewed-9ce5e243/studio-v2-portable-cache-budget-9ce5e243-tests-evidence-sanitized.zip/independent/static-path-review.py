import ast
import json
from pathlib import Path
import subprocess

evidence = Path(__file__).parent
repo = evidence.parent / 'ip'
target = '9ce5e243f925f6fb5141046758045c59b1dca46f'
parent = '19d90d51eed4a9683c4290592dd91495125e5fcf'
def git(*args): return subprocess.check_output(['git', *args], cwd=repo).decode('utf-8')
def methods(sha):
    module = ast.parse(git('show', sha + ':app/experimental/portable_projects.py'))
    cls = next(n for n in module.body if isinstance(n, ast.ClassDef) and n.name == 'PortableProjectsService')
    return {n.name: n for n in cls.body if isinstance(n, ast.FunctionDef)}
before, after = methods(parent), methods(target)
for name in ['_file', '_read_file']:
    assert ast.dump(before[name], include_attributes=False) == ast.dump(after[name], include_attributes=False)
unlink = [n for n in ast.walk(after['cleanup']) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == 'unlink']
assert len(unlink) == 1 and ast.unparse(unlink[0]) == 'self._file(ctx, rid).unlink()'
path_source = ast.unparse(after['_file'])
assert 'is_symlink' in path_source and 'root.parents' in path_source and 'digest([ctx.scope, ctx.actor, rid])' in path_source
candidate_source = ast.unparse(after['_cache_candidate'])
assert all(token in candidate_source for token in ['_assert_sources', '_read_file', '_build', 'manifest'])
cleanup_source = ast.unparse(after['cleanup'])
assert cleanup_source.count('reauthorize()') == 3 and 'cache_policy(ctx) != policy' in cleanup_source
assert git('rev-parse', parent + ':tests/test_r4_portable_batches.py').strip() == git('rev-parse', target + ':tests/test_r4_portable_batches.py').strip()
author_evidence = evidence.parent.parent / 'task-12/portable-cache-budget-evidence'
handoff = json.loads((author_evidence / 'handoff.json').read_text(encoding='utf-8'))
assert handoff['backend']['blocked_action_state'] == 'failed before symlink creation'
result = {'status': 'PASS_STATIC_PATH_REVIEW_WITH_WINDOWS_LINK_RUNTIME_UNACCEPTED',
    'fixed_commit': target, 'parent': parent,
    'checks': ['Original _file and _read_file AST unchanged', 'UUID record IDs and scope/actor/id-derived filename; caller submits no arbitrary filesystem path',
        'Existing root, ancestor and target is_symlink checks retained', 'Sole cleanup unlink remains through original self._file(ctx,rid)',
        'Original source, cache SHA and manifest reproducibility checks reused; final authorization call retained with additional policy/source checks',
        'Original blocked symlink test source unchanged'],
    'windows_link_case': {'target': handoff['backend']['blocked_original_test'], 'state': 'ENVIRONMENT_BLOCK / NOT_ACCEPTED',
        'reason': handoff['backend']['block_reason'], 'action_state': 'failed before symlink creation',
        'independently_rerun': False, 'test_not_altered_or_spoofed': True, 'windows_privileges_or_permissions_changed': False},
    'limits': 'Static inspection plus ordinary non-link isolated File fixtures does not establish Windows symlink/reparse or live-user cleanup acceptance.'}
(evidence / 'static-path-review.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print('Static path/owner checks passed; original Windows 1314 symlink case remains NOT_ACCEPTED, not counted as a pass.')
