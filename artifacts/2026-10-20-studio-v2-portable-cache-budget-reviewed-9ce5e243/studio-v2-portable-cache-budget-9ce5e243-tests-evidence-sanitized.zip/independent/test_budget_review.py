"""Four independent groups; only disposable File-owner data may be deleted."""
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from pathlib import Path
import base64

import pytest
from app.experimental.common import StaleSourceError
from app.experimental.portable_cache_policy import cache_budget, CachePolicyInput, MAX_SAFE_BYTES
from app.experimental.portable_projects import PortableProjectsService
from app.experimental.ux import ReadContext
from app.services.v1_capability_service import CapabilityVersionConflict
from test_r3_media_support import rig
from test_r4_portable_batches import work, add_media

EVIDENCE = Path(__file__).parent.resolve()


@pytest.fixture
def isolated(work):
    r = work
    assert r.backend == 'file'
    assert r.root.resolve().is_relative_to(EVIDENCE / 'runtime')
    assert r.portable.cache_root.resolve().is_relative_to(r.root.resolve())
    return r


def exported(r):
    value = r.portable.export(r.ctx, {'chapter_ids': [r.chapter['id']]})
    assert r.portable._file(r.ctx, value['id']).resolve().is_relative_to(r.root.resolve())
    return value


def confirmed(preview, ids):
    return {'preview_digest': preview['preview_digest'], 'record_ids': ids, 'confirmed': True}


def test_group1_actor_scope_isolation_reopen_and_concurrent_cas(isolated):
    r = isolated; before = deepcopy(r.store.read(r.nid, r.scope)); existed = r.portable.cache_root.exists()
    assert r.portable.cache_policy(r.ctx) == {'version': 0, 'limit_bytes': None}
    assert r.store.read(r.nid, r.scope) == before and r.portable.cache_root.exists() == existed
    r.portable.set_cache_policy(r.ctx, {'expected_version': 0, 'limit_bytes': 4096})
    other = ReadContext(r.nid, r.scope, 'separate-review-author')
    branch = ReadContext(r.nid, {'mode': 'collaboration', 'novel_id': r.nid, 'workspace_id': 'review-workspace', 'storyline_id': 'review-story', 'branch_id': 'review-branch'}, r.actor)
    assert r.portable.cache_policy(other)['version'] == r.portable.cache_policy(branch)['version'] == 0
    r.portable.set_cache_policy(other, {'expected_version': 0, 'limit_bytes': 0})
    r.portable.set_cache_policy(branch, {'expected_version': 0, 'limit_bytes': None})
    reopened = PortableProjectsService(r.store, r.novels, r.chapters, sources=r.sources, assets=r.assets)
    assert reopened.cache_policy(r.ctx) == {'version': 1, 'limit_bytes': 4096}
    def update(limit):
        try: return reopened.set_cache_policy(r.ctx, {'expected_version': 1, 'limit_bytes': limit})
        except CapabilityVersionConflict: return 'CONFLICT'
    with ThreadPoolExecutor(max_workers=2) as pool: results = list(pool.map(update, [1024, 2048]))
    assert results.count('CONFLICT') == 1 and reopened.cache_policy(r.ctx)['version'] == 2
    assert reopened.cache_policy(other) == {'version': 1, 'limit_bytes': 0}
    with pytest.raises(CapabilityVersionConflict): reopened.set_cache_policy(r.ctx, {'expected_version': 1, 'limit_bytes': None})


def test_group2_unknown_and_cumulative_budget_and_100_record_limit(isolated, monkeypatch):
    r = isolated; rows = [exported(r), exported(r)]
    initial = r.portable.storage(r.ctx); total = sum(row['bytes'] for row in initial['eligible'])
    r.portable.set_cache_policy(r.ctx, {'expected_version': 0, 'limit_bytes': total})
    equal = r.portable.storage(r.ctx)['cache_budget']
    assert equal['state'] == 'WITHIN_BUDGET' and equal['excess_bytes'] == 0 and equal['plan']['record_ids'] == []
    r.portable.set_cache_policy(r.ctx, {'expected_version': 1, 'limit_bytes': total - 1})
    over = r.portable.storage(r.ctx)['cache_budget']
    assert over['excess_bytes'] == 1 and len(over['plan']['record_ids']) == 1 and over['plan']['complete']
    r.portable.set_cache_policy(r.ctx, {'expected_version': 2, 'limit_bytes': 0})
    original = r.portable._read_file
    def unavailable(ctx, row, *args):
        if row['id'] == rows[0]['id']: raise PermissionError('PRIVATE_REVIEW_CACHE_PATH')
        return original(ctx, row, *args)
    monkeypatch.setattr(r.portable, '_read_file', unavailable)
    preview = r.portable.storage(r.ctx); unknown = preview['cache_budget']
    assert unknown['measurement']['state'] == 'UNKNOWN' and unknown['measurement']['bytes'] is None
    assert unknown['measurement']['verified_reproducible_bytes'] > 0 and unknown['measurement']['unmeasured_records'] == 1
    assert unknown['excess_bytes'] is None and unknown['plan']['record_ids'] == [] and unknown['plan']['remaining_excess_bytes'] is None
    assert 'PRIVATE_REVIEW_CACHE_PATH' not in str(preview)
    assert all(r.portable._file(r.ctx, row['id']).exists() for row in rows)
    # Pure planner boundary; these are arithmetic inputs, not fake media/file measurements.
    candidates = [{'id': str(i), 'bytes': i + 1} for i in range(101)]
    limited = cache_budget({'version': 1, 'limit_bytes': 0}, candidates, 0)
    assert limited['measurement']['bytes'] == 5151 and len(limited['plan']['record_ids']) == 100
    assert limited['plan']['reclaim_bytes'] == 5050 and limited['plan']['remaining_excess_bytes'] == 101 and not limited['plan']['complete']
    boundary = cache_budget({'version': 1, 'limit_bytes': MAX_SAFE_BYTES}, [{'id': 'large', 'bytes': MAX_SAFE_BYTES - 7}, {'id': 'small', 'bytes': 7}], 0)
    assert boundary['state'] == 'WITHIN_BUDGET' and boundary['measurement']['bytes'] == MAX_SAFE_BYTES
    with pytest.raises(ValueError): CachePolicyInput.model_validate({'expected_version': 0, 'limit_bytes': MAX_SAFE_BYTES + 1})


def test_group3_policy_aba_source_and_revocation_invalidate_cleanup_confirmation(isolated):
    r = isolated
    first = exported(r); preview = r.portable.storage(r.ctx)
    r.portable.set_cache_policy(r.ctx, {'expected_version': 0, 'limit_bytes': 0})
    r.portable.set_cache_policy(r.ctx, {'expected_version': 1, 'limit_bytes': None})
    with pytest.raises(StaleSourceError): r.portable.cleanup(r.ctx, confirmed(preview, [first['id']]))
    assert r.portable._file(r.ctx, first['id']).exists()
    source = exported(r); preview = r.portable.storage(r.ctx)
    r.chapters.save(r.chapter['id'], {'content': 'Independent new source revision'})
    with pytest.raises(StaleSourceError): r.portable.cleanup(r.ctx, confirmed(preview, [source['id']]))
    assert r.portable._file(r.ctx, source['id']).exists()
    revoked = exported(r); preview = r.portable.storage(r.ctx); calls = 0
    def deny_final():
        nonlocal calls
        calls += 1
        if calls == 3: raise PermissionError('review final authorization revoked')
    with pytest.raises(PermissionError): r.portable.cleanup(r.ctx, confirmed(preview, [revoked['id']]), deny_final)
    assert calls == 3 and r.portable._file(r.ctx, revoked['id']).exists()
    concurrent = exported(r); preview = r.portable.storage(r.ctx); calls = 0
    def source_at_final():
        nonlocal calls
        calls += 1
        if calls == 3: r.chapters.save(r.chapter['id'], {'content': 'Changed at original final authorization guard'})
    with pytest.raises(StaleSourceError): r.portable.cleanup(r.ctx, confirmed(preview, [concurrent['id']]), source_at_final)
    assert calls == 3 and r.portable._file(r.ctx, concurrent['id']).exists()


def test_group4_only_explicit_original_export_cache_cleanup_and_rebuild(isolated):
    r = isolated; asset, data = add_media(r)
    rows = [exported(r), exported(r)]; first = rows[0]
    original = r.portable.download(r.ctx, first['id'], first['version'])
    recovery = r.portable.preflight_import(r.ctx, {'filename': 'owned-recovery.zip', 'content_base64': base64.b64encode(original).decode()})
    recovery_path = r.portable._file(r.ctx, recovery['id']); recovery_bytes = recovery_path.read_bytes()
    neighbor = r.root / 'unrelated-owned-sentinel.txt'; neighbor.write_text('preserve isolated neighbor', encoding='utf-8')
    history = deepcopy(r.chapters.history(r.chapter['id'])); chapter = deepcopy(r.chapters.get(r.chapter['id']))
    r.portable.set_cache_policy(r.ctx, {'expected_version': 0, 'limit_bytes': 0})
    preview = r.portable.storage(r.ctx)
    assert preview['cache_budget']['automatic_cleanup'] is False
    assert recovery['id'] not in preview['cache_budget']['plan']['record_ids']
    assert all(r.portable._file(r.ctx, row['id']).exists() for row in rows)
    with pytest.raises(ValueError): r.portable.cleanup(r.ctx, {**confirmed(preview, [first['id']]), 'confirmed': False})
    with pytest.raises(ValueError): r.portable.cleanup(r.ctx, confirmed(preview, [recovery['id']]))
    result = r.portable.cleanup(r.ctx, confirmed(preview, [first['id']]))
    assert result['removed_cache_count'] == 1 and not r.portable._file(r.ctx, first['id']).exists()
    assert r.portable._file(r.ctx, rows[1]['id']).exists() and recovery_path.read_bytes() == recovery_bytes
    assert r.assets.content(asset['id']) == data and r.chapters.history(r.chapter['id']) == history and r.chapters.get(r.chapter['id']) == chapter
    assert neighbor.read_text(encoding='utf-8') == 'preserve isolated neighbor'
    assert r.portable.download(r.ctx, first['id'], first['version']) == original
