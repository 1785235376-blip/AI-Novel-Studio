from pathlib import Path
import json
import os
import subprocess
import sys
import time

sys.stdout.reconfigure(encoding='utf-8')
evidence = Path(__file__).parent
author = evidence.parent.parent / 'task-12/portable-cache-budget'
target = '9ce5e243f925f6fb5141046758045c59b1dca46f'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=author, text=True).strip() == target
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=author).strip()
profile = evidence / 'runtime/profile'
env = {k: v for k, v in os.environ.items() if not k.endswith(('_API_KEY', '_TOKEN', '_SECRET')) and k not in {'DATABASE_URL', 'TEST_POSTGRES_DATABASE_URL', 'E2E_DATABASE_URL', 'COLLABORATION_DEV_SESSIONS_JSON', 'PACKAGED_CONTROL_PIPE'}}
env.update(PROJECT_ROOT=str(author), PYTHONPATH=os.pathsep.join([str(author), str(author / 'tests')]), NOVEL_DATA_PATH=str(profile / 'data'),
    LOCALAPPDATA=str(profile / 'Local'), APPDATA=str(profile / 'Roaming'), USERPROFILE=str(profile / 'user'),
    XDG_DATA_HOME=str(profile / 'xdg-data'), XDG_CONFIG_HOME=str(profile / 'xdg-config'), XDG_CACHE_HOME=str(profile / 'xdg-cache'),
    CREDENTIAL_VAULT_BACKEND='memory', STORAGE_BACKEND='file', PYTHONDONTWRITEBYTECODE='1', PYTHONUTF8='1', PYTHONIOENCODING='utf-8',
    ENABLE_PACKAGED_RUNTIME='false', ENABLE_COLLABORATION_RUNTIME='false', MOCK_PROVIDER='true', ENABLE_CLOUD='false', HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
command = [sys.executable, '-m', 'pytest', str(evidence / 'test_budget_review.py'), '-q', '-m', 'file_backend_only', '-p', 'no:cacheprovider',
    '--basetemp=' + str(evidence / 'runtime/pytest'), '--junitxml=' + str(evidence / 'results.xml')]
started = time.monotonic()
result = subprocess.run(command, cwd=author, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(evidence / 'results.log').write_bytes(result.stdout)
(evidence / 'command.json').write_text(json.dumps({'command': command, 'cwd': str(author), 'target': target, 'exit_code': result.returncode, 'seconds': time.monotonic() - started,
    'scope': 'four independent groups, owned disposable File fixtures only; no symlink creation/Windows privilege change/real user cleanup'}, indent=2), encoding='utf-8')
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=author).strip()
print(result.stdout.decode('utf-8', 'replace'))
sys.exit(result.returncode)
