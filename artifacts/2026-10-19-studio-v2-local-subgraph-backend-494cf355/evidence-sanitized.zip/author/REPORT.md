# Current-pin local subgraph backend — local review handoff

Stable local commit `812910a117e4c392798720ba21669f88cd33ffe0` is based directly on `04fd0fa47a8349510aaf0fcbebbc776d60ac21b7`.
Tree `da66bd86cc2b2e117ce5acda37a3637ab6bbf207`; branch `work/v2-local-subgraph-backend-20261019`; worktree clean.
8 files changed, 922 insertions(+), 39 deletions(-). No remote push, integration, main, PR, tag or release.

## Contract delivered

Explicit opt-in schema 6 and `creative-graph-local-subgraph/1` execute one finite local child call through the original same-scope transaction and original Workflow host. No second engine, child job, scheduler, dynamic loader or provider route was added.

- Child is the **current** saved schema1 definition: exact version plus recomputed definition/execution digests. Saving the child invalidates an old pin even for a title-only save. No historical snapshot execution.
- Whole child is a closed pure local whitelist, all enabled and within the declared output ancestor closure. Input is only an unoccupied `text_reference.text` virtual TEXT boundary; output is fixed DRAFT. Missing required inputs, hidden/disconnected dependencies, nested calls and invalid interfaces are refused.
- Depth1, one call, child≤16 nodes, parent plus child≤24. Original output/record/scope/history capacities apply, with bounded intermediate outputs and ≤4096-byte server binding/receipt.
- Server recomputes binding over incarnation, scope, actor, call identity, current pin, normalized closure digest and interface; client cannot submit authority, receipts or closure digests.
- Save/preflight/admission/execute/read/display/approval use real captured guards and real scope state. Router composes original domain.read with write/review for schema6; source-read revocation is checked throughout evaluation. Observed guard failures roll back the original transaction, including ValueError, rather than writing unauthorized FAILED.
- Invalid current source masks derived output, review material and binding/receipt projections. Original cancel/reject cleanup stays available under its original action permission and returns no derived output/binding/receipt.
- Child evaluation shares a **total 5-second cooperative node budget** and checks the original parent deadline before/after local work. This does not preempt arbitrary code. Partial child output/receipts are discarded on failure.
- Cache lookup/reuse is disabled for schema6. Original request_id admission remains idempotent. Unknown admission/execute responses are recovered by original runs/GET; no automatic reexecution.
- DRAFT crosses only into the original parent human_review; approval does not apply a manuscript. Schema1–5 defaults, catalogs and legacy Host classifications remain. New catalog/list are explicit opt-in and expose no frontend execution entry.

## Validation and original failures

Raw logs, JUnit and exact commands are retained beside this report. Repeated runs are not added together.

| Run | Actual result | Interpretation |
| --- | --- | --- |
| initial-file | 5 passed / 1 failed | Real mixed-list transaction hit original legacy asset-read lock guard. Fixed per-schema6 read lease, original guard retained. |
| file-api-r2 | 76 passed / 1 failed | Includes **61 passing version-gate cases**. Missing real context was incorrectly classified as stale; context check moved outside mask, assertion retained. |
| guard-value-red | 1 failed | Observed guard ValueError became durable FAILED. Schema6 preserves the original error and rolls back. |
| file-api-r3 | 23 passed | File/API coverage after authority-error fix. |
| source-read-red | 4 failed | Real read permission revoked while write/review remained; execute/approve incorrectly returned200. Original read+action guards are now composed. |
| file-api-r4 | **27 passed / 27 deselected**, exit0 | Real File persistence and mounted production API/auth; both `/api` prefixes; source invalidation, authority, incarnation and unknown response checks. |
| authority-legacy-final | **12 passed / 86 deselected**, exit0 | Six current API permission cases plus six targeted original persistence/API smoke cases. Includes read-only revocation during child work while write remains, and schema6 create/save/admit refusal with legacy schema1 write retained. |

Final new-file coverage is **13 service File cases and18 mounted API cases** across the last two successful targeted runs, accounting for the superseded unparameterized revocation cases. The61 schema gate cases passed in the earlier mixed run; graph_models runtime code has not changed since, and that run's unrelated failure was subsequently corrected. Eight changed Python files passed `ast.parse` and `compile` without execution/imports. `git diff --check` passed. No tests were weakened.

Existing warnings retained: Starlette/httpx deprecation; GlossaryDocument schema-field warning.

## Limits and coordination

- **PostgreSQL NOT_RUN**: no dedicated TEST_POSTGRES_DATABASE_URL configured. Its fixture parameters were explicitly deselected, never counted as passes; no other database was used or searched for credentials.
- **Python static typechecker NOT_RUN**: no repository configuration/tool was present; no tool installed. Runtime Pydantic schema/port/version gates were exercised. Frontend TS/build/visual acceptance NOT_RUN because no frontend files changed.
- Real models, GPU and paid/cloud providers NOT_RUN; only the existing trusted in-process pure recipe adapter was exercised in isolated test profiles. No user demo process or ports18913/5293 touched.
- Independent review is **pending parent coordination before integration**. This is a server-only first slice, not full subgraph product completion. No frontend execution entry or end-to-end UI acceptance was claimed.
- Exclusive modified scope: the four Graph backend owner files, new finite resolver and three focused test files. No Image mask, Audio LUFS, Model/Comic workbench or DSH slice files changed.
- Parent's latest media combination `3d14ade722814ea3b4472c1c166466597f3b53f5` also has source04 as parent and remains owned by that line. Parent will serialize its archive and later review/integration of this slice. This commit does not include that media combination, change production_execution_contract/LUFS, or expand Graph's callable media operations.

## Offline delivery

`local-subgraph-current-pin-812910a1.bundle` and `local-subgraph-current-pin-812910a1.patch` are local deliverables; hashes are in `review-handoff.json`. Bundle verification passed and requires source base `04fd0fa47a8349510aaf0fcbebbc776d60ac21b7`. The source04 public archive remains a separate completed publication; this backend increment was not uploaded there.
