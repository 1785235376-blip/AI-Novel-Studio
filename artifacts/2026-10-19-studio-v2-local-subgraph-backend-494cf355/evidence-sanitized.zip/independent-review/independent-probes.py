from copy import deepcopy
from datetime import datetime,timedelta,timezone
import importlib.util,json,sys
from pathlib import Path
from types import SimpleNamespace
from uuid import uuid4
import pytest
ROOT=Path(__file__).resolve().parents[1];EVIDENCE=ROOT.parent
sys.path.insert(0,str(ROOT/'tests'))
from test_v2_independent_workspace import rig,import_asset,png_bytes,reopened
from test_v2_creative_graph_api import graph_client,scoped_graph_client
from test_v2_independent_workspace_api import client
from test_r3_mounted_contracts import mounted,prefix,checked
from app.creative.graph import CreativeGraphService,digest
from app.creative.graph_models import parse_graph,catalog_definitions,validate_output_ports
from app.creative.project_store import BINDING
from app.experimental.common import StaleSourceError
from app.authorization import AuthorizationScope,ModalityDomain,PermissionAssignment,ScopeKind
@pytest.fixture
def file_rig(tmp_path,monkeypatch):
    yield from rig.__wrapped__(SimpleNamespace(param='file'),tmp_path,monkeypatch)
def service(e):return CreativeGraphService(e.store,e.service)
def child_definition():
    # Deliberately reuse parent node IDs; child namespace must remain local.
    return {'schema_version':1,'title':'Independent reusable author rule','nodes':[
      {'id':'input','definition_id':'text_reference'},{'id':'call','definition_id':'text_reference'},
      {'id':'note','definition_id':'director_note','parameters':{'note':'Keep author-supplied direction'}},{'id':'review','definition_id':'draft_prepare'}],
      'edges':[{'id':'relay','source_node_id':'input','source_port':'text','target_node_id':'call','target_port':'text'},
        {'id':'draft','source_node_id':'call','source_port':'text','target_node_id':'review','target_port':'text'},
        {'id':'direction','source_node_id':'note','source_port':'direction','target_node_id':'review','target_port':'direction'}]}
def parent_definition(child):
    return {'schema_version':6,'title':'Independent pinned call','nodes':[
      {'id':'input','definition_id':'text_input','parameters':{'text':'独立输入 first beat' + chr(10) + 'Second authored beat'}},
      {'id':'call','definition_id':'local_subgraph','parameters':{'graph_id':child['id'],'expected_version':child['version'],
        'definition_digest':child['definition_digest'],'execution_digest':child['execution_digest'],'input_node_id':'input','output_node_id':'review'}},
      {'id':'review','definition_id':'human_review'}],
      'edges':[{'id':'input','source_node_id':'input','source_port':'text','target_node_id':'call','target_port':'text'},
        {'id':'review','source_node_id':'call','source_port':'draft','target_node_id':'review','target_port':'draft'}]}
def create(e,s,definition,actor=None):return s.create(e.nid,e.scope,actor or e.actor,{'request_id':uuid4().hex,'definition':definition})
def prepare(e):
    s=service(e);child=create(e,s,child_definition());parent=create(e,s,parent_definition(child));return s,child,parent
def admit(e,s,parent):
    pre=s.preflight(e.nid,e.scope,e.actor,parent['id'],{'expected_version':parent['version']});assert pre['executable'],pre
    body={'request_id':uuid4().hex,'expected_graph_version':parent['version'],'reviewed_preflight_digest':pre['preflight_digest'],'target_node_ids':[]}
    return s.create_run(e.nid,e.scope,e.actor,parent['id'],body),body
def execute(e,s,row,guard=lambda:None):return s.action(e.nid,e.scope,e.actor,row['id'],'execute',{'expected_version':row['version']},guard)
def decide(e,s,row,kind='approve'):
    r=row['review'];return s.action(e.nid,e.scope,e.actor,row['id'],kind,{'expected_version':row['version'],'node_id':r['node_id'],'reviewed_output_digest':r['output_digest']})
def hidden(row):
    assert row['review'] is None and all(v['output'] is None for v in row['node_states'].values())
    assert row['local_subgraph_runtime']['bindings']==row['local_subgraph_runtime']['receipts']=={}

def test_core1_real_file_unknown_recovery_exact_namespace_review_and_cache_disabled(file_rig,monkeypatch):
    e=file_rig;s,child,parent=prepare(e)
    pre=s.preflight(e.nid,e.scope,e.actor,parent['id'],{'expected_version':1});body={'request_id':'review-lost-admission','expected_graph_version':1,'reviewed_preflight_digest':pre['preflight_digest']}
    original=s.create_run
    def lost(*a,**k):original(*a,**k);raise RuntimeError('owned lost admission response')
    with monkeypatch.context() as m:
        m.setattr(s,'create_run',lost)
        with pytest.raises(RuntimeError,match='lost admission'):s.create_run(e.nid,e.scope,e.actor,parent['id'],body)
    rows=s.runs(e.nid,e.scope,e.actor,parent['id'])['items'];assert len(rows)==1 and rows[0]['status']=='QUEUED';queued=rows[0]
    assert s.create_run(e.nid,e.scope,e.actor,parent['id'],body)==queued
    calls=[];adapter=s.executor.adapter.execute
    def counted(request):calls.append(request.node_type);return adapter(request)
    monkeypatch.setattr(s.executor.adapter,'execute',counted);original_action=s.action
    def lost_action(*a,**k):original_action(*a,**k);raise RuntimeError('owned lost execute response')
    with monkeypatch.context() as m:
        m.setattr(s,'action',lost_action)
        with pytest.raises(RuntimeError,match='lost execute'):execute(e,s,queued)
    fresh_workspace=reopened(e);fresh=CreativeGraphService(fresh_workspace.store,fresh_workspace)
    waiting=fresh.get_run(e.nid,e.scope,e.actor,queued['id']);assert waiting['status']=='WAITING_APPROVAL' and waiting['version']==2 and len(calls)==5
    assert fresh.runs(e.nid,e.scope,e.actor,parent['id'])['items']==[waiting] and len(calls)==5
    assert '独立输入' in waiting['review']['draft']['text'] and waiting['review']['draft']['direction']=={'note':'Keep author-supplied direction'}
    assert waiting['review']['draft']['origin']=='USER_SUPPLIED' and not waiting['reviewed'] and not waiting['applied']
    runtime=waiting['local_subgraph_runtime'];binding=runtime['bindings']['call'];receipt=runtime['receipts']['call']
    assert binding[BINDING]==e.store.incarnation(e.nid) and binding['actor']==e.actor and binding['scope']==e.scope and binding['node_count']==4
    assert receipt['steps']==4 and receipt['binding_digest']==binding['binding_digest'] and receipt['output_digest']==digest(waiting['node_states']['call']['output'])
    assert len(json.dumps(binding).encode())<=4096 and len(json.dumps(receipt).encode())<=4096
    with pytest.raises(ValueError):execute(e,s,waiting)
    accepted=decide(e,s,waiting);assert accepted['status']=='SUCCEEDED' and accepted['reviewed'] and not accepted['applied']
    second,_=admit(e,s,parent);second=execute(e,s,second);assert len(calls)==10 and second['cache']['hits']==0
    assert second['cache']['mode']=='DISABLED_LOCAL_SUBGRAPH_V1' and not second['local_subgraph_runtime']['cache_enabled']
    state=e.raw_store.read(e.nid,e.scope);assert len(state['collections'][s.GRAPHS])==2 and len(state['collections'][s.RUNS])==2
    assert all(v['cacheable'] is False for r in state['collections'][s.RUNS].values() for v in r['cache_keys'].values())
    assert not second['model_called'] and second['external_calls']==0 and e.chapters.list(e.nid)==[]
    (EVIDENCE/'core1-runtime.json').write_text(json.dumps({'queued':queued,'waiting':waiting,'accepted':accepted,'second':second,'adapter_calls':calls},ensure_ascii=False,indent=2),encoding='utf-8')

def test_core2_current_child_pin_and_same_public_id_new_incarnation_refuse_old_source_outputs_and_approval(file_rig):
    e=file_rig;s,child,parent=prepare(e);queued,body=admit(e,s,parent);waiting,_=admit(e,s,parent);waiting=execute(e,s,waiting)
    old_state=deepcopy(e.raw_store.read(e.nid,e.scope));old_inc=e.store.incarnation(e.nid)
    foreign=create(e,s,child_definition(),actor='other-private-author')
    with pytest.raises(StaleSourceError):create(e,s,parent_definition(foreign))
    changed=s.save(e.nid,e.scope,e.actor,child['id'],{'expected_version':1,'definition':{**child['definition'],'title':'Only the current version/title changed'}})
    assert changed['execution_digest']==child['execution_digest'] and changed['definition_digest']!=child['definition_digest']
    before=deepcopy(e.raw_store.read(e.nid,e.scope))
    for op in [lambda:s.preflight(e.nid,e.scope,e.actor,parent['id'],{'expected_version':1}),lambda:s.create_run(e.nid,e.scope,e.actor,parent['id'],body),lambda:execute(e,s,queued),lambda:decide(e,s,waiting)]:
        with pytest.raises(StaleSourceError):op()
    assert e.raw_store.read(e.nid,e.scope)==before
    for row in s.runs(e.nid,e.scope,e.actor,parent['id'])['items']:assert row['stale'];hidden(row)
    cancelled=s.action(e.nid,e.scope,e.actor,queued['id'],'cancel',{'expected_version':1});assert cancelled['status']=='CANCELLED';hidden(cancelled)
    rejected=decide(e,s,waiting,'reject');assert rejected['status']=='REJECTED';hidden(rejected)
    e.novels.delete(e.nid);e.novels.create({'id':e.nid,'title':'New incarnation, same public ID'});assert e.store.incarnation(e.nid)!=old_inc
    with e.raw_store.transaction(e.nid,e.scope) as state:state['collections'].update(old_state['collections'])
    fresh=service(e)
    for op in [lambda:fresh.get(e.nid,e.scope,e.actor,parent['id']),lambda:fresh.get_run(e.nid,e.scope,e.actor,waiting['id'])]:
        with pytest.raises(FileNotFoundError):op()
    with pytest.raises(StaleSourceError):create(e,fresh,parent_definition(child))
    (EVIDENCE/'core2-invalidation.json').write_text(json.dumps({'old_incarnation':old_inc,'new_incarnation':e.store.incarnation(e.nid),'cancelled':cancelled,'rejected':rejected},ensure_ascii=False,indent=2),encoding='utf-8')

@pytest.mark.parametrize('mounted',['file'],indirect=True)
@pytest.mark.parametrize('prefix',['/api/v1'],indirect=True)
def test_core3_real_read_revocation_during_child_rolls_back_while_write_review_cleanup_and_legacy_write_remain(scoped_graph_client,monkeypatch):
    e=scoped_graph_client
    def make(d):return checked(e.client.post(e.graph_base,headers=e.headers,json={'request_id':uuid4().hex,'definition':d}),201)
    def start(parent):
        path=e.graph_base+'/'+parent['id'];pre=checked(e.client.post(path+'/preflight',headers=e.headers,json={'expected_version':1}))
        return checked(e.client.post(path+'/runs',headers=e.headers,json={'request_id':uuid4().hex,'expected_graph_version':1,'reviewed_preflight_digest':pre['preflight_digest']}),201)
    child=make(child_definition());parent=make(parent_definition(child));queued=start(parent);ready=start(parent)
    base=e.studio_base+'/graph-runs/';waiting=checked(e.client.post(base+ready['id']+'/execute',headers=e.headers,json={'expected_version':1}))
    scope=AuthorizationScope(ScopeKind.BRANCH,e.workspace,e.nid,e.storyline,e.branch)
    for permission in ('domain.write','domain.review'):e.authorization.assign_permission(PermissionAssignment(uuid4().hex,e.lead,permission,ModalityDomain.NOVEL,scope,e.lead))
    adapter=e.graphs.executor.adapter.execute;observed=[]
    def revoked(request):
        value=adapter(request)
        if request.node_type=='text_reference' and not observed:observed.append(1);e.authorization.revoke_role(e.role,e.lead)
        return value
    monkeypatch.setattr(e.graphs.executor.adapter,'execute',revoked);before=deepcopy(e.graphs.store.read(e.nid,parent['scope']))
    denied=e.client.post(base+queued['id']+'/execute',headers=e.headers,json={'expected_version':1});assert denied.status_code==403 and '独立输入' not in denied.text
    assert observed==[1] and e.graphs.store.read(e.nid,parent['scope'])==before
    review_body={'expected_version':waiting['version'],'node_id':'review','reviewed_output_digest':waiting['review']['output_digest']}
    assert e.client.post(base+ready['id']+'/approve',headers=e.headers,json=review_body).status_code==403
    assert e.client.get(base+queued['id'],headers=e.headers).status_code==403
    assert e.graphs.store.read(e.nid,parent['scope'])==before
    cancelled=checked(e.client.post(base+queued['id']+'/cancel',headers=e.headers,json={'expected_version':1}));assert cancelled['status']=='CANCELLED';hidden(cancelled)
    rejected=checked(e.client.post(base+ready['id']+'/reject',headers=e.headers,json=review_body));assert rejected['status']=='REJECTED';hidden(rejected)
    legacy=checked(e.client.put(e.graph_base+'/'+child['id'],headers=e.headers,json={'expected_version':1,'definition':child['definition']}));assert legacy['version']==2
    (EVIDENCE/'core3-real-authority.json').write_text(json.dumps({'execute_http':denied.status_code,'cancelled':cancelled,'rejected':rejected,'legacy_write_version':legacy['version']},ensure_ascii=False,indent=2),encoding='utf-8')

def test_core4_closed_depth_boundary_total_capacity_shared_budget_and_parent_deadline_publish_no_partial_child(file_rig,monkeypatch):
    from app.creative import graph_local_subgraph as sub
    e=file_rig;s,child,parent=prepare(e)
    for mutate in [lambda d:d['nodes'].append({'id':'unused','definition_id':'text_input','parameters':{'text':'hidden'}}),lambda d:d['nodes'][1].update(enabled=False),
      lambda d:d['nodes'].append({'id':'human','definition_id':'human_review'}),
      lambda d:(d['nodes'].append({'id':'occupied','definition_id':'text_input','parameters':{'text':'forbidden'}}),d['edges'].append({'id':'occupied','source_node_id':'occupied','source_port':'text','target_node_id':'input','target_port':'text'}))]:
        raw=child_definition();mutate(raw);bad_child=create(e,s,raw);before=deepcopy(e.raw_store.read(e.nid,e.scope))
        with pytest.raises((ValueError,StaleSourceError)):create(e,s,parent_definition(bad_child))
        assert e.raw_store.read(e.nid,e.scope)==before
    with pytest.raises((ValueError,StaleSourceError)):create(e,s,parent_definition(parent))
    for kind in ('text_generate','asset_reference','media_generate','image_generate','video_generate'):
        bad=parent_definition(child);bad['nodes'][0]['definition_id']=kind
        with pytest.raises(ValueError):parse_graph(bad)
    forged=parent_definition(child);forged['nodes'][1]['parameters']['server_authorized']=True
    with pytest.raises(ValueError):parse_graph(forged)
    ids=['input',*[f'ref{i}' for i in range(14)],'review'];large={'schema_version':1,'title':'Bounded sixteen','nodes':[{'id':i,'definition_id':'draft_prepare' if i=='review' else 'text_reference'} for i in ids],
      'edges':[{'id':'edge'+str(i),'source_node_id':a,'source_port':'text','target_node_id':b,'target_port':'text'} for i,(a,b) in enumerate(zip(ids,ids[1:]))]}
    large_child=create(e,s,large);cap=parent_definition(large_child);cap['nodes'].extend({'id':'extra'+str(i),'definition_id':'text_input','parameters':{'text':'bounded'}} for i in range(5));assert len(cap['nodes'])+16==24
    create(e,s,cap);cap['nodes'].append({'id':'overflow','definition_id':'text_input','parameters':{'text':'bounded'}});before=deepcopy(e.raw_store.read(e.nid,e.scope))
    with pytest.raises(ValueError,match='TOTAL_NODE_CAPACITY'):create(e,s,cap)
    assert e.raw_store.read(e.nid,e.scope)==before
    partial=s.preflight(e.nid,e.scope,e.actor,parent['id'],{'expected_version':1,'target_node_ids':['call']});assert not partial['executable'] and any(i['code']=='CREATIVE_GRAPH_SUBGRAPH_HUMAN_REVIEW_REQUIRED' for i in partial['issues'])
    budget,_=admit(e,s,parent);clock=[0.0];adapter=s.executor.adapter.execute;steps=[]
    def tick(request):
        result=adapter(request)
        if request.request_id.startswith(budget['id']+':call:'):clock[0]+=1.4;steps.append(request.node_type)
        return result
    with monkeypatch.context() as m:
        m.setattr(sub,'monotonic',lambda:clock[0]);m.setattr(s.executor.adapter,'execute',tick);failed=execute(e,s,budget)
    assert failed['status']=='FAILED' and clock[0]>5 and len(steps)==4;hidden(failed)
    expired,_=admit(e,s,parent)
    with e.raw_store.transaction(e.nid,e.scope) as state:
        row=state['collections'][s.RUNS][expired['id']];row['started_at']=(datetime.now(timezone.utc)-timedelta(seconds=row['timeout_seconds']+1)).isoformat()
    entered=[]
    with monkeypatch.context() as m:
        m.setattr(sub,'evaluate',lambda *a,**k:entered.append(1));timed=execute(e,s,expired)
    assert timed['status']=='FAILED' and entered==[];hidden(timed)
    excessive=parent_definition(large_child);excessive['nodes'][0]['parameters']['text']='x'*8000;large_parent=create(e,s,excessive);overflow,_=admit(e,s,large_parent);limited=execute(e,s,overflow);assert limited['status']=='FAILED';hidden(limited)
    with pytest.raises(ValueError,match='REAL_CONTEXT_REQUIRED'):s._preflight(s._owned(e.nid,e.scope,e.actor,s.GRAPHS,parent['id']),{'expected_version':1},e.actor)
    (EVIDENCE/'core4-bounds.json').write_text(json.dumps({'shared_budget_seconds':clock[0],'child_steps_before_failure':steps,'budget':failed,'expired':timed,'output_cap':limited},ensure_ascii=False,indent=2),encoding='utf-8')

def test_core5_legacy_schema_catalog_bytes_and_real_mixed_asset_list_lock_guard_preserved(file_rig):
    name='app.creative.review_legacy04_graph_models';spec=importlib.util.spec_from_file_location(name,EVIDENCE/'legacy04-graph_models.py');old=importlib.util.module_from_spec(spec);sys.modules[name]=old;spec.loader.exec_module(old)
    modes=[{}, {'include_model':True},{'include_model':True,'include_media':True},{'include_model':True,'include_media':True,'include_image':True},
      {'include_model':True,'include_media':True,'include_image':True,'include_production':True},{'include_model':True,'include_media':True,'include_image':True,'include_production':True,'include_video':True}]
    for flags in modes:assert catalog_definitions(**flags)==old.catalog_definitions(**flags)
    for version in range(1,6):
        raw={'schema_version':version,'title':'Legacy exact','nodes':[{'id':'same','definition_id':'text_input','parameters':{'text':'Legacy 中文'}}],'edges':[]}
        assert parse_graph(raw).model_dump()==old.parse_graph(raw).model_dump()
        assert validate_output_ports('text_input',{'text':'Legacy'},schema_version=version)==old.validate_output_ports('text_input',{'text':'Legacy'},schema_version=version)
    e=file_rig;s,child,parent=prepare(e);e.service.activate(e.nid,e.scope,e.actor);asset=import_asset(e,data=png_bytes(),filename='synthetic-legacy.png',kind='image')
    legacy=create(e,s,{'schema_version':1,'title':'Original asset reference','nodes':[{'id':'asset','definition_id':'asset_reference','parameters':{'asset_id':asset['id'],'version':asset['version'],'digest':asset['sha256'],'kind':'image'}}],'edges':[]})
    before=deepcopy(e.raw_store.read(e.nid,e.scope));default=s.list(e.nid,e.scope,e.actor);mixed=s.list(e.nid,e.scope,e.actor,include_local_subgraph=True)
    assert {r['id'] for r in default['items']}=={child['id'],legacy['id']} and {r['id'] for r in mixed['items']}=={child['id'],legacy['id'],parent['id']}
    assert e.raw_store.read(e.nid,e.scope)==before
    with pytest.raises(ValueError,match='ASSET_READ_INSIDE_SCOPE_DENIED'):
        with s.store.transaction(e.nid,e.scope):s._reference_states(e.nid,e.scope,legacy['definition'],lambda:None,e.actor)
    assert e.raw_store.read(e.nid,e.scope)==before
    (EVIDENCE/'core5-legacy-compatibility.json').write_text(json.dumps({'catalog_modes_exact':len(modes),'schema_parse_and_text_ports_exact':[1,2,3,4,5],'mixed_list_current':mixed,'legacy_lock_order_rejection_preserved':True},ensure_ascii=False,indent=2),encoding='utf-8')
