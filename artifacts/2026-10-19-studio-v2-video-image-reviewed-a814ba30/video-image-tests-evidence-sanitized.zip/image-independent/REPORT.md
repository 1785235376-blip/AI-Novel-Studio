# 双 PNG 叠层独立审查

固定提交 `bec46a1f912291627efb5c6b3c7d362a9c2158ec`；父 `d9b2ea4b602af099f133e7ef7e954fb7618979ae`；树 `f83ca9a9e516aaa28a6a56456add8f96bb4a936c`。

本次限定审查未发现 P1/P2。只读检查14文件diff与原owner调用链，并仅新增运行3个独立CPU/File反例。作者的22项后端、100项前端、TS/build/token/geometry未重跑，未修改任何产品文件/已释放的共享model或client，未push，未启动后台服务。

| 关键反例 | 实际结果 | 证据 |
| --- | --- | --- |
| 两来源版本、隐藏层、第二来源私有权限及配方绑定 | 两位置错误版本均409；外部actor私有第二来源404；隐藏层变更后Execute409且Job仍QUEUED、无candidate/publication_ready；opacity/order/source配方篡改拒绝 | one-source-binding.json |
| 限额解码、RGBA算法及完全透明语义 | 64×64小图、5种显隐/透明度组合共20,480像素与独立Fraction算术oracle一致；所有最终alpha=0的RGB均0；解压超额、额外chunk及8MiB+1输入拒绝 | two-cpu-oracle.json |
| 私有候选落盘之后的UNKNOWN与取消 | 原publish完成后注入丢失响应，UNKNOWN不能再Execute；原Reconcile只恢复AWAITING_REVIEW，正式Asset仍404；仅明确Review后APPROVED/v2/GET200。另一Job在publish完成后取消，CANCELLED候选仍404，Review/Execute均422 | three-private-state.json |

最终 `3 passed, 2 deselected`，耗时8.59s；原始日志 `three-counterexamples-third.log` 与JUnit同名xml。首次两次失败属于只读审查加载器遗漏namespace/interop包，未执行产品用例；日志与加载器版本均保留，未改弱断言。

审查使用Git cat-file批量只读pipe按需导入固定提交的blob，导入后逐一核对OID，共466个依赖blob；没有复制整份源码。原cutout、WebP编码与PNG解码算法文件相对d9的blob完全相同。完整导入记录见 snapshot-imports.json。

未覆盖PG、GPU/真实模型质量和完整live浏览器/backend E2E；本结论不延伸到proxy后续串行接线或未来组合树，也不表示整个IMAGE-14/V2已验收。无剩余阻断。
