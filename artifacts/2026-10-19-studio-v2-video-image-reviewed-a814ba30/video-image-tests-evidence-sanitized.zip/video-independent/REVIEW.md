# 视频底稿独立审查：a6678a41

结论：**PASS（有界独立审查）；未发现本次范围内需要阻塞合并的缺陷。**

审查对象 `a6678a4144b40277dce3c94f42cfed66a140fae5`，唯一父版本
`d9b2ea4b602af099f133e7ef7e954fb7618979ae`。只读作者 diff、REPORT 和
相关 owner；复用 Git 对象建立 app/tests 等必要路径的 sparse checkout。
没有改作者源码或共享文件，没有 push；links 的 `a8d30302` 保持冻结。

## 三组独立真实 CPU / File 反例

1. **审核、pin、来源和权限失效：PASS。** 真实已审核 Job/Asset owner 建立
   CPU WEBM 来源。错误 shot digest、创建前撤权、原 Timeline 暂写后撤权、
   当前文档版本仍未审核、通过原 Asset lifecycle 删除来源版本，均拒绝创建；
   逐例断言 scope 内容及持久 JSON 文件哈希不变。带貌似合理 duration/width/
   height 的伪 MP4 头也被原 native inspector 拒绝。
   见 `01-admission-counterexamples.json`、`counterexample-01.log/xml`。

2. **1–4 顺序、裁切、真实解码和原 Timeline 原子性：PASS。** 另外制作四种
   64×64 / 8fps / 1秒 CPU WEBM，前500ms黑色，后500ms分别红/绿/蓝/白。
   通过原 reviewed video Job/Asset/Storyboard owners，按 shot-3、shot-1、
   shot-4、shot-2 顺序选取500–1000ms。分别选1/2/3/4段，只读 preview 无写入，
   每次 create 恰好新增一条原 Timeline，其他 scope 内容不变，独立 owner
   重开一致。四段 DTO 再交原 CPU renderer，随后真实 RGB decode，得到16帧、
   2秒，中心样本依次 `[0,0,252] / [252,0,0] / [255,255,255] / [0,252,0]`。
   这同时验证了时间入点与顺序，而非只核对返回 metadata。
   见 `02-real-decode-order-trim.json` 和 `independent-four-trimmed-cpu.mp4`。
   额外 CPU 渲染只属于审查核验；待审 create 功能本身没有启动渲染任务。

3. **UNKNOWN 同键读取恢复与失败无半成品：PASS。** 原 create 成功后主动丢弃
   响应，再通过全新原 owner GET creation，恢复同一 Timeline；明确同键同完整
   请求重试返回 replay，持久 JSON 不变，Timeline 总数仍1。同键改载荷冲突。
   新键在第二条 Timeline 暂写后撤权，事务回滚；既无第二条 Timeline，也无可
   读取的 creation 回执。见 `03-unknown-recovery-atomicity.json`。

三个定向命令各 `1 passed, 2 deselected`，未重跑作者25新后端、12兼容、70前端、
TS/build或整组视觉测试。原始命令与 exit code 在对应 command JSON。
第一次审查脚本漏接原 owner 对已删素材正确返回的 FileNotFoundError，原日志
保留为 `counterexample-01.initial-harness.log`；仅修正审查异常类型，仍严格要求
失败和持久数据不变。另一次工具传输中断没有形成完整测试结果；确认原进程已
结束后才按三组分别执行，未将启动或中断状态计为通过。

## 共享 owner 的窄改动

- `production_execution.py:140` 增加默认关闭的尺寸 opt-in；原 source 的 Asset
  incarnation/version/hash/content 与 guard 流程保留。新路径明确传 true；默认
 调用没有多余关键词或新响应字段。另在约1277行仅增加独立创建回执投影。
- `media_files.py:167` 增加同一 opt-in；宽高来自已验证的 native ffprobe 输出，
  完整视频帧 decode 及原 bounded process/临时目录清理/权限异常保留逻辑未改。
  默认旧返回形状不变，音频路径不读取不存在的视频宽高。
- `storyboard_video_timeline.py:61–79` 复用原审核、精确 shot pin、已批准视频
  job/candidate 与 Asset phase 校验；约95–120行解码后重核来源。
- 约183–200行将原 Timeline Save、origin、独立创建回执及 capacity/guard 放入
  同一原 writable phase；故晚撤权回滚整条记录。约174–180、204–212行只读恢复
  原持久回执，重放先核完整意图，不再创建或执行来源任务。
- 原 `storyboard_call` 授权闭包没有修改，只新增三条路由调用；没有以小说权限
  替代 Storyboard/Graph 权限。未发现窄改动另起存储或绕开原 owner。

## 保留的边界

CPU 内容与 provider transport 都是合成测试夹具；真实的是本机媒体字节、native
decode、原审核/Asset/Storyboard/Timeline owners 与 File 原子写入。没有真实模型
或付费调用。本次未做 PostgreSQL、GPU、模型质量、全V2或有权限真实 Host 浏览器
Save 验收。作者浏览器组件 fixture 仍仅是组件/模拟传输证据，不升级为 Host 验收。

精简证据和可复现审查脚本保存在本目录；只清理 review checkout 内可再生测试
profile/临时数据。原 task13 演示 ZIP 校验与18913/5293服务保留，未动其文件/端口。
