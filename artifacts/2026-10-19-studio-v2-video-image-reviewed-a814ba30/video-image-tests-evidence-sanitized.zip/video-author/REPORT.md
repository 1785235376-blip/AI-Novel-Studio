# Storyboard 已审核视频直接创建 Timeline：本地审查交接

- 工作区：`<TASK_ROOT>\task\studio-v2-storyboard-video-timeline`
- 分支：`work/v2-storyboard-video-timeline-d9-20261019`
- 本地提交：`a6678a4144b40277dce3c94f42cfed66a140fae5`
- 唯一父版本：`d9b2ea4b602af099f133e7ef7e954fb7618979ae`；树：`5bc9007ea05b281ad1e0e9a98259825999b34f9e`
- 工作树干净；没有 push、main 合并、Tag、Release 或远端归档。

## 完成的稳定切片

已审核的同一 Storyboard 可明确选择并排序 1–4 个正式审核视频，无需绑定图片。原解码器检查真实字节的时长、尺寸、格式；显式裁切与来源 pin 进入只读预览。一次独立人工确认后，通过原 Timeline Save 和原 scope/Asset/project 事务写入；保留原 storyboard_origin，新增独立视频创建回执。未调用模型、未渲染、未修改 Graph 或 Timeline schema/edit。

同键同完整意图可重放/GET 恢复，变更载荷冲突；原 Timeline 后续 Save 的历史与初次创建证明同时保留。权限、批准、来源版本、解码中来源变化、原容量与字节限制、无音轨选择、写入后撤权回滚均经过 File 用例。前端包含脏表单/忙碌保护、来源/客户端/权限/active ABA、旧表单与确认回调失效、晚到结果、重复保存及 UNKNOWN 的明确读取/同键重试，并复用原离开风险请求标识边界。

## 验证

| 检查 | 结果 | 证据 |
| --- | --- | --- |
| 新 CPU/File owner 与 mounted API | 25 passed；25 PG deselected | backend-final.log/xml |
| 原图片创建与原视频替换兼容 | 12 passed（与最初10项新API合计22） | backend-api.log/xml |
| 新客户端/面板与旧面板 | 70 passed（19+15+36） | ui-hash-normalized.log |
| TypeScript | 首次0退出，只跑1次 | types-final-command.json |
| Vite build | 首次0退出，只跑1次；原大chunk提示 | build-final.log/command.json |
| 原 token guard | PASS | tokens-final.log |
| NOVEL/IMAGE/VIDEO基线及3桌面几何 | 6 passed | visual-final.log + protected-visual-headless.junit.xml |
| 新面板3宽度浏览器，含展开来源pin/UNKNOWN读取 | 3 passed，无溢出/pageerror | panel-browser-expanded.log/xml + PNG/proof JSON |

浏览器组件使用固定的真实 CPU API 捕获与模拟传输，不是有权限的真实 Host 浏览器 Save 验收。真实原 API/File 的 Save、GET重开和同键重放已通过。PG、GPU/安装模型、模型质量、完整V2与全仓库测试未运行。无额度限制或后台模型执行需要报告，因为本次没有运行任何模型。

## 原始失败及修复

原始日志均保留，未改弱测试。backend-first 的7项失败要求元数据检查进入原 Asset phase；backend-phase 的2项失败要求预览先复用原 Timeline 规范化。前端初轮标签不一致已修正测试；严格客户端的原轨道/全画布默认字段及 Python 0.0/1.0 摘要差异在独立创建回执校验内修正，原 Timeline schema/edit 未改。各原始失败文件见 review-handoff.json。

## 并发/串行整合要求

`api.py` 已完成并冻结在本提交，现明确释放给DIF串行接线。本线程不再编辑该文件；原闭包签名为 `storyboard_call(request, nid, token, branch, permission, callback)`，callback 接收 `(actor, scope, guard)`。文件仅新增 import 及约190–204行三条路由；原 storyboard_call 闭包与 d9 逐字相同。可以交DIF负责窄callback注入，但请父任务先串行整合本提交，再允许DIF修改同文件；保留原guard，不以小说权限替代Storyboard/Graph权限。

另需父任务串行协调 `production_execution.py`（source opt-in尺寸、回执投影）与 `media_files.py`（inspect_media opt-in尺寸返回）；这两个文件在并发归属通知后未继续编辑。`storyboard.py`只增三薄封装。其余新增helper/面板/客户端独立。本提交不授予其他lane并改共享文件的权限。即时父任务消息工具返回 thread not found，消息未送达；由此最终交接自动通知父任务。

## 产物与清理

commit.patch、review-handoff.json、源码SHA256及所有原始日志保存在本目录。浏览器独立入口源码 video-panel-fixture.tsx 已保留。按PID、完整命令、启动时间核对后停止唯一5326服务，未触及其他任务服务。仅删除白名单内可再生dist/cache/旧失败夹具共1,623文件、19,369,020字节；清理前哈希见 cleanup-manifest.json。保留 `.runtime/pytest-final`、测试profile和CPU原始捕获，node_modules junction未删除。
