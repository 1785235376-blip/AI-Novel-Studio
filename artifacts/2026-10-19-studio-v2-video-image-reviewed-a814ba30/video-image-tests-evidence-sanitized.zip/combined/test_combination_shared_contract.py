"""Bounded combined CPU/File counterexample; no provider inference or full E2E."""
from copy import deepcopy
import pytest
from pydantic import TypeAdapter, ValidationError
from conftest import restore_global_settings
from test_v2_independent_workspace import rig
from test_storyboard_video_timeline_additive import videos, request
from app.creative.production_execution_models import MediaCommand, GraphMediaOperation


def test_optional_dimensions_preserve_legacy_shape_and_closed_media_inputs(videos):
    p = videos; e = p.e
    shown, body = request(p)
    snapshot = deepcopy(shown['timeline']['tracks'][0]['clips'][0]['source_snapshot'])
    before = deepcopy(e.store.read(e.nid, e.scope))
    legacy = p.production.source(e.nid, e.scope, snapshot, lambda: None)
    measured = p.production.source(e.nid, e.scope, snapshot, lambda: None, include_video_dimensions=True)
    assert legacy['data'] == measured['data']
    assert 'width' not in legacy['measured'] and 'height' not in legacy['measured']
    assert measured['measured'] == {**legacy['measured'], 'width': 64, 'height': 64}
    def revoked(): raise PermissionError('original inspection authority revoked')
    for dimension_mode in [False, True]:
        with pytest.raises(PermissionError, match='inspection authority revoked'):
            p.production.source(e.nid, e.scope, snapshot, lambda: None,
                inspection_guard=revoked, include_video_dimensions=dimension_mode)
    stale = {**snapshot, 'version': snapshot['version'] + 1}
    with pytest.raises(ValueError): p.production.source(e.nid, e.scope, stale, lambda: None, include_video_dimensions=True)
    legacy_command = {'operation_id': 'm7.video.t2v', 'request_id': 'old-wire', 'provider_id': 'local-test',
        'model_id': 'local-test', 'prompt': 'Authored', 'parameters': {'duration_seconds': 1, 'width': 64, 'height': 64}}
    assert 'image_layers' not in MediaCommand.model_validate(legacy_command).model_dump()
    with pytest.raises(ValidationError): MediaCommand.model_validate({**legacy_command, 'image_layers': None})
    with pytest.raises(ValidationError): TypeAdapter(GraphMediaOperation).validate_python('m5.image.composite')
    assert e.store.read(e.nid, e.scope) == before
