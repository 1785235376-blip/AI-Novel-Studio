// @vitest-environment jsdom
import { webcrypto } from 'node:crypto';
import { act, cleanup, fireEvent, render, renderHook, screen, waitFor } from '@testing-library/react';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import actual from '../../../task/studio-v2-graph-conditions-ui/frontend/src/creative/fixtures/conditions.file-api.json';
import { createStudioGraphClient } from '../../../task/studio-v2-graph-conditions-ui/frontend/src/creative/studioGraphClient';
import { conditionHash } from '../../../task/studio-v2-graph-conditions-ui/frontend/src/creative/graphConditionContract';
import { modelCatalog } from '../../../task/studio-v2-graph-conditions-ui/frontend/src/creative/studioGraphModel.testFixtures';
import { useStudioGraphEditorController } from '../../../task/studio-v2-graph-conditions-ui/frontend/src/creative/useStudioGraphEditorController';
import { GraphRunPanel } from '../../../task/studio-v2-graph-conditions-ui/frontend/src/creative/GraphRunPanel';

beforeEach(() => vi.stubGlobal('crypto', webcrypto));
afterEach(() => { cleanup(); vi.unstubAllGlobals(); vi.restoreAllMocks(); });
const copy = <T,>(value: T): T => structuredClone(value);
const context: any = { scope: { projectId: actual.graph.project_id, workspaceId: actual.graph.scope.workspace_id,
  storylineId: actual.graph.scope.storyline_id, branchId: actual.graph.scope.branch_id } };
function reader(graph: any, run: any, preflight: any = actual.preflight) {
  const json = vi.fn(async (url: string) => copy(url.endsWith('/preflight') ? preflight : url.includes('/graph-runs/') ? run : graph));
  return { json, client: createStudioGraphClient(actual.graph.project_id, context, { json } as any) };
}

it('binds every accepted condition plan to the saved full definition and rejects malformed runtime proofs', async () => {
  const good = reader(actual.graph, actual.approved); await good.client.get(actual.graph.id);
  expect((await good.client.getRun(actual.approved.id)).status).toBe('SUCCEEDED');
  const variants = [
    (v: any) => { v.conditional_runtime.plan.selected_port = 'when_false'; },
    (v: any) => { v.conditional_runtime.skipped_dispatches = '0'; },
    (v: any) => { v.conditional_runtime.skipped_outputs = 1; },
    (v: any) => { v.conditional_runtime.plan.authorized = true; },
    (v: any) => { v.node_states.no.output = { draft: { origin: 'MANUAL', text: 'skipped leak' } }; },
    (v: any) => { v.graph_version++; },
  ];
  for (const change of variants) {
    const run = copy(actual.approved); change(run); const bad = reader(actual.graph, run);
    await bad.client.get(actual.graph.id); await expect(bad.client.getRun(run.id)).rejects.toThrow();
    expect(bad.json.mock.calls.every(([url]) => !url.endsWith('/execute') && !url.endsWith('/approve'))).toBe(true);
  }
  // A recomputed, structurally valid plan cannot repair an inconsistent saved definition digest.
  const forgedGraph = copy(actual.graph); forgedGraph.definition.title = 'Different same-version saved definition';
  const forgedRun = copy(actual.approved), { plan_digest: _, ...plan } = forgedRun.conditional_runtime.plan;
  forgedRun.conditional_runtime.plan.plan_digest = await conditionHash([forgedGraph.definition, plan]);
  const forged = reader(forgedGraph, forgedRun);
  await expect((async () => { await forged.client.get(actual.graph.id); await forged.client.getRun(forgedRun.id); })()).rejects.toThrow();
  const badPreflight = copy(actual.preflight); badPreflight.conditional_plan.active_node_ids.reverse();
  const preflight = reader(actual.graph, actual.approved, badPreflight); await preflight.client.get(actual.graph.id);
  await expect(preflight.client.preflight(actual.graph.id, { expected_version: 2, target_node_ids: [] })).rejects.toThrow();
});

it('retires retained condition edits across permission, selection and source ABA without implicit writes', async () => {
  const create = vi.fn(), save = vi.fn(), createRun = vi.fn(), action = vi.fn();
  const props: any = { active: true, denied: false, identity: 'independent-condition-review', canMutate: true, canReview: true,
    busy: false, externalDirty: false, isCurrent: () => true, read: (work: any) => work(), mutate: (work: any) => work(),
    client: { graphs: { catalog: vi.fn(async () => modelCatalog(false)), list: vi.fn(async () => ({ items: [] })),
      conditionsCatalog: vi.fn(async () => copy(actual.catalog)), conditionsList: vi.fn(async () => ({ items: [] })), create, save, createRun, action,
      runs: vi.fn(async () => ({ items: [] })) } } };
  const hook = renderHook(value => useStudioGraphEditorController(value), { initialProps: props });
  await waitFor(() => expect(hook.result.current.catalog).toBeTruthy());
  await act(async () => hook.result.current.loadConditions()); act(() => hook.result.current.createConditions());
  const baseline = copy(hook.result.current.draft), oldPermission = hook.result.current.updateCondition;
  hook.rerender({ ...props, canMutate: false }); hook.rerender(props);
  act(() => oldPermission({ kind: 'boolean', value: false })); expect(hook.result.current.draft).toEqual(baseline);
  const oldSelection = hook.result.current.updateCondition;
  act(() => hook.result.current.setSelected(['input'])); act(() => hook.result.current.setSelected(['condition']));
  act(() => oldSelection({ kind: 'boolean', value: false })); expect(hook.result.current.draft).toEqual(baseline);
  const oldSource = hook.result.current.updateCondition;
  act(() => hook.result.current.change({ ...baseline, title: 'Intermediate source revision' }));
  act(() => hook.result.current.change(baseline)); act(() => oldSource({ kind: 'boolean', value: false }));
  expect(hook.result.current.draft).toEqual(baseline);
  act(() => hook.result.current.updateCondition({ kind: 'enum', value: 'A', equals: 'B' }));
  expect(hook.result.current.draft.nodes.find(n => n.id === 'condition')?.parameters.predicate).toEqual({ kind: 'enum', value: 'A', equals: 'B' });
  expect(create).not.toHaveBeenCalled(); expect(save).not.toHaveBeenCalled(); expect(createRun).not.toHaveBeenCalled(); expect(action).not.toHaveBeenCalled();
});

it('shows unselected SKIPPED nodes as normal zero-dispatch results and never offers failed-run repair', async () => {
  const action = vi.fn(), createRun = vi.fn();
  const client: any = { runs: vi.fn(async () => ({ items: [copy(actual.approved)] })), getRun: vi.fn(async () => copy(actual.approved)), action, createRun };
  render(<GraphRunPanel client={client} graph={actual.graph as any} targetNodeIds={[]} dirty={false} busy={false} canMutate canReview
    isCurrent={() => true} read={work => work()} mutate={work => work()} />);
  fireEvent.click(screen.getByRole('button', { name: '读取运行记录' }));
  const select = await screen.findByRole('combobox', { name: '已保存运行' });
  fireEvent.change(select, { target: { value: actual.approved.id } });
  await screen.findAllByText('条件未选中，已正常跳过；派发 0，输出 0。');
  for (const id of actual.approved.conditional_runtime.plan.skipped_node_ids) expect(screen.queryByRole('button', { name: '检查节点 ' + id })).toBeNull();
  expect(screen.queryByRole('button', { name: '核对失败运行重试' })).toBeNull();
  expect(action).not.toHaveBeenCalled(); expect(createRun).not.toHaveBeenCalled();
});
