"""Two independent mounted File/API cases, original authority and owners."""
from copy import deepcopy
from uuid import uuid4

import pytest
from app.creative.graph import GRAPHS, RUNS
from app.creative.graph_local_conditions import compile_plan
from app.authorization import AuthorizationScope, ModalityDomain, PermissionAssignment, ScopeKind
from test_r3_mounted_contracts import checked, mounted
from test_v2_independent_workspace_api import client
from test_v2_creative_graph_api import graph_client, scoped_graph_client, definition as legacy_definition
from test_v2_graph_local_conditions_api import enable, create, grant
from test_v2_graph_local_conditions import definition
from test_v2_local_subgraph import child_definition, parent_definition


@pytest.fixture
def prefix():
    return '/api'


def test_default_off_preserves_schema1_and_schema6(scoped_graph_client, monkeypatch):
    e = scoped_graph_client
    monkeypatch.delenv('CREATIVE_GRAPH_CONDITIONS_V1', raising=False)
    original = checked(e.client.get(e.graph_base + '/catalog', headers=e.headers))
    assert all(item['id'] != 'local_condition' for item in original['definitions'])
    for suffix in ['/catalog?include_local_conditions=true', '?include_local_conditions=true']:
        result = e.client.get(e.graph_base + suffix, headers=e.headers)
        assert result.status_code == 422 and 'CREATIVE_GRAPH_CONDITIONS_DISABLED' in result.text
    assert e.client.post(e.graph_base, headers=e.headers, json={'request_id': uuid4().hex, 'definition': definition()}).status_code == 422
    legacy = create(e, legacy_definition(), e.headers)
    saved = checked(e.client.put(e.graph_base + '/' + legacy['id'], headers=e.headers,
        json={'expected_version': legacy['version'], 'definition': legacy['definition']}))
    assert saved['version'] == 2 and saved['definition']['schema_version'] == 1
    child = create(e, child_definition(), e.headers)
    parent = create(e, parent_definition(child), e.headers)
    assert parent['definition']['schema_version'] == 6
    assert checked(e.client.get(e.graph_base + '/' + parent['id'], headers=e.headers)) == parent
    preflight = checked(e.client.post(e.graph_base + '/' + parent['id'] + '/preflight', headers=e.headers, json={'expected_version': 1}))
    assert preflight['executable'] and preflight['graph_schema_version'] == 6
    enable(monkeypatch)
    assert checked(e.client.get(e.graph_base + '/catalog', headers=e.headers)) == original
    assert len(checked(e.client.get(e.graph_base + '/catalog?include_local_conditions=true', headers=e.headers))['definitions']) == 6


def test_saved_plan_original_review_and_skipped_dispatch_proof(scoped_graph_client, monkeypatch):
    e = scoped_graph_client; enable(monkeypatch)
    graph = create(e, definition({'kind': 'enum', 'value': 'A', 'equals': 'B'}), e.headers)
    path = e.graph_base + '/' + graph['id']
    graph = checked(e.client.put(path, headers=e.headers, json={'expected_version': graph['version'], 'definition': {**graph['definition'], 'title': 'Independent reviewed conditional source'}}))
    plan = checked(e.client.post(path + '/preflight', headers=e.headers, json={'expected_version': graph['version'], 'target_node_ids': []}))
    saved = e.graphs.store.read(e.nid, graph['scope'])['collections'][GRAPHS][graph['id']]
    assert saved['definition'] == graph['definition']
    assert compile_plan(saved['definition']) == plan['conditional_plan'] and plan['conditional_plan']['selected_port'] == 'when_false'
    body = {'expected_graph_version': graph['version'], 'reviewed_preflight_digest': plan['preflight_digest'], 'target_node_ids': [], 'request_id': uuid4().hex}
    queued = checked(e.client.post(path + '/runs', headers=e.headers, json=body), 201)
    assert checked(e.client.post(path + '/runs', headers=e.headers, json=body), 201) == queued
    run_path = e.studio_base + '/graph-runs/' + queued['id']
    waiting = checked(e.client.post(run_path + '/execute', headers=e.headers, json={'expected_version': queued['version']}))
    assert waiting['status'] == 'WAITING_APPROVAL' and waiting['review']['node_id'] == 'no_review'
    assert all(state['output'] is None for state in waiting['node_states'].values())
    review = {'expected_version': waiting['version'], 'node_id': waiting['review']['node_id'], 'reviewed_output_digest': waiting['review']['output_digest']}
    grant(e, ('domain.write', 'domain.review'))
    before = deepcopy(e.graphs.store.read(e.nid, graph['scope']))
    assert e.client.post(run_path + '/approve', headers=e.headers, json=review).status_code == 403
    assert e.graphs.store.read(e.nid, graph['scope']) == before
    e.authorization.assign_permission(PermissionAssignment(uuid4().hex, e.lead, 'domain.read',
        ModalityDomain.NOVEL, AuthorizationScope(ScopeKind.BRANCH, e.workspace, e.nid, e.storyline, e.branch), e.lead))
    assert e.client.post(run_path + '/approve', headers=e.headers, json={**review, 'reviewed_output_digest': '0' * 64}).status_code == 409
    approved = checked(e.client.post(run_path + '/approve', headers=e.headers, json=review))
    assert approved['status'] == 'SUCCEEDED' and approved['reviewed']
    raw = e.graphs.store.read(e.nid, graph['scope'])['collections'][RUNS][queued['id']]
    skipped = set(plan['conditional_plan']['skipped_node_ids'])
    assert raw['conditional_plan'] == plan['conditional_plan'] and raw['cache']['hits'] == 0
    assert not any(item.get('node_id') in skipped for item in raw['dispatch_trace'])
    assert not any(key in skipped for key in raw.get('typed_outputs', {}))
    for key in skipped:
        assert approved['node_states'][key] == {'status': 'SKIPPED', 'reviewed': False, 'output': None, 'error': {'code': 'CREATIVE_GRAPH_BRANCH_NOT_SELECTED'}}
    assert approved['conditional_runtime']['skipped_dispatches'] == approved['conditional_runtime']['skipped_outputs'] == 0
    updated = checked(e.client.put(path, headers=e.headers, json={'expected_version': graph['version'], 'definition': {**graph['definition'], 'title': 'New source version'}}))
    assert updated['version'] == graph['version'] + 1
    assert e.client.post(path + '/preflight', headers=e.headers, json={'expected_version': graph['version']}).status_code == 409
    stale = checked(e.client.get(run_path, headers=e.headers))
    assert stale['stale'] and stale['conditional_runtime']['plan'] is None
    assert all(s['output'] is None for s in stale['node_states'].values())
