# Graph schema7 原画布限定闭环

已完成并冻结本地切片。默认功能门禁保持 OFF，没有推送或合并 main。

- 工作区：`<TASK_ROOT>\task\studio-v2-graph-conditions-ui`
- 分支：`work/v2-graph-conditions-ui-11b-20261020`
- 基线：`11b53ede67259f7c2d81fb495e1b1dcfdfb7ce9c`
- 最终提交：`98ce5423e619e311aa574c73288bef8fe8fe1dd1`
- 源码树：`5209377b7cfae7f07ddd240b411ab11d362d1e4b`；工作区干净，20 个变更文件。
- 本任务自己的未公开提交 d003f9d4 已折入最终提交，父任务只采用最终 98ce5423。

## 实际改动

原 Graph API 增加显式 `include_local_conditions=true` 目录/列表读取；原默认目录/列表与 schemas 1–6 保持。新目录只声明原 schema7 的六类本地节点与关闭缓存的固定能力，原权限与功能门禁在读取前后核对。

原画布先明确核对能力，且只在未保存空图准备六节点模板。固定一输入、一条件、两条互不相交并以原 human_review 结束的链；本首片锁定结构，文本、闭合布尔/A-B 条件和位置仍走原 change/history。可一次撤销/重做；原 Save、整图预检、创建运行、执行和人工审核分别明确操作。没有自动 Save、执行或模型调用。

客户端严格拒绝 schema7 未知字段、参数/类型混用及外部/模型/媒体节点。分支计划连同完整规范化保存定义进行 SHA-256 核对；保存版本、范围和来源变化会使旧证明失效。原审核摘要绑定 run/node/graph-version/draft，选中输出在审核前仍隐藏。未选节点必须是原 SKIPPED、null 输出、零派发、零输出、零缓存命中；正常跳过不显示失败重试指导。晚到证明、忙碌/权限/来源/选择 ABA、旧回调、重复准备与 UNKNOWN、容量保护继续保留。

最后复核修正了 JS trim 与原 Python strip 的 BOM/Unicode 差别；通过原 File/API 假分支 + 原人审捕获验证，不改变原 recipe 或引擎。`graph_execution.py`、`graph_local_conditions.py`、WorkflowRun、app/api.py、Timeline/模型实现均未修改。

## 验证证据

| 范围 | 结果 | 原始记录 |
|---|---|---|
| File/API 原目录、Save/reopen、整图 preflight、幂等 admission、execute、人审、权限/版本/取消/跳过 | 33 passed，45 按 File marker deselected | backend-conditions-final.log / .xml |
| BOM、Unicode 换行/空白的假分支及原审核补充 | 4 passed，8 deselected | backend-conditions-unicode.log / .xml |
| 前端新协议/表单及 schema1/schema6/原运行回归 | 133 passed | frontend-conditions-complete.log |
| 最后 Unicode 改动后的受影响前端 | 12 passed | frontend-unicode-final.log |
| TypeScript | 最终 exit 0 | typescript-unicode-final.log / -command.json |
| 生产构建 | 最终 exit 0，5.04s；保留 Vite 大 chunk 警告 | production-unicode-final.log |
| 设计令牌 | PASS，52 文件 | design-tokens.log |
| 共用 NOVEL/IMAGE/VIDEO 视觉基线及三宽度几何 | 6 passed | protected-visual.log / .junit.xml |
| 条件表单、整图原确认/运行/审核组件浏览器，1366/1440/1920 | 3 场景 passed；第二遍仅补控件近景 | conditions-browser-inspected.log / .junit.xml / -results |

浏览器使用真实 File/API 捕获和模拟组件传输，明确不是 live Host 或完整 E2E。实际检查控件近景和人审截图；页面与 340px inspector 无水平溢出。共用 shell、令牌、原语及样式未修改。

### 原始失败与检查次数

不弱化产品或测试来换通过。所有原始失败日志保留：前三轮新 API 测试分别对混合媒体读取的原权限优先级（403）、SKIPPED 的原 reviewed 字段、错误审核摘要（409）作了错误假设，修正为原始契约。首轮前端有两项失败：审核摘要应绑定原四元组，而低层 action 不承诺无 POST；前者修正产品摘要核验，后者修正不成立的测试假设。额外 readonly Save 测试将原同步 throw 错写成 Promise rejection，已按原同步保护修正。

TS 实跑 3 次：首次 4 条新类型错误，修正后通过，最后 Unicode 修正后再次通过。生产构建实跑 2 次；第二次由最后发现的实际 Unicode 兼容性修正触发。原来的 133 项通过后，只重跑受 Unicode 改动影响的 12 项，未重跑无关全量套件。浏览器同 3 场景实跑两遍，第二遍只补近景，不计作 6 个独立场景。

## 明确阻断与未运行

**BLOCKED / 未运行**：本切片真实合法 Host 浏览器的原 Save → whole preflight → run → human review。当前任务没有新验证可用的合法 Host 会话；前次 519a 的真实浏览器尝试为 401 SESSION_REQUIRED。没有创建真实凭据或绕过授权，本切片没有发起不确定真实写入；不是已拒绝写入，也没有后台等待任务。已完成的替代证据是原挂载 File/API + 严格响应核验 + 明确标注的组件浏览器。

PostgreSQL、真实 Host/full E2E、provider/GPU/模型验收均未运行。没有新增付费 API、购买额度或模型任务；没有模型/额度运行失败可报告。前端本机草稿恢复仍沿用原 schema1–2 范围，未扩展 schema7 缓存。

## 交付、清理与父任务协调

补丁：`98ce5423-local-slice.patch`。完整交接：`review-handoff.json`。20 文件的 Git blob 和实际字节 SHA-256：`source-file-hashes.json`；证据文件校验见 `sha256-manifest.json`。

本任务 5328 UI 服务已在核对 PID 153656、创建时间及完整命令后停止。两轮仅清理已核对位于本隔离目录、无 reparse 的白名单，共 1054 个文件、16,754,279 字节；保留最终两套 File fixture、源捕获、全部原始成功/失败日志、截图和复现脚本。依赖 junction 目标、其他项目、旧工作区与用户既有服务未清理。

父任务可审核本地 98ce5423 并协调真实 Host 会话及与 Timeline 独立任务的集成；本任务不推送、不合 main、不创建 Tag/Release。源分支在交接后冻结，避免并发编辑。
