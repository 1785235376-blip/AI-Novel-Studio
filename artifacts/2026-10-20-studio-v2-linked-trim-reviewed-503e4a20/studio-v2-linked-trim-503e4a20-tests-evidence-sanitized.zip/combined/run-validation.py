from pathlib import Path
import os, subprocess, json, time, hashlib, concurrent.futures
root=Path(__file__).resolve().parent.parent; ev=Path(__file__).resolve().parent; own=root/'linked-trim-combined'; front=own/'frontend'
python=Path(r'<TASK_ROOT>\task-3\evidence\otio-metadata-p2\tools\pytest8-venv\Scripts\python.exe')
target=Path(r'<TASK_ROOT>\task\studio-v2-impact-decisions\frontend\node_modules'); link=front/'node_modules'
assert target.is_dir() and not link.exists()
r=subprocess.run(['cmd','/d','/c','mklink','/J',str(link),str(target)],capture_output=True); assert r.returncode==0,r.stderr
assert os.path.realpath(link)==os.path.realpath(target)
env={k:v for k,v in os.environ.items() if not any(s in k.upper() for s in ['API_KEY','TOKEN','SECRET','DATABASE_URL','DEV_SESSION'])}
env.pop('CREATIVE_GRAPH_CONDITIONS_V1',None)
env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',PYTHONPATH=str(own/'tests')+';'+str(own),PROJECT_ROOT=str(own),NOVEL_DATA_PATH=str(own/'.runtime/data'),LOCALAPPDATA=str(own/'.runtime/local'),STORAGE_BACKEND='file')
(own/'.runtime').mkdir(exist_ok=True)
config=ev/'pytest.ini';config.write_text('[pytest]\nmarkers =\n    file_backend_only: File contract\n    postgres_backend_only: PostgreSQL contract\n',encoding='utf-8')
backend=[str(python),'-B','-m','pytest','-c',str(config),'-p','no:cacheprovider','--basetemp',str(own/'.runtime/linked-trim-pytest'),'tests/test_timeline_linked_trim_additive.py::test_file_trim_replay_and_reopen_use_original_persistent_owner[file]','tests/test_timeline_linked_trim_additive.py::test_file_full_save_cas_history_and_forged_partner_rollback[file]','tests/test_timeline_linked_split_additive.py::test_file_split_same_request_reopen_and_two_relations_still_work[file]','tests/test_timeline_linked_split_additive.py::test_exact_partition_offsets_and_whole_dto_guard_without_schema_change[250]','-q','--junitxml='+str(ev/'backend.xml')]
frontend=['node','node_modules/vitest/vitest.mjs','run','src/creative/StudioTimelineLinkedTrim.additive.test.tsx','src/creative/StudioTimelineLinkedSplit.additive.test.tsx','-t','uses one Undo|preserves old single-clip|rejects retained selection ABA|partitions both sources exactly while retaining offset 250','--maxWorkers=1','--minWorkers=1','--no-file-parallelism','--no-cache','--reporter=default','--reporter=junit','--outputFile='+str(ev/'frontend.xml')]
results={}
def run(name,cmd,cwd):
 started=time.time()
 (ev/(name+'-command.json')).write_text(json.dumps(dict(command=cmd,cwd=str(cwd),external_credentials_removed=True,schema7_flag='UNSET / default OFF'),ensure_ascii=False,indent=2),encoding='utf-8')
 with (ev/(name+'.log')).open('wb') as f:r=subprocess.run(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
 item=dict(exit=r.returncode,seconds=round(time.time()-started,3),log=name+'.log');results[name]=item
 print(name,json.dumps(item),flush=True)
 assert r.returncode==0, name+' failed; see retained log'
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 fs=[pool.submit(run,'backend',backend,own),pool.submit(run,'frontend',frontend,front)]
 for f in fs:f.result()
run('typescript',['node','node_modules/typescript/bin/tsc','-b','--pretty','false'],front)
run('build',['node','node_modules/vite/bin/vite.js','build'],front)
(ev/'validation-results.json').write_text(json.dumps(dict(status='PASS',combined=json.loads((ev/'setup.json').read_text(encoding='utf-8'))['combined'],backend_real_File=3,backend_source_guard_unit=1,frontend_controlled_client_JSDOM=3,frontend_split_guard_unit=1,frontend_other_cases_skipped=19,typescript_runs=1,build_runs=1,results=results,full_E2E=False,postgres=False,real_models=False,schema7_default='OFF',dependency_junction_target=str(target)),ensure_ascii=False,indent=2),encoding='utf-8')
