"""Exactly two independent File checks; original target product imported read-only."""
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace
import hashlib
import json
import pytest
from app.experimental.common import StaleSourceError
from app.services.studio_timeline_links import split_linked_pair
from app.services.studio_timeline_render import normalize_studio_timeline
from app.services.v1_capability_service import CapabilityVersionConflict
from test_v2_independent_workspace import rig as original_rig, import_asset, reopened
from test_v2_audio_editing_pipeline import production, source, edit_body, cpu_video, audible_wav

ROOT = Path(__file__).parent

@pytest.fixture
def owner(tmp_path, monkeypatch):
    gen = original_rig.__wrapped__(SimpleNamespace(param='file'), tmp_path, monkeypatch)
    e = next(gen); e.service.activate(e.nid, e.scope, e.actor)
    e.video = import_asset(e, data=cpu_video(tmp_path/'tiny-source.mp4'), filename='review-source.mp4', kind='video')
    e.audio = import_asset(e, data=audible_wav(), filename='review-source.wav', kind='audio')
    e.production = production(e)
    yield e
    try: next(gen)
    except StopIteration: pass

def timeline(e, offset):
    return {'schema_version':2,'duration_ms':8000,'width':64,'height':64,'fps':25,
        'captions':[{'start_ms':0,'end_ms':100,'text':'Keep unrelated original caption'}], 'tracks':[
        {'id':'visual','kind':'VIDEO','order':0,'clips':[
            {'id':'v','source_snapshot':source(e.video),'start_ms':1300,'in_ms':123,'out_ms':943,'x':2,'y':4,'width':32,'height':32,'opacity':0.75},
            {'id':'unrelated-v','source_snapshot':source(e.video),'start_ms':4000,'in_ms':10,'out_ms':210}]},
        {'id':'voice','kind':'AUDIO','order':1,'clips':[
            {'id':'a','source_snapshot':source(e.audio),'start_ms':1300+offset,'in_ms':17,'out_ms':617,'gain_db':-3}]},
        {'id':'ambience','kind':'AUDIO','order':2,'clips':[
            {'id':'unrelated-a','source_snapshot':source(e.audio),'start_ms':40,'in_ms':0,'out_ms':50}]}],
        'clip_links':[{'video_clip_id':'v','audio_clip_id':'a','offset_ms':offset}]}

def save(e, offset=-275):
    return e.production.timeline_save(e.nid,e.scope,e.actor,None,
        {'title':'Independent fixed-start linked trim','expected_version':0,'timeline':timeline(e,offset)},lambda:None)
def clips(value): return {c['id']:(t['id'],c)for t in value['tracks']for c in t['clips']}
def op(start=37,end=563):
    return {'op':'clip.trim_linked','video_clip_id':'v','audio_clip_id':'a','keep_from_ms':start,'keep_to_ms':end}
def edit(e,row,ops,key,guard=lambda:None,actor=None):
    return e.production.timeline_edit(e.nid,e.scope,actor or e.actor,row['id'],edit_body(row,ops,key),guard)
def files(e): return {str(p.relative_to(e.root)):p.read_bytes()for p in e.root.rglob('*.json')}
def expected_trim(before,start,end):
    result=deepcopy(before)
    for identity in ['v','a']:
        original=clips(before)[identity][1];clips(result)[identity][1].update(in_ms=original['in_ms']+start,out_ms=original['in_ms']+end)
    return result
def whole(e,row,value,guard=lambda:None):
    return e.production.timeline_save(e.nid,e.scope,e.actor,row['id'],
        {'title':row['title'],'expected_version':row['version'],'timeline':value},guard)

def test_review1_exact_signed_offset_boundary_subintervals_and_original_file_roundtrip(owner):
    e=owner;cases=[]
    for offset in [275,-425]:
        for start,end in [(0,1),(599,600),(1,599),(0,600)]:
            row=save(e,offset);expected=expected_trim(row['timeline'],start,end)
            body=edit_body(row,[op(start,end)],f'fixed-{offset}-{start}-{end}')
            made=e.production.timeline_edit(e.nid,e.scope,e.actor,row['id'],body,lambda:None)
            assert made['timeline']==expected and made['version']==row['version']+1
            assert set(made['timeline'])==set(row['timeline']) and made['timeline']['clip_links']==row['timeline']['clip_links']
            for identity in ['v','a']:
                original,changed=clips(row['timeline'])[identity],clips(made['timeline'])[identity]
                assert changed[0]==original[0] and changed[1]['start_ms']==original[1]['start_ms']
                assert changed[1]['out_ms']-changed[1]['in_ms']==end-start
                assert original[1]['in_ms']<=changed[1]['in_ms']<changed[1]['out_ms']<=original[1]['out_ms']
            state=files(e)
            assert e.production.timeline_edit(e.nid,e.scope,e.actor,row['id'],body,lambda:None)==made and files(e)==state
            fresh=production(e,reopened(e));assert fresh.timeline_get(e.nid,e.scope,e.actor,row['id'],lambda:None)==made
            assert fresh.timeline_history(e.nid,e.scope,e.actor,row['id'],lambda:None)['items'][0]['timeline']==row['timeline']
            twin=save(e,offset);saved=whole(e,twin,expected)
            assert saved['timeline']==expected and production(e,reopened(e)).timeline_get(e.nid,e.scope,e.actor,twin['id'],lambda:None)==saved
            assert fresh.timeline_history(e.nid,e.scope,e.actor,twin['id'],lambda:None)['items'][0]['timeline']==twin['timeline']
            if (start,end)==(0,600):assert clips(made['timeline'])['a']==clips(row['timeline'])['a']
            cases.append({'offset':offset,'keep':[start,end],'before':row,'edited':made,'whole_saved':saved})
    assert e.production.list(e.nid,e.scope,e.actor,lambda:None)['items']==[]
    (ROOT/'case1-file.json').write_text(json.dumps({'cases':cases,'assets':[e.video,e.audio],'render_jobs':0,
        'file_json_sha256':{name:hashlib.sha256(raw).hexdigest()for name,raw in files(e).items()}},indent=2),encoding='utf-8')

def test_review2_refusal_atomicity_bounds_locks_sources_cas_authority_and_split_guard(owner,monkeypatch):
    e=owner;row=save(e);rejects=[]
    def refused(label,call,expected):
        before=files(e)
        with pytest.raises(expected)as caught:call()
        assert files(e)==before,label
        rejects.append({'case':label,'type':type(caught.value).__name__,'reason':str(caught.value)})
    invalid=[op(-1,500),op(40,40),op(501,500),op(0,601),op(0,820),op(True,500),op(0,True),op(0.5,500),
        {**op(),'audio_clip_id':'unrelated-a'},{**op(),'ripple':True},{**op(),'extend':True},
        {'op':'clip.trim','clip_id':'v','in_ms':160,'out_ms':686,'ripple':False}]
    for index,value in enumerate(invalid):
        refused(f'invalid-trim-{index}',lambda value=value,index=index:edit(e,row,[value],f'invalid-{index}'),ValueError)
    refused('valid-prefix-plus-trim',lambda:edit(e,row,[{'op':'caption.insert','caption':{'start_ms':200,'end_ms':250,'text':'must roll back'}},op()],'mixed'),ValueError)
    valid=expected_trim(row['timeline'],37,563)
    for fault in ['audio-in-point','member-starts','unrelated-caption','member-property','unrelated-clip']:
        forged=deepcopy(valid);by=clips(forged)
        if fault=='audio-in-point':by['a'][1]['in_ms']+=1
        elif fault=='member-starts':by['a'][1]['start_ms']+=2;by['v'][1]['start_ms']+=2
        elif fault=='unrelated-caption':forged['captions'][0]['text']='must not sneak into trim'
        elif fault=='member-property':by['a'][1]['gain_db']=-4
        else:by['unrelated-v'][1]['start_ms']+=1
        assert normalize_studio_timeline(forged)==forged
        refused('whole-save-'+fault,lambda forged=forged:whole(e,row,forged),ValueError)
    orphaned=split_linked_pair(row['timeline'],'v','a',1600,'tail-v','tail-a')
    orphaned['clip_links']=[pair for pair in orphaned['clip_links']if pair['video_clip_id']=='v']
    assert normalize_studio_timeline(orphaned)==orphaned
    refused('d946-orphaned-split-not-a-trim',lambda:whole(e,row,orphaned),ValueError)
    locked=edit(e,row,[{'op':'track.update','track_id':'voice','changes':{'locked':True}}],'lock')
    refused('locked-edit',lambda:edit(e,locked,[op()],'locked'),ValueError)
    refused('locked-whole-save',lambda:whole(e,locked,expected_trim(locked['timeline'],37,563)),ValueError)
    ready=edit(e,locked,[{'op':'track.update','track_id':'voice','changes':{'locked':False}}],'unlock')
    valid=expected_trim(ready['timeline'],37,563)
    refused('foreign-actor',lambda:edit(e,ready,[op()],'foreign',actor='independent-other-actor'),FileNotFoundError)
    refused('stale-edit-cas',lambda:edit(e,row,[op()],'stale-edit'),StaleSourceError)
    refused('stale-save-cas',lambda:whole(e,row,valid),CapabilityVersionConflict)
    original_view=e.production._timeline_view;revoked={'value':False,'edit_view':0,'save_before_commit':0}
    def view_then_revoke(*args,**kwargs):
        result=original_view(*args,**kwargs)
        if result['id']==ready['id']and result['version']>ready['version']and result['timeline']==valid:
            revoked['value']=True;revoked['edit_view']+=1
        return result
    def guard():
        if revoked['value']:raise PermissionError('late original transaction guard revoked after trimmed view')
    def save_guard():
        # Save's view is read after commit. Revoke on its original guard while the mutated row is still in the active transaction.
        document=e.production.store._local.active.get(e.production.store.key(e.nid,e.scope))
        if document:
            candidate=next((collection[ready['id']]for collection in document['collections'].values()
                if isinstance(collection,dict)and ready['id']in collection),None)
            if candidate and candidate['version']>ready['version']and candidate['timeline']==valid:
                revoked['save_before_commit']+=1
                raise PermissionError('original Save guard revoked after row change, before commit')
    with monkeypatch.context()as patch:
        patch.setattr(e.production,'_timeline_view',view_then_revoke)
        refused('late-permission-edit',lambda:edit(e,ready,[op()],'late-edit',guard=guard),PermissionError)
        revoked['value']=False
        refused('late-permission-save',lambda:whole(e,ready,valid,save_guard),PermissionError)
    assert revoked['edit_view']>=1 and revoked['save_before_commit']>=1
    with e.service._asset_scope(e.nid,e.scope):e.assets.update_metadata(e.audio['id'],{'scene_id':'changed-before-trim'},expected_version=e.audio['version'])
    refused('stale-source-edit',lambda:edit(e,ready,[op()],'stale-source'),(ValueError,FileNotFoundError,StaleSourceError))
    refused('stale-source-save',lambda:whole(e,ready,valid),(ValueError,FileNotFoundError,StaleSourceError))
    assert e.production.timeline_get(e.nid,e.scope,e.actor,ready['id'],lambda:None)==ready
    assert e.production.list(e.nid,e.scope,e.actor,lambda:None)['items']==[]
    (ROOT/'case2-rejections.json').write_text(json.dumps({'rejections':rejects,'unchanged':True,'late_guard_reached':revoked},indent=2),encoding='utf-8')
