# 联动裁剪独立复核

目标 `a36bc5b7d0211527b45606ec87ebba7cc8402cbf`，直接父版本 `d9466d253fa4d8141391fd7295af65ce7276ee56`。读完全部 11 个变更文件。三组独立检查通过，本限定范围内未发现 P1/P2；可按原 Timeline owner 上的 **schema 2、单对、1×、固定原起点、无扩展／波纹／淡化／转场**限定整合，不外推为全部裁剪支持。

1. 原 File 服务对 offset +275/−425ms，分别保留 [0,1)、[599,600)、[1,599)、[0,600)。原视频来源 [123,943)，音频 [17,617)，两者均按原入点加共同相对区间，原 timeline 起点、IDs、轨道、offset、其他属性／字幕／片段均保持。最后一组的较短音频成员本来就是 600ms，允许其来源不变而视频缩短。八个案例均完成原 /edit 重放、整表 Save、重开与 history，无新 schema 字段、无渲染任务。

2. 28 个拒绝分支每次比较所有既有 File JSON 字节，均无半写：越界、空反区间、类型、错误成员、未知扩展／波纹字段、旧单边裁剪、混批，五种 schema 合法的整表伪造，d946 缺少尾链接的拆分伪造，锁、外部 actor、两条 CAS、晚期撤权和真实 Asset 版本失效。/edit 在新视图生成后撤权；整表 Save 在原 guard 可见新行／版本但尚未提交时撤权，两个实际事务均回滚。

3. 原 hook/editor 使用第一组真实同项目 File 行和素材，客户端为受控 JSDOM 夹具。草稿、权限、来源、表单输入、选区和文档 ABA 的旧回调拒绝；普通数值／单边控件不能借较短成员不变获得联动能力。明确 Apply 重复调用只接受一次，一次 Undo/Redo 恢复整对；权限禁止时不能 Undo；原 CAS Save 清空本地历史。实际 UI 同时预览两来源区间和固定起点。UNKNOWN Save 保留已裁剪输入并阻止 Undo/Redo、再次 Apply 与重发 Save，无自动 render 或 /edit。

原始失败保留于 `backend1.log`、`backend-probe-initial.py` 与隔离运行目录：检查 1 已通过；检查 2 的整表 Save 探针错误地把提交后读取视图当成提交前围栏。读原 owner 确认 `timeline_save` 在事务结束后才 `timeline_get`，因此该撤权时点已经在提交后。没有把它当作产品问题，也没有改产品或降低边界；改用实际提交前 guard，在 active transaction 内确认新裁剪行／版本后撤权，只重跑检查 2，`backend2.log` 通过。前端一次通过。两个 pytest helper marker 告警保留，未运行 PostgreSQL 或修改配置。

目标 HEAD、空 git status 与 11 个源码 SHA 前后一致。只复制三份精确测试 helper，共 94,743 字节；产品／依赖零复制，复用原 junction。没有重跑作者 39+52 项、类型、构建、几何或全套；没有改演示／共享文件，没有启动服务、提交或推送。

Host、真实浏览器 HTTP／ACL、PostgreSQL、Timeline 渲染／导出／播放均未验收。这里的相对来源区间不承诺相同绝对时间区间或左边缘前移。原小型 File 数据、所有失败及最终回执保留以便核对。精确命令与版本见 `*-command.json`、`validation-environment.json`；结构化结论见 `review-handoff.json`。
