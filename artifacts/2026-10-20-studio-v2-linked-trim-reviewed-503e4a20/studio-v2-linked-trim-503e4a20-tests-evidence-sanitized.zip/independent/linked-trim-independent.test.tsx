import { act, cleanup, fireEvent, render, renderHook, screen, waitFor, within } from '@testing-library/react';
import { expect, it, vi } from 'vitest';
import { writeFileSync } from 'node:fs';
import { ApiError } from '<TASK_ROOT>/task-13/linked-split/frontend/src/api';
import { StudioTimelineEditor } from '<TASK_ROOT>/task-13/linked-split/frontend/src/creative/StudioTimelineEditor';
import { useStudioTimelineEditor, type StudioTimelineEditorProps } from '<TASK_ROOT>/task-13/linked-split/frontend/src/creative/useStudioTimelineEditor';
import { checkedTimelineRow, cloneTimeline, type StudioTimelineDraft } from '<TASK_ROOT>/task-13/linked-split/frontend/src/creative/studioTimelineTypes';
import type { StudioProductionClient } from '<TASK_ROOT>/task-13/linked-split/frontend/src/creative/studioProductionClient';
import type { StudioAsset } from '<TASK_ROOT>/task-13/linked-split/frontend/src/creative/studioClient';
import evidence from './case1-file.json';

const native=evidence.cases.find(c=>c.offset===275&&c.keep[0]===1&&c.keep[1]===599)!;
const row=checkedTimelineRow(native.before),other=checkedTimelineRow(evidence.cases.find(c=>c.offset===275&&c.keep[0]===0&&c.keep[1]===1)!.before);
const trimmed=checkedTimelineRow(native.edited);
function setup(panel=false){
 const rows=new Map([[row.id,cloneTimeline(row)],[other.id,cloneTimeline(other)]]);
 const client={timelineList:vi.fn(async()=>({items:[...rows.values()].map(v=>cloneTimeline(v))})),timelineGet:vi.fn(async(id:string)=>cloneTimeline(rows.get(id)!)),
  timelineSave:vi.fn(async(id:string|undefined,body:StudioTimelineDraft&{expected_version:number})=>{
   expect(id).toBe(row.id);expect(body).toEqual({title:row.title,timeline:trimmed.timeline,expected_version:row.version});
   rows.set(row.id,cloneTimeline(trimmed));return cloneTimeline(trimmed);
  }),timelineEdit:vi.fn(),timelineRender:vi.fn()};
 const props:StudioTimelineEditorProps={client:client as unknown as StudioProductionClient,assets:evidence.assets as unknown as StudioAsset[],canMutate:true,busy:false,
  projectId:native.before.novel_id,isCurrent:()=>true,read:work=>work(),mutate:work=>work(),onDirtyChange:vi.fn(),onJob:vi.fn(),onUnavailable:vi.fn()};
 const hook=panel?undefined:renderHook((value:StudioTimelineEditorProps)=>useStudioTimelineEditor(value),{initialProps:props});
 if(panel)render(<StudioTimelineEditor {...props}/>);return{client,props,hook};
}
async function adopt(s:ReturnType<typeof setup>){const h=s.hook!;await waitFor(()=>expect(h.result.current.rows).toHaveLength(2));
 await act(async()=>h.result.current.checkServer(row.id));act(()=>h.result.current.setAdoptConfirmed(true));act(()=>h.result.current.adoptCandidate(false));}
const noExecution=(s:ReturnType<typeof setup>)=>{expect(s.client.timelineEdit).not.toHaveBeenCalled();expect(s.client.timelineRender).not.toHaveBeenCalled();};
const reactClick=(button:HTMLElement)=>{const key=Object.keys(button).find(k=>k.startsWith('__reactProps$'))!;
 return(button as unknown as Record<string,{onClick:()=>void}>)[key].onClick;};
async function uiAdopt(id:string){fireEvent.change(screen.getByLabelText('读取已保存时间线'),{target:{value:id}});
 const review=await screen.findByLabelText('核对服务端时间线');fireEvent.click(within(review).getByLabelText('已核对服务端内容与本地输入，确认以下选择'));
 fireEvent.click(within(review).getByRole('button',{name:'采用服务端时间线'}));}
const fill=(from=1,to=599)=>{fireEvent.change(screen.getByLabelText('共同保留入点（相对毫秒）'),{target:{value:String(from)}});
 fireEvent.change(screen.getByLabelText('共同保留出点（相对毫秒）'),{target:{value:String(to)}});};
const apply=()=>screen.getByRole('button',{name:'按已预览区间联动裁剪链接'});

it('independently checks trim intent/history, input/selection/document ABA and UNKNOWN Save using genuine same-project File receipts',async()=>{
 const s=setup();await adopt(s);const h=s.hook!,before=cloneTimeline(h.result.current.draft);
 const retiredDraft=h.result.current.trimLinkedClips;act(()=>h.result.current.change(d=>{d.title+=' temporary';}));act(()=>h.result.current.undo());
 expect(h.result.current.draft).toEqual(before);act(()=>expect(retiredDraft(['v'],1,599)).toBe(false));
 const retiredPermission=h.result.current.trimLinkedClips;h.rerender({...s.props,canMutate:false});h.rerender(s.props);
 act(()=>expect(retiredPermission(['v'],1,599)).toBe(false));
 h.rerender({...s.props,assets:s.props.assets.filter(a=>a.kind!=='audio')});
 act(()=>expect(h.result.current.trimLinkedClips(['a'],1,599)).toBe(false));expect(h.result.current.draft).toEqual(before);h.rerender(s.props);
 // Short member is already 600ms: numeric/single controls must not accidentally acquire the explicit linked intent.
 act(()=>expect(h.result.current.change(d=>{d.timeline.tracks[0].clips[0].out_ms=723;})).toBe(false));
 act(()=>expect(h.result.current.trimClip('visual','v',123,723,false)).toBe(false));expect(h.result.current.draft).toEqual(before);
 act(()=>expect(h.result.current.trimLinkedClips(['a'],0,600)).toBe(true));
 expect(h.result.current.draft.timeline.tracks[1].clips[0]).toEqual(before.timeline.tracks[1].clips[0]);
 act(()=>h.result.current.undo());expect(h.result.current.draft).toEqual(before);
 const click=h.result.current.trimLinkedClips;
 act(()=>{expect(click(['a'],1,599)).toBe(true);expect(click(['v'],2,598)).toBe(false);});
 const value=cloneTimeline(h.result.current.draft);expect(value).toEqual({title:row.title,timeline:trimmed.timeline});
 h.rerender({...s.props,canMutate:false});act(()=>h.result.current.undo());expect(h.result.current.draft).toEqual(value);h.rerender(s.props);
 act(()=>h.result.current.undo());expect(h.result.current.draft).toEqual(before);act(()=>h.result.current.redo());expect(h.result.current.draft).toEqual(value);
 expect(s.client.timelineSave).not.toHaveBeenCalled();await act(async()=>h.result.current.save());expect(s.client.timelineSave).toHaveBeenCalledTimes(1);
 expect(h.result.current.canUndo).toBe(false);expect(h.result.current.canRedo).toBe(false);await act(async()=>h.result.current.checkServer(row.id));
 act(()=>h.result.current.setAdoptConfirmed(true));act(()=>h.result.current.adoptCandidate(false));expect(h.result.current.draft).toEqual(value);noExecution(s);cleanup();

 const ui=setup(true);await waitFor(()=>expect(screen.getByLabelText('读取已保存时间线').querySelector(`option[value="${row.id}"]`)).toBeTruthy());await uiAdopt(row.id);
 const selectV=()=>fireEvent.click(within(screen.getByLabelText('轨道头')).getByRole('button',{name:'v'}));selectV();fill();
 const panel=screen.getByRole('region',{name:'已保存链接联动裁剪'});
 expect(within(panel).getByText(/v：来源 \[123, 943\) → \[124, 722\).*起点保持 1300/)).toBeTruthy();
 expect(within(panel).getByText(/a：来源 \[17, 617\) → \[18, 616\).*起点保持 1575/)).toBeTruthy();
 const oldInput=reactClick(apply());fill(2,599);fill();act(()=>oldInput());
 expect((screen.getByRole('button',{name:'撤销本地编辑'})as HTMLButtonElement).disabled).toBe(true);
 const oldSelection=reactClick(apply());fireEvent.click(within(screen.getByLabelText('轨道头')).getByRole('button',{name:'unrelated-v'}));selectV();
 act(()=>oldSelection());expect((screen.getByRole('button',{name:'撤销本地编辑'})as HTMLButtonElement).disabled).toBe(true);fill();
 const oldDocument=reactClick(apply());await uiAdopt(other.id);await uiAdopt(row.id);selectV();fill();act(()=>oldDocument());
 expect((screen.getByRole('button',{name:'撤销本地编辑'})as HTMLButtonElement).disabled).toBe(true);
 const fresh=reactClick(apply());act(()=>{fresh();fresh();});expect(ui.client.timelineSave).not.toHaveBeenCalled();noExecution(ui);
 fireEvent.click(screen.getByRole('button',{name:'撤销本地编辑'}));expect((screen.getByRole('button',{name:'撤销本地编辑'})as HTMLButtonElement).disabled).toBe(true);
 fireEvent.click(screen.getByRole('button',{name:'重做本地编辑'}));fireEvent.click(screen.getByRole('button',{name:'保存时间线'}));
 await waitFor(()=>expect(ui.client.timelineSave).toHaveBeenCalledTimes(1));noExecution(ui);cleanup();

 const uncertain=setup();await adopt(uncertain);const u=uncertain.hook!;act(()=>expect(u.result.current.trimLinkedClips(['v','a'],1,599)).toBe(true));
 const retained=cloneTimeline(u.result.current.draft);uncertain.client.timelineSave.mockRejectedValueOnce(new ApiError({status:0,code:'NETWORK_ERROR',message:'lost Save reply'}));
 await act(async()=>u.result.current.save());expect(u.result.current.failure).toBe('UNKNOWN');
 act(()=>{u.result.current.undo();u.result.current.redo();expect(u.result.current.trimLinkedClips(['v'],2,598)).toBe(false);});
 expect(u.result.current.draft).toEqual(retained);await act(async()=>u.result.current.save());expect(uncertain.client.timelineSave).toHaveBeenCalledTimes(1);noExecution(uncertain);cleanup();
 writeFileSync('case3-proof.json',JSON.stringify({status:'passed',scope:'Original hook/editor, actual same-project File inputs, controlled clients/JSDOM; no Host/live HTTP',
  old_draft_permission_input_selection_document_aba_refused:true,unchanged_short_member_only_explicit_intent:true,
  repeated_apply_once:true,undo_redo_one_action:true,original_cas_save_and_history_reset:true,unknown_save_preserves_pair_and_blocks_undo_redo_retry:true,
  render_or_edit_requests:0},null,2));
});
