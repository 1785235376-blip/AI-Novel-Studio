import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
export default defineConfig({ plugins:[react()],cacheDir:'.cache',resolve:{dedupe:['react','react-dom']},
  server:{fs:{allow:['<TASK_ROOT>/task-5/linked-trim-cross-review','<TASK_ROOT>/task-13/linked-split/frontend']}},
  test:{include:['linked-trim-independent.test.tsx'],environment:'jsdom',pool:'forks',minWorkers:1,maxWorkers:1,cache:false} });
