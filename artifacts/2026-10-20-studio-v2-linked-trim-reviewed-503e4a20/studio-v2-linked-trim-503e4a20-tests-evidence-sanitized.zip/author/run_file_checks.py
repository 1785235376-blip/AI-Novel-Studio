from pathlib import Path
import os, sys, subprocess, importlib.util, json
out = Path(__file__).resolve().parent
root = out.parent / 'linked-split'
spec = importlib.util.spec_from_file_location('isolation', root / 'scripts/run_v2_checks.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
env = os.environ.copy()
for key in list(env):
    if key.endswith(('_API_KEY', '_TOKEN', '_SECRET')) or key in {'DATABASE_URL', 'TEST_POSTGRES_DATABASE_URL', 'E2E_DATABASE_URL', 'COLLABORATION_DEV_SESSIONS_JSON', 'PACKAGED_CONTROL_PIPE'}:
        env.pop(key, None)
env.update(mod.isolated_environment(root, root / '.runtime/linked-trim/profile'))
env['PYTHONIOENCODING'] = 'utf-8'
env['PYTHONUTF8'] = '1'
env['PYTHONPATH'] = str(root)
cmd = [sys.executable, '-B', '-m', 'pytest', 'tests/test_timeline_linked_trim_additive.py', 'tests/test_timeline_linked_split_additive.py', '-k', 'not postgres', '-q', '--basetemp', str(root / '.runtime/linked-trim/pytest'), f'--junitxml={out / "file-checks.xml"}']
r = subprocess.run(cmd, cwd=root, env=env, capture_output=True, text=True, encoding='utf8', errors='replace', creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
(out / 'file-checks.log').write_text(r.stdout + r.stderr, encoding='utf8')
(out / 'file-checks-command.json').write_text(json.dumps({'command': cmd, 'exit_code': r.returncode, 'profile': str(root / '.runtime/linked-trim/profile')}, indent=2))
print(r.stdout + r.stderr)
sys.exit(r.returncode)


