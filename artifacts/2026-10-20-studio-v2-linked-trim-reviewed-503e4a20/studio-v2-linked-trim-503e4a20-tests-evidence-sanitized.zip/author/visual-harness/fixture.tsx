import React, {useState} from 'react';
import {createRoot} from 'react-dom/client';
import {AppShell} from '../../src/ui/AppShell';
import {Button} from '../../src/ui/primitives';
import {LinkedClipTrimPanel} from '../../src/nle/LinkedClipTrimPanel';
import {trimLinkedTimeline} from '../../src/creative/studioTimelineLinkedTrim';
import {checkedTimeline} from '../../src/creative/studioTimelineTypes';
import '../../src/ui/ui.css';import '../../src/ui/fixture.css';import '../../src/ui/desktop-craft.css';
const snapshot=(kind:'video'|'audio')=>({id:'synthetic-'+kind,kind:'ASSET',asset_kind:kind,version:1,digest:'a'.repeat(64)});
const initial=checkedTimeline({schema_version:2,duration_ms:8000,width:64,height:64,fps:25,captions:[],tracks:[
 {id:'visual',kind:'VIDEO',order:0,muted:false,gain_db:0,clips:[{id:'picture',source_snapshot:snapshot('video'),start_ms:1000,in_ms:100,out_ms:900,x:0,y:0,width:64,height:64},{id:'unselected-video',source_snapshot:snapshot('video'),start_ms:4000,in_ms:0,out_ms:500,x:0,y:0,width:64,height:64}]},
 {id:'voice',kind:'AUDIO',order:1,muted:false,gain_db:0,clips:[{id:'sound',source_snapshot:snapshot('audio'),start_ms:1250,in_ms:50,out_ms:850},{id:'unselected-audio',source_snapshot:snapshot('audio'),start_ms:4000,in_ms:0,out_ms:500}]}],clip_links:[{video_clip_id:'picture',audio_clip_id:'sound',offset_ms:250}]});
function Fixture(){const[timeline,setTimeline]=useState(initial),changed=timeline!==initial;return <AppShell module="VIDEO" onModuleChange={()=>{}} scope={{workspace:'合成 UI 夹具',project:'EDIT04 / AUDIO09',storyline:'原 Timeline',branch:'有界联动裁剪'}} actor="界面检查"
 sidebar={<div className="placeholder-sidebar"><h2>联动裁剪</h2><p>合成 UI 夹具：仅验证真实 React 控件与壳层几何。独立 File 验收另有日志；本页未连接后端，不代表生成、播放或渲染。</p><p>选定绑定 picture / sound；显式输入共同保留区间。</p><Button onClick={()=>setTimeline(initial)}>重置合成状态</Button></div>}
 main={<><LinkedClipTrimPanel key={changed?'trimmed':'saved'} timeline={timeline} selectedClipIds={['picture']} ready={!changed} onTrim={(from,to)=>setTimeline(value=>checkedTimeline(trimLinkedTimeline(value,['picture'],from,to)))}/>
 {changed&&<p role="status">合成草稿已联动裁剪：picture [200, 750)，sound [150, 700)；原起点、250 毫秒偏移及未选片段保持。实际编辑器请先保存。</p>}</>}
 inspector={<div className="fixture-inspector"><h2>来源与未选内容</h2>{timeline.tracks.flatMap(track=>track.clips.map(clip=><p key={clip.id}>{clip.id}<br/>起点 {clip.start_ms} ms<br/>来源 [{clip.in_ms}, {clip.out_ms}) ms</p>))}<p>picture ↔ sound · 偏移 250 ms</p></div>}
 status={<>合成 UI 夹具 · 未调用后端／模型 · 真实 File 验收独立记录</>}/>;}
createRoot(document.getElementById('root')!).render(<Fixture/>);
