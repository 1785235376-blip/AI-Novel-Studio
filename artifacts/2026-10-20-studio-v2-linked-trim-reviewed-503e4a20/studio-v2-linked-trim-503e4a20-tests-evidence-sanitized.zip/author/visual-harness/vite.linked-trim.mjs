import {defineConfig} from '../../frontend/node_modules/vite/dist/node/index.js';
import react from '../../frontend/node_modules/@vitejs/plugin-react/dist/index.js';
import {fileURLToPath} from 'node:url';
export default defineConfig({root:fileURLToPath(new URL('../../frontend/',import.meta.url)),plugins:[react()],cacheDir:fileURLToPath(new URL('./visual-cache/',import.meta.url)),server:{host:'127.0.0.1',port:5296,strictPort:true,fs:{allow:[fileURLToPath(new URL('../../',import.meta.url)),'<TASK_ROOT>/task/studio-v2-director-run-f4-combined/frontend/node_modules','<TASK_ROOT>/task/studio-v2-comic-live-handoff-browser/frontend/node_modules']}}});

