import { defineConfig } from '../../frontend/node_modules/vitest/dist/config.js';
import { fileURLToPath } from 'node:url';
export default defineConfig({
  root: fileURLToPath(new URL('../../frontend/', import.meta.url)),
  esbuild: { jsx: 'automatic' },
  cacheDir: fileURLToPath(new URL('./vite-cache', import.meta.url)),
  test: { setupFiles: ['./vitest.setup.ts'], environment: 'jsdom', cache: false, pool: 'forks', minWorkers: 1, maxWorkers: 1 },
});

