# 已保存 VIDEO/AUDIO 链接联动裁剪：本地交付

独立提交 `a36bc5b7d0211527b45606ec87ebba7cc8402cbf`，直接父提交 `d9466d253fa4d8141391fd7295af65ce7276ee56`。未 push、未 Release，未操作串行归档工作区。

源码仍位于自有工作区 `<TASK_ROOT>/task-13/linked-split`。完整操作、契约与边界在 `docs/TIMELINE_LINKED_TRIM_HANDOFF.md`；直接打开本目录 `index.html` 查看 4 张明确标注的**合成 UI**截图。

## 范围

只新增一对已保存 schema 2、1×、无转场/淡入淡出的 VIDEO/AUDIO 共同来源子区间裁剪。固定时间线起点，保持原 offset、ID、link 与未选内容，不波纹、不扩展。独占 `clip.trim_linked` edit 操作；UI 通过原控制器草稿、历史和 CAS Save。原单片段行为与 d946 联动拆分保留。

共同相对区间示例 `[100,650)`：视频原 `[100,900)` 变 `[200,750)`，音频原 `[50,850)` 变 `[150,700)`；起点仍为 1000/1250，偏移仍 250。双方结果在 Apply 前明确预览。

首次前端回归暴露“缺尾部链接的拆分可被误识别为裁剪”，原始失败日志保留在 `frontend-initial-cross-pattern-failure.log`。最终校验收紧为整个 Timeline 仅双方来源 in/out 变化；原拆分拒绝测试随后全部通过。**联动裁剪后先保存，再进行其他 Timeline 编辑**。没有新增持久字段。

## 实际验证

- `file-checks.xml/log`：39 passed，7 PostgreSQL 参数 deselected；其中新增裁剪 23 项（4 项真实 File），d946 拆分回归 16 项（3 项真实 File）。CPU 创建极短 MP4/WAV 并通过原素材导入与 File owner；验证精确来源与未选内容、replay/reopen、CAS/history、最终 commit guard 撤回权限回滚、锁定/失效来源/错误范围不写入。
- `frontend-checks.xml/log`：52 passed，包括新增裁剪 16 项、原单片段裁剪 29 项、d946 拆分 7 项；一次 Undo/Redo、原 CAS Save、重复和失效回调、权限/输入/选择 ABA、来源版本变化、UNKNOWN 原请求保留及手动读取均有定向回归。UNKNOWN 测试只调用 mock render/list，没有真实渲染。
- `typecheck-exit.txt`：0，`typecheck.log` 无输出。`visual-result.json`：实际 React VIDEO 控件在 1366×768、1440×900、1920×1080 无文档横向溢出，壳层高 56/44/32，无 pageerror。未修改共享视觉基线。

## 复现

在源码工作区执行；隔离 runner 会只在 `.runtime/linked-trim/` 内创建测试数据：

```powershell
& '<TASK_ROOT>/task-3/evidence/otio-metadata-p2/tools/pytest8-venv/Scripts/python.exe' -B ../linked-trim-evidence/run_file_checks.py
node frontend/node_modules/vitest/vitest.mjs run --config .runtime/linked-trim/vitest.config.mjs src/creative/StudioTimelineLinkedTrim.additive.test.tsx src/creative/StudioTimelineLinkedSplit.additive.test.tsx src/creative/StudioTimelineTrim.test.tsx
```

类型检查在 `frontend` 运行 `node node_modules/typescript/bin/tsc -b`。依赖复用原 junction，未安装依赖。视觉脚本及配置保留在 `.runtime/linked-trim/`，前端夹具位于 `frontend/.runtime/linked-trim/`，本目录 `visual-harness/` 有副本。独占 5296 时可复现画面：

```powershell
node frontend/node_modules/vite/bin/vite.js --config .runtime/linked-trim/vite.linked-trim.mjs --configLoader native
# 另一个终端，仍在源码工作区：
node .runtime/linked-trim/check-visual.mjs
```

## 未验部分与保护

未验 PostgreSQL、真实浏览器到 HTTP 的保存与 ACL、媒体播放/渲染/导出、多对绑定、扩展/波纹/变速/淡入淡出/转场裁剪；不代表全 NLE 完成。File 权限用例验证真实事务的合成撤权 guard，并非真实 HTTP 身份鉴权。

无模型/付费 API 调用，无购买，无 DSH 六组件/Graph 公共核心/渲染播放实现更改，无演示服务修改。旧演示 ZIP SHA256 仍为 `29589627f5b2f50177d407de69e4e63864b56e9b179fcf0c6ae1db878886b8e8`；旧链接/移动工作区仍为 `a8d3030215a4975f07045ebdbb71c354dffb8ea2`。清理仅涉及自有 5296 进程和已验证路径下的可重建临时数据，全部唯一证据和复现源码保留。
