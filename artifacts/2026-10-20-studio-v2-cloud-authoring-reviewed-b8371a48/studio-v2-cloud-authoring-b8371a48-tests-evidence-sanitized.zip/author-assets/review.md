# Asset comparison boundary review

Verdict: both identified P2 issues are fixed. No remaining P1/P2 finding in the scoped comparison preview and host-transport review.

## Verified fixes

- Decoder failures: image/audio/video elements call bounded `mediaFailed`; only the still-current object URL can fail the slot. Failure stops playback, revokes bytes, clears the element, shows a fixed failure notice, and permits explicit retry. The actual-host audio case verifies cleanup and successful retry through the original owner.
- Host redraw stability: the Asset Browser uses a dedicated memoized `assetTransport`. A preference-draft edit in the actual `IndependentStudioWorkspace` preserves the same comparison media DOM node, object URL, and active playback, with no repeated comparison metadata or binary read.
- Explicit credential override: `assetTransport` depends on both `client` and `context.localHostToken`. A token-only prop change retires old comparison media; subsequent metadata and explicitly requested comparison bytes use the replacement token. Rotating back starts a fresh preview epoch and retires the replacement URL.

## Credential/authority review

- `client` changes for project, session token, actor ID, and every scope component.
- The session wrapper `signature` also covers actor workspace ID, ensuring a keyed session replacement for that change.
- `sameStudioIdentity` compares the captured session signature with the authoritative Studio store.
- `sameHostIdentity` compares captured Host token, actor ID, and epoch; synchronous subscriptions permanently retire the old session on observed ABA, including changes that return within a React batch.
- The dedicated Asset transport explicitly covers `localHostToken`, which is not represented in the Studio store signature. Task transport and unrelated consumers are unchanged.

## Test evidence

Command, run only for the newly authorized test file with one worker:

`./node_modules/.bin/vitest run src/assetbrowser/AssetBrowserHost.comparison.test.tsx --maxWorkers=1 --minWorkers=1`

Result: 1 file passed; 7 tests passed; 8.71 seconds total. Full output: `mounted-host-tests.log` in this evidence directory.

The seven scenarios cover unrelated host draft/playback preservation; mounted decoder cleanup/retry; Studio credential ABA; Host credential ABA; Host epoch ABA; keyed session replacement using new request headers; and explicit localHostToken replacement plus return cleanup.

The complete real workspace, browser, comparison, and byte-verification helper are mounted. Only HTTP owner responses and unavailable browser media APIs are substituted. Tests dispatch decoder events explicitly; they do not claim a real browser successfully decoded the fixture audio.

Scope: wrote only `frontend/src/assetbrowser/AssetBrowserHost.comparison.test.tsx` plus the requested evidence files. No product edits, installations, build, browser run, or push. Final TypeScript/build and integration belong to the parent.
