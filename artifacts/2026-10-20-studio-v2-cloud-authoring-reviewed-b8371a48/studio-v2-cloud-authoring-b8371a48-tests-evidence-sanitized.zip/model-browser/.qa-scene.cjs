const {chromium,expect}=require('@playwright/test');
const fs=require('fs');
(async()=>{const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});const page=await browser.newPage({locale:'zh-CN',timezoneId:'Asia/Shanghai',deviceScaleFactor:1});const errors=[];page.on('pageerror',error=>errors.push(error.message));const checks=[];
for(const viewport of [{width:1366,height:768},{width:1440,height:900},{width:1920,height:1080}]){
 await page.setViewportSize(viewport);await page.goto('http://127.0.0.1:5192/.qa-scene.html');await page.evaluate(()=>document.fonts.ready);
 await page.getByLabel('诊断坐标空间').selectOption('scene');await page.getByRole('button',{name:'明确读取 GLB 静态场景'}).click();await expect(page.getByRole('region',{name:'静态场景结构检查'})).toBeVisible();
 await page.getByLabel('结构高亮').selectOption('node:2');await expect(page.locator('svg[role="img"] g polygon')).toHaveCount(1);
 await page.getByLabel('结构高亮').focus();await page.keyboard.press('Home');await page.keyboard.press('ArrowDown');await page.keyboard.press('Enter');await expect(page.getByLabel('结构高亮')).toHaveValue('node:0');
 await page.getByLabel('结构高亮').selectOption('mesh:0');await expect(page.locator('svg[role="img"] g polygon')).toHaveCount(2);
 const geometry=await page.evaluate(()=>{const rect=s=>{const r=document.querySelector(s).getBoundingClientRect();return {width:r.width,height:r.height}};const region=document.querySelector('[aria-label="静态场景结构检查"]');const main=document.querySelector('.main-workspace');return {header:rect('.global-header'),context:rect('.context-bar'),status:rect('.status-bar'),region:{client:region.clientWidth,scroll:region.scrollWidth},main:{client:main.clientWidth,scroll:main.scrollWidth},document:{scroll:document.documentElement.scrollWidth,width:innerWidth}}});
 expect(geometry.header.height).toBe(56);expect(geometry.context.height).toBe(44);expect(geometry.status.height).toBe(32);expect(geometry.region.scroll).toBeLessThanOrEqual(geometry.region.client);expect(geometry.main.scroll).toBeLessThanOrEqual(geometry.main.client);expect(geometry.document.scroll).toBeLessThanOrEqual(viewport.width);
 await page.getByRole('region',{name:'静态场景结构检查'}).scrollIntoViewIfNeeded();await page.screenshot({path:`<MODEL_BROWSER_EVIDENCE>/structure-${viewport.width}.png`});
 await page.getByRole('button',{name:'清除结构高亮'}).click();await expect(page.locator('svg[role="img"] g')).toHaveCount(0);
 await page.getByLabel('结构高亮').selectOption('node:2');await page.getByRole('button',{name:'明确读取 GLB 静态场景'}).click();await expect(page.getByLabel('结构高亮')).toHaveValue('all');
 checks.push({viewport,geometry,result:'PASS'});
}
expect(errors).toEqual([]);fs.writeFileSync('<MODEL_BROWSER_EVIDENCE>/report.json',JSON.stringify({browser:await browser.version(),fixture:'synthetic contract response, real React AppShell and component, no backend',checks,errors},null,2));console.log(JSON.stringify(checks));await browser.close();})().catch(error=>{console.error(error);process.exitCode=1});
