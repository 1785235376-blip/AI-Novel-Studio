"""Verify archive payloads and product objects in an independently restored Git database."""
import argparse, hashlib, json, pathlib, subprocess, zipfile
p=argparse.ArgumentParser();p.add_argument('artifact');p.add_argument('repository');a=p.parse_args()
root=pathlib.Path(a.artifact).resolve();repo=pathlib.Path(a.repository).resolve()
def git(*args):return subprocess.check_output(['git','-C',str(repo),*args])
def text(*args):return git(*args).decode().strip()
def sha(b):return hashlib.sha256(b).hexdigest()
for line in (root/'SHA256SUMS').read_text().splitlines():
 h,name=line.split(None,1); name=name.lstrip('*'); assert pathlib.PurePosixPath(name).name==name; assert sha((root/name).read_bytes())==h,name
m=json.loads((root/'MANIFEST.json').read_text());tip=m['product_tip'];base=m['product_base']
assert text('rev-parse',tip+'^{tree}')==m['product_tree']
assert int(text('rev-list','--count',tip,'^'+base))==m['bundle_commit_count']
for o in m['new_object_inventory']:
 typ=text('cat-file','-t',o['oid']); data=git('cat-file',typ,o['oid'])
 assert typ==o['type'] and len(data)==o['bytes'] and sha(data)==o['sha256'],o['oid']
 assert hashlib.sha1(typ.encode()+b' '+str(len(data)).encode()+b'\0'+data).hexdigest()==o['oid']
expected={o['oid'] for o in m['new_object_inventory']};actual={line.split()[0] for line in text('rev-list','--objects',tip,'^'+base).splitlines()};assert expected==actual
for f in m['file_mapping']:
 line=text('ls-tree',tip,'--',f['path']);meta,path=line.split('\t');mode,typ,oid=meta.split();data=git('cat-file','blob',oid)
 assert path==f['path'] and mode==f['mode'] and oid==f['blob'] and len(data)==f['bytes'] and sha(data)==f['sha256'],path
for c in m['commit_mappings']:
 assert c['source']==c['adopted'];assert subprocess.run(['git','-C',str(repo),'merge-base','--is-ancestor',c['source'],tip]).returncode==0
files=set(text('diff','--name-only',base,tip).splitlines());assert files=={f['path'] for f in m['file_mapping']}
for payload in m['payload_hashes']:
 data=(root/payload['path']).read_bytes();assert len(data)==payload['bytes'] and sha(data)==payload['sha256']
with zipfile.ZipFile(root/m['evidence_zip']) as z:
 idx=json.loads(z.read('evidence-index.json'));assert set(z.namelist())=={'evidence-index.json'}|{x['path'] for x in idx['files']}
 for x in idx['files']:
  data=z.read(x['path']);assert len(data)==x['bytes'] and sha(data)==x['sha256'],x['path']
fsck=subprocess.run(['git','-C',str(repo),'fsck','--strict','--no-dangling'],capture_output=True,text=True);assert fsck.returncode==0,fsck.stderr
print(json.dumps({'status':'PASS','product_tip':tip,'product_tree':m['product_tree'],'commits':m['bundle_commit_count'],'source_commits_retained':len(m['commit_mappings']),'file_mappings':len(m['file_mapping']),'new_objects':len(expected),'payloads':len(m['payload_hashes']),'evidence_entries':len(idx['files'])+1,'fsck':'PASS'},indent=2))
