import {defineConfig} from 'vitest/config';
import react from '@vitejs/plugin-react';
export default defineConfig({plugins:[react()],test:{include:['*.review.test.tsx'],environment:'jsdom',pool:'forks',poolOptions:{forks:{singleFork:true}}}});
