# Independent cloud authoring review

Date: 2026-10-20 UTC.

## Verdict

No slice-introduced blocker found in the two reviewed commits. This is a bounded source review plus independent JSDOM/unit testing, not browser or end-to-end acceptance.

- 3D scene structure: `b4e23cfe870c8d7b8944710c47d79c8817ff4587`.
- Image-mask redo: `5167bcd6acb7db9c2a336d7a432ea6e597561a80`.
- Shared base: `9ce5e243f925f6fb5141046758045c59b1dca46f`.

## 3D findings

Two independent targeted cases passed:

1. Interleaved primitives across three node instances and two meshes, with coordinates at the admitted ±1e9 bound, retain deterministic grouping, finite projections and exact highlight subsets. Across all/node/mesh selections, exported SVG bytes are identical at each of two camera views. The checked receipt is unchanged.
2. A captured old selection callback cannot alter a freshly reread receipt, even when its source/scope/raw values are identical. It also cannot restore selection across a rendered visibility loss and return.

The third adversarial diagnostic intentionally asked whether the standalone component retires a pending read when an arbitrary `isCurrent` callback flips false → true under an unchanged scope. It does not: the late receipt appears. The same diagnostic reproduces against the base component, so this behavior is inherited.

This is outside the current production host contract, not a production P2:

- `IndependentStudioWorkspace.tsx:205–207` permanently latches `authorityLost.current` when studio/host identity changes.
- `deny()` at line 209 permanently sets `revoked.current`, clears overview and removes the model panel via its line-683 render condition.
- Store subscriptions at lines 217–225 synchronously observe identity ABA transitions.
- `guarded()` at lines 227–235 rejects late results after retirement.

Consequently, the mounted host does not return the same owner from false to true. The isolated diagnostic is retained as a future component-hardening consideration; it is not counted as passed. No broad standalone authorization-ABA guarantee should be claimed.

The existing checked contract bounds primitives to 128, positions to 4096, and triangles to 2048 before the new inventory is built. Per-node mesh consistency makes mesh-to-node highlighting safe. No export request, SVG generator, checked receipt, source camera, or backend write path is changed by selection.

## Mask findings

Three independent targeted cases passed:

1. A seeded 1,500-operation pixel oracle independently tracks individual pixels/history and compares packed bits after every operation. It covers point paint, rectangles, clear, undo, redo, no-op edits, cancelled strokes and invalid edits; the retained history reaches but never exceeds 16 states, buffers remain distinct, discarded redo states are zeroed, and disposal zeroes retained buffers.
2. A captured redo callback invoked twice in one React batch restores only one history step. The same callback is blocked during a no-op active stroke, even though that stroke does not advance revision; a later fresh UI click restores the next step normally.
3. A captured Save function cannot reuse previously agreed pixels after undo/redo even when the dirty notification is delayed. Revision checking blocks `createMask`; delivering the notification clears consent, and fresh consent enables Save again.

## Evidence

- `model.review.test.tsx`, `model-review.log`: two passed tests plus the isolated unsupported-contract diagnostic.
- `model-baseline.review.test.tsx`, `model-baseline-diagnostic.log`: the same diagnostic against the base component, confirming inheritance. Only that diagnostic was run; the other two tests were excluded by the name filter.
- `mask.review.test.tsx`, `mask-review-final.log`: all three passed, including explicit assertion that the 16-state limit was reached.
- `mask-review-harness-initial.log`: preserved initial harness error, caused by returning a spy from beforeEach; corrected only in reviewer-owned test code. This was not a product failure.

Committed source snapshots were extracted with git archive into this separate reviewer directory. Author worktrees remained unchanged and clean; selected source hashes match their snapshots. No product edit, commit, push, dependency install, full-suite rerun, TypeScript rerun or build was performed.

## Limits

All mounted checks use JSDOM. The PNG controller test uses a synthetic bounded header and mocks native decoding and client reads; no actual backend, image decoder or model service ran. No real browser/geometry check was retried because the confirmed cloud Chromium Unix-socket and bwrap mount blockers were inherited. No local computer, credentials, paid API, Release, or external mutation was used. The Assets slice is being reviewed separately and is excluded here.
