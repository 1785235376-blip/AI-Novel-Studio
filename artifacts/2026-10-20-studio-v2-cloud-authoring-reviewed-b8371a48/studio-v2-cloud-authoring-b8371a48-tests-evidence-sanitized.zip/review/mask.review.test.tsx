import {act,cleanup,fireEvent,render,renderHook,screen} from '@testing-library/react';
import {afterEach,beforeEach,expect,it,vi} from 'vitest';
import {webcrypto} from 'node:crypto';
import {Blob as NodeBlob} from 'node:buffer';
import {BinaryMaskDraft} from './mask/frontend/src/creative/studioBinaryMask';
import {StudioBinaryMaskCanvas} from './mask/frontend/src/creative/StudioBinaryMaskCanvas';
import {useStudioManualMask,type StudioManualMaskProps} from './mask/frontend/src/creative/useStudioManualMask';
import {useStudio} from './mask/frontend/src/store';
import {maskSha256} from './mask/frontend/src/creative/studioManualMaskContract';
beforeEach(()=>{vi.spyOn(HTMLCanvasElement.prototype,'getContext').mockReturnValue({createImageData:(w:number,h:number)=>({data:new Uint8ClampedArray(w*h*4)}),putImageData:vi.fn()} as any);});
afterEach(()=>{cleanup();vi.restoreAllMocks();vi.unstubAllGlobals();});
const internals=(mask:BinaryMaskDraft)=>mask as any as {bits:Uint8Array;history:Uint8Array[];future:Uint8Array[];stroke:null|{before:Uint8Array}};
it('seeded 1500-operation independent pixel oracle preserves branches, exact states and the combined buffer limit',()=>{
 const m=new BinaryMaskDraft(64,64);let pixels=new Uint8Array(4096).fill(1);let past:Uint8Array[]=[],future:Uint8Array[]=[];let seed=0x291735,maxCombined=0;
 const rand=(n:number)=>{seed^=seed<<13;seed^=seed>>>17;seed^=seed<<5;return (seed>>>0)%n;};
 const packed=()=>{const out=new Uint8Array(512);pixels.forEach((v,i)=>out[i>>3]|=v<<(7-(i&7)));return Buffer.from(out).toString('hex');};
 for(let step=0;step<1500;step++){
  const kind=step<40?0:rand(8),x=step<40?step:rand(64),y=rand(64),keep=rand(2)===1;
  const previous=pixels.slice(),retained=internals(m),discarded=[...retained.future];
  let committed=false;
  if(kind===0){pixels[y*64+x]=keep?1:0;m.paint(x,y,0,keep);committed=true;}
  if(kind===1){const w=Math.min(1+rand(5),64-x),h=Math.min(1+rand(5),64-y);for(let j=y;j<y+h;j++)for(let i=x;i<x+w;i++)pixels[j*64+i]=keep?1:0;m.rectangle(x,y,w,h,keep);committed=true;}
  if(kind===2){pixels.fill(keep?1:0);m.clear(keep);committed=true;}
  if(kind===3){const p=past.pop();expect(m.undo()).toBe(!!p);if(p){future.push(pixels);pixels=p;}}
  if(kind===4){const f=future.pop();expect(m.redo()).toBe(!!f);if(f){past.push(pixels);pixels=f;}}
  if(kind===5){m.beginStroke(x,y,0,!m.get(x,y));expect(()=>m.redo()).toThrow();m.cancelStroke();}
  if(kind===6){expect(m.paint(x,y,0,!!pixels[y*64+x])).toBe(false);}
  if(kind===7){expect(()=>m.rectangle(63,63,2,2,false)).toThrow();}
  if(committed&&!Buffer.from(previous).equals(Buffer.from(pixels))){past.push(previous);if(past.length>16)past.shift();future=[];for(const b of discarded)expect(b.every(v=>v===0)).toBe(true);}
  expect(Buffer.from(m.snapshot()).toString('hex')).toBe(packed());expect(m.canUndo).toBe(past.length>0);expect(m.canRedo).toBe(future.length>0);
  const r=internals(m),buffers=[r.bits,...r.history,...r.future];maxCombined=Math.max(maxCombined,r.history.length+r.future.length);expect(r.history.length+r.future.length).toBeLessThanOrEqual(16);expect(new Set(buffers).size).toBe(buffers.length);
 }
 expect(maxCombined).toBe(16);const r=internals(m);m.beginStroke(10,10,0,!m.get(10,10));const buffers=[r.bits,...r.history,...r.future,r.stroke!.before];m.dispose();expect(buffers.every(b=>b.every(v=>v===0))).toBe(true);expect(()=>m.redo()).toThrow();
});
it('one captured redo cannot replay twice in a React batch or during a no-op active stroke',()=>{
 const m=new BinaryMaskDraft(64,64);m.paint(1,1,0,false);m.paint(2,2,0,false);m.undo();m.undo();const onChange=vi.fn();
 render(<StudioBinaryMaskCanvas mask={m} sourceUrl="blob:review" readOnly={false} isCurrent={()=>true} onChange={onChange}/>);
 const el=screen.getByRole('button',{name:'重做蒙版编辑'}),callback=(el as any)[Object.keys(el).find(k=>k.startsWith('__reactProps$'))!].onClick;
 m.beginStroke(30,30,0,true);act(callback);expect(onChange).not.toHaveBeenCalled();expect(m.get(1,1)).toBe(true);m.cancelStroke();
 act(()=>{callback();callback();});expect(m.get(1,1)).toBe(false);expect(m.get(2,2)).toBe(true);expect(onChange).toHaveBeenCalledTimes(1);expect(m.canRedo).toBe(true);
 fireEvent.click(screen.getByRole('button',{name:'重做蒙版编辑'}));expect(m.get(2,2)).toBe(false);expect(onChange).toHaveBeenCalledTimes(2);
});
it('captured save cannot reuse old consent after undo-redo when dirty notification has not yet been delivered',async()=>{
 vi.stubGlobal('crypto',webcrypto);vi.stubGlobal('createImageBitmap',vi.fn(async()=>({width:64,height:64,close:vi.fn()})));
 Object.defineProperty(URL,'createObjectURL',{configurable:true,value:vi.fn(()=> 'blob:review-owner')});Object.defineProperty(URL,'revokeObjectURL',{configurable:true,value:vi.fn()});
 useStudio.setState({novelId:'review-project',sessionToken:'',actor:undefined,scope:undefined});
 const bytes=new Uint8Array(57),d=new DataView(bytes.buffer);bytes.set([137,80,78,71,13,10,26,10]);d.setUint32(8,13);bytes.set([73,72,68,82],12);d.setUint32(16,64);d.setUint32(20,64);bytes[24]=8;bytes[25]=6;bytes.set([73,68,65,84],37);bytes.set([73,69,78,68],49);
 const asset={id:'review-source',novel_id:'review-project',branch_id:null,version:1,kind:'image',media_type:'image/png',sha256:await maskSha256(bytes),filename:'source.png',size:bytes.length,created_at:'',updated_at:''};
 const p:StudioManualMaskProps={asset,client:{asset:vi.fn(async()=>({...asset})),download:vi.fn(async()=>new NodeBlob([bytes]) as any),createMask:vi.fn()},canMutate:true,busy:false,isBusy:()=>false,isCurrent:()=>true,read:async w=>w(),mutate:async w=>w(),onDirtyChange:vi.fn(),onUnavailable:vi.fn(),onSaved:vi.fn()};
 const v=renderHook(()=>useStudioManualMask(p));await act(async()=>v.result.current.load());const m=v.result.current.editor!.mask;
 act(()=>{m.paint(0,0,0,false);v.result.current.changed();v.result.current.agree(true);});expect(v.result.current.canSave).toBe(true);const save=v.result.current.save,expected=m.serialize();
 m.undo();m.redo();expect(m.serialize()).toEqual(expected);await act(async()=>save());expect(p.client.createMask).not.toHaveBeenCalled();expect(p.onSaved).not.toHaveBeenCalled();
 act(()=>v.result.current.changed());expect(v.result.current.consent).toBe(false);expect(v.result.current.canSave).toBe(false);act(()=>v.result.current.agree(true));expect(v.result.current.canSave).toBe(true);
});
