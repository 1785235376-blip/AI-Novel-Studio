import {act,cleanup,fireEvent,render,screen} from '@testing-library/react';
import {afterEach,expect,it,vi} from 'vitest';
import {StudioModelMeshPreview} from './model/frontend/src/creative/StudioModelMeshPreview';
import {checkedModelScenePreview,type ModelScenePreview} from './model/frontend/src/creative/studioModelReferenceContract';
import {modelAsset,modelInspection} from './model/frontend/src/creative/studioModelReference.testFixtures';
import {modelSceneStructure,modelSceneHighlightFaces} from './model/frontend/src/creative/studioModelSceneStructure';
import {meshFacePoints,projectModelMesh} from './model/frontend/src/creative/modelMeshProjection';
import {downloadPortableBlob} from './model/frontend/src/experimental/portableProjectsClient';
vi.mock('./model/frontend/src/experimental/portableProjectsClient',()=>({downloadPortableBlob:vi.fn()}));
afterEach(()=>{cleanup();vi.clearAllMocks();});
function scene():ModelScenePreview {
 const base=modelInspection();Object.assign(base.inspection,{node_count:4,mesh_count:2,primitive_count:2});
 const p=(node_index:number,mesh_index:number,primitive_index:number,z:number)=>({node_index,mesh_index,primitive_index,positions:[[-1e9,-1e9,z],[1e9,-1e9,z],[0,1e9,z]],triangles:[[0,1,2]]});
 return {...base,scene_preview:{contract:'studio-static-glb-scene-preview/1',space:'SCENE_WORLD_STATIC',scene_index:0,selection:'DECLARED_DEFAULT',traversed_nodes:4,mesh_instances:3,position_count:12,triangle_count:4,
 primitives:[p(3,1,0,1e9),p(0,0,0,-1e9),p(3,1,1,0),p(2,1,0,1e9)],bounds:{min:[-1e9,-1e9,-1e9],max:[1e9,1e9,1e9]},scene_transforms_applied:true,materials_rendered:false,animation_applied:false,decimated:false,model_called:false}};
}
const source=()=>({scope:{},asset:modelAsset(),disabled:false,canExport:true,isCurrent:()=>true,read:vi.fn(),readScene:vi.fn(async()=>scene())});
function start(){fireEvent.change(screen.getByLabelText('诊断坐标空间'),{target:{value:'scene'}});fireEvent.click(screen.getByRole('button',{name:'明确读取 GLB 静态场景'}));}
const change=(key:string)=>fireEvent.change(screen.getByLabelText('结构高亮'),{target:{value:key}});
const readBlob=(b:Blob)=>new Promise<string>(resolve=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result));reader.readAsText(b);});
const handler=(el:Element)=>(el as any)[Object.keys(el).find(k=>k.startsWith('__reactProps$'))!].onChange;
it('interleaved primitives and extreme finite bounds retain exact subsets and byte-identical exports at two views',async()=>{
 const receipt=checkedModelScenePreview(scene(),modelAsset()),before=JSON.stringify(receipt),s=modelSceneStructure(receipt);
 expect(s.instances.map(e=>e.key)).toEqual(['node:0','node:2','node:3']);expect(s.meshes[1].primitiveCount).toBe(3);
 for(const [yaw,pitch] of [[-180,89],[35,25]]){const faces=projectModelMesh(receipt,yaw,pitch).map(meshFacePoints);for(const e of [...s.instances,...s.meshes]){const h=modelSceneHighlightFaces(receipt,e,yaw,pitch);expect(h).toHaveLength(e.triangleCount);expect(h.every(f=>f.points.flat().every(Number.isFinite))).toBe(true);for(const f of h)expect(faces).toContain(meshFacePoints(f));}}
 expect(JSON.stringify(receipt)).toBe(before);
 const p=source();render(<StudioModelMeshPreview {...p}/>);start();await screen.findByLabelText('结构高亮');
 for(const yaw of ['-180','35']){fireEvent.change(screen.getByLabelText('诊断水平视角'),{target:{value:yaw}});const outputs=[];for(const key of ['all','node:3','mesh:1','node:0']){change(key);fireEvent.click(screen.getByRole('button',{name:'下载当前场景诊断 SVG'}));outputs.push(await readBlob(vi.mocked(downloadPortableBlob).mock.calls.at(-1)![0]));}expect(new Set(outputs).size).toBe(1);expect((outputs[0].match(/<polygon/g)||[])).toHaveLength(4);}
 expect(p.readScene).toHaveBeenCalledTimes(1);
});
it('a retained selection handler cannot change a fresh reread even when asset, scope and raw response are identical',async()=>{
 const p=source();const view=render(<StudioModelMeshPreview {...p}/>);start();await screen.findByLabelText('结构高亮');
 const old=handler(screen.getByLabelText('结构高亮'));change('node:3');
 fireEvent.click(screen.getByRole('button',{name:'明确读取 GLB 静态场景'}));await screen.findByLabelText('结构高亮');change('node:0');
 act(()=>old({target:{value:'mesh:1'}}));expect((screen.getByLabelText('结构高亮') as HTMLSelectElement).value).toBe('node:0');
 view.rerender(<StudioModelMeshPreview {...p} isCurrent={()=>false}/>);view.rerender(<StudioModelMeshPreview {...p}/>);act(()=>old({target:{value:'mesh:1'}}));expect((screen.getByLabelText('结构高亮') as HTMLSelectElement).value).toBe('all');
});
it('pending scene reads do not cross a rendered authorization ABA with an unchanged scope',async()=>{
 const p=source();let resolve!:(r:ModelScenePreview)=>void;p.readScene.mockImplementation(()=>new Promise(done=>resolve=done));const view=render(<StudioModelMeshPreview {...p}/>);start();
 const signal=(p.readScene.mock.calls[0] as any)[1] as AbortSignal;
 view.rerender(<StudioModelMeshPreview {...p} isCurrent={()=>false}/>);view.rerender(<StudioModelMeshPreview {...p}/>);
 await act(async()=>resolve(scene()));
 expect({aborted:signal.aborted,visible:!!screen.queryByLabelText('结构高亮')}).toEqual({aborted:true,visible:false});
});
