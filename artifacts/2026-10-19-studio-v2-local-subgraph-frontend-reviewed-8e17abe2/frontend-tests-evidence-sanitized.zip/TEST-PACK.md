# Bounded test pack

The incremental bundle contains all original added frontend tests and the actual synthetic File API fixture. The independent red/green probes are retained separately. Restore 494cf prerequisite and this frontend bundle first. Use existing offline project dependencies.

To reproduce the two P2 closure checks, copy independent-green/independent-probes-relocated.tsx to frontend/src/creative/localSubgraph.independent.review.test.tsx in a disposable worktree, create the sibling local-subgraph-fix-recheck-evidence output directory, then run from frontend:

    node node_modules/vitest/vitest.mjs run src/creative/localSubgraph.independent.review.test.tsx -t "^review[12] " --reporter=verbose

The same two assertions failed on 0ec19910 and passed on 8e17abe2. The other three independent checks were not repeated during P2 recheck. Original browser A/B/C/D are retained segmented real File evidence, not a new complete end-to-end acceptance. PG is BLOCKED for missing controlled test environment. No credentials/profiles, backend implementation, dependencies, dist or real-user data are bundled in this test pack.
