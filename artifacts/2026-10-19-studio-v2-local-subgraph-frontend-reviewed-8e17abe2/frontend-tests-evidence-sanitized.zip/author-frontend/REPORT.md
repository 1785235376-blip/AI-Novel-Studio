# PoemSeed Studio V2：受限本地子调用前端审查交接

状态：**仅本地提交，待父任务安排独立审查**。没有推送、合并 main、创建 Tag/Release 或新 PR。

- 提交：`0ec1991024bd1ed4bac57a6ab61c0a3057aa3320`
- 父版本：`494cf355a4057a977e736fee4bb39130881cd089`
- 源树：`6ec96ab52bafb349e43ccbaa16d16e9e34ec49e6`
- 分支：`work/v2-local-subgraph-frontend-20261019`
- 唯一源码 owner：`<local-workspace>\poemseed-v2-local-subgraph-frontend-494`，提交后工作树干净。
- 离线增量 bundle：`studio-v2-local-subgraph-frontend-494cf355-0ec19910.bundle`，须已有父版本 494；已 `git bundle verify`，完整 ref 和 SHA256 见 `review-handoff.json`。
- 补丁：`0001-local-subgraph-frontend-0ec19910.patch`。

## 实现与实际操作路径

在原 Graph 手工编辑区增加“受限本地子调用 · 首片”。显式读取已保存 schema1 纯本地图目录、选择可编辑当前子图并重新 GET 校对版本及两个摘要，显示唯一 TEXT/DRAFT 接口、整个子图闭包与既有上限。用户输入父文本并明确勾选同意后，原空白 schema1 图经原 `change()` 一次生成固定 `text_input → local_subgraph → human_review` 父草稿；支持原撤销/重做。不会自动 Save、预检、创建运行、执行或调用模型。

新父图走原 Save/reopen，以及原显式 preflight/create/execute 和人工审核；受限 schema6 始终预检整个已保存三节点链。执行只产出未批准 `DRAFT/USER_SUPPLIED`，原人工审核后完成，未应用到正文。代码不生成服务端 binding/receipt，也不赋予模型、媒体、云端或外部调用权限。

仅保存八个既有 pin 参数。schema6 节点、启用状态、连线及 pin 固定，可编辑父文本、标题与布局。来源保存后旧 pin 必须失效：不静默选新版本、不自动更新 pin，失效/不可见/终态失败的回包不会恢复来源摘要、输出、binding 或 receipt。新 decoder 对已观察到的保存父图核对 binding 的来源版本、两个摘要与接口节点，并要求完成的调用有对应 receipt。来源闭包为 1–16 个已启用纯本地节点；UI 限定唯一接口和固定三节点父图，范围比后端更窄。保留后端深度 1、总节点 24、五秒协作式预算及禁用缓存边界。

旧确认回调、选源/owner/busy ABA、晚到来源读取、来源版本变化、重复应用均有围栏；作者文本参与原脏表单拦截。原运行 owner、request_id/unknown-recovery 不改。未改后端 Python、媒体/DSH、AppShell、设计 token、全局 CSS 或原视觉快照。后端冻结元数据 `local_subgraph_frontend_entry=false` 保持原值；没有据此生成新权限。

## 最小写集

共 13 个前端文件：10 个产品文件，2 个测试文件，1 个真实 File API 回包 fixture。

- 类型/解析/标签：`studioGraphTypes.ts`、`studioGraphClient.ts`、`studioGraphLabels.ts`、`graphDraft.ts`。
- 原编辑器连接：`studioGraphEditorView.tsx`、`useStudioGraphEditorController.ts`，以及 `canvasops/canvasOps.ts` 的 local_subgraph 文本角色映射。
- 新增：`graphLocalSubgraph.ts`、`useGraphLocalSubgraphParent.ts`、`GraphLocalSubgraphPanel.tsx`。
- 验证：`studioGraphLocalSubgraph.test.ts`、`GraphLocalSubgraphPanel.test.tsx`、`fixtures/localSubgraph.file-api.json`。

除 canvasops 文件外以上路径均在 `frontend/src/creative/`。具体 Git blob/工作文件 SHA256、每个执行镜像字节比对见 `review-handoff.json`；Git LF 与 Windows 工作文件行尾可能不同，分别记录。

## 定向验证与原始失败

| 项目 | 原始结果与最终结果 |
|---|---|
| 真实 mounted File API | `file-segment.log`：1 passed / 3 deselected，原应用、原认证与 File fixture；Save/reopen、原运行/审核、标题保存失效、GET 屏蔽、preflight 409。保留原 Starlette/Glossary 及外部 probe 缺 marker 注册警告。未跑 PG。 |
| 前端目标用例 | `targeted-r1.log` 启动失败（C 路径父目录不可读，无用例运行）；D 字节镜像后 `targeted-r2.log` **10 passed / 8 skipped**。浏览器发现范围问题后 `scope-confirmation-fixed.log` 重跑 1 个关联用例；最终 pin/receipt 对应校验后 `receipt-binding-final.log` 重跑 2 个关联用例。唯一覆盖仍是 10 个，不累加为 13。 |
| 类型 | `types-once.log` 仅因镜像漏复制 2 个未变更跨根 JSON fixture 出现 5 个 import 错误；补入原 fixture 后通过。后续两次实际代码修正各重查一次。共 4 次（1 失败、3 通过），最终 `types-final-bound.log` / command exit 0。 |
| Vite 构建 | 初始、范围修正后、最终回包校验后三次通过；最终 `build-final-bound.log`。保留原 >500KB chunk 警告，未调弱阈值。 |
| 真实浏览器 A/B/C | 现有项目 Playwright CLI + 已安装 Chromium，无响应 mock。`browser-r1.log` 因 Windows harness URL 路径编码 No tests found；修正 harness 后 r2 的 A 通过，B 在确认框失败、C 未运行。发现 UI 传空 targetIDs，服务端规范化为完整三节点而原确认键不匹配；只修 schema6 View 传完整已保存节点 ID，未改原运行 controller/backend。恢复前真实 GET 证明 runs=[]，无未知/重复执行。r3 的 B/C 两段通过。 |
| 最终只读浏览器 D | `browser-read-final.log` 通过；最终 decoder 的失效父图/旧运行读取，`browser-D-events.json` 为 errors=[] / writes=[] / blocked=[]。 |
| 共享壳/视觉 | `protected-visual.log` **6 passed**：原 NOVEL/IMAGE/VIDEO 三张基准及 1366/1440/1920 三个几何检查；未更新任何快照。新面板同样检验三个桌面宽度无横向溢出。最终只读 binding 校验不影响布局。 |
| Git/镜像 | `git diff --check` 通过，提交后干净。D 镜像 1823 文件 / 16,686,843 字节与 C 源码逐文件一致；不包含 node_modules 的重安装。 |

真实浏览器路径：A 从原首页建立隔离合成项目，原 UI 建立并保存纯子图，再读源/预览/生成父图/撤销重做/Save/reopen；B 显式完整预检、创建 queued、执行得到待审 DRAFT，再原审核完成且不 apply；C 原子图仅改标题保存（version 增长，execution_digest 相同）使父 pin 失效，重新读取屏蔽输出且 preflight 409；D 在最终 decoder 下只读确认屏蔽。三段操作通过来自分段运行，不声称一次全绿完整产品验收。

截图：`parent-draft-1440.png`、`current-pin-reopened-1440.png`、`unapproved-draft-1440.png`、`stale-pin-visible-1440.png`、`masked-output-visible-1440.png`。保留失败 B 截图及原始日志。既有本地草稿身份代次提示属于原持久化说明，未修改；实际原 File Save/run 已成功。

## 执行环境与边界

D 盘完整 checkout 曾因空间不足失败；Git 回滚失败 checkout，未清理用户数据。完整源码改建在允许的 C TEMP 下；esbuild 无权扫描该父路径，故只把前端/contracts 与两个原 JSON fixture 字节复制到 D 执行镜像 `local-subgraph-frontend-execution-494`。两处 node_modules 使用已有依赖 junction，无安装/下载。Cua 两次初始化错误（进程退出、拒绝访问）后改用现有项目 Playwright CLI；未改 ACL、系统、账户、密钥或计费。

原 API `/health` 因 provider status 超时导致初始 readiness helper 失败；Graph/features/novels 实际请求均成功。没有改 health/provider 配置。测试只用隔离本地 File 数据、禁云/禁 fallback/不调用模型，无 GPU、新增付费 API 或额度购买。测试服务仅本任务端口 19124/5318，已核对 PID/命令/启动时间后关闭；`browser-stop-receipt.json` 记录释放，原演示 18913/5293 未触碰。没有后台任务继续执行。

## 交给父任务的剩余事项

安排独立前端审查，再决定集成/公开归档；本任务没有推送。PG、真实协作浏览器撤权、断网恢复模拟、完整子图/全产品/生产验收均未运行，不纳入本切片完成声明。撤权晚到结果/旧回调由定向 hook 测试覆盖；原 request_id/unknown recovery 维持原 owner。当前无执行阻断，审查前保持分支隔离。
