"""One synthetic original mounted File API segment; no provider or user profile."""
from pathlib import Path
import json,sys
ROOT=Path(r'<local-workspace>\poemseed-v2-local-subgraph-frontend-494')
sys.path.insert(0,str(ROOT/'tests'))
from test_v2_local_subgraph_api import graph_client, client, mounted, prefix, checked, create, admit
from test_v2_local_subgraph import child_definition,parent_definition

def test_file_contract_segment(graph_client):
    e=graph_client
    catalog=checked(e.client.get(e.graph_base+'/catalog?include_local_subgraph=true'))
    child=create(e,child_definition());parent=create(e,parent_definition(child))
    reopened=checked(e.client.get(e.graph_base+'/'+parent['id']));assert reopened==parent
    preview=checked(e.client.post(e.graph_base+'/'+parent['id']+'/preflight',json={'expected_version':1,'target_node_ids':[]}))
    queued=admit(e,parent);path=e.studio_base+'/graph-runs/'+queued['id']
    waiting=checked(e.client.post(path+'/execute',json={'expected_version':queued['version']}))
    assert waiting['status']=='WAITING_APPROVAL' and waiting['review']['draft']['origin']=='USER_SUPPLIED'
    assert waiting['cache']['hits']==0 and not waiting['model_called'] and not waiting['external_calls']
    approved=checked(e.client.post(path+'/approve',json={'expected_version':waiting['version'],'node_id':'review','reviewed_output_digest':waiting['review']['output_digest']}))
    assert approved['status']=='SUCCEEDED' and approved['reviewed'] and not approved['applied']
    changed=checked(e.client.put(e.graph_base+'/'+child['id'],json={'expected_version':1,'definition':{**child['definition'],'title':'Explicit saved current version change'}}))
    stale=checked(e.client.get(e.graph_base+'/'+parent['id']));masked=checked(e.client.get(path))
    assert stale['reference_states']==[{'node_id':'call','state':'STALE'}]
    assert masked['stale'] and masked['review'] is None and all(x['output'] is None for x in masked['node_states'].values())
    assert masked['local_subgraph_runtime']['bindings']==masked['local_subgraph_runtime']['receipts']=={}
    denied=e.client.post(e.graph_base+'/'+parent['id']+'/preflight',json={'expected_version':1,'target_node_ids':[]})
    assert denied.status_code==409
    fixture={'synthetic_actual_File_API':True,'project':e.nid,'prefix':e.prefix,'catalog':catalog,'child':child,'parent':parent,
        'preflight':preview,'queued':queued,'waiting':waiting,'approved':approved,'saved_child':changed,'stale_parent':stale,'masked_run':masked}
    target=ROOT/'frontend/src/creative/fixtures/localSubgraph.file-api.json'
    assert not target.exists();target.write_text(json.dumps(fixture,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
