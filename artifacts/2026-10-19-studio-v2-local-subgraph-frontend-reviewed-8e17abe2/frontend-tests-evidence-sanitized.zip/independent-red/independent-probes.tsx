// @vitest-environment jsdom
import { afterEach, expect, it, vi } from 'vitest';
import { act, cleanup, renderHook } from '@testing-library/react';
import { useGraphLocalSubgraphParent } from './useGraphLocalSubgraphParent';
import { useStudioGraphRunController } from './useStudioGraphRunController';
import type { StudioGraphRecord, StudioGraphCatalog } from './studioGraphTypes';
import type { StudioGraphClient } from './studioGraphClient';
import { checkedStudioGraphDraft } from './studioGraphClient';
import { inspectLocalSubgraphSource, buildLocalSubgraphParent } from './graphLocalSubgraph';
import { createHash, webcrypto } from 'node:crypto';
import { writeFileSync } from 'node:fs';
import { join } from 'node:path';
import actual from './fixtures/localSubgraph.file-api.json';
import { createStudioGraphClient } from './studioGraphClient';
vi.stubGlobal('crypto', webcrypto);
afterEach(() => { cleanup(); vi.restoreAllMocks(); });
const evidence = join(process.cwd(), '..', '..', 'local-subgraph-review-evidence');
const canonical = (v: unknown): string => JSON.stringify(v && typeof v === 'object' ? Array.isArray(v) ? v.map(x => JSON.parse(canonical(x))) : Object.fromEntries(Object.entries(v).sort(([a], [b]) => a.localeCompare(b)).map(([k,x]) => [k, JSON.parse(canonical(x))])) : v);
const hash = (v: unknown) => createHash('sha256').update(canonical(v)).digest('hex');
function boundClient(reply: unknown) {
  const transport = { json: vi.fn(async (url: string) => url.endsWith('/preflight') || url.includes('/graph-runs/') ? reply : actual.parent) };
  return { client: createStudioGraphClient(actual.project, {}, transport), transport };
}
it('review1 rejects a different child version in preflight after the saved parent pin was observed', async () => {
  const malformed = structuredClone(actual.preflight); malformed.local_subgraph_bindings.call.source.version++;
  const {client} = boundClient(malformed); await client.get(actual.parent.id);
  let accepted = false;
  try { await client.preflight(actual.parent.id, {expected_version:1, target_node_ids:[]}); accepted = true; } catch {}
  writeFileSync(join(evidence,'preflight-pin-observation.json'), JSON.stringify({savedPin:actual.parent.definition.nodes[1].parameters,returnedBinding:malformed.local_subgraph_bindings.call,accepted},null,2));
  expect(accepted, 'preflight current-pin binding must equal observed saved parent pin').toBe(false);
});
it('review2 rejects a completed receipt whose output hash disagrees with actual call output', async () => {
  const original = actual.waiting, originalReceipt = original.local_subgraph_runtime.receipts.call;
  expect(hash(original.node_states.call.output)).toBe(originalReceipt.output_digest);
  const malformed = structuredClone(original); malformed.local_subgraph_runtime.receipts.call.output_digest = 'a'.repeat(64);
  const {client} = boundClient(malformed); await client.get(actual.parent.id);
  let accepted = false;
  try { await client.getRun(malformed.id); accepted = true; } catch {}
  writeFileSync(join(evidence,'receipt-output-observation.json'), JSON.stringify({actualOutputDigest:hash(original.node_states.call.output),receiptOutputDigest:malformed.local_subgraph_runtime.receipts.call.output_digest,accepted,callStatus:malformed.node_states.call.status,reviewPresent:!!malformed.review},null,2));
  expect(accepted, 'SUCCEEDED call receipt must hash its actual output').toBe(false);
});

const child = () => structuredClone(actual.child) as unknown as StudioGraphRecord;
const catalog = () => structuredClone(actual.catalog) as unknown as StudioGraphCatalog;
const deferred = <T,>() => {let resolve!: (v:T)=>void; const promise = new Promise<T>(done=>{resolve=done;}); return {promise,resolve};};
function hookProps() {
  return {client:{localSubgraphCatalog:vi.fn(async()=>catalog()),localSubgraphList:vi.fn(async()=>({items:[child()]})),get:vi.fn(async()=>child())} as unknown as StudioGraphClient,
    identity:'review-A',scope:{},readable:true,blank:true,current:()=>true,locked:()=>false,read:<T,>(fn:()=>Promise<T>)=>fn(),onRecords:vi.fn(),onCatalog:vi.fn(),apply:vi.fn(()=>true)};
}
it('review3 keeps a fresh owner/child/text when the previous owner GET arrives late and retires consent on permission ABA', async()=>{
  const props = hookProps(),gate=deferred<StudioGraphRecord>(); props.client.get=vi.fn(()=>gate.promise);
  const view=renderHook(value=>useGraphLocalSubgraphParent(value),{initialProps:props});
  await act(async()=>{await view.result.current.load();});act(()=>view.result.current.choose(actual.child.id));
  let pending!:Promise<void>;act(()=>{pending=view.result.current.verify();});
  const b=child();b.id='review-child-B';const fresh={...props,identity:'review-B',scope:{},client:{...props.client,
    localSubgraphList:vi.fn(async()=>({items:[b]})),get:vi.fn(async()=>b)} as StudioGraphClient};
  view.rerender(fresh);await act(async()=>{await view.result.current.load();});act(()=>view.result.current.choose(b.id));
  await act(async()=>{await view.result.current.verify();});act(()=>view.result.current.edit('fresh B author text'));act(()=>view.result.current.confirm(true));
  await act(async()=>{gate.resolve(child());await pending;});
  expect(view.result.current.preview?.source.id).toBe(b.id);expect(view.result.current.text).toBe('fresh B author text');expect(view.result.current.confirmed).toBe(true);
  const retained=view.result.current.create;view.rerender({...fresh,readable:false});view.rerender(fresh);act(()=>retained());
  expect(props.apply).not.toHaveBeenCalled();expect(view.result.current.preview).toBeUndefined();
  await act(async()=>{await view.result.current.load();});act(()=>view.result.current.choose(b.id));await act(async()=>{await view.result.current.verify();});
  act(()=>view.result.current.edit('new explicit text'));act(()=>view.result.current.confirm(true));act(()=>view.result.current.create());
  expect(props.apply).toHaveBeenCalledTimes(1);expect(props.apply.mock.calls[0][0].nodes[1].parameters.graph_id).toBe(b.id);
});
it('review4 UNKNOWN execute is never replayed and original human review still requires fresh consent after permission ABA',async()=>{
  const transport={json:vi.fn(async(url:string,method='GET')=>{
    if(url.endsWith('/preflight'))return actual.preflight;
    if(url.endsWith('/runs')&&method==='POST')return actual.queued;
    if(url.endsWith('/execute'))throw new Error('synthetic lost execute response');
    if(url.endsWith('/approve'))return actual.approved;
    if(url.includes('/graph-runs/'))return actual.waiting;
    return actual.parent;
  })};
  const client=createStudioGraphClient(actual.project,{},transport);const graph=await client.get(actual.parent.id);
  const props={client,graph,targetNodeIds:['input','call','review'],dirty:false,busy:false,canMutate:true,canReview:true,isCurrent:()=>true,read:<T,>(fn:()=>Promise<T>)=>fn(),mutate:<T,>(fn:()=>Promise<T>)=>fn()};
  const view=renderHook(value=>useStudioGraphRunController(value),{initialProps:props});
  await act(async()=>{await view.result.current.inspect();});act(()=>view.result.current.reviewPreflight(true));await act(async()=>{await view.result.current.createRun();});
  expect(view.result.current.selected?.status).toBe('QUEUED');const retained=view.result.current.action;
  await act(async()=>{await view.result.current.action('execute');});expect(view.result.current.uncertain).toBe(true);
  await act(async()=>{await retained('execute');await view.result.current.action('execute');});expect(transport.json.mock.calls.filter(([url])=>url.endsWith('/execute'))).toHaveLength(1);
  await act(async()=>{await view.result.current.openRun(actual.waiting.id);});expect(view.result.current.selected?.status).toBe('WAITING_APPROVAL');
  expect(view.result.current.canAction('approve')).toBe(false);act(()=>view.result.current.reviewOutput(true));expect(view.result.current.canAction('approve')).toBe(true);
  view.rerender({...props,canReview:false});view.rerender(props);await act(async()=>{await retained('approve');});
  expect(transport.json.mock.calls.filter(([url])=>url.endsWith('/approve'))).toHaveLength(0);
  act(()=>view.result.current.reviewOutput(true));await act(async()=>{await view.result.current.action('approve');});expect(view.result.current.selected?.status).toBe('SUCCEEDED');
  writeFileSync(join(evidence,'unknown-review-observation.json'),JSON.stringify({executeCalls:transport.json.mock.calls.filter(([url])=>url.endsWith('/execute')).length,approveCalls:transport.json.mock.calls.filter(([url])=>url.endsWith('/approve')).length,status:view.result.current.selected?.status},null,2));
});
it('review5 fixed parent save uses actual child pin; schema1-5 and extra local authority never reach transport',async()=>{
  const plan=inspectLocalSubgraphSource(child(),catalog()),definition=buildLocalSubgraphParent(plan,'independent fixed parent');
  expect(definition.nodes.map(n=>n.definition_id)).toEqual(['text_input','local_subgraph','human_review']);
  expect(definition.nodes[1].parameters).toMatchObject({graph_id:actual.child.id,expected_version:actual.child.version,definition_digest:actual.child.definition_digest,execution_digest:actual.child.execution_digest});
  const transport={json:vi.fn(async()=>actual.parent)};const client=createStudioGraphClient(actual.project,{},transport);
  await client.get(actual.parent.id);await client.save(actual.parent.id,{expected_version:1,definition:actual.parent.definition as never});
  expect(transport.json.mock.calls.at(-1)?.[2]).toEqual({expected_version:1,definition:checkedStudioGraphDraft(actual.parent.definition)});
  const before=transport.json.mock.calls.length;
  for(const version of [1,2,3,4,5]){
    expect(()=>checkedStudioGraphDraft({...actual.parent.definition,schema_version:version})).toThrow();
  }
  const forged=structuredClone(actual.parent.definition);Object.assign(forged.nodes[1].parameters,{server_authorized:true,binding_digest:'a'.repeat(64)});
  await expect(async()=>client.save(actual.parent.id,{expected_version:1,definition:forged as never})).rejects.toThrow();
  expect(transport.json.mock.calls).toHaveLength(before);
});
