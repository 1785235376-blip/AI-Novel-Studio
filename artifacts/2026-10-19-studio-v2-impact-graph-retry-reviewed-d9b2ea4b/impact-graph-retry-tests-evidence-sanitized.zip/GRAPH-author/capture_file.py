"""Owned, offline File evidence; no database/model/provider access."""
import hashlib
import json
import os
from pathlib import Path
import sys

root = Path(__file__).resolve().parent.parent / "gr"
evidence = Path(__file__).resolve().parent
sys.path[:0] = [str(root), str(root / "tests")]
from scripts.run_v2_checks import isolated_environment
os.environ.update(isolated_environment(root, evidence / "file-state"))
from app.config import Settings
from app.repositories.factory import create_repository_bundle
from app.services import NovelService, ChapterService
from app.creative.graph import CreativeGraphService
from test_v2_independent_workspace import services
from test_v2_creative_graph_persistence import definition

data = evidence / "file-state" / "project-data"
bundle = create_repository_bundle(Settings(storage_backend="file", novel_data=data, enable_cloud=False, mock_provider=True), data_root=data)
novels = NovelService(bundle.novels, bundle.chapters)
chapters = ChapterService(bundle.chapters)
nid = novels.create({"id": "graph-failed-local-retry-proof", "title": "Owned retry evidence"})["id"]
scope = {"mode": "local", "novel_id": nid}
actor = "local-studio-author"
workspace = services(data, "file", "", novels, chapters)
owner = CreativeGraphService(workspace.store, workspace)
value = definition()
value["nodes"][0]["parameters"]["text"] = "line\n" * 101
graph = owner.create(nid, scope, actor, {"request_id": "proof-graph", "definition": value})
preflight = owner.preflight(nid, scope, actor, graph["id"], {"expected_version": 1, "target_node_ids": ["review"]})
queued = owner.create_run(nid, scope, actor, graph["id"], {"expected_graph_version": 1,
    "reviewed_preflight_digest": preflight["preflight_digest"], "target_node_ids": ["review"], "request_id": "proof-run"})
source = owner.action(nid, scope, actor, queued["id"], "execute", {"expected_version": queued["version"]})
assert source["status"] == "FAILED"
def fingerprint(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
old_before = workspace.store.read(nid, scope)["collections"][owner.RUNS][source["id"]]
retry_flight = owner.preflight(nid, scope, actor, graph["id"], {"expected_version": 1, "target_node_ids": sorted(source["node_states"])})
request = {"expected_version": source["version"], "expected_graph_version": 1,
    "reviewed_preflight_digest": retry_flight["preflight_digest"], "request_id": "proof-retry-exact"}
new = owner.executor.retry_failed_local(nid, scope, actor, source["id"], request, lambda: None)
fresh_workspace = services(data, "file", "", novels, chapters)
fresh = CreativeGraphService(fresh_workspace.store, fresh_workspace)
replay = fresh.executor.retry_failed_local(nid, scope, actor, source["id"], request, lambda: None)
document = fresh.store.read(nid, scope)
old_after = document["collections"][owner.RUNS][source["id"]]
raw_new = document["collections"][owner.RUNS][new["id"]]
assert replay == new and old_before == old_after and len(document["collections"][owner.RUNS]) == 2
assert new["status"] == "QUEUED" and raw_new["dispatch_trace"] == raw_new["history"] == []
assert new["retry_of"] == source["id"] and new["attempt"] == 2
artifact = {"backend": "real File", "graph": graph, "failed": source, "queued": new, "preflight": retry_flight,
    "retry_request": request, "proof": {"scope_document": str(workspace.store.path(nid, scope)),
    "source_sha256_before": fingerprint(old_before), "source_sha256_after": fingerprint(old_after),
    "source_history_count": len(old_after["history"]), "new_history_count": len(raw_new["history"]),
    "new_dispatch_count": len(raw_new["dispatch_trace"]), "persisted_run_count": 2,
    "reopened_same_key_run_id": replay["id"], "model_calls": 0, "external_calls": 0,
    "browser_scope": "segmented HTTP fixture of these real File receipts; not full E2E"}}
(evidence / "actual-file.json").write_text(json.dumps(artifact, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(artifact["proof"], ensure_ascii=False))
