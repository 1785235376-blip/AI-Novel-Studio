import React, {useState} from 'react';
import {createRoot} from 'react-dom/client';
import {AppShell} from './src/ui/AppShell';
import type {StudioModule} from './src/ui/ModuleWorkspace';
import {GraphRunPanel} from './src/creative/GraphRunPanel';
import {createStudioGraphClient} from './src/creative/studioGraphClient';
import './src/ui/ui.css';import './src/ui/fixture.css';import './src/ui/desktop-craft.css';import './src/experimental/experimental.css';
const actual = await fetch('/qa-graph-retry-context.json').then(response=>response.json());
const client = createStudioGraphClient(actual.graph.project_id, {}, {json: async (url,method='GET',body) => {
  const response=await fetch(url,{method,headers:{'Content-Type':'application/json'},...(body?{body:JSON.stringify(body)}:{})});
  if(!response.ok)throw new Error('Fixture HTTP '+response.status);return response.json();
}});
await client.get(actual.graph.id);
const perform = <T,>(work:()=>Promise<T>)=>work();
function Fixture(){const [module,setModule]=useState<StudioModule>('NOVEL');return <AppShell module={module} onModuleChange={setModule}
  scope={{workspace:'本地工作区',project:'失败运行重试',storyline:'主线',branch:'当前草稿'}} actor="测试创作者"
  sidebar={<h2>创作图工作台</h2>} inspector={<p>真实 File 回执的分段 HTTP 界面夹具。重试仅创建新尝试，保留原失败历史。</p>}
  status="原 Graph / WorkflowRun owner · 无模型调用" main={<div className="experimental-workbench"><GraphRunPanel client={client}
    graph={actual.graph} requestedRunId={actual.failed.id} targetNodeIds={['review']} dirty={false} busy={false} canMutate canReview
    isCurrent={()=>true} read={perform} mutate={perform}/></div>}/>;}
createRoot(document.getElementById('root')!).render(<Fixture/>);
