import fs from 'node:fs/promises';import path from 'node:path';import {createServer} from 'vite';import {chromium,expect} from '@playwright/test';
const evidence=path.resolve('../../graph-retry-evidence');const actual=JSON.parse(await fs.readFile(path.join(evidence,'actual-file.json'),'utf8'));
await fs.writeFile('qa-graph-retry-context.json',JSON.stringify(actual));
const server=await createServer({cacheDir:path.resolve('.qa-graph-retry-cache'),server:{host:'127.0.0.1',port:5239,strictPort:true}});await server.listen();
const browser=await chromium.launch({headless:true});const page=await browser.newPage({viewport:{width:1440,height:900},locale:'zh-CN',timezoneId:'Asia/Shanghai',reducedMotion:'reduce'});
const errors=[],requests=[],geometry=[];page.on('pageerror',error=>errors.push(error.message));
let retryBody;
try{await page.route('**/api/**',async route=>{const req=route.request(),endpoint=new URL(req.url()).pathname;requests.push({method:req.method(),endpoint});
  if(endpoint.endsWith('/graphs/'+actual.graph.id))return route.fulfill({json:actual.graph});
  if(endpoint.endsWith('/graph-runs/'+actual.failed.id))return route.fulfill({json:actual.failed});
  if(endpoint.endsWith('/preflight')){expect(req.postDataJSON()).toEqual({expected_version:actual.graph.version,target_node_ids:Object.keys(actual.failed.node_states).sort()});return route.fulfill({json:actual.preflight});}
  if(endpoint.endsWith('/retry-local')){retryBody=req.postDataJSON();expect(retryBody.expected_version).toBe(actual.failed.version);expect(retryBody.expected_graph_version).toBe(actual.graph.version);expect(retryBody.reviewed_preflight_digest).toBe(actual.preflight.preflight_digest);return route.fulfill({json:actual.queued});}
  throw new Error('Unexpected '+req.method()+' '+endpoint);
});
await page.goto('http://127.0.0.1:5239/qa-graph-retry.html');await page.getByRole('button',{name:'核对失败运行重试',exact:true}).click();
await expect(page.getByRole('button',{name:'仅创建重试运行',exact:true})).toBeDisabled();expect(requests.some(r=>r.endpoint.endsWith('/retry-local'))).toBe(false);
await page.getByLabel('已核对原失败运行，仅创建关联的新尝试').check();
await page.addStyleTag({content:'*,*::before,*::after{animation:none!important;transition:none!important;caret-color:transparent!important}'});
for(const [width,height]of [[1366,768],[1440,900],[1920,1080]])for(const module of ['NOVEL','IMAGE','VIDEO']){
  await page.setViewportSize({width,height});await page.locator('[data-module-tab="'+module+'"]').click();
  await page.getByRole('button',{name:'仅创建重试运行',exact:true}).scrollIntoViewIfNeeded();await page.evaluate(()=>document.fonts.ready);
  const g=await page.evaluate(()=>{const rect=s=>{const r=document.querySelector(s).getBoundingClientRect();return{width:r.width,height:r.height};};const main=document.querySelector('.main-workspace');if(!main)throw new Error('Original main workspace missing');return{header:rect('.global-header'),context:rect('.context-bar'),sidebar:rect('.workspace-sidebar'),inspector:rect('.workspace-inspector'),status:rect('.status-bar'),scrollWidth:document.documentElement.scrollWidth,mainOverflow:main.scrollWidth>main.clientWidth};});
  expect(g.header.height).toBe(56);expect(g.context.height).toBe(44);expect(g.sidebar.width).toBe(248);expect(g.inspector.width).toBe(340);expect(g.status.height).toBe(32);expect(g.scrollWidth).toBeLessThanOrEqual(width);expect(g.mainOverflow).toBe(false);geometry.push({width,height,module,...g});
  if((width===1366&&module==='NOVEL')||(width===1440&&module==='IMAGE')||(width===1920&&module==='VIDEO'))await page.screenshot({path:path.join(evidence,`graph-retry-${width}.png`)});
}
await page.getByRole('button',{name:'仅创建重试运行',exact:true}).click();await expect(page.getByText(/第 2 次尝试/)).toBeVisible();
expect(requests.filter(r=>r.endpoint.endsWith('/retry-local')).length).toBe(1);expect(requests.some(r=>r.endpoint.endsWith('/execute'))).toBe(false);expect(errors).toEqual([]);
await fs.writeFile(path.join(evidence,'browser-results.json'),JSON.stringify({status:'passed',scope:'segmented real-File receipt fixture, not full E2E',requests,retryBody,geometry,errors},null,2));
console.log(JSON.stringify({status:'passed',geometryCases:geometry.length,retryRequests:1,executeRequests:0,errors}));
}catch(error){console.error(error);await page.screenshot({path:path.join(evidence,'browser-failure.png')});process.exitCode=1;}finally{await browser.close();await server.close();}
