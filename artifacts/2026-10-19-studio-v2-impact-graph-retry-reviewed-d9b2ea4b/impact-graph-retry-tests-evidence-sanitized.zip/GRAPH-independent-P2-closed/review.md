# GRAPH-21 权限 ABA P2 关闭复查

提交 `2e5ef296d8f908d07c37f444387fdd4efd0c591f`，父 `7533f4c6c091bf157f0627acef86689bfb138bcd`。结论：原 P2 已关闭，本轮无新增 P1/P2；结合上一轮已通过的 File/API 证据，可限定整合该有界 GRAPH-21 重试能力。

只读核对 controller+test 两文件。唯一产品变更将 canMutate 加入原 navigation callback fence，使写权限变化退休旧回调，同时保留 UNKNOWN retry plan 与 request_id。没有改后端、路由或持久化。

独立最小复查首次 `2 passed in 1.43s`：

1. 原反例：原 GraphRunPanel 使用上轮真实 File 的公开回执，第一次显式重试在受控 client 模拟丢回复后进入 UNKNOWN。捕获旧恢复回调，canMutate=false 时不调用；恢复 true 后重复调用旧回调仍不调用。总 retryLocal=1，UNKNOWN 计划和已核对状态仍可见，preflight=1，action/createRun=0。
2. 直接合法恢复：同样经过 UNKNOWN 与权限 ABA，旧回调无调用。明确重新读取原 source run 后，再点击当前界面的恢复按钮，retryLocal=2，第二次完整参数与第一次逐值相同（包括 request_id、source、两个版本与 reviewed_preflight_digest）。只发生一次 preflight、没有自动重核对，也没有 action/execute 或普通 createRun。原 getRun 为初次读取与一次明确重读，共2次。

这是原 controller 的受控客户端边界，没有实际 HTTP 重发，也不扩大为服务器权限/浏览器验收。上轮同键幂等与真实 File/API guard 检查继续作为既有证据，本轮未重跑。

原红日志 `../frontend1.log`、JUnit、反例 JSON、原独立探针与真实 File 回执的 SHA256 均保持。新绿日志、JUnit、命令、两项 JSON 及新子集探针都保留；没有覆盖唯一红证据。测试探针 `../retry-permission-closure.test.tsx`。

直接引用原干净工作区源码和既有依赖，零完整源码/依赖复制、无安装、未改产品/原测试、未推送。运行前后两个差异文件均与目标 blob 相同，HEAD 未变且 git status 为空。原77/129、File/API、TS/build、几何、浏览器、PG/full E2E 均未重跑；PG 本任务不要求，完整浏览器/E2E 仍未验收。没有模型/GPU、付费 API或真实账号/凭据变化。工具动作没有拒绝、待审批或不确定执行结果。
