# GRAPH-21 失败本地运行重试独立审查

提交 `7533f4c6c091bf157f0627acef86689bfb138bcd`，父 `25f9839459a39f79634b6024d22a5e644ea10da9`，原工作区 `<workspace>/gr`。十二文件只读 diff；四项独立反例，三项后端通过，一项前端产品反例失败。结论：1 个 P2，无 P1，建议修复 P2 后再整合整个提交。

## P2：UNKNOWN 恢复旧回调在权限 ABA 后复活

定位 `frontend/src/creative/useStudioGraphRunController.ts:282-286`，根因关联 `:48` 与 `:151-153,312-315`。retry canSubmit 使用 navigationScope，而 navigationValues 不包含 canMutate。UNKNOWN 后保留 retryRef（包括原请求键）是恢复所需，但权限 false→true 不退休该恢复按钮的旧回调。

独立复现：使用本轮真实 File 服务生成的原 graph、FAILED source、QUEUED retry 公开回执驱动原 GraphRunPanel。第一次明确提交，受控 client 模拟 NETWORK_ERROR 丢回复，进入“使用同一请求核对重试创建”。捕获此时的旧回调。canMutate=false 时调用该回调没有调用 client；恢复 canMutate=true 后，不点击新的按钮而直接调用旧回调，client.retryLocal 从 1 次增加到 2 次。原 request_id 完全相同，action/execute 与普通 createRun 都是 0 次。见 `case4-old-callbacks.json`、`frontend1.log`。

证据范围：这是原 React controller 的受控客户端反例，未发真实 HTTP，也没有证明服务器权限绕过、额外落盘运行或自动执行。按真实 client 的只读 diff，此方法会提交 retry-local POST。后端同键幂等在本轮独立 File 检查中保持有效。产品缺口是旧权限回调应被退休，而不是换键或清除不确定恢复记录。

最小建议：让 retry 回调携带包含写权限变化的退休代际（或将 canMutate 纳入对应 fence）；保留 UNKNOWN 的原 request_id。撤权/恢复后旧回调必须无调用，新界面明确恢复仍可用同键。不要用丢弃 UNKNOWN key 或自动重新 preflight/执行来修正。由作者修改，本审查没有改产品。

## 四项独立检查

| 项目 | 实际结果 |
| --- | --- |
| 真实 File 正向、并发、丢回包 | PASS。用原 draft_prepare 真实规则产生确定 FAILED；3 个并发同键请求得到同一 QUEUED 子运行，retry_of/attempt=2、version=1。提交后模拟丢回复，重开 File owner 同键仍返回同一行。物理 scope JSON 共 2 行，旧运行及 history JSON 值完整不变；子 history/trace/dispatch_trace 空、输入/typed nodes/closure 沿用、全部 PENDING、无审核。重试阶段原 adapter 被设为失败探针，未执行节点。 |
| 状态、输入、白名单 | PASS。8 种非 FAILED 状态含 UNKNOWN、改 input、模型或媒体运行标记、schema6 标记、非法 attempt 全拒绝，scope 文件逐字节不变；4 种额外请求字段拒绝。另建含未选 asset_reference 的完整图，即使所选闭包纯本地，重试也因整图白名单拒绝。 |
| mounted /api/v1 原 guard | PASS（仅该项经过两次探针准备修正复跑）。POST 精确路径允许，其余方法/未知子动作不允许。无会话401、只读403、错分支403；另一个确有 write 的作者仍404。run/graph/preflight 版本不符409；Save 后旧 preflight 和新读 preflight 都不能刷新旧 run 的 pin。事务插入后挂钩撤销真实原角色，403 且 scope 字节未变。删除/重建同 public ID、重新建立有效测试分支和 write 权限后，放回旧 incarnation 原记录仍404，旧行保留但对新 owner 不可见。 |
| 前端旧 callback | FAIL，P2。普通 dirty/busy/authority/definition/client ABA 与卸载旧 callback 均0调用；唯 UNKNOWN 恢复计划保留后的 authority ABA 出现1次额外 retryLocal 调用。无 execute/createRun。 |

物理旧行 SHA256 前后均为 `dc6506913ad834df7edaf9cc3bd7eb1778a6894c87adfae39b9bda4290d0dfe3`；source history=1，child history=0；scope 文件 SHA256 `9ceff6797b97d64873d3000d2c90a119c2f124f9480bdf35c031ac059171785e`。物理文件保留且再次核对摘要一致，路径和完整 JSON 在 `case1-file.json`。

运行账本：backend1 为 2 passed /1 failed（API 探针漏规范路径 /api 前缀）；backend2 只复跑 API 项，前面的权限/版本/事务撤权检查完成后，测试重建项目时遗漏原删除级联移除的 storyline/branch，准备阶段 KeyError；backend3 补回该原测试上下文后只复跑 API，1 passed /2 deselected，7.74 秒。两份早期探针、三份原始日志和修正 diff 保留；没有改产品或原测试、没有弱化断言。pytest 自定义 marker 注册警告源于本独立小目录未加载仓库 pyproject；没有执行 PG 分支。Starlette 和原 Glossary 字段警告保留。

frontend1 首次 1 failed，1.75 秒，为上面的产品反例；未改成通过或重跑。总计四项独立检查，三个通过，一个产品失败；不是全绿。

## 路由与边界结论

`workspace_api.py` 只增加精确 POST retry-local allowlist。新 handler 仍经原 graph_invoke(domain.write,target=RUNS)，回到原 invoke 的 actor/scope/incarnation guard；来源 owner 和图版本在原 transaction 内再查。原事务末端 current() 保证撤权回滚；本轮真实 File mounted 验证与静态路径一致。没有出现权限/同 public ID 继承 P1/P2 发现。

十二个 diff 文件运行前后与目标 blob 一致，HEAD 未变、git status 为空。直接导入原源文件，零产品源码复制、零依赖复制/安装；仅复制 6 个当前提交原测试 helper（142072 字节）让 fixture 的 .runtime 根属于本审查目录。独立探针、数据、配置、日志、JUnit、版本与 SHA 清单都在本目录。

未重跑作者77/129、TS/build、几何或其他大套件；作者原始失败/成功证据保留，未计作本轮通过项。没有启动服务或模型/GPU、付费 API，未读取/修改用户真实凭据，原授权测试 fixture 只建立独立 File 数据中的合成身份。PostgreSQL 本任务不要求、未运行；完整浏览器/E2E 未验收。未推送。工具动作没有拒绝、待审批或不确定结果。
