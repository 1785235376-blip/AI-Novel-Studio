// @vitest-environment jsdom
import {act,cleanup,fireEvent,render,screen,waitFor} from '@testing-library/react';
import {afterEach,expect,it,vi} from 'vitest';
import {readFileSync,writeFileSync} from 'node:fs';
import {GraphRunPanel} from '<workspace>/gr/frontend/src/creative/GraphRunPanel';
import {ApiError} from '<workspace>/gr/frontend/src/api';
import type {ComponentProps} from 'react';
import type {StudioGraphRun,StudioGraphRecord} from '<workspace>/gr/frontend/src/creative/studioGraphTypes';
const actual=JSON.parse(readFileSync('case1-file.json','utf8'));
type Props=ComponentProps<typeof GraphRunPanel>;
const perform=<T,>(work:()=>Promise<T>)=>work();
function setup(){
 const graph=structuredClone(actual.graph) as StudioGraphRecord,source=structuredClone(actual.source) as StudioGraphRun,queued=structuredClone(actual.new) as StudioGraphRun;
 const client={catalog:vi.fn(),list:vi.fn(),create:vi.fn(),get:vi.fn(),save:vi.fn(),modelCapabilities:vi.fn(),previewModel:vi.fn(),dispatchModel:vi.fn(),refreshModel:vi.fn(),
  preflight:vi.fn().mockResolvedValue({graph_id:graph.id,expected_version:graph.version,valid:true,executable:true,issues:[],preflight_digest:actual.request_body.reviewed_preflight_digest,selected_closure:Object.keys(source.node_states).sort(),target_node_ids:Object.keys(source.node_states).sort(),execution_order:Object.keys(source.node_states),definition_digest:graph.definition_digest,model_called:false,external_calls:0}),
  runs:vi.fn().mockResolvedValue({items:[source]}),getRun:vi.fn().mockResolvedValue(source),createRun:vi.fn(),action:vi.fn(),retryLocal:vi.fn().mockResolvedValue(queued)};
 const props:Props={client,graph,targetNodeIds:['review'],dirty:false,busy:false,canMutate:true,canReview:true,isCurrent:()=>true,read:perform,mutate:perform,requestedRunId:source.id};
 const view=render(<GraphRunPanel {...props}/>);return {props,client,view,queued};
}
const button=(name:string)=>screen.getByRole('button',{name}) as HTMLButtonElement;
function handler(node:HTMLElement):()=>void{const key=Object.keys(node).find(key=>key.startsWith('__reactProps$'))!;return (node as unknown as Record<string,{onClick:()=>void}>)[key].onClick;}
async function prepare(){
 await waitFor(()=>expect(button('核对失败运行重试').disabled).toBe(false));fireEvent.click(button('核对失败运行重试'));
 const consent=await screen.findByRole('checkbox',{name:'已核对原失败运行，仅创建关联的新尝试'});fireEvent.click(consent);
 await waitFor(()=>expect(button('仅创建重试运行').disabled).toBe(false));
}
afterEach(cleanup);
async function lostReply(){
 const e=setup();await prepare();
 e.client.retryLocal.mockRejectedValueOnce(new ApiError({status:0,code:'NETWORK_ERROR',message:'independent lost admission reply'}));
 fireEvent.click(button('仅创建重试运行'));
 await screen.findByRole('button',{name:'使用同一请求核对重试创建'});
 expect(e.client.retryLocal).toHaveBeenCalledTimes(1);
 return e;
}
it('original UNKNOWN permission ABA old recovery callback stays retired with the recovery plan retained',async()=>{
 const e=await lostReply(),first=e.client.retryLocal.mock.calls[0],old=handler(button('使用同一请求核对重试创建'));
 e.view.rerender(<GraphRunPanel {...e.props} canMutate={false}/>);
 expect(button('使用同一请求核对重试创建').disabled).toBe(true);
 await act(async()=>{old();await Promise.resolve();});expect(e.client.retryLocal).toHaveBeenCalledTimes(1);
 e.view.rerender(<GraphRunPanel {...e.props}/>);
 expect(button('使用同一请求核对重试创建').disabled).toBe(false);
 expect((screen.getByRole('checkbox',{name:'已核对原失败运行，仅创建关联的新尝试'}) as HTMLInputElement).checked).toBe(true);
 await act(async()=>{old();old();await Promise.resolve();});
 expect(e.client.retryLocal).toHaveBeenCalledTimes(1);expect(e.client.preflight).toHaveBeenCalledTimes(1);
 expect(e.client.action).not.toHaveBeenCalled();expect(e.client.createRun).not.toHaveBeenCalled();
 writeFileSync('p2-closure/original-counterexample.json',JSON.stringify({old_callback_calls_while_denied:0,old_callback_calls_after_restore:0,total_retry_calls:1,recovery_plan_visible:true,preflight_calls:1,first_request:first,execute_calls:0,ordinary_create_calls:0},null,2));
});
it('fresh explicit recovery after permission ABA and original run reread uses the identical UNKNOWN request body and key',async()=>{
 const e=await lostReply(),first=e.client.retryLocal.mock.calls[0],old=handler(button('使用同一请求核对重试创建'));
 e.view.rerender(<GraphRunPanel {...e.props} canMutate={false}/>);e.view.rerender(<GraphRunPanel {...e.props}/>);
 await act(async()=>{old();await Promise.resolve();});expect(e.client.retryLocal).toHaveBeenCalledTimes(1);
 e.client.getRun.mockResolvedValue(structuredClone(actual.source));fireEvent.click(button('重新读取当前运行'));
 await waitFor(()=>expect(e.client.getRun).toHaveBeenCalledTimes(2));
 await waitFor(()=>expect(button('使用同一请求核对重试创建').disabled).toBe(false));
 expect(e.client.preflight).toHaveBeenCalledTimes(1);expect(e.client.retryLocal).toHaveBeenCalledTimes(1);
 fireEvent.click(button('使用同一请求核对重试创建'));
 await screen.findByText(/第 2 次尝试/);
 expect(e.client.retryLocal).toHaveBeenCalledTimes(2);expect(e.client.retryLocal.mock.calls[1]).toEqual(first);
 expect(e.client.preflight).toHaveBeenCalledTimes(1);expect(e.client.action).not.toHaveBeenCalled();expect(e.client.createRun).not.toHaveBeenCalled();
 writeFileSync('p2-closure/fresh-same-key-recovery.json',JSON.stringify({first_request:first,recovered_request:e.client.retryLocal.mock.calls[1],same_exact_request:true,preflight_calls:1,get_run_calls:2,execute_calls:0,ordinary_create_calls:0,queued_run:actual.new},null,2));
});
