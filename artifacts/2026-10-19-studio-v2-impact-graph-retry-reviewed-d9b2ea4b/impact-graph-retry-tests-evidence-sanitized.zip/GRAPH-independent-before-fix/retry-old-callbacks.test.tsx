// @vitest-environment jsdom
import {act,cleanup,fireEvent,render,screen,waitFor} from '@testing-library/react';
import {afterEach,expect,it,vi} from 'vitest';
import {readFileSync,writeFileSync} from 'node:fs';
import {GraphRunPanel} from '<workspace>/gr/frontend/src/creative/GraphRunPanel';
import {ApiError} from '<workspace>/gr/frontend/src/api';
import type {ComponentProps} from 'react';
import type {StudioGraphRun,StudioGraphRecord} from '<workspace>/gr/frontend/src/creative/studioGraphTypes';
const actual=JSON.parse(readFileSync('case1-file.json','utf8'));
type Props=ComponentProps<typeof GraphRunPanel>;
const perform=<T,>(work:()=>Promise<T>)=>work();
function setup(){
 const graph=structuredClone(actual.graph) as StudioGraphRecord,source=structuredClone(actual.source) as StudioGraphRun,queued=structuredClone(actual.new) as StudioGraphRun;
 const client={catalog:vi.fn(),list:vi.fn(),create:vi.fn(),get:vi.fn(),save:vi.fn(),modelCapabilities:vi.fn(),previewModel:vi.fn(),dispatchModel:vi.fn(),refreshModel:vi.fn(),
  preflight:vi.fn().mockResolvedValue({graph_id:graph.id,expected_version:graph.version,valid:true,executable:true,issues:[],preflight_digest:actual.request_body.reviewed_preflight_digest,selected_closure:Object.keys(source.node_states).sort(),target_node_ids:Object.keys(source.node_states).sort(),execution_order:Object.keys(source.node_states),definition_digest:graph.definition_digest,model_called:false,external_calls:0}),
  runs:vi.fn().mockResolvedValue({items:[source]}),getRun:vi.fn().mockResolvedValue(source),createRun:vi.fn(),action:vi.fn(),retryLocal:vi.fn().mockResolvedValue(queued)};
 const props:Props={client,graph,targetNodeIds:['review'],dirty:false,busy:false,canMutate:true,canReview:true,isCurrent:()=>true,read:perform,mutate:perform,requestedRunId:source.id};
 const view=render(<GraphRunPanel {...props}/>);return {props,client,view,queued};
}
const button=(name:string)=>screen.getByRole('button',{name}) as HTMLButtonElement;
function handler(node:HTMLElement):()=>void{const key=Object.keys(node).find(key=>key.startsWith('__reactProps$'))!;return (node as unknown as Record<string,{onClick:()=>void}>)[key].onClick;}
async function prepare(){
 await waitFor(()=>expect(button('核对失败运行重试').disabled).toBe(false));fireEvent.click(button('核对失败运行重试'));
 const consent=await screen.findByRole('checkbox',{name:'已核对原失败运行，仅创建关联的新尝试'});fireEvent.click(consent);
 await waitFor(()=>expect(button('仅创建重试运行').disabled).toBe(false));
}
afterEach(cleanup);
it('retires captured retry callbacks across owner/permission ABA including retained UNKNOWN admission key',async()=>{
 const observed=[];
 for(const mode of ['dirty','busy','authority','definition','client','unmount']){
  const e=setup();await prepare();const old=handler(button('仅创建重试运行'));
  if(mode==='unmount')e.view.unmount();
  else{
   const next={...e.props};
   if(mode==='dirty')next.dirty=true;if(mode==='busy')next.busy=true;if(mode==='authority')next.canMutate=false;
   if(mode==='definition')next.graph={...e.props.graph!,definition_digest:'f'.repeat(64)};
   if(mode==='client')next.client={...e.props.client};
   e.view.rerender(<GraphRunPanel {...next}/>);e.view.rerender(<GraphRunPanel {...e.props}/>);
  }
  await act(async()=>{old();await Promise.resolve();});
  observed.push({mode,old_callback_retry_posts:e.client.retryLocal.mock.calls.length});
  expect(e.client.action).not.toHaveBeenCalled();expect(e.client.createRun).not.toHaveBeenCalled();e.view.unmount();
 }
 const e=setup();await prepare();
 e.client.retryLocal.mockRejectedValueOnce(new ApiError({status:0,code:'NETWORK_ERROR',message:'independent lost admission reply'}));
 fireEvent.click(button('仅创建重试运行'));
 await screen.findByRole('button',{name:'使用同一请求核对重试创建'});
 expect(e.client.retryLocal).toHaveBeenCalledTimes(1);
 const first=e.client.retryLocal.mock.calls[0],old=handler(button('使用同一请求核对重试创建'));
 e.view.rerender(<GraphRunPanel {...e.props} canMutate={false}/>);
 expect(button('使用同一请求核对重试创建').disabled).toBe(true);
 await act(async()=>{old();await Promise.resolve();});expect(e.client.retryLocal).toHaveBeenCalledTimes(1);
 e.view.rerender(<GraphRunPanel {...e.props}/>);
 await act(async()=>{old();await Promise.resolve();});
 const delta=e.client.retryLocal.mock.calls.length-1;
 observed.push({mode:'UNKNOWN-authority-ABA',old_callback_retry_posts:delta});
 writeFileSync('case4-old-callbacks.json',JSON.stringify({actual_file_source_run:actual.source.id,actual_file_new_run:actual.new.id,observed,first_request:first,second_request:e.client.retryLocal.mock.calls[1]??null,same_key_if_repeated:e.client.retryLocal.mock.calls[1]?.[1].request_id===first[1].request_id,execute_calls:e.client.action.mock.calls.length,ordinary_create_calls:e.client.createRun.mock.calls.length,external_permission_bypass_claimed:false},null,2));
 expect(e.client.action).not.toHaveBeenCalled();expect(e.client.createRun).not.toHaveBeenCalled();
 expect(observed.filter(row=>row.old_callback_retry_posts!==0)).toEqual([]);
});
