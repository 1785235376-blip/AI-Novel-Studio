"""Three independent File/service/API checks; original product is imported read-only."""
from copy import deepcopy
from concurrent.futures import ThreadPoolExecutor
from threading import Barrier
from types import SimpleNamespace
from uuid import uuid4
from pathlib import Path
import hashlib,json
import pytest
from test_v2_independent_workspace import rig as original_rig,reopened,import_asset
from test_r3_mounted_contracts import mounted as original_mounted,checked,scoped
from test_v2_independent_workspace_api import client
from test_v2_creative_graph_api import graph_client,create as api_create,admit,definition as api_definition
from test_v2_creative_graph_persistence import service,create,run,save,definition,asset_node
from test_v2_creative_graph_execution import action
from app.creative.graph import CreativeGraphService
from app.creative.workspace_api import is_independent_studio_route
from app.experimental.store import canonical
from app.authorization import AuthorizationScope,ModalityDomain,PermissionAssignment,ScopeKind
from app.collaboration import Storyline,Branch

ROOT=Path(__file__).resolve().parent
@pytest.fixture
def file_rig(tmp_path,monkeypatch):yield from original_rig.__wrapped__(SimpleNamespace(param='file'),tmp_path,monkeypatch)
@pytest.fixture
def prefix():return '/api/v1'
@pytest.fixture
def mounted(tmp_path,monkeypatch,prefix):yield from original_mounted.__wrapped__(SimpleNamespace(param='file'),tmp_path,monkeypatch,prefix)

def record(name,value):(ROOT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
def sha(data):return hashlib.sha256(data).hexdigest()
def row_sha(row):return sha(canonical(row).encode())
def failing(e,extra=None):
 value=definition();value['nodes'][0]['parameters']['text']='\n'.join('Independent beat '+str(i) for i in range(104))
 if extra:value['nodes'].append(extra)
 graph=create(e,value);source=action(e,run(e,graph,targets=['review']),'execute')
 assert source['status']=='FAILED',source
 return graph,source

def request(e,graph,source,key=None):
 flight=service(e).preflight(e.nid,e.scope,e.actor,graph['id'],{'expected_version':graph['version'],'target_node_ids':sorted(source['node_states'])})
 return {'expected_version':source['version'],'expected_graph_version':graph['version'],'reviewed_preflight_digest':flight['preflight_digest'],'request_id':key or 'review-retry-'+uuid4().hex}
def retry(e,source,body,owner=None):return (owner or service(e)).executor.retry_failed_local(e.nid,e.scope,e.actor,source['id'],body,lambda:None)


def test_retry1_real_file_concurrent_and_lost_reply_exact_key_keep_old_history(file_rig,monkeypatch):
 e=file_rig;graph,source=failing(e);body=request(e,graph,source);owner=service(e)
 before=deepcopy(e.raw_store.read(e.nid,e.scope));old=before['collections'][owner.RUNS][source['id']]
 import app.creative.graph_execution as module
 monkeypatch.setattr(module._LocalGraphAdapter,'execute',lambda *a,**k:pytest.fail('retry admission executed local node'))
 barrier=Barrier(3)
 def concurrent(_):barrier.wait(timeout=10);return retry(e,source,body)
 with ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(concurrent,range(3)))
 assert results[0]==results[1]==results[2]
 new=results[0];assert new['status']=='QUEUED' and new['retry_of']==source['id'] and new['attempt']==2 and new['version']==1
 assert not new['reviewed'] and not new['model_called'] and new['external_calls']==0
 fresh=CreativeGraphService(reopened(e).store,reopened(e))
 def lost_reply():retry(e,source,body,fresh);raise OSError('independent lost admission reply after durable commit')
 with pytest.raises(OSError):lost_reply()
 assert retry(e,source,body,CreativeGraphService(reopened(e).store,reopened(e)))==new
 physical=e.raw_store.path(e.nid,e.scope);after=json.loads(physical.read_text(encoding='utf-8'))
 rows=after['collections'][owner.RUNS];assert len(rows)==2 and rows[source['id']]==old
 child=rows[new['id']]
 assert child['selected_closure']==old['selected_closure'] and child['typed_nodes']==old['typed_nodes'] and child['typed_edges']==old['typed_edges'] and child['input']==old['input']
 assert child['trace']==child['dispatch_trace']==child['history']==[] and child['typed_outputs']=={}
 assert all(n['status']=='PENDING' and n['output'] is None for n in child['node_states'].values())
 persisted=physical.read_bytes()
 with pytest.raises(ValueError):retry(e,source,{**body,'reviewed_preflight_digest':'0'*64})
 assert physical.read_bytes()==persisted
 record('case1-file.json',{'source':source,'new':new,'graph':graph,'request_body':body,'old_sha256_before':row_sha(old),'old_sha256_after':row_sha(rows[source['id']]),'source_history_count':len(old['history']),'new_history_count':len(child['history']),'persisted_run_count':len(rows),'concurrent_requests':3,'lost_reply_reopened_equal':True,'scope_file':str(physical),'scope_sha256':sha(physical.read_bytes()),'retry_native_executions':0,'persisted':after})


def test_retry2_closed_status_input_runtime_and_whole_graph_allowlist(file_rig):
 e=file_rig;graph,source=failing(e);body=request(e,graph,source);owner=service(e)
 original=deepcopy(e.raw_store.read(e.nid,e.scope)['collections'][owner.RUNS][source['id']]);observed=[]
 patches=[('status-'+status,{'status':status}) for status in ['QUEUED','RUNNING','PAUSED','WAITING_APPROVAL','SUCCEEDED','CANCELLED','REJECTED','UNKNOWN']]
 patches += [('input',{'input':{'text':'cannot substitute input'}}),('model',{'model_execution_contract':'creative-graph-model/1'}),('media',{'media_executions':{'node':{'status':'UNKNOWN'}}}),('schema6',{'graph_schema_version':6}),('attempt-bool',{'attempt':True}),('attempt-limit',{'attempt':100})]
 for label,patch in patches:
  with e.store.transaction(e.nid,e.scope) as state:state['collections'][owner.RUNS][source['id']].update(patch)
  physical=e.raw_store.path(e.nid,e.scope);before=physical.read_bytes()
  with pytest.raises(ValueError) as error:retry(e,source,body)
  assert physical.read_bytes()==before
  observed.append({'case':label,'error':str(error.value),'writes':0})
  with e.store.transaction(e.nid,e.scope) as state:state['collections'][owner.RUNS][source['id']]=deepcopy(original)
 for extra in [{'input':{}},{'target_node_ids':[]},{'attempt':2},{'retry_of':source['id']}]:
  before=e.raw_store.path(e.nid,e.scope).read_bytes()
  with pytest.raises(ValueError):retry(e,source,{**body,**extra})
  assert e.raw_store.path(e.nid,e.scope).read_bytes()==before
 asset=import_asset(e);other,failed=failing(e,asset_node(asset));otherbody=request(e,other,failed)
 assert 'asset' not in failed['node_states']
 before=e.raw_store.path(e.nid,e.scope).read_bytes()
 with pytest.raises(ValueError,match='SCHEMA1_LOCAL_REQUIRED'):retry(e,failed,otherbody)
 assert e.raw_store.path(e.nid,e.scope).read_bytes()==before
 assert e.raw_store.read(e.nid,e.scope)['collections'][owner.RUNS][source['id']]==original
 record('case2-closed.json',{'rejections':observed,'extra_request_fields_rejected':4,'unselected_whole_graph_asset_rejected':True,'runs_after':len(e.raw_store.read(e.nid,e.scope)['collections'][owner.RUNS]),'retry_rows_created':0})


def api_failed(e):
 value=api_definition('\n'.join('API beat '+str(i) for i in range(104)));value['nodes'][1].update(definition_id='draft_prepare',parameters={})
 graph=api_create(e,headers=e.headers,value=value);source=admit(e,graph,headers=e.headers);path=e.studio_base+'/graph-runs/'+source['id']
 source=checked(e.client.post(path+'/execute',headers=e.headers,json={'expected_version':source['version']}));assert source['status']=='FAILED'
 flight=checked(e.client.post(e.graph_base+'/'+graph['id']+'/preflight',headers=e.headers,json={'expected_version':graph['version'],'target_node_ids':sorted(source['node_states'])}))
 body={'expected_version':source['version'],'expected_graph_version':graph['version'],'reviewed_preflight_digest':flight['preflight_digest'],'request_id':'independent-api-'+uuid4().hex}
 return graph,source,path,body


def test_retry3_mounted_allowlist_actor_scope_live_permission_version_and_incarnation(graph_client,monkeypatch):
 e=scoped(graph_client,monkeypatch);graph,source,path,body=api_failed(e);observed=[]
 norm='/api/projects/'+e.nid+'/studio/graph-runs/'+source['id']+'/retry-local'
 assert is_independent_studio_route('POST',norm)
 for method in ['GET','PUT','DELETE','PATCH']:assert not is_independent_studio_route(method,norm)
 for suffix in ['/execute','-extra','/extra']:assert not is_independent_studio_route('POST',norm+suffix)
 before=e.graphs.store.path(e.nid,e.scope).read_bytes()
 for label,headers in [('no-session',{}),('read-only',e.viewer_headers),('wrong-branch',{**e.headers,'X-Branch-ID':e.other_branch})]:
  response=e.client.post(path+'/retry-local',headers=headers,json=body);assert response.status_code in {401,403,404}
  observed.append({'case':label,'status':response.status_code})
 auth=AuthorizationScope(ScopeKind.BRANCH,e.workspace,e.nid,e.storyline,e.branch)
 e.authorization.assign_permission(PermissionAssignment('review-viewer-write-'+uuid4().hex,e.viewer,'domain.write',ModalityDomain.NOVEL,auth,e.lead))
 foreign=e.client.post(path+'/retry-local',headers=e.viewer_headers,json=body);assert foreign.status_code==404
 observed.append({'case':'foreign-author-with-write','status':foreign.status_code})
 for label,changed in [('run-version',{**body,'expected_version':body['expected_version']+1}),('graph-version',{**body,'expected_graph_version':body['expected_graph_version']+1}),('preflight',{**body,'reviewed_preflight_digest':'0'*64})]:
  response=e.client.post(path+'/retry-local',headers=e.headers,json=changed);assert response.status_code==409
  observed.append({'case':label,'status':response.status_code})
 assert e.graphs.store.path(e.nid,e.scope).read_bytes()==before
 assert e.client.post(path+'/retry-local-extra',headers=e.headers,json=body).status_code==501
 changed={**graph['definition'],'title':'Saved later title'}
 newer=checked(e.client.put(e.graph_base+'/'+graph['id'],headers=e.headers,json={'expected_version':graph['version'],'definition':changed}))
 assert e.client.post(path+'/retry-local',headers=e.headers,json=body).status_code==409
 freshflight=checked(e.client.post(e.graph_base+'/'+graph['id']+'/preflight',headers=e.headers,json={'expected_version':newer['version'],'target_node_ids':sorted(source['node_states'])}))
 freshbody={**body,'expected_graph_version':newer['version'],'reviewed_preflight_digest':freshflight['preflight_digest']}
 assert e.client.post(path+'/retry-local',headers=e.headers,json=freshbody).status_code==409
 graph2,source2,path2,body2=api_failed(e);before=e.graphs.store.path(e.nid,e.scope).read_bytes();capacity=e.graphs._capacity
 def revoke_after_insert(state):
  capacity(state);e.authorization.revoke_role(e.role,e.lead)
 monkeypatch.setattr(e.graphs,'_capacity',revoke_after_insert)
 denied=e.client.post(path2+'/retry-local',headers=e.headers,json=body2);assert denied.status_code==403,denied.text
 assert e.graphs.store.path(e.nid,e.scope).read_bytes()==before
 monkeypatch.setattr(e.graphs,'_capacity',capacity)
 old_state=deepcopy(e.store.read(e.nid,e.scope));old_incarnation=e.graphs.store.incarnation(e.nid)
 e.novels.delete(e.nid);e.novels.create({'id':e.nid,'title':'Recreated same public ID'})
 e.scopes.link_project(e.workspace,e.nid)
 e.scopes.create_storyline(Storyline(e.storyline,e.workspace,e.nid,'Recreated test storyline'))
 for bid in (e.branch,e.other_branch):e.scopes.create_branch(Branch(bid,e.workspace,e.nid,e.storyline,bid))
 new_incarnation=e.graphs.store.incarnation(e.nid);assert old_incarnation!=new_incarnation
 with e.store.transaction(e.nid,e.scope) as state:
  state['collections'].update(deepcopy(old_state['collections']))
 e.authorization.assign_permission(PermissionAssignment('review-new-owner-write-'+uuid4().hex,e.lead,'domain.write',ModalityDomain.NOVEL,auth,e.lead))
 physical=e.graphs.store.path(e.nid,e.scope);transplanted=physical.read_bytes()
 recycled=e.client.post(path2+'/retry-local',headers=e.headers,json=body2);assert recycled.status_code==404,recycled.text
 assert physical.read_bytes()==transplanted
 assert source2['id'] not in e.graphs.store.read(e.nid,e.scope)['collections'].get(e.graphs.RUNS,{})
 record('case3-authority.json',{'prefix':e.prefix,'exact_post_allowlist_only':True,'denials':observed,'old_and_refreshed_preflight_after_save_rejected':True,'late_revocation_status':denied.status_code,'late_revocation_scope_bytes_unchanged':True,'incarnation_status':recycled.status_code,'old_incarnation':old_incarnation,'new_incarnation':new_incarnation,'transplanted_old_records_preserved_but_hidden':True,'retry_rows_created':0})
