import { act, cleanup, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, expect, it, vi } from 'vitest';
import { writeFileSync } from 'node:fs';
import { ApiError } from '../../task/studio-v2-impact-decisions/frontend/src/api';
import { ImpactDecisionPanel } from '../../task/studio-v2-impact-decisions/frontend/src/experimental/ImpactDecisionPanel';
import { changeImpactClient, type ImpactView } from '../../task/studio-v2-impact-decisions/frontend/src/experimental/changeImpactClient';
import type { ExperimentalClient } from '../../task/studio-v2-impact-decisions/frontend/src/experimental/api';
import { checkedDecisionSave } from '../../task/studio-v2-impact-decisions/frontend/src/experimental/changeImpactDecisionContract';

afterEach(cleanup);
const handler = (el: HTMLElement) => (el as any)[Object.keys(el).find(k => k.startsWith('__reactProps$'))!].onClick as () => void;
const clickRead = () => fireEvent.click(screen.getByRole('button', {name:'读取已保存的保留 / 重建决定'}));

it('case2 fences duplicate/UNKNOWN callbacks, recovers exact history without another Save and hides denied or late private history', async () => {
  const source = {kind:'CHAPTER' as const,id:'independent-source',label:'Synthetic original source',binding:{version:4,digest:'a'.repeat(64)}};
  const nodes = ['A','B','C'].map((label,index) => ({key:`PLANNING_NODE:${label}`,kind:'PLANNING_NODE',id:label,label:`Target ${label}`,
    version:index+2,status:'DRAFT',stale:true,locked:index===1,lock_version:index===1?1:0,refresh_candidate:false,
    refresh_reason:'ORIGINAL_DOMAIN_MANUAL_REVIEW_REQUIRED',evidence:[]}));
  const view: ImpactView = {source,items:nodes,coverage:'EXACT_RECORDED_DEPENDENCIES_ONLY',inferred:[],unrecorded_dependencies:'UNKNOWN',automatic_regeneration:false};
  const originalView = JSON.stringify(view);
  let committed:any, preview:any, getMode='wrong';
  let finishLate!:(value:unknown)=>void;
  const post = vi.fn(async (path:string,body:any) => {
    if(path==='/change-impact/decisions/preview') {
      preview={source_snapshot:source,preview_digest:'b'.repeat(64),decision_only:true,automatic_execution:false,
        items:body.selected.map((item:any)=>({...nodes.find(node=>node.key===item.key),choice:item.choice}))};
      return preview;
    }
    if(path!=='/change-impact/decisions') throw new Error('Unexpected execution/preflight/lock endpoint');
    if(!committed) committed={id:'one-private-checkpoint',version:1,request_id:body.request_id,source_snapshot:source,
      preview_digest:body.preview_digest,current:true,decision_only:true,automatic_execution:false,
      items:body.selected.map((item:any)=>({...item,version:item.expected_version,current_version:item.expected_version,current:true,
        kind:'PLANNING_NODE',label:nodes.find(node=>node.key===item.key)!.label}))};
    throw new Error('transport lost after one committed checkpoint');
  });
  const get = vi.fn(async () => {
    if(getMode==='denied') throw new ApiError({status:403,code:'FORBIDDEN',message:'Independent permission revoked'});
    if(getMode==='late') return new Promise(resolve=>{finishLate=resolve;});
    return {items:[getMode==='wrong'?{...committed,id:'different-private-checkpoint',request_id:'other-explicit-request'}:committed]};
  });
  const client={post,get} as unknown as ExperimentalClient, api=changeImpactClient(client);
  const mounted=render(<ImpactDecisionPanel api={api} view={view} disabled={false}/>);
  for(const [label,choice] of [['A','KEEP'],['B','REBUILD']]) fireEvent.change(screen.getByRole('combobox',{name:new RegExp(`^决定 Target ${label}`)}),{target:{value:choice}});
  expect((screen.getByRole('combobox',{name:/^决定 Target C/}) as HTMLSelectElement).value).toBe('');
  fireEvent.click(screen.getByRole('button',{name:'预览 2 项保留 / 重建决定'}));
  await screen.findByRole('region',{name:'保留与重建决定预览'});
  fireEvent.click(screen.getByRole('checkbox',{name:'确认只保存以上决定，保留原成果且不启动任务'}));
  const oldSave=handler(screen.getByRole('button',{name:'保存保留 / 重建决定'}));
  act(()=>{oldSave();oldSave();});
  const oldRetry=handler(await screen.findByRole('button',{name:'使用同一请求核对保存'}));
  expect(post.mock.calls.filter(([path])=>path==='/change-impact/decisions')).toHaveLength(1);
  expect(screen.getByRole('combobox',{name:/^决定 Target A/}).hasAttribute('disabled')).toBe(true);
  mounted.rerender(<ImpactDecisionPanel api={api} view={view} disabled/>);
  mounted.rerender(<ImpactDecisionPanel api={api} view={view} disabled={false}/>);
  act(oldRetry); expect(post).toHaveBeenCalledTimes(2);
  clickRead(); await screen.findByText(/different-private-checkpoint/);
  expect(screen.queryByRole('button',{name:'使用同一请求核对保存'})).not.toBeNull();
  expect(post).toHaveBeenCalledTimes(2); // another valid record cannot clear UNKNOWN
  getMode='recover'; clickRead();
  await screen.findByText('已从原保存记录核对此请求，未重复新增决定。');
  expect(post).toHaveBeenCalledTimes(2);
  act(()=>{oldRetry();oldSave();}); expect(post).toHaveBeenCalledTimes(2);
  const body:any=post.mock.calls.find(([path])=>path==='/change-impact/decisions')![1];
  expect(body.selected.map((item:any)=>[item.key,item.choice])).toEqual([['PLANNING_NODE:A','KEEP'],['PLANNING_NODE:B','REBUILD']]);
  expect(()=>checkedDecisionSave({...committed,automatic_execution:true},source,preview,committed.request_id)).toThrow();
  getMode='denied'; clickRead();
  await screen.findByText('当前决定内容不可用，请重新读取有权限的影响范围。');
  expect(screen.queryByRole('region',{name:'已保存的保留与重建决定'})).toBeNull();
  expect(screen.queryByText(/one-private-checkpoint/)).toBeNull();
  act(oldRetry); expect(post).toHaveBeenCalledTimes(2);

  const refreshed=structuredClone(view);
  mounted.rerender(<ImpactDecisionPanel api={api} view={refreshed} disabled={false}/>);
  getMode='late'; clickRead();
  const next=changeImpactClient({get:vi.fn(async()=>({items:[]})),post:vi.fn()} as unknown as ExperimentalClient);
  mounted.rerender(<ImpactDecisionPanel api={next} view={{...structuredClone(view),source:{...source,id:'other-source'}}} disabled={false}/>);
  await act(async()=>finishLate({items:[committed]}));
  expect(screen.queryByRole('region',{name:'已保存的保留与重建决定'})).toBeNull();
  act(()=>{oldSave();oldRetry();}); expect(post).toHaveBeenCalledTimes(2);
  expect(JSON.stringify(view)).toBe(originalView);
  writeFileSync(new URL('./case2-UNKNOWN.json',import.meta.url),JSON.stringify({pass:true,save_POST_count:1,
    duplicate_same_frame_and_stale_callbacks_fenced:true,wrong_history_does_not_clear_UNKNOWN:true,
    exact_history_recovery_additional_Save_POSTs:0,denied_and_prior_client_private_history_hidden:true,
    unselected_C_unchanged:true,execution_or_lock_endpoints_called:false,kind:'controlled transport UI test, not E2E'},null,2)+'\n');
});
