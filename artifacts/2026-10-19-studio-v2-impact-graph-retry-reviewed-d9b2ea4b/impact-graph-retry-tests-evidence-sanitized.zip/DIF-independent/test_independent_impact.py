"""Two independent original-File-owner cases; no browser/model execution."""
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
import json
import os
from pathlib import Path
from threading import Barrier

import pytest

from test_r3_media_support import rig
from test_r4_change_impact import impact, FLAGS
from app.experimental.change_impact import ChangeImpactService, node_key
from app.experimental.common import StaleSourceError
from app.experimental.store import ExperimentalStore
from app.services.v1_capability_service import CapabilityVersionConflict
import app.experimental.change_impact as loaded_owner

SOURCE = Path(r'<workspace>\studio-v2-impact-decisions')
assert Path(loaded_owner.__file__).resolve() == SOURCE / 'app/experimental/change_impact.py'


def receipt(name, data):
    (Path(os.environ['IMPACT_REVIEW_EVIDENCE']) / name).write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')


def setup(r, s):
    graphs = [s.planning.create_graph(r.nid, r.scope, r.actor,
        {'title': title, 'links': {'chapter_ids': [r.chapter['id']]}})
        for title in ['independent keep', 'independent rebuild', 'same-source unselected']]
    other = r.chapters.create(r.nid, {'title': 'Unrelated source', 'content': 'Unselected text remains unchanged.'})
    unrelated = s.planning.create_graph(r.nid, r.scope, r.actor,
        {'title': 'out-of-impact target', 'links': {'chapter_ids': [other['id']]}})
    r.chapters.save(r.chapter['id'], {'content': 'Independent source revision two.'})
    source = {'kind': 'CHAPTER', 'id': r.chapter['id']}
    return source, graphs, other, unrelated


def selection(r, s, source, graphs):
    view = s.impact(r.nid, r.scope, {'source': source})
    nodes = {n['key']: n for n in view['items']}
    return {'source': source, 'selected': [
        {'key': node_key('PLANNING_NODE', graph['root_node_id']),
         'expected_version': nodes[node_key('PLANNING_NODE', graph['root_node_id'])]['version'], 'choice': choice}
        for graph, choice in zip(graphs[:2], ['KEEP', 'REBUILD'])]}


def pending(r, s, body, request):
    preview = s.preview_decisions(r.nid, r.scope, r.actor, body)
    return {**body, 'preview_digest': preview['preview_digest'], 'request_id': request}


def test_1_current_impact_version_lock_actor_and_late_permission_are_bound(rig, impact, monkeypatch):
    r, s = rig, impact
    source, graphs, other, unrelated = setup(r, s)
    rejected = []
    body = selection(r, s, source, graphs)
    outside = deepcopy(body); outside['selected'][0]['key'] = node_key('PLANNING_NODE', unrelated['root_node_id'])
    with pytest.raises(FileNotFoundError): s.preview_decisions(r.nid, r.scope, r.actor, outside)
    rejected.append('real target outside this source impact')

    request = pending(r, s, body, 'target-version-changed')
    s.planning.edit_node(r.nid, r.scope, r.actor, graphs[1]['root_node_id'],
        {'expected_version': body['selected'][1]['expected_version'], 'title': 'changed by original owner',
         'links': {'chapter_ids': [r.chapter['id']]}})
    before = deepcopy(r.store.read(r.nid, r.scope))
    with pytest.raises(CapabilityVersionConflict): s.save_decisions(r.nid, r.scope, r.actor, request)
    assert r.store.read(r.nid, r.scope) == before
    rejected.append('original node version change')

    body = selection(r, s, source, graphs); request = pending(r, s, body, 'lock-changed')
    s.set_lock(r.nid, r.scope, r.actor, {**{k: body['selected'][0][k] for k in ['key', 'expected_version']},
        'expected_lock_version': 0, 'locked': True})
    before = deepcopy(r.store.read(r.nid, r.scope))
    with pytest.raises(StaleSourceError): s.save_decisions(r.nid, r.scope, r.actor, request)
    assert r.store.read(r.nid, r.scope) == before
    rejected.append('original lock version change')

    request = pending(r, s, body, 'source-changed')
    r.chapters.save(r.chapter['id'], {'content': 'Source changed after independent preview.'})
    before = deepcopy(r.store.read(r.nid, r.scope))
    with pytest.raises(StaleSourceError): s.save_decisions(r.nid, r.scope, r.actor, request)
    assert r.store.read(r.nid, r.scope) == before
    rejected.append('source snapshot change')

    request = pending(r, s, body, 'actor-bound')
    with pytest.raises(StaleSourceError): s.save_decisions(r.nid, r.scope, 'foreign-author', request)
    assert r.store.read(r.nid, r.scope) == before
    rejected.append('preview used by different author')

    allowed = True
    normal_view = s._decision_view
    def revoke_after_record_prepared(*args):
        nonlocal allowed
        result = normal_view(*args); allowed = False
        return result
    def guard():
        if not allowed: raise PermissionError('independent last-mile revocation')
    with monkeypatch.context() as patch:
        patch.setattr(s, '_decision_view', revoke_after_record_prepared)
        with pytest.raises(PermissionError): s.save_decisions(r.nid, r.scope, r.actor, request, guard)
    assert r.store.read(r.nid, r.scope) == before
    assert not s.list(r.nid, r.scope, s.DECISIONS)
    rejected.append('guard revoked after row preparation before commit')
    receipt('case1-current-authority.json', {'pass': True, 'rejected': rejected,
        'decision_records_created': 0, 'rejected_saves_leave_entire_scope_unchanged': True,
        'fixture': 'original File owners; controlled authority callback, not live collaborator browser'})


def test_3_concurrent_replay_is_one_intent_and_never_rebuild_authority(rig, impact, monkeypatch):
    r, s = rig, impact
    source, graphs, other, unrelated = setup(r, s)
    body = selection(r, s, source, graphs)
    s.set_lock(r.nid, r.scope, r.actor, {**{k: body['selected'][1][k] for k in ['key', 'expected_version']},
        'expected_lock_version': 0, 'locked': True})
    body = selection(r, s, source, graphs)
    manual = s.preflight(r.nid, r.scope, r.actor,
        {'source': source, 'selected': [{k: body['selected'][1][k] for k in ['key', 'expected_version']}]})
    assert not manual['ready']
    before = deepcopy(r.store.read(r.nid, r.scope)); chapter_before = deepcopy(r.chapters.get(r.chapter['id']))
    def no_execution(*args, **kwargs): raise AssertionError('intent attempted task/provider execution')
    for target, name in [(s, '_prepare_brief'), (s.media, 'queue'), (s.media, 'execute'), (s.media, 'prepare_task')]:
        monkeypatch.setattr(target, name, no_execution)
    request = pending(r, s, body, 'concurrent-lost-response')
    assert r.store.read(r.nid, r.scope) == before
    barrier = Barrier(2)
    def same_request():
        barrier.wait(timeout=10)
        return s.save_decisions(r.nid, r.scope, r.actor, deepcopy(request))
    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(lambda _: same_request(), range(2)))
    assert results[0] == results[1]
    saved = results[0]
    assert saved['version'] == 1 and saved['decision_only'] is True and saved['automatic_execution'] is False
    after = deepcopy(r.store.read(r.nid, r.scope)); decisions = after['collections'].pop(s.DECISIONS)
    assert len(decisions) == 1 and after == before
    assert r.chapters.get(r.chapter['id']) == chapter_before
    assert {item['key'] for item in saved['items']} == {item['key'] for item in body['selected']}

    corrupt = deepcopy(request); corrupt['selected'][0]['choice'] = 'REBUILD'
    with pytest.raises(ValueError, match='REQUEST_REUSED'): s.save_decisions(r.nid, r.scope, r.actor, corrupt)
    control = {'expected_version': 1, 'preflight_digest': saved['preview_digest'], 'idempotency_key': 'intent-is-not-authority'}
    with pytest.raises(FileNotFoundError): s.prepare(r.nid, r.scope, r.actor, saved['id'], control)
    with pytest.raises(StaleSourceError): s.prepare(r.nid, r.scope, r.actor, manual['id'], control)
    with pytest.raises(ValueError): s.prepare(r.nid, r.scope, r.actor, manual['id'],
        {**control, 'preflight_digest': manual['preflight_digest']})
    after_attacks = deepcopy(r.store.read(r.nid, r.scope)); after_attacks['collections'].pop(s.DECISIONS)
    assert after_attacks == before

    fresh = ChangeImpactService(ExperimentalStore(r.root, r.backend, r.store.database_url), r.novels, r.chapters,
        s.graph, s.production, s.planning, s.audiobook, enabled=s.enabled)
    assert fresh.decisions(r.nid, r.scope, r.actor, {'source': source}) == {'items': [saved]}
    immutable = deepcopy(s.list(r.nid, r.scope, s.DECISIONS))
    r.chapters.save(r.chapter['id'], {'content': 'Later revision makes intent historical, not executable.'})
    replay = s.save_decisions(r.nid, r.scope, r.actor, request)
    assert replay['id'] == saved['id'] and not replay['current'] and replay['version'] == 1
    assert s.list(r.nid, r.scope, s.DECISIONS) == immutable
    assert s.decisions(r.nid, r.scope, 'foreign-author', {'source': source}) == {'items': []}
    assert s.decisions(r.nid, r.scope, r.actor, {'source': {'kind': 'CHAPTER', 'id': other['id']}}) == {'items': []}
    with monkeypatch.context() as patch:
        patch.setattr(s, 'enabled', lambda name: name in FLAGS - {'advanced_planning_v2'})
        assert s.decisions(r.nid, r.scope, r.actor, {'source': source}) == {'items': []}
    receipt('case3-intent-only.json', {'pass': True, 'concurrent_identical_requests': 2, 'immutable_records': 1,
        'conflicting_reuse_rejected': True, 'checkpoint_not_preflight_or_prepare_authority': True,
        'proper_locked_manual_preflight_still_blocked': True, 'all_original_scope_collections_unchanged_except_decisions': True,
        'unselected_same_source_and_unrelated_targets_unchanged': True, 'fresh_File_owner_reopened_exact_record': True,
        'later_source_change_only_marks_read_projection_historical': True, 'foreign_author_source_and_hidden_targets_not_enumerated': True})
