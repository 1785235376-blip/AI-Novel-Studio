import { defineConfig } from '@playwright/test';
import { readFileSync } from 'node:fs';
import path from 'node:path';
import base from '../playwright.visual.config';
const evidence=process.env.HOST_NLE_COMBINED_EVIDENCE_DIR;
if(!evidence)throw new Error('Task-private evidence required');
const ports=JSON.parse(readFileSync(path.join(evidence,'runtime-ports.json'),'utf8'));
export default defineConfig({...base,testDir:'.',testMatch:'nle-combined-smoke.spec.ts',outputDir:'../test-results/nle-combined-smoke',timeout:90_000,reporter:'list',webServer:undefined,
 use:{...base.use,baseURL:`http://127.0.0.1:${ports.frontend}`,viewport:{width:1366,height:768},trace:'off',launchOptions:{args:['--disable-gpu']}}});
