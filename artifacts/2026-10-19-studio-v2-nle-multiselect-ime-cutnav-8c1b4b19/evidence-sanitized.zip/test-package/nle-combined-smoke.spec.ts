import {expect,test} from '@playwright/test';
import {readFileSync,writeFileSync} from 'node:fs';
import path from 'node:path';
const evidence=process.env.HOST_NLE_COMBINED_EVIDENCE_DIR!;
const runtime=JSON.parse(readFileSync(path.join(evidence,'runtime-ports.json'),'utf8'));
const seed=JSON.parse(readFileSync(path.join(evidence,'seed-result.json'),'utf8'));
const privateHost=JSON.parse(readFileSync(path.join(runtime.profile,'host.private.json'),'utf8'));
test('combined original selection -> current-boundary navigation -> one CAS save and same File document reopen',async({page,browser},info)=>{
 const calls:any[]=[],pending:Promise<void>[]=[],errors:string[]=[];let phase='OPEN',saved:any;
 const endpoint=`/api/projects/${seed.project.id}/studio/production/timelines/${seed.timeline.id}`;
 page.on('pageerror',error=>errors.push(error.message));page.on('response',response=>{
  const pathname=new URL(response.url()).pathname;if(!pathname.startsWith('/api/'))return;
  pending.push((async()=>{let body,request;if(pathname.includes('/production/timelines'))try{body=await response.json();}catch{body={non_json:true};}
   try{request=response.request().postDataJSON();}catch{}calls.push({method:response.request().method(),path:pathname,status:response.status(),request,response:body});})());
 });
 const editor=page.locator('[aria-label="Studio 多轨时间线编辑器"]'),ruler=editor.locator('[aria-label="时间线标尺"]'),tracks=editor.locator('[aria-label="轨道头"]');
 const verifyHost=async()=>{
  await page.getByRole('tab',{name:'小说',exact:true}).click();await page.getByRole('button',{name:'打开功能导航',exact:true}).click();
  const group=page.getByRole('button',{name:/^协作(?:\s*当前)?$/});if(await group.getAttribute('aria-expanded')!=='true')await group.click();
  await page.getByRole('button',{name:'Agent 团队',exact:true}).click();await page.getByRole('button',{name:'关闭功能导航',exact:true}).click();
  await page.getByLabel('本机访问凭证',{exact:true}).fill(privateHost.token);const response=page.waitForResponse(r=>new URL(r.url()).pathname==='/api/local-session');
  await page.getByRole('button',{name:'验证并绑定本机会话',exact:true}).click();expect((await response).status()).toBe(200);
  await expect(page.getByText('已验证本机身份：synthetic-host-nle-combined-host',{exact:true})).toBeVisible();await page.getByRole('tab',{name:'图片',exact:true}).click();
 };
 const open=async(version:number)=>{
  await page.getByRole('button',{name:'制作操作',exact:true}).click();await page.getByRole('button',{name:'读取当前素材版本',exact:true}).click();await expect(editor).toBeVisible();
  await editor.getByRole('button',{name:'刷新时间线列表',exact:true}).click();const select=editor.getByLabel('读取已保存时间线');
  await expect(select.locator(`option[value="${seed.timeline.id}"]`)).toHaveText(seed.timeline.title+` · v${version}`);await select.selectOption(seed.timeline.id);
  const review=editor.locator('[aria-label="核对服务端时间线"]');await expect(review.getByRole('heading',{name:seed.timeline.title+` · v${version}`,exact:true})).toBeVisible();
  await review.getByLabel('已核对服务端内容与本地输入，确认以下选择',{exact:true}).check();await review.getByRole('button',{name:'采用服务端时间线',exact:true}).click();
 };
 const selected=()=>tracks.locator('button[aria-pressed="true"]').allTextContents();
 const positions=async(values:number[])=>{
  for(const [i,[track,clip]] of [[1,1],[1,2],[2,1],[2,2]].entries())await expect(editor.getByRole('region',{name:`轨道 ${track} 片段 ${clip}`,exact:true}).getByLabel('放入时间线（毫秒）',{exact:true})).toHaveValue(String(values[i]));
 };
 try{
  await page.goto('/',{waitUntil:'networkidle'});await verifyHost();await open(1);
  phase='SELECT_NAVIGATE_AND_HISTORY';await ruler.focus();await ruler.press('ArrowDown');await expect(ruler).toHaveAttribute('data-playhead-ms','1000');
  await tracks.getByRole('button',{name:'v2-b',exact:true}).click();await tracks.getByRole('button',{name:'v1-a',exact:true}).click({modifiers:['Control']});expect(await selected()).toEqual(['v1-a','v2-b']);
  await editor.getByLabel('整体移动增量（毫秒，可为负）',{exact:true}).fill('500');await editor.getByRole('button',{name:'整体移动所选片段',exact:true}).click();await positions([1500,4000,2000,7000]);
  await editor.getByRole('button',{name:'撤销本地编辑',exact:true}).click();await positions([1000,4000,2000,6500]);await expect(editor.getByRole('button',{name:'撤销本地编辑',exact:true})).toBeDisabled();
  await editor.getByRole('button',{name:'重做本地编辑',exact:true}).click();await positions([1500,4000,2000,7000]);
  await ruler.focus();await ruler.press('ArrowDown');await expect(ruler).toHaveAttribute('data-playhead-ms','1500');
  await Promise.all(pending);expect(calls.filter(c=>c.method!=='GET')).toEqual([]);
  phase='SAVE_SENT';const response=page.waitForResponse(r=>new URL(r.url()).pathname===endpoint&&r.request().method()==='PUT');await editor.getByRole('button',{name:'保存时间线',exact:true}).click();const receipt=await response;expect(receipt.status()).toBe(200);saved=await receipt.json();phase='SAVE_ACKNOWLEDGED';
  const expected=structuredClone(seed.timeline.timeline);for(const track of expected.tracks)for(const clip of track.clips)if(seed.selected_ids.includes(clip.id))clip.start_ms+=500;
  expect(receipt.request().postDataJSON()).toEqual({expected_version:1,title:seed.timeline.title,timeline:expected});expect(saved.id).toBe(seed.timeline.id);expect(saved.version).toBe(2);expect(saved.timeline).toEqual(expected);
  phase='REFRESH_SAME_ID_REOPEN';await page.reload({waitUntil:'networkidle'});await verifyHost();await open(2);await positions([1500,4000,2000,7000]);expect(await selected()).toEqual([]);
  await ruler.focus();await ruler.press('ArrowDown');await expect(ruler).toHaveAttribute('data-playhead-ms','1500');await ruler.press('ArrowDown');await expect(ruler).toHaveAttribute('data-playhead-ms','2000');
  await expect(editor.getByRole('button',{name:'撤销本地编辑',exact:true})).toBeDisabled();await expect(editor.getByRole('button',{name:'保存时间线',exact:true})).toBeDisabled();
  await page.evaluate(()=>document.fonts.ready);await ruler.scrollIntoViewIfNeeded();await page.screenshot({path:info.outputPath('combined-same-file-reopened.png')});
  await Promise.all(pending);expect(errors).toEqual([]);expect(calls.filter(c=>c.method!=='GET').map(c=>[c.method,c.path,c.status])).toEqual([['PUT',endpoint,200]]);
  const stored=await page.evaluate(()=>[...Object.values(localStorage),...Object.values(sessionStorage)]);expect(stored.some(value=>value.includes(privateHost.token))).toBe(false);
  phase='PASS';writeFileSync(path.join(evidence,'live-result.json'),JSON.stringify({status:'PASS',proof:'REAL_ORIGINAL_APP_HTTP_FILE_NO_API_INTERCEPTION',browser_version:browser.version(),before:seed.timeline,after:saved,calls,errors,selection_and_navigation_combined:true,original_atomic_undo_redo:true,one_expected1_CAS_to2:true,refresh_same_id_reopen:true,unselected_caption_canvas_sources_preserved:true,model_gpu_paid_api_render_called:false,credential_persisted:false},null,2));
 }catch(error){if(!page.isClosed()){await page.screenshot({path:info.outputPath('failure-real-ui.png')});writeFileSync(path.join(evidence,'failure-dom.txt'),await page.locator('body').innerText());}throw error;}
 finally{await Promise.allSettled(pending);writeFileSync(path.join(evidence,'live-attempt.json'),JSON.stringify({phase,saved,calls,errors},null,2));}
});
