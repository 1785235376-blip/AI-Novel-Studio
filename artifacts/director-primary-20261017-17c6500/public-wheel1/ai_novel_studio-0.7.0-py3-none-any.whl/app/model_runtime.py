"""Provider-neutral model runtime foundation for built-in model nodes."""

from __future__ import annotations

import time
from threading import Event
from dataclasses import dataclass, field, replace as dc_replace
from enum import Enum
from typing import Any, Callable, Iterable, Mapping, Protocol, TYPE_CHECKING
from uuid import UUID

from .providers import Generation, LLMProvider, ProviderError
from .stable_identity import IdentityMutationError, StableIdentityStore, canonical_model_identity_key, validate_uuid

if TYPE_CHECKING:
    from .audio_processing_runtime import AudioProcessingProvider


class Modality(str, Enum):
    TEXT = "TEXT"
    EMBEDDING = "EMBEDDING"
    IMAGE = "IMAGE"
    VISION = "VISION"
    VIDEO = "VIDEO"
    AUDIO = "AUDIO"


class RuntimeErrorCode(str, Enum):
    PROVIDER_NOT_FOUND = "PROVIDER_NOT_FOUND"
    MODEL_NOT_FOUND = "MODEL_NOT_FOUND"
    MODEL_DISABLED = "MODEL_DISABLED"
    CAPABILITY_NOT_SUPPORTED = "CAPABILITY_NOT_SUPPORTED"
    INVALID_CONFIGURATION = "INVALID_CONFIGURATION"
    INVALID_REQUEST = "INVALID_REQUEST"
    PROVIDER_UNAVAILABLE = "PROVIDER_UNAVAILABLE"
    AUTHENTICATION_FAILED = "AUTHENTICATION_FAILED"
    RATE_LIMITED = "RATE_LIMITED"
    TIMEOUT = "TIMEOUT"
    TEXT_PROVIDER_NOT_CONFIGURED = "TEXT_PROVIDER_NOT_CONFIGURED"
    GENERATION_FAILED = "GENERATION_FAILED"
    CANCELLED = "CANCELLED"


class ModelRuntimeError(RuntimeError):
    def __init__(self, code: RuntimeErrorCode, message: str, *, retryable: bool = False,
                 provider_id: str | None = None, model_id: str | None = None,
                 metadata: Mapping[str, Any] | None = None):
        super().__init__(message)
        self.code = code
        self.safe_message = message
        self.retryable = retryable
        self.provider_id = provider_id
        self.model_id = model_id
        self.metadata = dict(metadata or {})


@dataclass(frozen=True, slots=True)
class TextGenerationParameters:
    temperature: float | None = None
    max_output_tokens: int | None = None
    stop_sequences: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if self.temperature is not None and not 0 <= self.temperature <= 2:
            raise ModelRuntimeError(RuntimeErrorCode.INVALID_REQUEST, "temperature must be between 0 and 2")
        if self.max_output_tokens is not None and self.max_output_tokens <= 0:
            raise ModelRuntimeError(RuntimeErrorCode.INVALID_REQUEST, "max_output_tokens must be positive")


@dataclass(frozen=True, slots=True)
class TextGenerationRequest:
    provider_id: str
    model_id: str
    prompt: str
    system_instruction: str | None = None
    context: Mapping[str, Any] = field(default_factory=dict)
    parameters: TextGenerationParameters = field(default_factory=TextGenerationParameters)
    structured_output_schema: Mapping[str, Any] | None = None
    metadata: Mapping[str, str] = field(default_factory=dict)
    job_id: str | None = None
    cancellation: Event | None = field(default=None, repr=False, compare=False)
    dispatch_guard: Callable[[], None] | None = field(default=None, repr=False, compare=False)
    preparation_guard: Callable[[], None] | None = field(default=None, repr=False, compare=False)

    def __post_init__(self) -> None:
        if not self.provider_id or not self.model_id or not self.prompt.strip():
            raise ModelRuntimeError(RuntimeErrorCode.INVALID_REQUEST, "provider, model and prompt are required")


@dataclass(frozen=True, slots=True)
class GenerationUsage:
    input_tokens: int | None = None
    output_tokens: int | None = None
    total_tokens: int | None = None


@dataclass(frozen=True, slots=True)
class TextGenerationResponse:
    text: str
    finish_reason: str
    provider_id: str
    model_id: str
    usage: GenerationUsage | None = None
    latency_ms: int = 0
    provider_reference_id: str | None = None
    structured_output: Mapping[str, Any] | None = None
    execution_mode: str = "real"


@dataclass(frozen=True, slots=True)
class GenerationEvent:
    event_type: str
    job_id: str | None
    delta: str = ""
    response: TextGenerationResponse | None = None
    error_code: RuntimeErrorCode | None = None


@dataclass(frozen=True, slots=True)
class ProviderDescriptor:
    provider_id: str
    display_name: str
    provider_type: str
    supported_modalities: frozenset[Modality]
    configured: bool
    available: bool
    health_status: str = "available"
    identity_id: UUID | None = None

    @property
    def provider_uuid(self) -> UUID | None:
        return self.identity_id


@dataclass(frozen=True, slots=True)
class ModelDescriptor:
    model_id: str
    provider_id: str
    display_name: str
    modality: Modality
    capabilities: frozenset[str]
    context_window: int | None = None
    structured_output: bool = False
    streaming: bool = False
    enabled: bool = True
    identity_id: UUID | None = None

    @property
    def model_uuid(self) -> UUID | None:
        return self.identity_id


class TextProvider(Protocol):
    provider_id: str
    def generate_text(self, request: TextGenerationRequest) -> TextGenerationResponse: ...
    def stream_text(self, request: TextGenerationRequest) -> Iterable[GenerationEvent]: ...


class LegacyTextProviderAdapter:
    """Moves existing providers onto the normalized contract without vendor leakage."""

    def __init__(self, provider_id: str, provider: LLMProvider):
        self.provider_id = provider_id
        self.provider = provider

    @staticmethod
    def _kwargs(request: TextGenerationRequest) -> dict[str, Any]:
        values: dict[str, Any] = {}
        if request.parameters.temperature is not None:
            values["temperature"] = request.parameters.temperature
        if request.parameters.max_output_tokens is not None:
            values["max_tokens"] = request.parameters.max_output_tokens
        if request.parameters.stop_sequences:
            values["stop"] = list(request.parameters.stop_sequences)
        return values

    def _response(self, request: TextGenerationRequest, value: Generation) -> TextGenerationResponse:
        return TextGenerationResponse(
            text=value.text,
            finish_reason="completed",
            provider_id=self.provider_id,
            model_id=request.model_id,
            usage=(None if value.metadata.get("usage_known") is False else GenerationUsage(value.input_tokens, value.output_tokens, value.input_tokens + value.output_tokens)),
            latency_ms=value.latency_ms,
            provider_reference_id=str(value.metadata.get("request_id")) if value.metadata.get("request_id") else None,
            execution_mode="mock_standin" if value.metadata.get("mock") else "real",
        )

    def generate_text(self, request: TextGenerationRequest) -> TextGenerationResponse:
        try:
            kwargs=self._kwargs(request)
            if getattr(self.provider,"supports_dispatch_guard",False):
                kwargs.update(dispatch_guard=request.dispatch_guard,cancellation=request.cancellation)
            return self._response(request, self.provider.generate(request.prompt, request.model_id, **kwargs))
        except ProviderError as exc:
            raise ModelRuntimeError(RuntimeErrorCode.PROVIDER_UNAVAILABLE, "模型服务暂时不可用", retryable=True) from exc

    def stream_text(self, request: TextGenerationRequest) -> Iterable[GenerationEvent]:
        started = time.monotonic()
        yield GenerationEvent("generation.started", request.job_id)
        chunks: list[str] = []
        reported_usage: dict[str, Any] = {}
        kwargs=self._kwargs(request)
        if getattr(self.provider,"supports_dispatch_guard",False):
            kwargs.update(dispatch_guard=request.dispatch_guard,cancellation=request.cancellation)
        if getattr(self.provider,"supports_stream_usage",False):
            kwargs["usage_callback"]=reported_usage.update
        try:
            for chunk in self.provider.stream(request.prompt, request.model_id, **kwargs):
                if request.cancellation is not None and request.cancellation.is_set():
                    raise ModelRuntimeError(RuntimeErrorCode.CANCELLED, "已停止生成")
                chunks.append(chunk)
                yield GenerationEvent("generation.delta", request.job_id, delta=chunk)
            text = "".join(chunks)
            response = TextGenerationResponse(
                text=text,
                finish_reason="completed",
                provider_id=self.provider_id,
                model_id=request.model_id,
                usage=(GenerationUsage(reported_usage.get("input_tokens"),reported_usage.get("output_tokens"),sum(reported_usage.values()) if all(isinstance(value,int) for value in reported_usage.values()) else None) if any(value is not None for value in reported_usage.values()) else None),
                execution_mode="mock_standin" if getattr(self.provider,"name",None)=="mock" else "real",
                latency_ms=int((time.monotonic() - started) * 1000),
            )
            yield GenerationEvent("generation.completed", request.job_id, response=response)
        except ProviderError as exc:
            raise ModelRuntimeError(RuntimeErrorCode.PROVIDER_UNAVAILABLE, "模型服务暂时不可用", retryable=True) from exc


class ProviderRegistry:
    def __init__(self, identity_store: StableIdentityStore | None = None) -> None:
        self._providers: dict[str, TextProvider | AudioProcessingProvider] = {}
        self._descriptors: dict[str, ProviderDescriptor] = {}
        self.identity_store = identity_store

    def register(self, descriptor: ProviderDescriptor, provider: TextProvider | AudioProcessingProvider, *, replace: bool = False) -> None:
        if descriptor.provider_id in self._providers and not replace:
            raise ValueError(f"provider already registered: {descriptor.provider_id}")
        if self.identity_store is not None:
            previous = self.identity_store.get("provider", descriptor.provider_id)
            supplied = validate_uuid(descriptor.identity_id, field="provider_id") if descriptor.identity_id is not None else None
            canonical = self.identity_store.get_or_create("provider", descriptor.provider_id)
            if supplied is not None and previous is not None and supplied != previous:
                raise IdentityMutationError("provider_ID_IMMUTABLE")
            descriptor = dc_replace(descriptor, identity_id=canonical)
        self._providers[descriptor.provider_id] = provider
        self._descriptors[descriptor.provider_id] = descriptor

    def resolve(self, provider_id: str) -> TextProvider | AudioProcessingProvider:
        try:
            descriptor, provider = self._descriptors[provider_id], self._providers[provider_id]
        except KeyError as exc:
            raise ModelRuntimeError(RuntimeErrorCode.PROVIDER_NOT_FOUND, "未找到指定的模型服务") from exc
        if not descriptor.configured or not descriptor.available:
            raise ModelRuntimeError(RuntimeErrorCode.PROVIDER_UNAVAILABLE, "模型服务当前不可用", retryable=True)
        return provider

    def descriptors(self) -> tuple[ProviderDescriptor, ...]:
        return tuple(self._descriptors[key] for key in sorted(self._descriptors))

    def is_configured(self, provider_id: str) -> bool:
        descriptor = self._descriptors.get(provider_id)
        return bool(descriptor and descriptor.configured and descriptor.available)

    def contains(self, provider_id: str) -> bool:
        return provider_id in self._descriptors

class ModelRegistry:
    def __init__(self, identity_store: StableIdentityStore | None = None) -> None:
        self._models: dict[tuple[str, str], ModelDescriptor] = {}
        self.identity_store = identity_store

    def register(self, model: ModelDescriptor, *, replace: bool = False) -> None:
        key = (model.provider_id, model.model_id)
        if key in self._models and not replace:
            raise ValueError(f"model already registered: {key}")
        if self.identity_store is not None:
            identity_key = canonical_model_identity_key(model.provider_id, model.model_id)
            previous = self.identity_store.get("model", identity_key)
            supplied = validate_uuid(model.identity_id, field="model_id") if model.identity_id is not None else None
            canonical = self.identity_store.get_or_create("model", identity_key)
            if supplied is not None and previous is not None and supplied != previous:
                raise IdentityMutationError("model_ID_IMMUTABLE")
            model = dc_replace(model, identity_id=canonical)
        self._models[key] = model

    def resolve(self, provider_id: str, model_id: str, modality: Modality) -> ModelDescriptor:
        try:
            model = self._models[(provider_id, model_id)]
        except KeyError as exc:
            raise ModelRuntimeError(RuntimeErrorCode.MODEL_NOT_FOUND, "未找到指定模型") from exc
        if not model.enabled:
            raise ModelRuntimeError(RuntimeErrorCode.MODEL_DISABLED, "该模型当前已停用")
        if model.modality is not modality:
            raise ModelRuntimeError(RuntimeErrorCode.CAPABILITY_NOT_SUPPORTED, "该模型不支持文本生成")
        return model

    def descriptors(self) -> tuple[ModelDescriptor, ...]:
        return tuple(self._models[key] for key in sorted(self._models))

    def contains(self, provider_id: str, model_id: str) -> bool:
        return (provider_id, model_id) in self._models

@dataclass(frozen=True, slots=True)
class TextModelNodeInput:
    request: TextGenerationRequest


@dataclass(frozen=True, slots=True)
class TextModelNodeOutput:
    generated_text: str
    response: TextGenerationResponse
    job_reference: str | None


class TextModelNode:
    type_id = "builtin.text_model"
    contract_version = 1

    def __init__(self, providers: ProviderRegistry, models: ModelRegistry):
        self.providers = providers
        self.models = models

    def execute(self, value: TextModelNodeInput) -> TextModelNodeOutput:
        request = value.request
        provider = self.providers.resolve(request.provider_id)
        model = self.models.resolve(request.provider_id, request.model_id, Modality.TEXT)
        if request.structured_output_schema is not None and not model.structured_output:
            raise ModelRuntimeError(RuntimeErrorCode.CAPABILITY_NOT_SUPPORTED, "当前模型不支持结构化输出")
        if request.cancellation is not None and request.cancellation.is_set():
            raise ModelRuntimeError(RuntimeErrorCode.CANCELLED, "已停止生成")
        guard = request.preparation_guard or request.dispatch_guard
        if guard is not None:
            guard()
        if request.cancellation is not None and request.cancellation.is_set():
            raise ModelRuntimeError(RuntimeErrorCode.CANCELLED, "已停止生成")
        response = provider.generate_text(request)
        if request.cancellation is not None and request.cancellation.is_set():
            raise ModelRuntimeError(RuntimeErrorCode.CANCELLED, "已停止生成")
        if response.provider_id != request.provider_id or response.model_id != request.model_id:
            raise ModelRuntimeError(RuntimeErrorCode.GENERATION_FAILED, "模型响应与已批准路由不一致")
        return TextModelNodeOutput(response.text, response, request.job_id)

    def stream(self, value: TextModelNodeInput) -> Iterable[GenerationEvent]:
        request = value.request
        provider = self.providers.resolve(request.provider_id)
        model = self.models.resolve(request.provider_id, request.model_id, Modality.TEXT)
        if not model.streaming:
            raise ModelRuntimeError(RuntimeErrorCode.CAPABILITY_NOT_SUPPORTED, "当前模型不支持流式生成")
        terminal = False
        try:
            if request.cancellation is not None and request.cancellation.is_set():
                raise ModelRuntimeError(RuntimeErrorCode.CANCELLED, "已停止生成")
            # A guarded preparation phase may wait or inspect an existing
            # runtime. Its adapter retains the actual final-hop dispatch guard.
            # Existing requests without this opt-in retain their old boundary.
            guard = request.preparation_guard or request.dispatch_guard
            if guard is not None:
                guard()
            if request.cancellation is not None and request.cancellation.is_set():
                raise ModelRuntimeError(RuntimeErrorCode.CANCELLED, "已停止生成")
            for event in provider.stream_text(request):
                if terminal:
                    break
                if request.cancellation is not None and request.cancellation.is_set():
                    raise ModelRuntimeError(RuntimeErrorCode.CANCELLED, "已停止生成")
                if event.response and (event.response.provider_id != request.provider_id or event.response.model_id != request.model_id):
                    raise ModelRuntimeError(RuntimeErrorCode.GENERATION_FAILED, "模型响应与已批准路由不一致")
                if event.event_type in {"generation.completed", "generation.failed", "generation.cancelled"}:
                    if terminal:
                        continue
                    terminal = True
                yield event
            if not terminal:
                # An interrupted adapter is not evidence of a completed generation.
                yield GenerationEvent("generation.failed", request.job_id, error_code=RuntimeErrorCode.GENERATION_FAILED)
        except ModelRuntimeError as exc:
            event_type = "generation.cancelled" if exc.code is RuntimeErrorCode.CANCELLED else "generation.failed"
            yield GenerationEvent(event_type, request.job_id, error_code=exc.code)


class GenerationRuntime:
    def __init__(self, providers: ProviderRegistry, models: ModelRegistry):
        self.providers = providers
        self.models = models
        self.text_node = TextModelNode(providers, models)
        # AUDIO is additive and never broadens the original TEXT Router. No
        # audio route is registered or launched by constructing this node.
        from .audio_processing_runtime import AudioProcessingModelNode
        self.audio_processing_node = AudioProcessingModelNode(providers, models)
