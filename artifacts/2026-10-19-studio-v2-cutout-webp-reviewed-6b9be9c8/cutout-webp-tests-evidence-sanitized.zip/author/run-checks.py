import importlib.util
import os
from pathlib import Path
import subprocess
import sys

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
evidence = Path(__file__).resolve().parent; root = evidence.parent / 'cap'
spec = importlib.util.spec_from_file_location('owned_runner', root / 'scripts/run_v2_checks.py')
runner = importlib.util.module_from_spec(spec); spec.loader.exec_module(runner)
env = os.environ.copy()
for key in list(env):
    if key.endswith(('_API_KEY', '_TOKEN', '_SECRET')) or key in {'DATABASE_URL', 'TEST_POSTGRES_DATABASE_URL', 'COLLABORATION_DEV_SESSIONS_JSON', 'PACKAGED_CONTROL_PIPE'}: env.pop(key, None)
profile = root / '.runtime' / 'v2-checks' / 'cutout-webp'
env.update(runner.isolated_environment(root, profile))
if not (evidence / 'actual-file.json').exists(): env['CUTOUT_WEBP_EVIDENCE_DIR'] = str(evidence)
else: env.pop('CUTOUT_WEBP_EVIDENCE_DIR', None)
targets = sys.argv[1:] or ['tests/test_v2_cpu_cutout_webp.py', 'tests/test_v2_cpu_cutout_api.py::test_mounted_cutout_no_ai_flag_response_fixture_and_explicit_approval']
base = profile / 'pytest-data'; assert base.resolve().is_relative_to((root / '.runtime').resolve())
result = subprocess.run([sys.executable, '-m', 'pytest', '-q', *targets, '-m', 'not postgres_backend_only', '-k', 'not v1', '-p', 'no:cacheprovider', '--tb=short', '--basetemp', str(base)], cwd=root, env=env, capture_output=True, encoding='utf-8', errors='replace')
(evidence / ('backend-binding-final.log' if sys.argv[1:] else 'backend-checks.log')).write_text(result.stdout + result.stderr, encoding='utf-8'); print(result.stdout + result.stderr); sys.exit(result.returncode)
