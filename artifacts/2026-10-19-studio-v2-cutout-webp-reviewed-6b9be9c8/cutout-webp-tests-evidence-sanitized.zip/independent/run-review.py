from pathlib import Path
import os
import subprocess
import sys
import json

evidence = Path(__file__).resolve().parent
source = Path(r'<workspace>\cap')
env = os.environ.copy()
env.update(PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1',
    PYTHONPATH=str(source / 'tests') + os.pathsep + str(source),
    PROJECT_ROOT=str(evidence), NOVEL_DATA_PATH=str(evidence / '.runtime' / 'data'),
    LOCALAPPDATA=str(evidence / '.runtime' / 'local'), STORAGE_BACKEND='file',
    INDEPENDENT_WEBP_EVIDENCE=str(evidence))
for name in ['TEST_POSTGRES_DATABASE_URL', 'DATABASE_URL', 'E2E_DATABASE_URL', 'CUTOUT_WEBP_EVIDENCE_DIR', 'STUDIO_CAPTURE_CPU_CUTOUT']:
    env.pop(name, None)
command = [sys.executable, '-m', 'pytest', str(evidence / 'test_independent_webp.py'),
    '--rootdir=' + str(evidence), '--basetemp=' + str(evidence / '.runtime' / 'pytest'),
    '-p', 'no:cacheprovider', '-k', 'not postgres and test_3', '-vv', '--tb=short']
with (evidence / 'independent-run.log').open('wb') as log:
    result = subprocess.run(command, cwd=evidence, env=env, stdout=log, stderr=subprocess.STDOUT)
(evidence / 'run-status.json').write_text(json.dumps({'exit': result.returncode,
    'command': command, 'source_read_only': True, 'source_or_dependencies_copied': False}, indent=2) + '\n', encoding='utf-8')
print((evidence / 'independent-run.log').read_text(encoding='utf-8'))
sys.exit(result.returncode)
