"""Three independent bounded WebP review cases; imports original File owners."""
from copy import deepcopy
import hashlib
import io
import json
import os
from pathlib import Path
import struct
import zlib

import pytest
from PIL import Image

from conftest import restore_global_settings  # original autouse restoration
from test_v2_cpu_cutout_api import cpu_client, mask_client, client, mounted, checked, queue, run, action
from app.creative.production_execution import digest
from app.creative.production_execution_models import MediaCommand
from app.services.studio_image_execution import _context
from app.services.studio_image_cutout import render_cutout
from app.services.studio_image_mask_authoring import encode_mask
import app.services.studio_image_cutout_webp as webp


@pytest.fixture
def prefix():
    return '/api'  # one original route alias; no duplicate /api/v1 run


def receipt(name, value):
    (Path(os.environ['INDEPENDENT_WEBP_EVIDENCE']) / name).write_text(
        json.dumps(value, indent=2) + '\n', encoding='utf-8')


def candidate(e, job):
    response = e.client.get(e.base + '/jobs/image/' + job['id'] + '/candidate', headers=e.headers)
    assert response.status_code == 200, response.text
    assert response.headers['cache-control'] == 'no-store'
    assert response.headers['x-content-type-options'] == 'nosniff'
    assert hashlib.sha256(response.content).hexdigest() == job['output_candidate']['digest']
    return response


def approve(e, row, output_digest=None):
    return e.client.post(e.base + '/jobs/image/' + row['id'] + '/review', headers=e.headers,
        json={**action(row), 'reviewed_output_digest': output_digest or row['output_candidate']['digest']})


def test_1_closed_format_binding_actual_bytes_and_legacy_png(cpu_client):
    e = cpu_client
    legacy_command = deepcopy(e.command)
    png_preview = checked(e.client.post(e.base + '/preview', headers=e.headers, json=e.command))
    e.command['parameters'] = {'cutout_output': webp.PROFILE}
    webp_preview = checked(e.client.post(e.base + '/preview', headers=e.headers, json=e.command))
    assert webp_preview['request_digest'] != png_preview['request_digest']
    assert png_preview['command']['parameters'] == png_preview['execution_recipe']['parameters'] == {}
    assert png_preview['execution_recipe']['output_profile'] == 'PNG_RGBA8_STORED_DEFLATE'
    assert MediaCommand.model_validate(legacy_command).model_dump(exclude_none=True)['parameters'] == {}
    for invalid in [None, True, 'WEBP', 'PNG', 'WEBP_LOSSLESS_V2']:
        malformed = deepcopy(e.command); malformed['parameters']['cutout_output'] = invalid
        assert e.client.post(e.base + '/preview', headers=e.headers, json=malformed).status_code == 422
    assert webp_preview['execution_recipe']['parameters'] == webp_preview['command']['parameters'] == {'cutout_output': webp.PROFILE}
    assert webp_preview['execution_recipe']['output_profile'] == webp.OUTPUT_PROFILE
    _, queued = queue(e)
    stored = next(row for path in e.root.glob('image-jobs/actors/*/image-jobs/*.json')
        for row in json.loads(path.read_text(encoding='utf-8')) if row['id'] == queued['id'])
    rejected = []
    for mutation in ['missing_recipe', 'missing_command', 'wrong_output_profile', 'command_downgrade', 'recipe_downgrade']:
        context = deepcopy(stored['context']); body = deepcopy(stored['body'])
        if mutation.startswith('missing_'):
            context.pop('execution_recipe' if mutation == 'missing_recipe' else 'command')
        elif mutation == 'wrong_output_profile': context['execution_recipe']['output_profile'] = 'PNG_RGBA8_STORED_DEFLATE'
        elif mutation == 'command_downgrade': context['command']['parameters'] = {}
        else: context['execution_recipe']['parameters'] = {}
        # Recompute structural digests: the explicit profile/format checks must reject too.
        if 'execution_recipe' in context:
            recipe = context['execution_recipe']
            recipe['recipe_digest'] = digest({k: v for k, v in recipe.items() if k != 'recipe_digest'})
        if 'command' in context:
            context['request_digest'] = digest({'context': {k: v for k, v in context.items() if k not in {'command', 'request_digest'}}, 'command': context['command']})
        with pytest.raises(ValueError): _context(context, body, stored['owner_actor_id'])
        rejected.append(mutation)
    executed = checked(run(e, queued)); assert executed['status'] == 'AWAITING_REVIEW'
    data = candidate(e, executed)
    assert data.headers['content-type'].split(';')[0] == 'image/webp'
    assert data.content[:4] == b'RIFF' and data.content[8:16] == b'WEBPVP8L'
    assert len(data.content) == executed['processing_proof']['output_bytes']
    assert e.client.get(e.studio_base + '/assets/' + executed['output_candidate']['id'], headers=e.headers).status_code == 404
    assert approve(e, executed, 'f' * 64).status_code in {409, 422}
    assert e.client.get(e.studio_base + '/assets/' + executed['output_candidate']['id'], headers=e.headers).status_code == 404
    approved = checked(approve(e, executed)); assert approved['status'] == 'APPROVED'
    asset = checked(e.client.get(e.studio_base + '/assets/' + executed['output_candidate']['id'], headers=e.headers))
    assert asset['media_type'] == 'image/webp' and asset['filename'].endswith('.webp')
    assert asset['provenance']['origin'] == 'DERIVED_PROCESSING'
    assert asset['id'] not in {e.source['id'], e.mask['id']}
    assert e.client.get(e.studio_base + '/assets/' + asset['id'] + '/download', headers=e.headers).content == data.content

    # Original omitted-parameter request still uses the exact original PNG renderer.
    e.command = legacy_command; e.command['request_id'] = 'independent-legacy-png'
    _, legacy = queue(e); legacy = checked(run(e, legacy)); old = candidate(e, legacy)
    assert old.headers['content-type'].split(';')[0] == 'image/png'
    source = e.client.get(e.studio_base + '/assets/' + e.source['id'] + '/download', headers=e.headers).content
    mask = e.client.get(e.studio_base + '/assets/' + e.mask['id'] + '/download', headers=e.headers).content
    reference, _ = render_cutout(source, mask)
    assert old.content == reference and old.content[:8] == b'\x89PNG\r\n\x1a\n'
    assert legacy['processing_proof']['contract'] == 'cpu-binary-mask-cutout/1'
    old_approved = checked(approve(e, legacy)); assert old_approved['status'] == 'APPROVED'
    old_asset = checked(e.client.get(e.studio_base + '/assets/' + legacy['output_candidate']['id'], headers=e.headers))
    assert old_asset['media_type'] == 'image/png' and old_asset['filename'].endswith('.png')
    receipt('case1-format.json', {'pass': True, 'actual_WebP_sha256': hashlib.sha256(data.content).hexdigest(),
        'actual_WebP_bytes': len(data.content), 'closed_profile_rejections': 5,
        'binding_rejections_after_rehash': rejected, 'command_recipe_MIME_suffix_bytes_agree': True,
        'wrong_review_digest_stays_private': True, 'legacy_PNG_bytes_equal_original_renderer': True})


def raw_png(width, height, color, scanlines):
    def chunk(kind, data):
        return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data) & 0xffffffff)
    return b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', width, height, 8, color, 0, 0, 0)) + chunk(b'IDAT', zlib.compress(scanlines)) + chunk(b'IEND', b'')


def test_2_every_RGBA_byte_including_hidden_color_and_alpha_is_lossless(monkeypatch):
    import base64
    width, height = 64, 72
    keep = lambda x, y: (x + y * 3) % 7 != 6
    bits = [keep(x, y) for y in range(height) for x in range(width)]
    plane = bytes(sum(int(bits[start + j]) << (7 - j) for j in range(8)) for start in range(0, len(bits), 8))
    mask, _ = encode_mask(width, height, base64.b64encode(plane).decode())
    results = []
    for color in [0, 2, 4, 6]:
        scanlines = bytearray(); expected = bytearray()
        for y in range(height):
            scanlines.append(0)
            for x in range(width):
                r, g, b = (x * 19 + y * 13 + 9) % 256, (x * 7 + y * 23 + 11) % 256, (x * 37 + y * 5 + 3) % 256
                alpha = [0, 1, 127, 254, 255][(x + y) % 5]
                pixel = {0: (r,), 2: (r, g, b), 4: (r, alpha), 6: (r, g, b, alpha)}[color]
                scanlines.extend(pixel)
                rgba = {0: (r, r, r, 255), 2: (r, g, b, 255), 4: (r, r, r, alpha), 6: (r, g, b, alpha)}[color]
                expected.extend(rgba if keep(x, y) else (0, 0, 0, 0))
        png, proof = render_cutout(raw_png(width, height, color, scanlines), mask)
        encoded, result = webp.encode(png, proof, lambda: None)
        with Image.open(io.BytesIO(encoded)) as image:
            assert image.format == 'WEBP' and image.size == (width, height) and image.n_frames == 1
            assert image.convert('RGBA').tobytes() == expected
        assert result['rgba_sha256'] == hashlib.sha256(expected).hexdigest()
        results.append({'color_type': color, 'bytes': len(encoded), 'rgba_sha256': result['rgba_sha256']})
    original_save = Image.Image.save
    def corrupt_native_output(image, fp, *args, **kwargs):
        changed = image.copy(); changed.putpixel((0, 0), (0, 0, 0, 0))
        try: return original_save(changed, fp, *args, **kwargs)
        finally: changed.close()
    with monkeypatch.context() as patch:
        patch.setattr(Image.Image, 'save', corrupt_native_output)
        with pytest.raises(ValueError, match='IMAGE_CUTOUT_WEBP_PIXELS_CHANGED'):
            webp.encode(png, proof, lambda: None)
    receipt('case2-pixels.json', {'pass': True, 'dimensions': [width, height], 'native_results': results,
        'independently_constructed_expected_pixels': True, 'retained_alpha_values': [0, 1, 127, 254, 255],
        'retained_RGB_under_zero_alpha_checked': True, 'deliberately_corrupted_native_hidden_RGB_rejected': True})


def test_3_post_encode_cancel_and_source_revision_never_promote(cpu_client, monkeypatch):
    e = cpu_client; e.command['parameters'] = {'cutout_output': webp.PROFILE}
    e.command['request_id'] = 'review-waits-for-source'
    _, awaiting = queue(e); awaiting = checked(run(e, awaiting)); assert awaiting['status'] == 'AWAITING_REVIEW'
    private = awaiting['output_candidate']['id']
    assert e.client.get(e.studio_base + '/assets/' + private, headers=e.headers).status_code == 404
    baseline_files = len(list(e.assets.root.glob('*.bin')))
    assert baseline_files == 3
    original = webp.encode
    e.command['request_id'] = 'cancel-after-native-return'; _, queued = queue(e)
    def cancel_after_native(*args, **kwargs):
        value = original(*args, **kwargs)
        current = checked(e.client.get(e.base + '/jobs/image/' + queued['id'], headers=e.headers))
        assert current['status'] == 'RUNNING'
        stopped = checked(e.client.post(e.base + '/jobs/image/' + queued['id'] + '/cancel', headers=e.headers, json=action(current)))
        assert stopped['status'] == 'CANCELLED'
        return value
    with monkeypatch.context() as patch:
        patch.setattr(webp, 'encode', cancel_after_native)
        cancelled = checked(run(e, queued))
    assert cancelled['status'] == 'CANCELLED' and cancelled['output_candidate'] is None
    assert not cancelled['remote_compute_may_continue']
    denied_cancel_review = approve(e, cancelled, 'a' * 64)
    assert denied_cancel_review.status_code in {409, 422}
    assert len(list(e.assets.root.glob('*.bin'))) == baseline_files

    e.command['request_id'] = 'source-revised-after-native'; _, queued = queue(e)
    def revise_after_native(*args, **kwargs):
        value = original(*args, **kwargs)
        with e.studio._asset_scope(e.nid, e.scope):
            changed = e.assets.update_metadata(e.source['id'], {'scene_id': 'independent-new-revision'}, expected_version=1)
        assert changed['version'] == 2
        return value
    with monkeypatch.context() as patch:
        patch.setattr(webp, 'encode', revise_after_native)
        stale_execute = run(e, queued)
    stale_result = checked(stale_execute)
    assert stale_result['status'] == 'FAILED'
    assert stale_result['error_code'] == 'STUDIO_IMAGE_CUTOUT_SOURCE_CHANGED'
    assert stale_result['output_candidate'] is None
    assert len(list(e.assets.root.glob('*.bin'))) == baseline_files
    denied_stale_review = approve(e, awaiting)
    assert denied_stale_review.status_code == 409, denied_stale_review.text
    assert e.client.get(e.studio_base + '/assets/' + private, headers=e.headers).status_code == 404
    public = checked(e.client.get(e.studio_base + '/assets', headers=e.headers))['items']
    assert {row['id'] for row in public} == {e.source['id'], e.mask['id']}
    receipt('case3-fences.json', {'pass': True, 'cancel_after_real_native_encode': cancelled['status'],
        'cancelled_candidate': cancelled['output_candidate'], 'cancel_review_HTTP': denied_cancel_review.status_code,
        'source_revision_after_real_native_encode_HTTP': stale_execute.status_code,
        'source_revision_after_real_native_encode_state': stale_result['status'],
        'source_revision_after_real_native_encode_error': stale_result['error_code'],
        'source_revision_before_original_review_HTTP': denied_stale_review.status_code,
        'pre_review_candidate_Asset_GET_HTTP': 404, 'public_Asset_count': len(public),
        'no_new_candidate_after_cancel_or_source_change': True})
