# 现代 DIF02 独立业务链审查

固定 head `c246f2d1fe0a32bb2071aedaf124a04e7a247044`，树 `2ff36ec7dae31a3bcea75800df2048bd7d84f714`。

本次限定 DIF 原 owner 读授权、20直接引用观察和决定保存/重开链，未发现 P1/P2，可支持限定整合。schema7运行与c4dd来源权限语义不作专项结论，按另一个reviewer结果处理。未将PG、模型或完整E2E算作通过。

## 身份及依赖

- adapter：`a886978864e9e685c6cc7d9476abbccb5434ace5`
- Graph API前置修复：`c4dd04b557c90e6f8d7038364e8f76aa1a2d9820`
- DIF业务接线：`c246f2d1fe0a32bb2071aedaf124a04e7a247044`
- 原依赖：`5c5a48f6745c54e2f122759014aa9b5211c8b86e`、`a6678a4144b40277dce3c94f42cfed66a140fae5`。

两依赖在作者分支分别以 `ee694b4b44da4f0a2354b5c0e357d06c4a5743fd`、`6c836692d7ccdd8c5dd81f0c81bbacd5edbed864` cherry-pick存在。已独立核对两对 stable patch-id完全一致；不能将原SHA误称为head的直接祖先。按原依赖各整合一次，再用上述三个own commits，勿重复整合两份local copy。

## 三个真实 File/API 反例

| 反例 | 实际结果 | 证据 |
| --- | --- | --- |
| 小说write不能替代现代来源read | 原真实分支身份仅授NOVEL domain.write，DIF作者sources入口200；现代query、preview、Save、GET决定均403，未泄露标题，两个范围都无部分记录 | one-original-read-authority.json |
| 20直接引用/版本/scope/incarnation/超限 | 20含禁用项完整返回；Graph版本和Storyboard版本变化后的旧预览Save均409；21项整次422且无items；跨项目404，缺失/重建incarnation拒绝，不自动初始化、不留决定 | two-reference-fences.json |
| UNKNOWN重开、同键及意图边界 | 实际原Save提交后注入响应丢失；换新ExperimentalStore实例后通过原API重开；同键同意图仅1条记录，改动同键422；只变决定集合，Graph不变、无模型/任务；现代决定不能直接用于原preflight（404） | three-unknown-intent.json |

结果：`3 passed, 3 deselected`（PG），17.11s。没有使用伪造OwnerRead reader；复用原mounted Host/角色/Storyboard/Graph服务，只在独立证据目录创建一次性File数据和响应丢失故障。原始日志及JUnit已保留，未改弱测试。

## 只读范围

通过Git blob按需加载固定head，共466个依赖blob并核对OID；没有复制整份源码。静态读过原Storyboard和逐图invoker接线、元数据/epoch fence、观察上限、原决定事务/幂等和复用的UNKNOWN面板。作者77后端/31前端/TS/build/token/geometry未重跑。

产品文件、已冻结视频a667、已释放共享model/client均未修改，也未push或启动服务。作者工作区开始时就有未跟踪的交接日志/视觉夹具，未改/未清理，记录于 author-worktree-status.txt。无本次剩余阻断；后续组合树须由父任务串行整合后另验。
