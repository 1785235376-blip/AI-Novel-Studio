"""Four independent bounded File/API groups; no providers or full E2E."""
from copy import deepcopy
from pathlib import Path
from uuid import uuid4
import json,types,sys,subprocess
import pytest
from app.creative.graph import CreativeGraphService
from app.creative.graph_models import parse_graph,catalog_definitions,validate_output_ports
from app.experimental.common import StaleSourceError
from app.services.v1_capability_service import CapabilityVersionConflict
from test_v2_independent_workspace import rig
from test_v2_graph_local_conditions import definition as conditional_definition
from test_r3_mounted_contracts import mounted,prefix,checked
from test_v2_independent_workspace_api import client
from test_v2_creative_graph_api import graph_client,scoped_graph_client
from test_v2_graph_local_conditions_api import grant
from test_v2_local_subgraph import child_definition

OUT=Path(__file__).resolve().parent
@pytest.fixture(autouse=True)
def gate(monkeypatch):
    monkeypatch.setenv('CREATIVE_GRAPH_CONDITIONS_V1','1');monkeypatch.setenv('EXPERIMENTAL_FEATURES','narrative_production_v2');monkeypatch.delenv('V1_ACCEPTANCE_MODE',raising=False)

def record(name,value):(OUT/(name+'.json')).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf8')
def saved(e,service,value=None):return service.create(e.nid,e.scope,e.actor,{'request_id':uuid4().hex,'definition':value or conditional_definition()})
def admitted(e,service,graph,key=None):
    flight=service.preflight(e.nid,e.scope,e.actor,graph['id'],{'expected_version':graph['version']})
    assert flight['executable'];body={'expected_graph_version':graph['version'],'reviewed_preflight_digest':flight['preflight_digest'],'request_id':key or uuid4().hex}
    return service.create_run(e.nid,e.scope,e.actor,graph['id'],body),body

@pytest.mark.parametrize('rig',['file'],indirect=True)
def test_01_boolean_enum_both_arms_real_file_skips_zero_dispatch_and_zero_effect(rig,monkeypatch):
    e=rig;service=CreativeGraphService(e.store,e.service);original=service.executor.adapter.execute;calls=[]
    def observed(request):calls.append((request.node_type,request.request_id));return original(request)
    monkeypatch.setattr(service.executor.adapter,'execute',observed);proof=[]
    for predicate,chosen,other in [({'kind':'boolean','value':True},'yes','no'),({'kind':'boolean','value':False},'no','yes'),
        ({'kind':'enum','value':'B','equals':'B'},'yes','no'),({'kind':'enum','value':'B','equals':'A'},'no','yes')]:
        graph=saved(e,service,conditional_definition(predicate));run,body=admitted(e,service,graph);start=len(calls)
        waiting=service.action(e.nid,e.scope,e.actor,run['id'],'execute',{'expected_version':run['version']})
        actual=calls[start:];assert len(actual)==3 and not any(req.endswith(':'+other) for _,req in actual)
        assert waiting['review']['node_id']==chosen+'_review' and all(item['output'] is None for item in waiting['node_states'].values())
        raw=e.store.read(e.nid,e.scope)['collections'][service.RUNS][run['id']]
        for key in (other,other+'_review'):
            assert raw['node_states'][key]['status']=='SKIPPED' and raw['node_states'][key]['output'] is None
            assert key not in raw['typed_outputs'] and key not in raw['cache_keys']
            assert all(item['node_id']!=key for item in raw['dispatch_trace'])
            assert all(item['node_statuses'][key]=='SKIPPED' for item in raw['trace'])
        assert all(item['cacheable'] is False for item in raw['cache_keys'].values())
        review=waiting['review'];done=service.action(e.nid,e.scope,e.actor,run['id'],'approve',{
            'expected_version':waiting['version'],'node_id':review['node_id'],'reviewed_output_digest':review['output_digest']})
        assert done['status']=='SUCCEEDED' and not done['model_called'] and done['external_calls']==0 and not done['applied']
        assert done['node_states'][other]['output'] is None
        assert CreativeGraphService(e.store,e.service).get_run(e.nid,e.scope,e.actor,run['id'])==done
        proof.append({'predicate':predicate,'chosen':chosen,'skipped':[other,other+'_review'],'adapter_calls':len(actual),'skipped_dispatches':0,'skipped_outputs':0,'reopened':True})
    assert e.chapters.list(e.nid)==[] and e.service.list_assets(e.nid,e.scope)=={'items':[]}
    record('01-routing',{'passed':True,'cases':proof,'real_file':True,'chapter_asset_side_effects':0,'model_or_external_calls':0})

@pytest.mark.parametrize('rig',['file'],indirect=True)
def test_02_closed_topology_ports_cycle_and_models_media_refused_before_write(rig):
    e=rig;service=CreativeGraphService(e.store,e.service);cases=[]
    def reject(name,mutate):
        value=conditional_definition();mutate(value);before=deepcopy(e.raw_store.read(e.nid,e.scope))
        with pytest.raises(ValueError):saved(e,service,value)
        assert e.raw_store.read(e.nid,e.scope)==before;cases.append(name)
    reject('missing_branch',lambda d:d['edges'].pop())
    reject('illegal_port',lambda d:d['edges'][1].update(source_port='text'))
    reject('cycle',lambda d:d['edges'].append({'id':'cycle','source_node_id':'yes','source_port':'draft','target_node_id':'condition','target_port':'text'}))
    reject('join_between_arms',lambda d:d['edges'].append({'id':'join','source_node_id':'yes','source_port':'draft','target_node_id':'no_review','target_port':'draft'}))
    reject('disabled_node',lambda d:d['nodes'][2].update(enabled=False))
    for kind in ('text_generate','video_generate','image_generate','asset_reference','local_subgraph'):
        reject(kind,lambda d,kind=kind:d['nodes'][2].update(definition_id=kind))
    reject('truthiness_not_boolean',lambda d:d['nodes'][1]['parameters']['predicate'].update(value=1))
    record('02-admission',{'passed':True,'refused':cases,'no_durable_graph_or_run_write':True,'no_adapter_dispatch':True})

@pytest.mark.parametrize('mounted',['file'],indirect=True)
@pytest.mark.parametrize('prefix',['/api'],indirect=True)
def test_03_actual_api_scope_version_and_live_read_permission_revocation(scoped_graph_client,monkeypatch):
    e=scoped_graph_client
    def create(value):return checked(e.client.post(e.graph_base,headers=e.headers,json={'request_id':uuid4().hex,'definition':value}),201)
    def admit(graph):
        path=e.graph_base+'/'+graph['id'];flight=checked(e.client.post(path+'/preflight',headers=e.headers,json={'expected_version':graph['version']}))
        return checked(e.client.post(path+'/runs',headers=e.headers,json={'expected_graph_version':graph['version'],'reviewed_preflight_digest':flight['preflight_digest'],'request_id':uuid4().hex}),201)
    graph=create(conditional_definition());queued=admit(graph);waiting=admit(graph);legacy=create(child_definition())
    runpath=lambda run:e.studio_base+'/graph-runs/'+run['id'];gpath=e.graph_base+'/'+graph['id']
    waiting=checked(e.client.post(runpath(waiting)+'/execute',headers=e.headers,json={'expected_version':waiting['version']}))
    before=deepcopy(e.graphs.store.read(e.nid,graph['scope']))
    stale=e.client.put(gpath,headers=e.headers,json={'expected_version':graph['version']+1,'definition':graph['definition']});assert stale.status_code==409
    wrongscope=e.client.get(gpath,headers={**e.headers,'X-Branch-ID':'review-other-'+uuid4().hex});assert wrongscope.status_code in (403,404)
    assert e.graphs.store.read(e.nid,graph['scope'])==before
    original=e.graphs.executor.adapter.execute;calls=[]
    def revoke(request):
        calls.append(request.node_type);result=original(request)
        if request.node_type=='local_condition':grant(e,('domain.write','domain.review'))
        return result
    monkeypatch.setattr(e.graphs.executor.adapter,'execute',revoke)
    response=e.client.post(runpath(queued)+'/execute',headers=e.headers,json={'expected_version':queued['version']})
    assert response.status_code==403 and e.graphs.store.read(e.nid,graph['scope'])==before
    assert calls==['text_input','local_condition']
    review=waiting['review'];denied=[
        e.client.post(e.graph_base,headers=e.headers,json={'request_id':uuid4().hex,'definition':conditional_definition()}),
        e.client.put(gpath,headers=e.headers,json={'expected_version':graph['version'],'definition':graph['definition']}),
        e.client.get(runpath(queued),headers=e.headers),
        e.client.post(runpath(waiting)+'/approve',headers=e.headers,json={'expected_version':waiting['version'],'node_id':review['node_id'],'reviewed_output_digest':review['output_digest']})]
    assert all(r.status_code==403 and 'Pinned authored source' not in r.text and 'Selected A' not in r.text for r in denied)
    assert e.graphs.store.read(e.nid,graph['scope'])==before
    cancel=checked(e.client.post(runpath(queued)+'/cancel',headers=e.headers,json={'expected_version':queued['version']}));assert cancel['status']=='CANCELLED'
    reject=checked(e.client.post(runpath(waiting)+'/reject',headers=e.headers,json={'expected_version':waiting['version'],'node_id':review['node_id'],'reviewed_output_digest':review['output_digest']}));assert reject['status']=='REJECTED'
    assert all(item['output'] is None for result in (cancel,reject) for item in result['node_states'].values())
    old=checked(e.client.put(e.graph_base+'/'+legacy['id'],headers=e.headers,json={'expected_version':legacy['version'],'definition':legacy['definition']}))
    assert old['definition']==legacy['definition'] and old['version']==legacy['version']+1
    record('03-api-authority',{'passed':True,'original_mounted_file_api':True,'stale_version_status':409,'wrong_scope_status':wrongscope.status_code,
        'source_read_revoked_inside_condition_status':response.status_code,'graph_transaction_rolled_back':True,'denied_without_source_read':[r.status_code for r in denied],
        'cancel_reject_remain_available_and_redacted':True,'schema1_write_only_save_unchanged':True,'full_e2e':False})

@pytest.mark.parametrize('rig',['file'],indirect=True)
def test_04_legacy_1_to_6_frozen_default_off_unknown_no_rerun_cancel_and_incarnation(rig,monkeypatch):
    e=rig;service=CreativeGraphService(e.store,e.service)
    # Evaluate the frozen baseline model module in memory, never copy/patch source files.
    baseline=types.ModuleType('app.creative._review_d9_graph_models');baseline.__package__='app.creative';sys.modules[baseline.__name__]=baseline
    root=Path(__file__).resolve().parents[1]/'graph7-review'
    source=subprocess.check_output(['git','show','d9b2ea4b602af099f133e7ef7e954fb7618979ae:app/creative/graph_models.py'],cwd=root).decode('utf8')
    exec(compile(source,'<frozen-d9-graph-models>','exec'),baseline.__dict__)
    legacy=[]
    for version in range(1,7):
        value={'schema_version':version,'title':'Frozen legacy anchor','nodes':[],'edges':[]}
        assert parse_graph(value).model_dump()==baseline.parse_graph(value).model_dump()
        assert validate_output_ports('text_reference',{'text':'Author'},schema_version=version)==baseline.validate_output_ports('text_reference',{'text':'Author'},schema_version=version)
        legacy.append(version)
    assert catalog_definitions()==baseline.catalog_definitions()
    graph=saved(e,service);run,body=admitted(e,service,graph,'independent-unknown');calls=[]
    monkeypatch.setattr(service.executor.adapter,'execute',lambda request:calls.append(request.node_type))
    with e.store.transaction(e.nid,e.scope) as state:state['collections'][service.RUNS][run['id']]['node_states']['condition']['status']='UNKNOWN'
    before=deepcopy(e.raw_store.read(e.nid,e.scope));masked=service.get_run(e.nid,e.scope,e.actor,run['id'])
    assert masked['stale'] and masked['review'] is None and all(x['output'] is None for x in masked['node_states'].values())
    with pytest.raises(StaleSourceError):service.action(e.nid,e.scope,e.actor,run['id'],'execute',{'expected_version':run['version']})
    assert e.raw_store.read(e.nid,e.scope)==before and calls==[]
    with monkeypatch.context() as disabled:
        disabled.delenv('CREATIVE_GRAPH_CONDITIONS_V1')
        with pytest.raises(ValueError):parse_graph(conditional_definition())
        cancelled=service.action(e.nid,e.scope,e.actor,run['id'],'cancel',{'expected_version':run['version']})
        assert cancelled['status']=='CANCELLED' and cancelled['conditional_runtime']['plan'] is None
    before=deepcopy(e.raw_store.read(e.nid,e.scope))
    try:replayed=service.create_run(e.nid,e.scope,e.actor,graph['id'],body);assert replayed['id']==run['id']
    except ValueError:pass
    assert len(e.raw_store.read(e.nid,e.scope)['collections'][service.RUNS])==1 and calls==[]
    old_incarnation=e.store.incarnation(e.nid);e.novels.delete(e.nid);e.create_project(nid=e.nid)
    assert e.store.incarnation(e.nid)!=old_incarnation
    with e.raw_store.transaction(e.nid,e.scope) as state:state['collections'].update(before['collections'])
    with pytest.raises(FileNotFoundError):service.get_run(e.nid,e.scope,e.actor,run['id'])
    assert calls==[]
    record('04-legacy-unknown',{'passed':True,'schemas_compared_to_frozen_d9_module':legacy,'default_catalog_equal':True,'gate_off_refuses_schema7':True,
        'persisted_unknown_redacted_and_execute_refused':True,'gate_off_cancel_available':True,'same_request_no_second_run':True,'adapter_calls':0,'incarnation_recreation_fenced':True})
