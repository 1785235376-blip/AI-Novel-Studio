# GRAPH schema7 运行核心与来源读权限：独立限定审查

结论：**限定整合；本次只读审查与四组反例中未发现 P1/P2。**
保持 `CREATIVE_GRAPH_CONDITIONS_V1` 默认关闭。可整合本后端有界条件切片及其
完整来源读权限接线，不据此宣称浏览器、full E2E、PG、模型或媒体条件执行验收。

## 精确对象与依赖顺序

- 原核心：`5c5a48f6745c54e2f122759014aa9b5211c8b86e`，父
  `d9b2ea4b602af099f133e7ef7e954fb7618979ae`，六文件。
- 来源读权限接线：`c4dd04b557c90e6f8d7038364e8f76aa1a2d9820`。
  不是仅审核心后忽略该补丁。该提交只改 graph_api 与定向 API 测试。
- 实际测试树：`c246f2d1fe0a32bb2071aedaf124a04e7a247044`。
  从 task12 的 handoff 核实实际祖先依次为 d9 → a8869788 →
  ee694b4b（5c5a48f6 的本地依赖副本）→ 6c836692（a6678a41 视频底稿的依赖副本）
  → c4dd04b5 → c246f2d1。六个冻结核心文件的 Git blob 与原5c提交逐一一致。
- 正式整合按作者交接：原5c核心、原a667视频依赖各一次，再接
  `a886978864e9e685c6cc7d9476abbccb5434ace5`、完整c4、完整c246；
  **不要再重复应用 ee694b4b / 6c836692 本地依赖副本**。

本审查只覆盖运行核心、c4的schema7来源读分类，以及c246在graph_api里增加的
三行原读绑定上下文；未重做DIF业务审查。没有修改任何作者源码或推送。

## 四组独立反例：4 passed / 13.42s

1. **布尔／枚举正反分支与真实File：PASS。** true、false、B==B、B==A均命中
   正确支路。实际原本地adapter只收到input、condition、命中支路的三次调用。
   未命中的片段及审核节点在持久run、所有trace中保持SKIPPED，null输出、没有
   dispatch、typed output或cache key。选中审核前全部输出隐藏，原human_review
   后成功、独立owner读回一致。无章节/素材改动、无模型或外部调用。
   见 `01-routing.json`。

2. **非法结构与外部能力拒绝：PASS。** 缺分支、错误端口、循环、支路汇合、
   disabled节点、模型/视频/图片/Asset/subgraph节点、布尔值1，均在原create
   admission拒绝，原File scope前后完全不变；未进入执行器。见 `02-admission.json`。

3. **原mounted API权限、scope与版本：PASS。** 使用原trusted session、真实File
   authorization/Graph owners，限定 `/api` 一条路由族。错误scope被403拒绝，
   错误保存版本409且不改Graph。在condition执行完成后，通过原授权owner撤回
   来源读权限，仅保留write/review；请求403，整个Graph事务回滚，命中支路尚未
   执行。随后create/save/get run/approve全部403且不泄露来源文本。取消/拒绝仍
   可清理并隐藏全部输出，旧schema1仍可仅凭write保存。见 `03-api-authority.json`。

4. **旧schema、默认gate、UNKNOWN和incarnation：PASS。** 从Git对象读取d9原
   graph_models，在内存独立模块运行，对1–6的空图规范化、text_reference端口
   及默认catalog与本树作实值比较，完全一致。未启gate时schema7拒绝；模拟
   持久UNKNOWN节点后读回隐藏、execute拒绝且adapter零调用；gate关闭仍可取消。
   同request不会新增第二个run。通过原项目owner删除重建同id，再放入旧scope
   记录，旧incarnation run不可读。见 `04-legacy-unknown.json`。

四组源代码、原始命令、JUnit和结果JSON保留；未重跑作者29条件、108兼容、DIF77
或前端整组测试，没有执行TSbuild/全仓库测试。本次兼容证据是上述明确对象的
比较与原schema1 API行为，不声称穷尽schemas1–6所有历史执行路径。

## 核心与接线审读

- schema7只允许一条inline text_input、一个固定布尔/枚举condition、两条互斥
  线性支路与原human_review。compile_plan检查完整覆盖/端口/环，并将完整定义
  与决定绑定plan digest；不是脚本求值或任意变量/模型路由。
- ConditionalWorkflowHost只投影被选nodes/edges/states，advance/claim/complete/
  review/cancel仍走原WorkflowRun owner。回写合并完整SKIPPED事实，原dispatch
  guard再拒绝未选节点。run读取/行动复核scope、actor、incarnation、图版本与
  execution digest、输出/trace/skip证明；不使用缓存，UNKNOWN不自动重试。
- c4将schema7与schema6一起纳入新建/保存及已保存Graph/Run的source-read分类。
  原invoker分别获取目标write/review与来源read，合成guard持续核对相同actor/
  scope；并发schema升级也不能借用先前的仅写授权。cleanup路径不借权限读取输出。
- c246的graph_api差异仅绑定原reads，没有改上述guard闭包；DIF业务适配由其他
  审查负责，本报告不对其业务行为作判断。

## 不能扩大为验收的部分

独立API检查是原mounted API与真实File授权/事务，**不等于真实Host浏览器或full
E2E**。未做PG、并发压力、GPU或真实模型/媒体执行。schema7不进入默认catalog，
不开放模型/媒体/subgraph/循环或任意条件表达式；保持默认关闭。

links提交 `a8d3030215a4975f07045ebdbb71c354dffb8ea2` 未修改；原task13演示ZIP
校验不变，18913/5293端口保留。仅本审查的可再生profile/测试数据清理，精简源码、
日志与结果证据保留。
