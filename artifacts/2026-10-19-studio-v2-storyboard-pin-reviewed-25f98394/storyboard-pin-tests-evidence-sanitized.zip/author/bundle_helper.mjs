import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
const require=createRequire('<workspace>/studio-v2-storyboard-pin-fork/frontend/package.json');
await createRequire(require.resolve('vite/package.json'))('esbuild').build({entryPoints:[fileURLToPath(new URL('./fork_entry.ts',import.meta.url))],bundle:true,platform:'node',format:'esm',outfile:fileURLToPath(new URL('./fork_helper.mjs',import.meta.url)),logLevel:'warning'});
