import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import fs from 'node:fs/promises';
import path from 'node:path';
const require=createRequire('<workspace>/studio-v2-storyboard-pin-fork/frontend/package.json');
const {test,expect}=require('@playwright/test');
const OUT=path.dirname(fileURLToPath(import.meta.url)),ledgerPath=path.join(OUT,'browser-ledger.json');
const TITLE='分镜版本联动独立图 File 验收';
const docs=id=>`/api/novels/${id}/experimental/creative/documents`,graphs=id=>`/api/projects/${id}/studio/graphs`;
const writeLedger=v=>fs.writeFile(ledgerPath,JSON.stringify(v,null,2)+'\n');
const checked=async(r,status=200)=>{expect(r.status(),await r.text()).toBe(status);return r.json();};
const responseFor=(page,p,method)=>page.waitForResponse(r=>new URL(r.url()).pathname===p&&r.request().method()===method,{timeout:20000});
async function enterGraph(page){
 await page.goto('/');const nav=page.getByLabel('独立工作区内容',{exact:true});await expect(nav).toBeVisible({timeout:30000});
 const professional=page.getByRole('radio',{name:/专业/});if(await professional.getAttribute('aria-checked')!=='true')await professional.click();
 await nav.getByRole('button',{name:'创作图',exact:true}).click();await expect(page.getByLabel('节点类型',{exact:true})).toBeVisible();
 await page.getByRole('button',{name:'明确读取视频图节点目录',exact:true}).click();
}
async function openGraph(page,id){await page.getByRole('combobox',{name:'已保存创作图',exact:true}).selectOption(id);await expect(page.getByRole('button',{name:'重新读取创作图',exact:true})).toBeEnabled();}
const capture=async(page,name)=>{await page.evaluate(()=>document.fonts.ready);await page.screenshot({path:path.join(OUT,name+'.png'),fullPage:true});};
test.describe.configure({mode:'serial'});
test.beforeEach(async({page})=>{
 page.setDefaultTimeout(15000);const events={errors:[],writes:[],blocked:[]};page.__events=events;page.__sessionHeaders={};
 page.on('pageerror',e=>events.errors.push(e.message));page.on('request',r=>{const u=new URL(r.url());const headers=r.headers();if(headers['x-session-token'])page.__sessionHeaders['X-Session-Token']=headers['x-session-token'];if(headers['x-branch-id'])page.__sessionHeaders['X-Branch-Id']=headers['x-branch-id'];if(u.pathname.startsWith('/api/')&&!['GET','HEAD','OPTIONS'].includes(r.method()))events.writes.push({method:r.method(),path:u.pathname});});
 await page.route('**/*',r=>{const u=new URL(r.request().url());if(['http:','https:'].includes(u.protocol)&&!['http://127.0.0.1:5322','http://127.0.0.1:19128'].includes(u.origin)){events.blocked.push(u.origin);return r.abort();}return r.continue();});
});
test.afterEach(async({page},info)=>{const run=process.env.BROWSER_RUN_LABEL||'browser-first';await fs.writeFile(path.join(OUT,run+'-'+info.title[0]+'-events.json'),JSON.stringify(page.__events,null,2));if(info.status!==info.expectedStatus)await fs.writeFile(path.join(OUT,run+'-'+info.title[0]+'-body.txt'),await page.locator('body').innerText());});

test('A original File approved board changes, coupled preview stages once and explicit original Save creates a separate current graph',async({page,request:raw})=>{
 const request=Object.fromEntries(['get','post','put'].map(method=>[method,(url,options={})=>raw[method](url,{...options,headers:{...page.__sessionHeaders,...options.headers}})]));
 const resume=process.env.BROWSER_RESUME_SEED==='1';let project;
 if(resume){const prior=JSON.parse(await fs.readFile(ledgerPath,'utf8'));expect(prior.phase).toBe('project-created');project=prior.project;expect(project.title).toBe(TITLE);}
 else{expect(await checked(await request.get('/api/novels'))).toEqual([]);await page.goto('/');await page.getByLabel('空白项目名称',{exact:true}).fill(TITLE);
 const creating=responseFor(page,'/api/experimental/projects','POST');await page.getByRole('button',{name:'创建空白项目',exact:true}).click();project=await checked(await creating,201);}
 await enterGraph(page);await expect.poll(()=>Boolean(page.__sessionHeaders['X-Session-Token'])).toBe(true);
 await writeLedger({project,phase:'project-created'});
 let board;
 if(resume){const rows=(await checked(await request.get(docs(project.id)))).items;expect(rows).toHaveLength(1);board=await checked(await request.get(docs(project.id)+'/'+rows[0].id));expect(board.version).toBe(1);expect(board.title).toBe('两镜头合成作者分镜');}
 else board=await checked(await request.post(docs(project.id),{data:{mode:'STORYBOARD',title:'两镜头合成作者分镜',source_independent:true,
 scenes:[{id:'scene-1',sequence:1,heading:'INT. QUIET ROOM'}],shots:[{id:'shot-1',number:1,scene_id:'scene-1',duration_seconds:3,frame_prompt:'保留首镜头作者内容',lens:'35mm'},
 {id:'shot-2',number:2,scene_id:'scene-1',duration_seconds:2,frame_prompt:'保留第二镜头作者内容',lens:'50mm'}]}}),201);
 const boardPath=docs(project.id)+'/'+board.id;
 const initial=await checked(await request.get(boardPath+'/storyboard'));
 const oldReceipt=await checked(await request.post(boardPath+'/storyboard/approve',{data:{expected_version:initial.document_snapshot.version,reviewed_content_digest:initial.content_digest}}));
 const oldBoard=await checked(await request.get(boardPath));
 const nodes=[{id:'board',definition_id:'storyboard_plan',definition_version:1,enabled:true,position:{x:40,y:80},parameters:{document_snapshot:oldReceipt.document_snapshot}}],edges=[];
 for(const [i,shot]of oldReceipt.shots.entries()){
  const y=80+i*240;nodes.push({id:'shot-'+(i+1),definition_id:'storyboard_shot',definition_version:1,enabled:true,position:{x:460,y},parameters:{shot_id:shot.shot_id,shot_version:shot.shot_version,shot_digest:shot.shot_digest}},
   {id:'video-'+(i+1),definition_id:'video_generate',definition_version:1,enabled:true,position:{x:880,y},parameters:{operation_id:'m7.video.t2v',provider_id:'configured-not-verified',model_id:'authored-local-model',prompt:'保留视频作者提示 '+i,parameters:{seed:17+i},allow_cloud:false,license_note:'作者保留许可',bind_shot:true}},
   {id:'review-'+(i+1),definition_id:'media_review',definition_version:1,enabled:true,position:{x:1300,y},parameters:{}});
  for(const [from,port,to,input]of [['board','storyboard','shot-'+(i+1),'storyboard'],['shot-'+(i+1),'shot','video-'+(i+1),'shot'],['video-'+(i+1),'candidate','review-'+(i+1),'candidate']])edges.push({id:'e-'+edges.length,source_node_id:from,source_port:port,target_node_id:to,target_port:input});
 }
 const definition={schema_version:5,title:'原分镜视频图 · 保留历史',nodes,edges,viewport:{x:20,y:30,zoom:1},presentation:{comment:'保留作者图注'}};
 const original=await checked(await request.post(graphs(project.id),{data:{request_id:'pin-fork-original',expected_version:0,definition}}),201);
 const contentKeys=['mode','title','source_chapter_ids','source_independent','scenes','director_notes','shots','video_plan','visual_target','source_documents','storyboard_origin'];
 const content=Object.fromEntries(contentKeys.filter(k=>Object.hasOwn(oldBoard,k)).map(k=>[k,structuredClone(oldBoard[k])]));content.shots[0].lens='85mm';
 await checked(await request.put(boardPath,{data:{...content,expected_version:oldBoard.version}}));
 const changed=await checked(await request.get(boardPath+'/storyboard'));
 const receipt=await checked(await request.post(boardPath+'/storyboard/approve',{data:{expected_version:changed.document_snapshot.version,reviewed_content_digest:changed.content_digest}}));
 expect(receipt.shots[0].shot_version).toBe(oldReceipt.shots[0].shot_version+1);expect(receipt.shots[1].shot_version).toBe(oldReceipt.shots[1].shot_version);
 const oldOnly=structuredClone(original.definition);oldOnly.title='仅文档更新的旧行为诊断';oldOnly.nodes[0].parameters.document_snapshot=receipt.document_snapshot;
 const oldOnlyResponse=await request.post(graphs(project.id),{data:{request_id:'pin-fork-legacy-diagnostic',expected_version:0,definition:oldOnly}});
 expect([201,409]).toContain(oldOnlyResponse.status());const diagnostic={create_status:oldOnlyResponse.status(),create:await oldOnlyResponse.json()};
 if(oldOnlyResponse.status()===201){diagnostic.preflight=await checked(await request.post(graphs(project.id)+'/'+diagnostic.create.id+'/preflight',{data:{expected_version:diagnostic.create.version,target_node_ids:['shot-1']}}));expect(diagnostic.preflight.executable).toBe(false);expect(diagnostic.preflight.issues.some(i=>/PLANNING|STORYBOARD|SOURCE/.test(i.code))).toBe(true);}
 await writeLedger({project,oldBoard,oldReceipt,original,receipt,diagnostic,phase:'seeded-original-current-receipt'});
 await enterGraph(page);await openGraph(page,original.id);
 await page.getByRole('button',{name:'选择节点 分镜节点（已保存文档） · board',exact:true}).click();
 const before=page.__events.writes.length;
 await page.getByRole('button',{name:'核对更新来源用于独立新图',exact:true}).click();
 const preview=page.getByRole('region',{name:'更新分镜与镜头 pin 预览',exact:true});await expect(preview).toContainText('2 个已连接镜头');
 await expect(preview).toContainText(receipt.shots[0].shot_digest);await expect(preview).toContainText(oldReceipt.shots[0].shot_digest);
 await preview.scrollIntoViewIfNeeded();await capture(page,'coupled-preview-1440');
 const confirm=page.getByRole('checkbox',{name:'已核对全部文档及镜头 pin，确认准备独立新图草稿，保留原图',exact:true});
 const prepare=page.getByRole('button',{name:'准备使用更新来源的独立草稿',exact:true});await expect(prepare).toBeDisabled();await confirm.check();await prepare.click();
 await expect(page.getByRole('region',{name:'独立新图来源上下文',exact:true})).toContainText(original.id);
 expect(page.__events.writes.length).toBe(before);await expect(page.getByRole('combobox',{name:'已保存创作图',exact:true})).toHaveValue('');
 const savedResponse=responseFor(page,graphs(project.id),'POST');await page.getByRole('button',{name:'保存创作图',exact:true}).click();const saved=await checked(await savedResponse,201);
 expect(saved.id).not.toBe(original.id);const expected=structuredClone(original.definition);expected.nodes[0].parameters.document_snapshot=receipt.document_snapshot;
 for(const n of expected.nodes.filter(n=>n.definition_id==='storyboard_shot')){const s=receipt.shots.find(s=>s.shot_id===n.parameters.shot_id);n.parameters.shot_version=s.shot_version;n.parameters.shot_digest=s.shot_digest;}
 expect(saved.definition).toEqual(expected);expect(saved.reference_states.every(row=>row.state==='CURRENT')).toBe(true);
 const flight=await checked(await request.post(graphs(project.id)+'/'+saved.id+'/preflight',{data:{expected_version:saved.version,target_node_ids:['shot-1','shot-2']}}));expect(flight.executable).toBe(true);expect(flight.issues).toEqual([]);
 const oldAgain=await checked(await request.get(graphs(project.id)+'/'+original.id));expect(oldAgain.definition).toEqual(original.definition);expect(oldAgain.version).toBe(original.version);expect(oldAgain.definition_digest).toBe(original.definition_digest);expect(oldAgain.capacity.history_used).toBe(original.capacity.history_used);
 expect(page.__events.writes.slice(before)).toEqual([{method:'POST',path:graphs(project.id)}]);
 expect((await checked(await request.get(graphs(project.id)+'/'+saved.id+'/runs'))).items).toEqual([]);
 expect(page.__events.errors).toEqual([]);expect(page.__events.blocked).toEqual([]);
 await writeLedger({project,oldBoard,oldReceipt,original,receipt,diagnostic,saved,flight,oldAgain,phase:'saved-independent-current-pins-no-runs'});
});

test('B fresh browser reopens saved graph with exact pins and preserved parameters and shell geometry at three widths',async({page,request:raw})=>{
 const request={get:(url)=>raw.get(url,{headers:page.__sessionHeaders})};
 const ledger=JSON.parse(await fs.readFile(ledgerPath,'utf8'));expect(ledger.phase).toBe('saved-independent-current-pins-no-runs');
 await enterGraph(page);await openGraph(page,ledger.saved.id);
 const reopened=await checked(await request.get(graphs(ledger.project.id)+'/'+ledger.saved.id));expect(reopened.definition).toEqual(ledger.saved.definition);expect(reopened.definition_digest).toBe(ledger.saved.definition_digest);expect(reopened.capacity).toEqual(ledger.saved.capacity);
 const geometry=[];
 for(const [width,height]of [[1366,768],[1440,900],[1920,1080]]){
  await page.setViewportSize({width,height});await expect(page.locator('.app-shell')).toBeVisible();
  const row=await page.evaluate(()=>({viewport:{width:innerWidth,height:innerHeight},pageScrollWidth:document.documentElement.scrollWidth,shellWidth:document.querySelector('.app-shell').getBoundingClientRect().width,headerHeight:document.querySelector('.global-header').getBoundingClientRect().height,statusHeight:document.querySelector('.status-bar').getBoundingClientRect().height}));
  expect(row.shellWidth).toBe(width);expect(row.pageScrollWidth).toBeLessThanOrEqual(width);expect(row.headerHeight).toBe(56);expect(row.statusHeight).toBe(32);geometry.push(row);await capture(page,'coupled-reopened-'+width);
 }
 expect(page.__events.writes).toEqual([]);expect(page.__events.errors).toEqual([]);expect(page.__events.blocked).toEqual([]);
 await fs.writeFile(path.join(OUT,'fresh-reopen.json'),JSON.stringify({reopened,geometry,writes:page.__events.writes},null,2));
});
