from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace
import json,subprocess,sys
import pytest
SOURCE=Path(r'<temp-workspace>')
OUT=Path(__file__).parent
sys.path[:0]=[str(SOURCE),str(SOURCE/'tests')]
from test_v2_independent_workspace import services
from test_v2_graph_production_planning import documents
from test_v2_graph_image_nodes import graph_owner
from test_v2_storyboard_workspace import content
from app.creative.storyboard import storyboard_receipt
from app.creative.graph import CreativeGraphService,GRAPHS
from app.creative.service import document_digest

def test_actual_typescript_pin_fork_persists_reopens_and_passes_original_file_source_preflight(tmp_path,monkeypatch):
    from app.config import Settings
    from app.repositories.factory import create_repository_bundle
    from app.services import NovelService,ChapterService
    bundle=create_repository_bundle(Settings(storage_backend='file',database_url='',novel_data=tmp_path,enable_cloud=False,mock_provider=True),data_root=tmp_path)
    novels,chapters=NovelService(bundle.novels,bundle.chapters),ChapterService(bundle.chapters)
    nid=novels.create({'id':'pin-fork-file-service','title':'SYNTHETIC exact pin fork'})['id']
    workspace=services(tmp_path,'file','',novels,chapters)
    e=SimpleNamespace(nid=nid,scope={'mode':'local','novel_id':nid},actor='local-studio-author',service=workspace)
    owner=graph_owner(e,monkeypatch)
    director,board=documents(e)
    # A second authored Shot makes the unchanged per-Shot version visible.
    body=content(board);second=deepcopy(body['shots'][0]);second.update(id='shot-two',number=2,frame_prompt='Unchanged second shot');body['shots'].append(second)
    board=workspace.creative.update(nid,e.scope,e.actor,board['id'],board['version'],body)
    before=storyboard_receipt(board)
    old_receipt=workspace.creative.storyboards.approve(nid,e.scope,e.actor,board['id'],{'expected_version':board['version'],'reviewed_content_digest':before['content_digest']})
    old_board=workspace.creative.get(nid,e.scope,board['id'])
    node=lambda id,kind,params,x,y:{'id':id,'definition_id':kind,'definition_version':1,'enabled':True,'position':{'x':x,'y':y},'parameters':params}
    nodes=[node('board','storyboard_plan',{'document_snapshot':old_receipt['document_snapshot']},40,80)];edges=[]
    for i,shot in enumerate(old_receipt['shots'],1):
        nodes.extend([node(f'shot-{i}','storyboard_shot',{key:shot[key] for key in ('shot_id','shot_version','shot_digest')},460,80+(i-1)*240),
            node(f'video-{i}','video_generate',{'operation_id':'m7.video.t2v','provider_id':'configured-not-verified','model_id':'authored-model','prompt':f'Keep prompt {i}','parameters':{'seed':17+i},'allow_cloud':False,'license_note':'keep license','bind_shot':True},880,80+(i-1)*240),node(f'review-{i}','media_review',{},1300,80+(i-1)*240)])
        for source,port,target,input in [('board','storyboard',f'shot-{i}','storyboard'),(f'shot-{i}','shot',f'video-{i}','shot'),(f'video-{i}','candidate',f'review-{i}','candidate')]:
            edges.append({'id':f'e-{len(edges)}','source_node_id':source,'source_port':port,'target_node_id':target,'target_port':input})
    definition={'schema_version':5,'title':'Original kept graph','nodes':nodes,'edges':edges,'viewport':{'x':20,'y':30,'zoom':1.2},'presentation':{'comment':'keep author annotation'}}
    original=owner.create(nid,e.scope,e.actor,{'request_id':'original-pin-graph','expected_version':0,'definition':definition})
    original_raw=deepcopy(workspace.store.read(nid,e.scope)['collections'][GRAPHS][original['id']])
    update=content(old_board);update['shots'][0]['lens']='85mm'
    updated=workspace.creative.update(nid,e.scope,e.actor,board['id'],old_board['version'],update)
    receipt=workspace.creative.storyboards.approve(nid,e.scope,e.actor,board['id'],{'expected_version':updated['version'],'reviewed_content_digest':storyboard_receipt(updated)['content_digest']})
    current=workspace.creative.get(nid,e.scope,board['id'])
    assert receipt['shots'][0]['shot_version']==old_receipt['shots'][0]['shot_version']+1
    assert receipt['shots'][1]['shot_version']==old_receipt['shots'][1]['shot_version']
    input={'definition':original['definition'],'nodeId':'board','nodeIds':['board'],'document':{'id':board['id'],'mode':'STORYBOARD','title':current['title'],'version':current['version'],'digest':document_digest(current)},'receipt':receipt}
    (OUT/'file-helper-input.json').write_text(json.dumps(input,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    result=subprocess.run([r'C:\Program Files\nodejs\node.exe',str(OUT/'fork_helper.mjs'),str(OUT/'file-helper-input.json'),str(OUT/'file-helper-output.json')],capture_output=True,text=True,encoding='utf-8')
    (OUT/'file-helper-process.json').write_text(json.dumps({'exit':result.returncode,'stdout':result.stdout,'stderr':result.stderr},indent=2)+'\n',encoding='utf-8')
    assert result.returncode==0,result.stderr
    transformed=json.loads((OUT/'file-helper-output.json').read_text(encoding='utf-8'))
    legacy=owner.create(nid,e.scope,e.actor,{'request_id':'doc-only-pin-graph','definition':transformed['legacy']})
    legacy_flight=owner.preflight(nid,e.scope,e.actor,legacy['id'],{'expected_version':legacy['version'],'target_node_ids':['shot-1','shot-2']})
    assert not legacy_flight['executable']
    assert any(i['code']=='CREATIVE_GRAPH_PLANNING_INPUT_CHANGED_OR_INVALID' for i in legacy_flight['issues'])
    fork=owner.create(nid,e.scope,e.actor,{'request_id':'coupled-pin-graph','definition':transformed['result']['definition']})
    expected=deepcopy(original['definition']);expected['nodes'][0]['parameters']['document_snapshot']=receipt['document_snapshot']
    for item in expected['nodes']:
        if item['definition_id']=='storyboard_shot':
            shot=next(s for s in receipt['shots'] if s['shot_id']==item['parameters']['shot_id'])
            item['parameters'].update(shot_version=shot['shot_version'],shot_digest=shot['shot_digest'])
    assert fork['definition']==expected
    fork_raw=deepcopy(workspace.store.read(nid,e.scope)['collections'][GRAPHS][fork['id']])
    new_workspace=services(tmp_path,'file','',novels,chapters)
    reopened=CreativeGraphService(new_workspace.store,new_workspace);reopened.configure_media(SimpleNamespace())
    actual=reopened.get(nid,e.scope,e.actor,fork['id'])
    assert actual['definition']==expected
    assert new_workspace.store.read(nid,e.scope)['collections'][GRAPHS][fork['id']]==fork_raw
    flight=reopened.preflight(nid,e.scope,e.actor,fork['id'],{'expected_version':fork['version'],'target_node_ids':['shot-1','shot-2']})
    assert flight['executable'] and flight['issues']==[]
    old_again=reopened.get(nid,e.scope,e.actor,original['id'])
    assert old_again['definition']==original['definition'] and old_again['version']==original['version']
    assert new_workspace.store.read(nid,e.scope)['collections'][GRAPHS][original['id']]==original_raw
    assert reopened.runs(nid,e.scope,e.actor,fork['id'])=={'items':[]}
    assert new_workspace.creative.get(nid,e.scope,board['id'])==current
    (OUT/'real-file-service.json').write_text(json.dumps({'director':director,'old_receipt':old_receipt,'receipt':receipt,'original':original,'legacy':legacy,'legacy_preflight':legacy_flight,'fork':fork,'reopened':actual,'source_only_preflight':flight,'old_again':old_again,'original_raw_unchanged':True,'fork_raw_reopened_equal':True,'runs':[],'model_called':False,'acceptance':'REAL_FILE_SERVICE_NOT_AUTHENTICATED_BROWSER'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
