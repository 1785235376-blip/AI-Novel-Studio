import {readFileSync,writeFileSync} from 'node:fs';
import {planningSourceFork,planningStoryboardSourceFork} from '../studio-v2-storyboard-pin-fork/frontend/src/creative/graphPlanningForkHelpers';
const [input,output]=process.argv.slice(2),value=JSON.parse(readFileSync(input,'utf8'));
const result=planningStoryboardSourceFork(value.definition,value.nodeId,value.document,value.receipt,value.nodeIds);
writeFileSync(output,JSON.stringify({result,legacy:planningSourceFork(value.definition,value.nodeId,value.document,value.nodeIds)},null,2)+'\n');
