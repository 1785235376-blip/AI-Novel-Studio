# v5 Storyboard / Shot pin 联动独立图

本地提交 `519a1410aa1dc9f8d49e6414b770560e1a2e4792`，父提交 `8e17abe2262333459bcfd8d59da4b1998ff3d5f7`，源码树 `7ecce853046babe4dde2abc907b1a9b9a50664f1`。分支 `work/v2-storyboard-shot-pin-fork-20261019`；工作区 `<workspace>\studio-v2-storyboard-pin-fork`；已提交且干净。未推送、未合并、未归档、未新增启动器。父任务唯一归档写入器的快照未改动。

真实缺口：原 `planningSourceFork` 仅更新文档 pin，改变过的 Shot tuple 仍旧，原预检拒绝。现通过原 GraphPlanningFork 一次明确核对最新已审核回执，预览全部同文档旧引用和 1–4 个已连接 Shot（包含停用），按稳定 shot_id 更新版本/摘要，复用原 stageIndependentGraph。本次仅改变 pin，原图/历史、节点、连线、视频提示/模型/种子/时长/许可等保留。原 Save 和预检仍独立核对，不自动保存、审核、调用或创建运行。

改动 5 文件、253 增加/16 删除；其中153行是10项针对性测试。4个生产文件为 `GraphPlanningFork.tsx`、`graphPlanningForkHelpers.ts`、`studioGraphEditorView.tsx`、`useStudioGraphEditorController.ts`。

验证：新增10项通过；直接相关旧42项通过；TypeScript通过；Vite构建通过（原大块提示保留）；NOVEL/IMAGE/VIDEO shell视觉3项、1366/1440/1920几何3项通过。实际 TypeScript helper 以真实原 File Storyboard回执计算，新定义由原 Graph service 创建并重开，文档-only旧行为来源预检失败，联动 pin 的两个 Shot 来源预检通过，原图完整原始记录（含历史）一致，运行列表为空。见 `real-file-service.json` 和 `real-file-history-corrected.log`。这是 File service 验证；没有冒称已完成鉴权浏览器闭环或模型可用性。

原始失败：新夹具复制了无效 continuity ID（10失败/42旧通过）→修正夹具后10通过；直接浏览器 Storyboard GET401 SESSION_REQUIRED；恢复后视频目录仍401、未得到本机Host凭证；pnpm的esbuild根解析失败→从已有Vite依赖解析；File夹具错误假定GET包含history→改为对比完整原始File记录，最终通过。所有首轮日志/输入及独有截图保留。首次Git提交因无作者失败；单次命令复用8e既有元数据后提交成功，不修改配置。随后PowerShell的只读HEAD树参数引用错误已单独核实。

待父任务协调：原后端拒绝（401）读取视频目录/Storyboard；目标19128/5322上的真实 v5 浏览器预览→确认→Save→重开尚未执行，状态明确、无不确定写入。需要一个已经授权的原本机Host会话；未创建凭证、未放宽鉴权。隔离浏览器File目前仅保留同名合成项目和1份未审核v1分镜。保留脚本可续验，续验前须重新读实际File状态。PostgreSQL、全套、完整provider预检、GPU/模型/素材审核均未运行。

隔离：父8e是明确已确认源码；以sparse worktree共享Git对象，仅复用现有node_modules junction。后端复用冻结dc69工作区的原文件，只读；其app树与8e相同（21ca4983…），新运行配置与数据全部在本任务路径。未复制整份历史源码。两个自有测试根进程经PID/命令/创建时间核对后终止，19128/5322释放；18913/5293未动。清理前列出路径/哈希，已移除 7,118,788 字节可复现dist/类型缓存/失败夹具/临时目录/编译helper；保留源码、现有依赖、成功File恢复和独有证据。详见cleanup及stop receipts。

集成建议：父任务审查此独立提交后，由唯一写入器协调cherry-pick到其最终组合；不要拿本分支父8e覆盖较新组合，也不要整树复制。仅属于CORE-16/GRAPH-08/GRAPH-21局部来源闭环，未把整个需求标绿。
