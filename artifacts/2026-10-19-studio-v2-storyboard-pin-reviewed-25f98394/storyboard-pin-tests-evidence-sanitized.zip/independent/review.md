# Storyboard/Shot pin 联动更新：独立审查

目标 `519a1410aa1dc9f8d49e6414b770560e1a2e4792`，父 `8e17abe2262333459bcfd8d59da4b1998ff3d5f7`，五文件差异。结论：本轮未发现 P1/P2，可限定整合原独立草稿能力；认证浏览器预览→Save→新上下文重开验收仍 BLOCKED，不能归为完整浏览器通过。

直接引用精确提交的干净工作区，不复制完整源码或依赖；新探针/配置/缓存仅在本审查目录，依赖以 junction 复用既有安装。运行前后五个差异文件字节均与目标 blob 一致，HEAD 未变、git status 为空。后端 app tree 与作者复用的 dc69b317 一致（21ca49838af0cbf7a1c9bf071317745a25bd8ff5）。没有写产品/原测试、创建凭据、改 auth 设置、启动服务、运行模型或推送。

## 三项独立反例

首次 `3 passed`，Vitest 总计 1.75s，见 `independent1.log`、JUnit 和命令账本。

1. **跨版本 pin 一致性与原子拒绝**：构造同一 Storyboard 的两个不同旧版本文档引用，四个已连接 Shot（含一个停用节点），新回执重排镜头顺序并保留一个未变化 Shot 版本。结果按稳定 shot_id 同步更新全部旧文档与四个 pin，未凭序号猜测或虚构未变 Shot 的版本。部分旧引用范围、未审核、回执版本/摘要不一致、稳定 ID 已移除、第五个节点均拒绝，输入没有部分修改。
2. **原图/历史与原 Save 边界**：经原 useStudioGraphEditorController，权限撤销并恢复后旧 scope 回调不能准备新图；缺少 coupled receipt 不能只更新文档 pin。合法准备后 base 变为独立草稿，完整新定义等于只改 document_snapshot 与 shot_version/shot_digest 的预期；没有 create/save/run。明确原 Save 后仅 create 一次，未 save 原图、未 createRun，测试持有的原记录与历史完整相等。这里是受控 client 的原控制器反例，不声称再次执行真实 File 持久化；作者的真实 File service 原始证据单独保留。
3. **旧 preview/权限与迟到回执**：组件中 disabled、client、definition、pin、scope 的 A→B→A，以及卸载均使旧 consent/准备回调失效。重新读取并确认后，旧回调仍不能借新确认写入，当前回调只消费一次。旧 client 尚未完成的 receipt 在换 owner 后被丢弃。此处是 React 边界，不替代实际协作撤权验收。

来源、拓扑、作者视频参数、provider/model、prompt、seed、license_note、allow_cloud、视口与注释均通过完整定义对比保留；原图和旧运行/审核没有转入新图。

## 既有 Host 会话：只读核对结论

支持流程在原源码中已经存在：`frontend/src/novel/LocalHostSessionPanel.tsx:17-34` 接收用户已有凭据，调用原 `api.validateLocalHostSession`；原 `app/api.py:803-815` 的 GET `/api/local-session` 使用既有 registry 校验，拒绝不匹配的 Origin，只返回 LOCAL_HOST/actor_id，不签发凭据。前端 `frontend/src/localHostSession.ts:4-8` 只存当前页面内存，刷新或新上下文须重新验证；原 `frontend/src/api.ts:68-72` 把经验证的当前 Host 凭据交给原请求头。后端 `app/trusted_sessions.py:18-19,59-64` 的 registry 属于进程内存。原测试也明确 absent/unregistered/revoked token 均拒绝，但这些测试会 register synthetic token，因此本轮只读、没有运行或借其创建凭据。

只读端口检查：目标19128/5322均未监听。作者最后原浏览器回执是401 SESSION_REQUIRED、缺 X-Session-Token，服务随后关闭。本轮没有任何可确认对该隔离后端仍有效的既有会话，不能自动认定其他服务/页面/项目的授权可复用；也没有搜索这些凭据。旧浏览器的内存绑定和旧进程 registry 都不是可自动恢复的登录态。

需要用户/父任务协调的下一步：在同一隔离后端的既有授权与原启动流程下，通过原“本机可信会话”面板验证并绑定已有有效凭据；Origin须符合既有配置，刷新/新context后再次验证。无需在聊天中发送凭据。如果该后端已没有可复用的注册会话，本轮“不得创建凭据/改安全设置”范围内不能继续。随后才可跑认证浏览器的联动预览、明确 Save、新上下文重开。未重试作者失败的浏览器写操作，也无不确定写结果。

## 限定验收

作者52定向、TS/build、6共享壳、1真实File service未重跑，既有证据不计为本轮独立通过项。作者浏览器401原日志保留，File service不等于浏览器通过。PG、实际协作浏览器撤权、完整E2E、视频生成/模型质量仍未验收。没有源码副本需要删除；唯一探针/日志/证据全部保留。没有自动审批拒绝、待审批或不确定工具执行结果；剩余阻塞是原认证前提缺失。
