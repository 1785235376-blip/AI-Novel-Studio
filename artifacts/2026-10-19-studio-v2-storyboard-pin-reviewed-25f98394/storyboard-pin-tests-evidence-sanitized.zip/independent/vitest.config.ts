import {defineConfig} from 'vitest/config';
import react from '@vitejs/plugin-react';
export default defineConfig({root:"D:/codex\u6570\u636e/2026-10-19/task-5/storyboard-pin-fork-cross-review",plugins:[react()],cacheDir:'.cache',resolve:{dedupe:['react','react-dom']},test:{include:['pin-fork-independent.test.tsx'],environment:'jsdom',pool:'forks',maxWorkers:1,minWorkers:1,cache:false},server:{fs:{allow:["D:/codex\u6570\u636e/2026-10-19/task-5/storyboard-pin-fork-cross-review","D:/codex\u6570\u636e/2026-10-19/task/studio-v2-storyboard-pin-fork/frontend"]}}});
