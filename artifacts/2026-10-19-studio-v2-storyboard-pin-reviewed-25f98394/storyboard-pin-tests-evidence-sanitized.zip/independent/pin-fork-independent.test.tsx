// @vitest-environment jsdom
import {act,cleanup,fireEvent,render,renderHook,screen,waitFor} from '@testing-library/react';
import {afterEach,expect,it,vi} from 'vitest';
import {writeFileSync} from 'node:fs';
import {GraphPlanningFork} from '<workspace>/studio-v2-storyboard-pin-fork/frontend/src/creative/GraphPlanningFork';
import {planningSourceReferences,planningStoryboardSourceFork} from '<workspace>/studio-v2-storyboard-pin-fork/frontend/src/creative/graphPlanningForkHelpers';
import {checkedStudioGraphDraft} from '<workspace>/studio-v2-storyboard-pin-fork/frontend/src/creative/studioGraphClient';
import {blankGraph} from '<workspace>/studio-v2-storyboard-pin-fork/frontend/src/creative/graphDraft';
import {buildStoryboardVideoBranches} from '<workspace>/studio-v2-storyboard-pin-fork/frontend/src/creative/graphStoryboardStarterHelpers';
import {checkedStoryboardReceipt,type StoryboardReceipt} from '<workspace>/studio-v2-storyboard-pin-fork/frontend/src/creative/studioStoryboardContract';
import {imageGraphRecord} from '<workspace>/studio-v2-storyboard-pin-fork/frontend/src/creative/studioImageGraph.testFixtures';
import {useStudioGraphEditorController,type StudioGraphEditorProps} from '<workspace>/studio-v2-storyboard-pin-fork/frontend/src/creative/useStudioGraphEditorController';
import catalog from '<workspace>/studio-v2-storyboard-pin-fork/frontend/src/creative/fixtures/phase5.capture.video-catalog.json';
import capturedReceipt from '<workspace>/studio-v2-storyboard-pin-fork/frontend/src/creative/fixtures/phase5.capture.storyboard-video-approved.json';

afterEach(cleanup);
const record=(name:string,value:unknown)=>writeFileSync(name,JSON.stringify(value,null,2));
const read=async<T,>(work:()=>Promise<T>)=>work();
function fixture(){
 const {video_result:_video,...template}=capturedReceipt.shots[0];
 const old=checkedStoryboardReceipt({...capturedReceipt,shots:Array.from({length:4},(_,i)=>({...template,image_asset:null,
  shot_id:'preserved-shot-'+(i+1),shot_version:i+1,shot_digest:String(i+1).repeat(64),
  shot:{...template.shot,id:'preserved-shot-'+(i+1),number:i+1,continuity:{characters:'A',outfit:'red',environment:'room',camera:'same'}}}))});
 let seq=0;const draft=buildStoryboardVideoBranches({...blankGraph(),schema_version:5},catalog as never,old,old.shots.map(s=>s.shot_id),p=>p+'-review-'+(++seq));
 const nodeId=draft.nodes.find(n=>n.definition_id==='storyboard_plan')!.id;
 const other={...structuredClone(draft.nodes.find(n=>n.id===nodeId)!),id:'other-planning-reference'};
 other.parameters.document_snapshot={...old.document_snapshot,version:old.document_snapshot.version+1,digest:'9'.repeat(64)};
 draft.nodes.push(other);
 const shots=draft.nodes.filter(n=>n.definition_id==='storyboard_shot');
 for(const shot of shots.slice(2))draft.edges.find(e=>e.target_node_id===shot.id&&e.target_port==='storyboard')!.source_node_id=other.id;
 shots[3].enabled=false;
 for(const node of draft.nodes.filter(n=>n.definition_id==='video_generate'))Object.assign(node.parameters,{provider_id:'review-provider',model_id:'review-model',prompt:'Unchanged video author intent',parameters:{seed:37},license_note:'Keep own note',allow_cloud:false});
 draft.presentation={comment:'Preserved graph annotation'};draft.viewport={x:23,y:45,zoom:1.3};
 const receipt=structuredClone(old);receipt.document_snapshot.version+=2;receipt.document_snapshot.digest='e'.repeat(64);
 for(const [i,shot] of receipt.shots.entries())if(i!==1){shot.shot_version+=3;shot.shot_digest=String(i+5).repeat(64);shot.shot.lens='new lens '+i;}
 receipt.shots.reverse();receipt.shots.forEach((shot,i)=>shot.shot.number=i+1);
 const document={...receipt.document_snapshot,title:'Latest approved story board',mode:'STORYBOARD' as const};
 return{old,draft,nodeId,receipt,document,parents:[nodeId,other.id]};
}
function expected(f:ReturnType<typeof fixture>){
 const value=structuredClone(f.draft);
 for(const n of value.nodes){
  if(f.parents.includes(n.id))n.parameters.document_snapshot={...f.receipt.document_snapshot};
  if(n.definition_id==='storyboard_shot'){
   const s=f.receipt.shots.find(s=>s.shot_id===n.parameters.shot_id)!;n.parameters.shot_version=s.shot_version;n.parameters.shot_digest=s.shot_digest;
  }
 }
 return value;
}

it('keeps mixed document generations and reordered stable Shot IDs coherent; rejects partial, removed, unapproved and mismatched receipts atomically',()=>{
 const f=fixture(),before=structuredClone(f.draft),receiptBefore=structuredClone(f.receipt),result=planningStoryboardSourceFork(f.draft,f.nodeId,f.document,f.receipt,f.parents);
 expect(result.definition).toEqual(expected(f));expect(checkedStudioGraphDraft(result.definition)).toEqual(result.definition);
 expect(result.documents).toHaveLength(2);expect(result.shots).toHaveLength(4);
 expect(result.definition.nodes.find(n=>n.definition_id==='storyboard_shot'&&n.parameters.shot_id==='preserved-shot-2')!.parameters.shot_version).toBe(2);
 expect(result.definition.nodes.filter(n=>n.definition_id==='storyboard_shot')[3].enabled).toBe(false);
 const rejections=[];
 for(const mode of ['partial_old_refs','unapproved','document_version','document_digest','removed_stable_id','too_many_nodes']){
  const r=structuredClone(f.receipt),d=structuredClone(f.draft);let ids=f.parents;
  if(mode==='partial_old_refs')ids=[f.nodeId];if(mode==='unapproved')r.approved=false;
  if(mode==='document_version')r.document_snapshot.version++;if(mode==='document_digest')r.document_snapshot.digest='f'.repeat(64);
  if(mode==='removed_stable_id')r.shots=r.shots.filter(s=>s.shot_id!=='preserved-shot-3');
  if(mode==='too_many_nodes'){
   const n={...structuredClone(d.nodes.find(n=>n.definition_id==='storyboard_shot')!),id:'fifth-shot-reference'};d.nodes.push(n);
   d.edges.push({id:'fifth-shot-link',source_node_id:f.nodeId,source_port:'storyboard',target_node_id:n.id,target_port:'storyboard'});
  }
  const dBefore=structuredClone(d);expect(()=>planningStoryboardSourceFork(d,f.nodeId,f.document,r,ids)).toThrow();expect(d).toEqual(dBefore);rejections.push(mode);
 }
 expect(f.draft).toEqual(before);expect(f.receipt).toEqual(receiptBefore);
 record('case1-pin-coherence.json',{documents:result.documents,shots:result.shots,rejections,before,after:result.definition});
});

it('uses original independent draft and explicit create Save while preserving the source graph and history; revoked old controller intent cannot stage',async()=>{
 localStorage.clear();const f=fixture();
 const original={...imageGraphRecord(),definition:f.draft,reference_states:f.parents.map(node_id=>({node_id,state:'STALE' as const})),can_edit:true};
 const history=[{version:original.version,definition:structuredClone(f.draft),definition_digest:original.definition_digest}];
 const persistedBefore=JSON.stringify({original,history});
 const create=vi.fn(async(body:any)=>({...structuredClone(original),id:'independent-review-fork',version:1,definition:checkedStudioGraphDraft(body.definition),reference_states:f.parents.map(node_id=>({node_id,state:'CURRENT' as const}))}));
 const save=vi.fn(),createRun=vi.fn();
 const client={graphs:{catalog:vi.fn(async()=>catalog),videoCatalog:vi.fn(async()=>catalog),list:vi.fn(async()=>({items:[structuredClone(original)]})),get:vi.fn(async()=>structuredClone(original)),create,save,createRun}} as any;
 const base:StudioGraphEditorProps={active:true,denied:false,identity:'independent-fork-owner',client,canMutate:true,canReview:true,busy:false,externalDirty:false,isCurrent:()=>true,read,mutate:read};
 const hook=renderHook(extra=>useStudioGraphEditorController({...base,...extra}),{initialProps:{} as Partial<StudioGraphEditorProps>});
 await waitFor(()=>expect(hook.result.current.loading).toBe(false));await act(async()=>hook.result.current.open(original.id));act(()=>hook.result.current.setSelected([f.nodeId]));
 const old=hook.result.current.preparePlanningGraphFork,scope=hook.result.current.planningForkScope;
 hook.rerender({canMutate:false});act(()=>expect(old(f.document,scope,f.parents,f.receipt)).toBe(false));
 hook.rerender({});act(()=>expect(old(f.document,scope,f.parents,f.receipt)).toBe(false));
 const current=hook.result.current;act(()=>expect(current.preparePlanningGraphFork(f.document,current.planningForkScope,f.parents)).toBe(false));
 expect(hook.result.current.base?.id).toBe(original.id);
 act(()=>expect(hook.result.current.preparePlanningGraphFork(f.document,hook.result.current.planningForkScope,f.parents,f.receipt)).toBe(true));
 expect(hook.result.current.base).toBeUndefined();expect(hook.result.current.draft).toEqual(expected(f));
 expect(create).not.toHaveBeenCalled();expect(save).not.toHaveBeenCalled();expect(createRun).not.toHaveBeenCalled();
 expect(JSON.stringify({original,history})).toBe(persistedBefore);
 await act(async()=>hook.result.current.save());expect(create).toHaveBeenCalledTimes(1);expect(save).not.toHaveBeenCalled();expect(createRun).not.toHaveBeenCalled();
 expect(create.mock.calls[0][0].definition).toEqual(expected(f));expect(JSON.stringify({original,history})).toBe(persistedBefore);
 record('case2-original-owner.json',{source_id:original.id,original_and_history_unchanged:true,old_authority_callback_rejected:true,missing_coupled_receipt_rejected:true,create_calls:create.mock.calls.length,source_save_calls:save.mock.calls.length,run_calls:createRun.mock.calls.length,new_definition:create.mock.calls[0][0].definition});
});

const button=(name:string)=>screen.getByRole('button',{name});
const inspect=()=>fireEvent.click(button('核对更新来源用于独立新图'));
const consent=()=>fireEvent.click(screen.getByRole('checkbox',{name:'已核对全部文档及镜头 pin，确认准备独立新图草稿，保留原图'}));
const handler=(element:HTMLElement)=>((element as any)[Object.keys(element).find(k=>k.startsWith('__reactProps$'))!].onClick as ()=>void);
function props(){const f=fixture();return{...f,pin:f.old.document_snapshot,definition:f.draft,scope:{},mode:'STORYBOARD' as const,disabled:false,isCurrent:()=>true,read,references:planningSourceReferences(f.draft,f.nodeId),prepare:vi.fn(()=>true),client:{planningDocuments:vi.fn(async()=>({documents:[f.document]})),videoStoryboard:vi.fn(async()=>f.receipt)}};}
it('retires old coupled preview and consent on permission/client/definition/pin/scope ABA and refuses a late old receipt',async()=>{
 const observed=[];
 for(const mode of ['disabled','client','definition','pin','scope','unmount']){
  const p=props(),view=render(<GraphPlanningFork {...p}/>);inspect();await screen.findByLabelText('更新分镜与镜头 pin 预览');consent();
  const old=handler(button('准备使用更新来源的独立草稿')),next={...p};
  if(mode==='disabled')next.disabled=true;if(mode==='client')next.client={...p.client};if(mode==='definition')next.definition=structuredClone(p.definition);
  if(mode==='pin')next.pin={...p.pin};if(mode==='scope')next.scope={};
  if(mode==='unmount')view.unmount();else{view.rerender(<GraphPlanningFork {...next}/>);view.rerender(<GraphPlanningFork {...p}/>);}
  act(old);expect(p.prepare).not.toHaveBeenCalled();
  if(mode!=='unmount'){
   inspect();await screen.findByLabelText('更新分镜与镜头 pin 预览');consent();act(old);expect(p.prepare).not.toHaveBeenCalled();
   const fresh=handler(button('准备使用更新来源的独立草稿'));act(()=>{fresh();fresh();});expect(p.prepare).toHaveBeenCalledTimes(1);
   expect(p.prepare).toHaveBeenCalledWith(p.document,p.scope,p.parents,p.receipt);view.unmount();
  }
  observed.push({mode,old_callback_writes:0,fresh_prepares:p.prepare.mock.calls.length});
 }
 const p=props();let finish!:(value:StoryboardReceipt)=>void;
 p.client.videoStoryboard=vi.fn(()=>new Promise<StoryboardReceipt>(resolve=>finish=resolve));
 const view=render(<GraphPlanningFork {...p}/>);inspect();await waitFor(()=>expect(p.client.videoStoryboard).toHaveBeenCalledTimes(1));
 const next=props();view.rerender(<GraphPlanningFork {...next}/>);await act(async()=>finish(p.receipt));
 expect(screen.queryByLabelText('更新分镜与镜头 pin 预览')).toBeNull();expect(p.prepare).not.toHaveBeenCalled();expect(next.prepare).not.toHaveBeenCalled();
 record('case3-stale-authority.json',{observed,late_old_receipt_discarded:true});
});
