"""Independent closure: only the original three File queue counterexamples + one positive."""
from copy import deepcopy
import hashlib,json
from pathlib import Path
import pytest
from test_denoise_review import file_rig,prepare
from test_v2_audio_wav_controls import queue,get,production
from test_v2_independent_workspace import reopened
from app.services.studio_audio_execution import _binding
from app.services.audiobook_service import AudiobookError
from app.creative.production_execution import digest

EVIDENCE=Path(__file__).resolve().parents[2]/'p2-closure'

def record(name,value):
    (EVIDENCE/name).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')

@pytest.fixture(autouse=True)
def forbid_execution(monkeypatch):
    import app.services.studio_timeline_export as native
    monkeypatch.setattr(native,'run_guarded_process',lambda *a,**k:pytest.fail('binding recheck must not execute any native filter'))

@pytest.mark.parametrize('mode,code,status',[
    ('missing_command','STUDIO_AUDIO_DENOISE_BINDING_REQUIRED',403),
    ('missing_recipe','STUDIO_AUDIO_DENOISE_BINDING_REQUIRED',403),
    ('command_profile_removed','STUDIO_AUDIO_DENOISE_BINDING_CHANGED',409),
])
def test_original_inconsistent_binding_rejected_by_original_file_queue(file_rig,mode,code,status):
    e=prepare(file_rig,'p2-'+mode);normal=queue(e);owner=e.production._audio(e.scope,e.actor)
    stored=owner.store.load(e.nid,include_studio=True)['jobs'][0]
    context=deepcopy(stored['context']);context['request_id']='independent-binding-'+mode
    context['command']['request_id']=context['request_id']
    if mode=='missing_command':context.pop('command')
    elif mode=='missing_recipe':context.pop('execution_recipe')
    else:context['command']['parameters'].pop('denoise_profile')
    if 'command' in context:
        context['request_digest']=digest({'context':{k:v for k,v in context.items() if k not in {'command','request_digest'}},'command':context['command']})
    errors={}
    for stage,invoke in [
        ('binding',lambda:_binding(context,stored['_studio_body'])),
        ('file_queue',lambda:owner.queue(e.nid,stored['_studio_body'],context,lambda:None,e.production._source_guard(e.nid,e.scope,lambda:None))),
    ]:
        with pytest.raises(AudiobookError) as failure:invoke()
        assert (failure.value.code,failure.value.status)==(code,status)
        errors[stage]={'code':failure.value.code,'status':failure.value.status}
    jobs=owner.store.load(e.nid,include_studio=True)['jobs']
    assert len(jobs)==1 and jobs[0]['id']==normal['id'] and jobs[0]['status']=='QUEUED' and jobs[0]['attempt']==0
    assert get(e,normal)==normal and normal['output_candidate'] is None
    assert len(e.service.list_assets(e.nid,e.scope)['items'])==1
    record(mode+'.json',{'mode':mode,'errors':errors,'persisted_jobs':len(jobs),'normal_job_id':normal['id'],'native_executions':0,'inconsistent_jobs_created':0,'external_permission_bypass_claimed':False})


def test_legitimate_denoise_file_queue_remains_bound_durable_and_idempotent(file_rig):
    e=prepare(file_rig,'p2-legitimate');normal=queue(e);owner=e.production._audio(e.scope,e.actor)
    stored=owner.store.load(e.nid,include_studio=True)['jobs'][0]
    assert _binding(stored['context'],stored['_studio_body'])==stored['context']
    assert queue(e)==normal
    second=reopened(e);e.production=production(e,second)
    assert get(e,normal)==normal
    jobs=e.production._audio(e.scope,e.actor).store.load(e.nid,include_studio=True)['jobs']
    assert len(jobs)==1 and jobs[0]['attempt']==0
    assert normal['status']=='QUEUED' and normal['output_candidate'] is None and normal['media_measurement'] is None
    assert len(second.list_assets(e.nid,e.scope)['items'])==1
    assert hashlib.sha256((e.assets.root/(e.source['id']+'.bin')).read_bytes()).hexdigest()==e.source['sha256']
    record('legitimate.json',{'status':normal['status'],'normal_job_id':normal['id'],'persisted_jobs':len(jobs),'reopen_equals':True,'idempotent_equals':True,'source_sha256':e.source['sha256'],'native_executions':0,'auto_approved':False})
