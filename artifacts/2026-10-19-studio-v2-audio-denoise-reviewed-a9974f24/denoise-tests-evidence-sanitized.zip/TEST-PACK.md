# Limited CPU/File denoise test pack

The bundle contains the original denoise and binding regression tests plus frontend receipt fixture/tests. Two unique independent probes are retained in test-pack; they require the frozen original test helpers already present in the prerequisite repository. Set PROJECT_ROOT and isolated LOCALAPPDATA/NOVEL_DATA_PATH under a disposable worktree .runtime. Use existing installed FFmpeg/Python/Node dependencies only.

Integration selected exactly the real File /api import-filter-private-candidate-review-Asset case and one missing-command File binding case; frontend selected denoise and retained subgraph receipt codecs. Full author suites were not rerun. See integration/validation.json for exact selection and the initial sparse import harness failure.

Independent initial internal binding failures and the final4/4 closure remain separate. No external permission bypass or inconsistent native execution was claimed. PG is BLOCKED; speech quality and full E2E remain unaccepted. No user profiles, credentials, dependencies, models, raw traces or historical source tree copies are included.
