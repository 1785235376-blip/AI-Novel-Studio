import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
evidence = Path(__file__).resolve().parent
root = evidence.parents[1] / 'cap'
spec = importlib.util.spec_from_file_location('owned_runner', root / 'scripts/run_v2_checks.py')
runner = importlib.util.module_from_spec(spec); spec.loader.exec_module(runner)
env = os.environ.copy()
for key in list(env):
    if key.endswith(('_API_KEY', '_TOKEN', '_SECRET')) or key in {'DATABASE_URL', 'TEST_POSTGRES_DATABASE_URL', 'COLLABORATION_DEV_SESSIONS_JSON', 'PACKAGED_CONTROL_PIPE'}: env.pop(key, None)
env.update(runner.isolated_environment(root, root / '.runtime' / 'v2-checks' / 'denoise-binding'))
phase = sys.argv[1]
assert phase in {'red', 'green'}
base_temp = root / '.runtime' / 'v2-checks' / 'denoise-binding' / ('pytest-' + phase)
assert base_temp.resolve().is_relative_to((root / '.runtime').resolve())
env['DENOISE_BINDING_EVIDENCE_DIR'] = str(evidence / phase)
targets = ['tests/test_v2_audio_denoise_binding.py']
if phase == 'green':
    targets += ['tests/test_v2_audio_denoise.py::test_real_file_import_denoise_private_candidate_review_saved_asset',
        'tests/test_v2_audio_fade_contract.py::test_frozen_pre_edit_canonical_bytes_and_all_original_hashes']
command = [sys.executable, '-m', 'pytest', '-q', *targets, '-m', 'not postgres_backend_only', '-k', 'not v1', '-p', 'no:cacheprovider', '--tb=short', '--basetemp', str(base_temp)]
result = subprocess.run(command, cwd=root, env=env, capture_output=True, encoding='utf-8', errors='replace')
(evidence / (phase + '.log')).write_text(result.stdout + result.stderr, encoding='utf-8')
(evidence / (phase + '-status.json')).write_text(json.dumps({'phase': phase, 'exit_code': result.returncode,
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(), 'targets': targets}), encoding='utf-8')
print(result.stdout + result.stderr)
sys.exit(result.returncode)
