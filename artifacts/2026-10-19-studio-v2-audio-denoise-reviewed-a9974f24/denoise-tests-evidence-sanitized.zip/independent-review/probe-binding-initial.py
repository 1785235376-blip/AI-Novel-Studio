from copy import deepcopy
import hashlib,io,json,math,random,struct,sys,wave
from pathlib import Path
from types import SimpleNamespace
import pytest
ROOT=Path(__file__).resolve().parents[1];EVIDENCE=ROOT.parent
sys.path.insert(0,str(ROOT/'tests'))
from test_v2_independent_workspace import rig,import_asset,reopened
from test_v2_audio_wav_controls import production,command,snapshot,queue,run,get,review,action
from test_v2_audio_fade_contract import captured
from app.services.studio_audio_execution import _body,_binding,StudioAudioExecution
from app.services.studio_audio_denoise import PROFILE,FILTER,validate_proof
from app.services.audiobook_service import AudiobookError
from app.creative.production_execution import digest
from app.creative.production_execution_models import MediaCommand,MediaReview
from app.creative.graph_models import MediaNodeParameters
@pytest.fixture
def file_rig(tmp_path,monkeypatch):yield from rig.__wrapped__(SimpleNamespace(param='file'),tmp_path,monkeypatch)

def test_denoise3_new_profile_requires_exact_command_recipe_binding_at_original_audio_owner():
    raw=command(in_ms=1000,out_ms=4500,sample_rate=22050,channels=2,denoise_profile=PROFILE)
    _,valid,_,body=captured(raw);assert _binding(valid,body)==valid
    admitted=[]
    for mode in ['missing_command','missing_recipe','command_profile_removed']:
        context=deepcopy(valid)
        if mode=='missing_command':context.pop('command')
        elif mode=='missing_recipe':context.pop('execution_recipe')
        else:
            context['command']['parameters'].pop('denoise_profile')
            context['request_digest']=digest({'context':{k:v for k,v in context.items() if k not in {'command','request_digest'}},'command':context['command']})
        try:_binding(context,body);admitted.append(mode)
        except (AudiobookError,ValueError):pass
    (EVIDENCE/'binding-counterexample.json').write_text(json.dumps({'profile':PROFILE,'incorrectly_admitted':admitted,'normal_request_is_valid':True,'source_snapshots_retained':body['source_snapshots'],'note':'Original Audio binding helper accepts new-profile jobs lacking original command/recipe or with command describing plain trim. This probe uses original capture helper; no external permission or paid-execution bypass is claimed.'},indent=2),encoding='utf-8')
    assert admitted==[], 'New denoise profile omitted from immutable command/recipe binding fence: '+repr(admitted)


def prepare(e, label):
    e.nid=e.create_project('Independent denoise review '+label)
    e.scope={'mode':'local','novel_id':e.nid}
    e.service.activate(e.nid,e.scope,e.actor)
    rate=22050;channels=2;rng=random.Random(701206)
    frames=[]
    for i in range(rate*6):
        tone=4700*math.sin(2*math.pi*617*i/rate) if rate*2<=i<rate*4 else 0
        frames.extend((round(tone+rng.uniform(-340,340)),round(.7*tone+rng.uniform(-270,270))))
    pcm=struct.pack('<'+'h'*len(frames),*frames);out=io.BytesIO()
    with wave.open(out,'wb') as w:
        w.setnchannels(channels);w.setsampwidth(2);w.setframerate(rate);w.writeframes(pcm)
    e.original=out.getvalue();e.selected=pcm[22050*4:99225*4]
    e.source=import_asset(e,data=e.original,filename='review-stereo-22050.wav',kind='audio')
    e.production=production(e)
    e.command=command(snapshot(e.source),in_ms=1000,out_ms=4500,sample_rate=rate,channels=channels,denoise_profile=PROFILE)
    e.command['request_id']='review-'+label
    return e

def persisted_source(e):
    return (e.assets.root/(e.source['id']+'.bin')).read_bytes()

def save_json(name,value):
    (EVIDENCE/name).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')


def test_denoise1_real_stereo_frame_pin_private_review_and_proof(file_rig,monkeypatch):
    e=prepare(file_rig,'positive');observed=[]
    import app.services.studio_timeline_export as native
    original=native.run_guarded_process
    def capture(argv,**kwargs):
        observed.append(list(argv));return original(argv,**kwargs)
    monkeypatch.setattr(native,'run_guarded_process',capture)
    queued=queue(e);candidate=run(e,queued)
    assert candidate['status']=='AWAITING_REVIEW',candidate
    measured=candidate['media_measurement'];proof=measured['noise_reduction'];pin=snapshot(e.source)
    meta,data=e.production.candidate(e.nid,e.scope,e.actor,'audio',candidate['id'],lambda:None)
    with wave.open(io.BytesIO(data),'rb') as decoded:
        assert (decoded.getframerate(),decoded.getnchannels(),decoded.getsampwidth(),decoded.getnframes())==(22050,2,2,77175)
        raw=decoded.readframes(decoded.getnframes())
    assert proof['selected_frames']==proof['output_frames']==77175
    assert proof['selected_pcm_sha256']==hashlib.sha256(e.selected).hexdigest()
    assert proof['output_pcm_sha256']==hashlib.sha256(raw).hexdigest()
    assert proof['output_sha256']==hashlib.sha256(data).hexdigest()==meta['sha256']==candidate['output_candidate']['digest']
    assert (proof['source_id'],proof['source_version'],proof['source_sha256'])==(pin['id'],pin['version'],pin['digest'])
    assert (proof['in_ms'],proof['out_ms'])==(1000,4500)
    assert validate_proof(proof,e.command['parameters'],proof['output_sha256'],pin)==proof
    assert len(observed)==1
    argv=observed[0]
    assert argv[argv.index('-af')+1]=='atrim=start_sample=22050:end_sample=99225,asetpts=PTS-STARTPTS,'+FILTER
    assert argv[argv.index('-protocol_whitelist')+1]=='file,pipe' and '-nostdin' in argv
    assert '-ss' not in argv and '-t' not in argv
    assert len(e.service.list_assets(e.nid,e.scope)['items'])==1
    with pytest.raises(FileNotFoundError):e.service.asset(e.nid,e.scope,candidate['output_candidate']['id'])
    assert persisted_source(e)==e.original
    owner=e.production._audio(e.scope,e.actor);state=owner.store.load(e.nid,include_studio=True);saved=deepcopy(state)
    corruptions={'source_version':proof['source_version']+1,'in_ms':1001,'selected_frames':77174,'output_frames':77176,'output_rms_s16':'NaN','output_sha256':'d'*64}
    for key,value in corruptions.items():
        altered=deepcopy(saved);row=altered['jobs'][0];row['measured']['noise_reduction'][key]=value
        StudioAudioExecution._receipt(row);owner.store.save(e.nid,altered,include_studio=True)
        with pytest.raises(AudiobookError):get(e,candidate)
        with pytest.raises(AudiobookError):review(e,candidate)
    owner.store.save(e.nid,saved,include_studio=True)
    second=reopened(e);e.production=production(e,second)
    assert get(e,queued)==candidate
    with pytest.raises((AudiobookError,ValueError)):
        e.production.review(e.nid,e.scope,e.actor,'audio',candidate['id'],MediaReview(**action(candidate).model_dump(),reviewed_output_digest='d'*64),lambda:None)
    assert len(second.list_assets(e.nid,e.scope)['items'])==1
    approved=review(e,candidate);assert approved['status']=='APPROVED'
    assert approved['media_measurement']==measured
    asset=second.asset(e.nid,e.scope,candidate['output_candidate']['id'])
    assert asset['provenance']['origin']=='DERIVED_PROCESSING'
    assert [p['id'] for p in asset['provenance']['parents']]==[e.source['id']]
    assert second.download(e.nid,e.scope,asset['id'])[1]==data
    assert persisted_source(e)==e.original
    (EVIDENCE/'review-source.wav').write_bytes(e.original);(EVIDENCE/'review-denoised.wav').write_bytes(data)
    save_json('native-file.json',{'command':e.command,'source':e.source,'queued':queued,'candidate':candidate,'approved':approved,'asset':asset,'argv':argv,'corruptions_rejected':list(corruptions),'frames':77175,'source_pcm_sha256':hashlib.sha256(e.selected).hexdigest(),'output_pcm_sha256':hashlib.sha256(raw).hexdigest(),'output_sha256':hashlib.sha256(data).hexdigest()})


def test_denoise2_malformed_limits_actual_profile_and_frame_alignment(file_rig,monkeypatch):
    e=prepare(file_rig,'invalid')
    invalid=[{'denoise_profile':None},{'denoise_profile':True},{'denoise_profile':'afftdn=nr=90'},
        {'in_ms':True},{'in_ms':1000.5},{'out_ms':math.inf},{'out_ms':'4500'},
        {'out_ms':1999},{'in_ms':-1},{'in_ms':0,'out_ms':120001},
        {'gain_db':math.nan},{'gain_db':1},{'fade_in_ms':1},{'fade_out_ms':1},
        {'target_lufs':-23},{'target_peak_dbfs':-6},{'output_format':'FLAC'},{'output_format':'MP3'},
        {'sample_rate':True},{'channels':3},{'filter':'anull'}]
    for changes in invalid:
        raw=deepcopy(e.command);raw['parameters'].update(changes)
        with pytest.raises(ValueError):MediaCommand.model_validate(raw)
        with pytest.raises(AudiobookError):_body({k:v for k,v in raw.items() if k not in {'request_id','allow_cloud','license_note'}})
    large=deepcopy(e.command);large['parameters'].update(in_ms=0,out_ms=120000,sample_rate=96000,channels=2)
    with pytest.raises(AudiobookError) as failure:
        e.production.preview(e.nid,e.scope,e.actor,large,lambda:None)
    assert failure.value.code=='STUDIO_AUDIO_TRIM_BYTES_BUDGET_EXCEEDED'
    import app.services.studio_timeline_export as native
    monkeypatch.setattr(native,'run_guarded_process',lambda *a,**k:pytest.fail('invalid profile/range must not run filter'))
    actual=[]
    for label,changes in [('rate',{'sample_rate':24000}),('channel',{'channels':1}),('unaligned',{'in_ms':1001}),('past_source',{'out_ms':6500})]:
        raw=deepcopy(e.command);raw['request_id']='review-invalid-'+label;raw['parameters'].update(changes)
        result=run(e,queue(e,raw));assert result['status']=='FAILED' and result['output_candidate'] is None and result['media_measurement'] is None,result
        actual.append({'case':label,'error_code':result.get('error_code'),'status':result['status']})
    with pytest.raises(ValueError):MediaNodeParameters.model_validate({'operation_id':'m8.audio.trim','parameters':e.command['parameters']})
    assert len(e.service.list_assets(e.nid,e.scope)['items'])==1 and persisted_source(e)==e.original
    save_json('invalid-inputs.json',{'strict_model_and_owner_rejections':len(invalid),'capacity_error':failure.value.code,'real_file_failures':actual,'filter_calls':0})


def test_denoise4_source_version_change_and_cancel_after_real_filter(file_rig,monkeypatch):
    e=file_rig;results=[]
    import app.services.studio_timeline_export as native
    original=native.run_guarded_process
    for mode in ['source_version','cancel']:
        prepare(e,mode);queued=queue(e);encodes=[]
        def stop_after_filter(argv,**kwargs):
            result=original(argv,**kwargs)
            if '-af' in argv and FILTER in argv[argv.index('-af')+1]:
                encodes.append(list(argv))
                if mode=='source_version':
                    with e.service._asset_scope(e.nid,e.scope):
                        e.assets.update_metadata(e.source['id'],{'scene_id':'changed-after-filter'},expected_version=e.source['version'])
                else:
                    running=get(e,queued)
                    stopped=e.production.cancel(e.nid,e.scope,e.actor,'audio',queued['id'],action(running),lambda:None)
                    assert stopped['status']=='CANCELLED'
            return result
        monkeypatch.setattr(native,'run_guarded_process',stop_after_filter)
        result=run(e,queued)
        assert len(encodes)==1
        assert result['status']==('FAILED' if mode=='source_version' else 'CANCELLED'),result
        assert result['output_candidate'] is None and result['media_measurement'] is None
        assert len(e.service.list_assets(e.nid,e.scope)['items'])==1 and persisted_source(e)==e.original
        assert len(list(e.assets.root.glob('*.bin')))==len(results)+1
        monkeypatch.setattr(native,'run_guarded_process',lambda *a,**k:pytest.fail('cancel/failure must never rerun'))
        with pytest.raises((AudiobookError,ValueError)):run(e,result)
        results.append({'mode':mode,'job':result,'real_filter_calls':len(encodes)})
    save_json('source-cancel.json',{'phases':results})


def test_denoise5_unknown_recovers_exact_private_candidate_without_second_filter(file_rig,monkeypatch):
    e=prepare(file_rig,'unknown');queued=queue(e);create=e.assets.create;published=[]
    def lost(*args,**kwargs):
        row=create(*args,**kwargs);published.append(row);raise OSError('independent simulated lost publication reply')
    monkeypatch.setattr(e.assets,'create',lost)
    interrupted=run(e,queued)
    assert interrupted['status']=='UNKNOWN' and interrupted['media_measurement']['noise_reduction'] and len(published)==1,interrupted
    monkeypatch.setattr(e.assets,'create',create)
    import app.services.studio_timeline_export as native
    monkeypatch.setattr(native,'run_guarded_process',lambda *a,**k:pytest.fail('UNKNOWN recovery must not execute native filter again'))
    recovered=e.production.reconcile(e.nid,e.scope,e.actor,'audio',queued['id'],action(interrupted),lambda:None)
    assert recovered['status']=='AWAITING_REVIEW' and recovered['attempt']==1
    assert recovered['media_measurement']==interrupted['media_measurement']
    candidate=recovered['output_candidate'];assert candidate['digest']==recovered['media_measurement']['noise_reduction']['output_sha256']
    assert len(e.service.list_assets(e.nid,e.scope)['items'])==1
    with pytest.raises(FileNotFoundError):e.service.asset(e.nid,e.scope,candidate['id'])
    assert len(list(e.assets.root.glob('*.bin')))==2 and persisted_source(e)==e.original
    _,data=e.production.candidate(e.nid,e.scope,e.actor,'audio',queued['id'],lambda:None)
    assert hashlib.sha256(data).hexdigest()==candidate['digest']
    approved=review(e,recovered);assert approved['status']=='APPROVED' and approved['media_measurement']==recovered['media_measurement']
    assert review(e,approved)==approved
    save_json('unknown-recovery.json',{'interrupted':interrupted,'recovered':recovered,'approved':approved,'asset_create_calls':len(published),'recovery_filter_calls':0,'candidate_sha256':hashlib.sha256(data).hexdigest()})
