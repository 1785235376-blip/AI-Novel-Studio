"""Bounded archival convergence over the original graph and asset owners.

This is not a queue, asset database, dispatch authority or review state machine.
Each authorized read/refresh makes at most one attempt. A durable completed job
may be archived after restart, but its former execution closure is never rebuilt.
"""
from __future__ import annotations

from contextlib import contextmanager
from contextvars import ContextVar
from collections import OrderedDict
from copy import deepcopy
from datetime import datetime, timezone
from hashlib import sha256
from threading import Lock
from uuid import UUID
import time

from ..experimental.common import StaleSourceError, check_version
from ..experimental.store import canonical
from .graph_models import validate_output_ports
from .project_store import BINDING
from .text_execution_receipt import (CONTRACT as EXECUTION_CONTRACT, PRIVATE_FIELD,
    public_receipt, receipt_payload, request_payload, validate_receipt)

CONTRACT = "creative-graph-text-asset/1"
_phase = ContextVar("graph_text_asset_read_authority", default=None)


class GraphTextAssets:
    def __init__(self, runtime):
        self.runtime, self.service = runtime, runtime.service
        self.workspace, self.assets = self.service.workspace, self.service.workspace.assets
        # Bounded, transient retry suppression only. Durable state remains in
        # the original owners; this never schedules or repeats model work.
        self._cooldowns, self._cooldown_lock = OrderedDict(), Lock()

    @staticmethod
    def enabled(row):
        return row.get("model_asset_intent", {}).get("contract") == CONTRACT

    def validate_intent(self, row):
        intent = row.get("model_asset_intent")
        if intent is None:
            return
        execution, preview = row.get("model_execution") or {}, row.get("model_preview") or {}
        expected = {"contract", "job_id", "source_run_version", "preview_digest"}
        if isinstance(intent, dict) and "execution_receipt_contract" in intent:
            expected.add("execution_receipt_contract")
            if intent["execution_receipt_contract"] != EXECUTION_CONTRACT:
                raise StaleSourceError("CREATIVE_TEXT_EXECUTION_CONTRACT_CHANGED")
        if (not isinstance(intent, dict) or set(intent) != expected
                or intent["contract"] != CONTRACT or intent["job_id"] != execution.get("job_id")
                or type(intent["source_run_version"]) is not int or not 1 <= intent["source_run_version"] <= row["version"]
                or intent["preview_digest"] != preview.get("preview_digest")):
            raise StaleSourceError("CREATIVE_TEXT_ASSET_INTENT_CHANGED")

    def _key(self, row):
        return "graph-text:" + sha256(canonical([CONTRACT, row[BINDING], row["scope"], row["created_by"],
            row["id"], row["model_asset_intent"]]).encode()).hexdigest()

    def _job(self, row):
        """Require original durable completion, never infer success from text."""
        execution, preview = row["model_execution"], row["model_preview"]
        job = self.runtime.bound_job(row)
        saved = self.runtime.manager.persistence.get(job.id)
        if not isinstance(saved, dict):
            raise StaleSourceError("CREATIVE_TEXT_ASSET_COMPLETION_UNCONFIRMED")
        fields = ("id", "novel_id", "actor_id", "scope", "operation", "experimental_origin", "graph_binding",
            "requested_provider", "requested_model", "provider", "model", "output", "status", "execution_outcome",
            "terminal_hook_status", "expected_request_digest", "created_at", "updated_at")
        if row["model_asset_intent"].get("execution_receipt_contract"):
            fields += ("execution_mode", "profile", "chapter_id", "generation_max_output_bytes", "generation_deadline")
        if any(saved.get(key) != getattr(job, key, None) for key in fields):
            raise StaleSourceError("CREATIVE_TEXT_ASSET_DURABLE_JOB_CHANGED")
        if (saved.get("status") != "COMPLETED" or saved.get("execution_outcome") != "COMPLETED"
                or saved.get("terminal_hook_status") != "COMPLETED" or saved.get("operation") != "graph_text"
                or saved.get("experimental_origin") != "creative_graph_model"
                or (saved.get("provider"), saved.get("model")) != (preview["route"]["provider_id"], preview["route"]["model_id"])):
            raise StaleSourceError("CREATIVE_TEXT_ASSET_COMPLETION_UNCONFIRMED")
        ledger = self.runtime.broker.get(row["novel_id"], row["scope"], self.runtime.broker.LEDGER, execution["reservation_id"])
        if (ledger.get("created_by") != row["created_by"] or ledger.get("job_id") != job.id
                or ledger.get("status") != "SETTLED" or ledger.get("job_status") != "COMPLETED"
                or ledger.get("actual_microusd") != 0 or not ledger.get("dispatched")):
            raise StaleSourceError("CREATIVE_TEXT_ASSET_SETTLEMENT_UNCONFIRMED")
        validate_output_ports("text_generate", {"draft": {"text": job.output, "origin": "MODEL_PROPOSAL"}})
        return job

    def _route(self, row):
        """Current registered identity, without recreating historical consent."""
        preview = row["model_preview"]
        route = self.runtime.broker.current_route(preview["route"]["route_id"], local_text_only=True)
        self.runtime.router.guard_route(route, synthetic_allowed=preview["allow_synthetic"])
        job = self.runtime.bound_job(row)
        if (route["fingerprint"] != job.graph_binding.get("route_fingerprint")
                or not route["synthetic"] and not route.get("identity", {}).get("license_confirmed")):
            raise StaleSourceError("CREATIVE_TEXT_ASSET_ROUTE_CHANGED")
        from ..model_execution import LocalModelInvocation
        from ..model_center.discovery_bridge import LocalTextAdapter
        invocation = LocalModelInvocation(self.runtime.broker.runtime, route["provider_id"], route["model_id"],
            synthetic_allowed=preview["allow_synthetic"])
        provider = invocation._provider
        registration = deepcopy(provider.bridge.guard(provider.candidate["id"])) if type(provider) is LocalTextAdapter else None
        synthetic_config = None if registration is not None else (
            getattr(provider.provider, "delay_ms", None), getattr(provider.provider, "failure", None))
        def current_registration():
            invocation.validate()
            if registration is not None:
                if provider.bridge.guard(provider.candidate["id"]) != registration:
                    raise StaleSourceError("CREATIVE_TEXT_ASSET_ROUTE_CHANGED")
            elif synthetic_config != (getattr(provider.provider, "delay_ms", None), getattr(provider.provider, "failure", None)):
                raise StaleSourceError("CREATIVE_TEXT_ASSET_ROUTE_CHANGED")
        current_registration()
        return current_registration

    def _source(self, nid, scope, actor, rid, guard, state=None):
        row = self.runtime.row(nid, scope, actor, rid, guard, state)
        self.validate_intent(row)
        if not self.enabled(row):
            raise ValueError("CREATIVE_TEXT_ASSET_CONTRACT_REQUIRED")
        return row

    @contextmanager
    def _lease(self, nid, scope, actor, rid, guard):
        if self.runtime.broker.store is not self.service.store.store:
            raise ValueError("CREATIVE_TEXT_ASSET_SHARED_SCOPE_OWNER_REQUIRED")
        row = self.service._owned(nid, scope, actor, self.service.RUNS, rid)
        if row.get("graph_schema_version") == 3:
            # Share schema 3's writable raw-scope -> asset -> project phase
            # while completing/reviewing the original workflow. Never open a
            # nested raw transaction or acquire assets after a project lease.
            with self.service.asset_inputs.phase(nid, scope, actor, guard) as state:
                yield self._source(nid, scope, actor, rid, guard, state)
                guard()
            return
        with self.service.store.source_lease(nid, scope) as state:
            with self.workspace._asset_scope(nid, scope):
                row = self._source(nid, scope, actor, rid, guard, state)
                yield row
                guard()

    def _find(self, row):
        matches = [asset for asset in self.assets.list(row["novel_id"], branch_id=row["scope"].get("branch_id"),
            actor_id=row["created_by"], include_deleted=True) if asset.get("idempotency_key") == self._key(row)]
        if len(matches) > 1:
            raise ValueError("CREATIVE_TEXT_ASSET_IDENTITY_AMBIGUOUS")
        return matches[0] if matches else None

    def _origin_payload(self, row, *, source_run_version, job_id, output_digest, produced_at):
        node = self.runtime.node(row)
        return {"schema_version": 1, "contract": CONTRACT, "graph_id": row["graph_id"],
            "graph_version": row["graph_version"], "graph_digest": row["graph_digest"], "run_id": row["id"],
            "source_run_version": source_run_version, "model_node_id": node["id"],
            "job_id": job_id, "input_digest": row["model_preview"]["input_digest"],
            "output_digest": output_digest, "preview_digest": row["model_preview"]["preview_digest"],
            "produced_at": produced_at}

    def validate_admission(self, row, route, source_run_version):
        """Use the actual archival encoders before any original Job is prepared.

        Only not-yet-created owner values need sizing stand-ins: JobManager
        emits str(uuid.uuid4()); request/output digests and ModelBroker's
        reservation key are SHA-256 hex; common.change_row stamps settlement
        with datetime.now(timezone.utc).isoformat(). datetime.max provides its
        longest possible UTC encoding (including six fractional digits).
        Every other value is the exact reviewed input/current route. These
        transient bytes grant no authority and are never persisted as evidence.
        """
        data = b"x"
        job_id = str(UUID(int=0))
        digest = sha256(data).hexdigest()
        origin = self._origin_payload(row, source_run_version=source_run_version, job_id=job_id,
            output_digest=digest, produced_at=datetime.max.replace(tzinfo=timezone.utc).isoformat())
        receipt = receipt_payload(row["model_preview"], self.runtime.node(row), route, origin,
            execution_mode="mock_standin" if route["synthetic"] else "real",
            request_digest=digest, settlement_id=digest)
        initial = self.assets.text_result_metadata(source_receipt=origin, source_job_id=job_id,
            provider_id=route["provider_id"], model_id=route["model_id"], parameters=self._parameters(row),
            execution_receipt=receipt)
        # Keep both original limits/errors: receipt first, then the complete
        # containing initial metadata (which repeats source/model/parameters).
        self.assets._text_initial(initial, data)

    def _origin(self, row, job):
        # JobManager's final notification legitimately changes job.updated_at
        # after its durable terminal hook. Use the original once-only completed
        # settlement's time, not that mutable notification timestamp.
        ledger = self.runtime.broker.get(row["novel_id"], row["scope"], self.runtime.broker.LEDGER,
            row["model_execution"]["reservation_id"])
        return self._origin_payload(row, source_run_version=row["model_asset_intent"]["source_run_version"],
            job_id=job.id, output_digest=sha256(job.output.encode()).hexdigest(), produced_at=ledger["updated_at"])

    def _execution_receipt(self, row, job, origin):
        """Verify passive provenance against the original durable owners.

        No adapter, prepared invocation, callback or dispatch permission is
        reconstructed. Legacy v1 archives remain byte-for-byte unextended.
        """
        if "execution_receipt_contract" not in row["model_asset_intent"]:
            return None
        from ..model_execution import graph_request_payload_digest
        preview = row["model_preview"]
        payload = request_payload(preview, self.runtime.node(row))
        if (job.graph_binding.get("execution_receipt_contract") != EXECUTION_CONTRACT
                or graph_request_payload_digest(job, payload, preview["allow_synthetic"]) != job.expected_request_digest):
            raise StaleSourceError("CREATIVE_TEXT_EXECUTION_REQUEST_CHANGED")
        decision = self.runtime.broker.get(row["novel_id"], row["scope"], self.runtime.broker.DECISIONS,
            preview["broker_preview_id"])
        check_version(decision, preview["broker_preview_version"])
        chosen = decision.get("chosen") or {}
        ledger = self.runtime.broker.get(row["novel_id"], row["scope"], self.runtime.broker.LEDGER,
            row["model_execution"]["reservation_id"])
        if (decision.get("created_by") != row["created_by"] or decision.get("novel_id") != row["novel_id"]
                or decision.get("scope") != row["scope"] or decision.get("status") != "PREVIEW"
                or any(chosen.get(key) != preview["route"][key] for key in
                    ("route_id", "provider_id", "model_id", "synthetic", "verification"))
                or chosen.get("fingerprint") != job.graph_binding["route_fingerprint"]
                or ledger.get("preview_id") != decision["id"]
                or ledger.get("authorization_digest") != preview["preview_digest"]
                or ledger.get("route_fingerprint") != chosen.get("fingerprint")
                or any(ledger.get(key) != chosen.get(key) for key in ("route_id", "provider_id", "model_id"))):
            raise StaleSourceError("CREATIVE_TEXT_EXECUTION_ROUTE_CHANGED")
        value = receipt_payload(preview, self.runtime.node(row), chosen, origin,
            execution_mode=job.execution_mode, request_digest=job.expected_request_digest, settlement_id=ledger["id"])
        return validate_receipt(value, source=origin, provider_id=job.provider, model_id=job.model,
            parameters=self._parameters(row))

    def _parameters(self, row):
        return {"max_output_tokens": self.runtime.node(row)["parameters"]["max_output_tokens"],
            "temperature": 0.0, "synthetic": row["model_preview"]["route"]["synthetic"], "quality_verification": "NOT_RUN"}

    def prepare_projection(self, row, guard):
        """Capture registered route authority before any persistence lease.

        This is transient preparation, not archive/dispatch authority. The
        existing original asset and durable completion are checked again inside
        the caller's exact source/asset phase before establishing a proof.
        """
        if not self.enabled(row) or row["node_states"][self.runtime.node(row)["id"]]["status"] != "SUCCEEDED":
            return None
        guard(); self.validate_intent(row); self._job(row)
        return (row[BINDING], deepcopy(row["model_preview"]), self._route(row))

    @contextmanager
    def projection(self, nid, scope, actor, rid, guard, prepared):
        """Establish read authority in an already held Graph asset phase.

        Never creates an archive, projects review, upgrades a readonly phase or
        opens another raw transaction. Slow route preparation ran outside.
        """
        if prepared is None:
            yield None
            return
        if not self.service.asset_inputs.in_phase(nid, scope, actor):
            raise ValueError("CREATIVE_TEXT_ASSET_LEASE_REQUIRED")
        asset, row, origin, route_guard = self.ensure(nid, scope, actor, rid, guard,
            create=False, _prepared=prepared)
        self.projected(asset, row, origin)
        with self._proof(nid, scope, actor, rid, guard, asset, row, origin, route_guard):
            yield (asset, row, origin)

    def _verify_private(self, row, asset, job, origin, execution_receipt):
        from .ai_execution import FLAGS
        expected_binding = {"novel_id": row["novel_id"], "branch_id": row["scope"].get("branch_id"),
            "scope_key": self.service.store.key(row["novel_id"], row["scope"]), "incarnation": row[BINDING]}
        if (not isinstance(asset, dict) or asset.get("deleted_at") or asset.get("kind") != "text"
                or asset.get("media_type") != "text/plain" or asset.get("novel_id") != row["novel_id"]
                or asset.get("branch_id") != row["scope"].get("branch_id")
                or asset.get("_owner_actor_id") != row["created_by"] or asset.get("_project_binding") != expected_binding
                or not set(FLAGS).issubset(asset.get("_required_features", []))
                or asset.get("_text_result_origin") != origin or asset.get(PRIVATE_FIELD) != execution_receipt
                or asset.get("source_job_id") != job.id or asset.get("provider_id") != job.provider
                or asset.get("model_id") != job.model or asset.get("parameters") != self._parameters(row)
                or self.assets.content(asset["id"], branch_id=row["scope"].get("branch_id"),
                    actor_id=row["created_by"]) != job.output.encode()):
            raise StaleSourceError("CREATIVE_TEXT_ASSET_OUTPUT_CHANGED")

    def current_under_asset_lease(self, nid, scope, actor, row, guard, prepared):
        """Pure archive fence in the original publication/promote asset lease.

        The caller checked the original raw scope first. No scope lookup,
        transaction, phase or route construction occurs here; broker reads see
        the caller's same already active raw document.
        """
        if prepared is None:
            if self.enabled(row) and row["node_states"][self.runtime.node(row)["id"]]["status"] == "SUCCEEDED":
                raise StaleSourceError("CREATIVE_TEXT_ASSET_ARCHIVE_INCOMPLETE")
            return
        if getattr(self.assets._scope, "binding", None) != {"novel_id": nid,
                "branch_id": scope.get("branch_id"), "incarnation": row[BINDING],
                "scope_key": self.service.store.key(nid, scope)}:
            raise ValueError("CREATIVE_TEXT_ASSET_LEASE_REQUIRED")
        incarnation, preview, route_guard = prepared
        guard(); route_guard()
        if row[BINDING] != incarnation or row["model_preview"] != preview or row["created_by"] != actor:
            raise StaleSourceError("CREATIVE_TEXT_ASSET_SOURCE_CHANGED")
        self.validate_intent(row)
        job = self._job(row)
        origin = self._origin(row, job)
        receipt = self._execution_receipt(row, job, origin)
        asset = self._find(row)
        self._verify_private(row, asset, job, origin, receipt)
        self.projected(asset, row, origin)
        output = row.get("typed_outputs", {}).get(self.runtime.node(row)["id"])
        if not output or output.get("draft", {}).get("text") != job.output:
            raise StaleSourceError("CREATIVE_TEXT_ASSET_OUTPUT_CHANGED")
        guard(); route_guard()

    def ensure(self, nid, scope, actor, rid, guard, *, create, _prepared=None):
        row = self._source(nid, scope, actor, rid, guard)
        # Slow metadata checks are outside the source/asset persistence lease.
        if _prepared is None:
            route_guard = self._route(row)
            incarnation, preview = row[BINDING], deepcopy(row["model_preview"])
        else:
            incarnation, preview, route_guard = _prepared
            if row[BINDING] != incarnation or row["model_preview"] != preview:
                raise StaleSourceError("CREATIVE_TEXT_ASSET_SOURCE_CHANGED")
        with self._lease(nid, scope, actor, rid, guard) as current:
            if current[BINDING] != incarnation or current["model_preview"] != preview:
                raise StaleSourceError("CREATIVE_TEXT_ASSET_SOURCE_CHANGED")
            job = self._job(current)
            origin = self._origin(current, job)
            execution_receipt = self._execution_receipt(current, job, origin)
            def fresh():
                guard()
                live = self._source(nid, scope, actor, rid, guard)
                if live != current:
                    raise StaleSourceError("CREATIVE_TEXT_ASSET_SOURCE_CHANGED")
                # No new probe/IO: exact registration still has its original
                # enablement and model identity. Full observation ran above.
                route_guard()
                if self._origin(live, self._job(live)) != origin:
                    raise StaleSourceError("CREATIVE_TEXT_ASSET_COMPLETION_CHANGED")
                if self._execution_receipt(live, job, origin) != execution_receipt:
                    raise StaleSourceError("CREATIVE_TEXT_EXECUTION_RECEIPT_CHANGED")
            asset = self._find(current)
            if asset is None and create:
                if current.get("graph_schema_version") == 3 and current["status"] != "RUNNING":
                    raise StaleSourceError("CREATIVE_TEXT_ASSET_ARCHIVE_INCOMPLETE")
                usage = self.assets.project_usage(nid, branch_id=scope.get("branch_id"))
                data = job.output.encode()
                if usage["count"] >= self.workspace.MAX_ASSETS or usage["bytes"] + len(data) > self.workspace.MAX_PROJECT_BYTES:
                    raise ValueError("CREATIVE_PROJECT_ASSET_QUOTA")
                self.workspace.storage_admission.require(len(data))
                from .ai_execution import FLAGS
                def before_commit():
                    fresh(); self.workspace.storage_admission.require(1)
                asset = self.assets.create_text_result(nid, "graph-" + rid + ".txt", job.output,
                    source_receipt=origin, provider_id=preview["route"]["provider_id"], model_id=preview["route"]["model_id"],
                    source_job_id=job.id, parameters=self._parameters(current), execution_receipt=execution_receipt,
                    idempotency_key=self._key(current), branch_id=scope.get("branch_id"), owner_actor_id=actor,
                    required_features=FLAGS, guard=before_commit)
            if asset is None:
                raise StaleSourceError("CREATIVE_TEXT_ASSET_ARCHIVE_INCOMPLETE")
            if (asset.get("deleted_at") or asset.get("kind") != "text" or asset.get("media_type") != "text/plain"
                    or asset.get("_text_result_origin") != origin or asset.get(PRIVATE_FIELD) != execution_receipt):
                raise StaleSourceError("CREATIVE_TEXT_ASSET_ORIGIN_CHANGED")
            if execution_receipt is not None and (asset.get("source_job_id") != job.id
                    or asset.get("provider_id") != job.provider or asset.get("model_id") != job.model
                    or asset.get("parameters") != self._parameters(current)):
                raise StaleSourceError("CREATIVE_TEXT_EXECUTION_RECEIPT_CHANGED")
            if self.assets.content(asset["id"], branch_id=scope.get("branch_id"), actor_id=actor) != job.output.encode():
                raise StaleSourceError("CREATIVE_TEXT_ASSET_BYTES_CHANGED")
            if current.get("graph_schema_version") == 3:
                self._verify_private(current, asset, job, origin, execution_receipt)
            fresh()
            return deepcopy(asset), deepcopy(current), origin, route_guard

    @contextmanager
    def phase(self, nid, scope, actor, rid, guard, *, create=True):
        row = self._source(nid, scope, actor, rid, guard)
        if row.get("graph_schema_version") == 3:
            if self.service.asset_inputs.in_phase(nid, scope, actor):
                raise ValueError("CREATIVE_TEXT_ASSET_PHASE_PREPARATION_ORDER_INVALID")
            # Resolve the route before persistence leases, then keep original
            # assets fixed until the workflow's original raw scope commit.
            prepared = (row[BINDING], deepcopy(row["model_preview"]), self._route(row))
            with self.service.asset_inputs.transaction(nid, scope, actor, guard):
                asset, current, origin, route_guard = self.ensure(nid, scope, actor, rid, guard,
                    create=create, _prepared=prepared)
                with self._proof(nid, scope, actor, rid, guard, asset, current, origin, route_guard):
                    yield asset
            return
        asset, row, origin, route_guard = self.ensure(nid, scope, actor, rid, guard, create=create)
        with self._proof(nid, scope, actor, rid, guard, asset, row, origin, route_guard):
            yield asset

    @contextmanager
    def _proof(self, nid, scope, actor, rid, guard, asset, row, origin, route_guard):
        proof = {"runtime": self.runtime, "run_id": rid, "incarnation": row[BINDING], "origin": origin,
            "execution_receipt": deepcopy(asset.get(PRIVATE_FIELD)),
            "actor": actor, "scope": deepcopy(scope), "guard": guard, "route_guard": route_guard,
            "leased_asset": deepcopy(asset) if row.get("graph_schema_version") == 3 else None}
        token = _phase.set(proof)
        try:
            yield asset
        finally:
            _phase.reset(token)

    def output_authority(self, row):
        proof = _phase.get()
        if (not proof or proof["runtime"] is not self.runtime or proof["run_id"] != row["id"]
                or proof["incarnation"] != row[BINDING] or proof["actor"] != row["created_by"] or proof["scope"] != row["scope"]):
            raise StaleSourceError("CREATIVE_TEXT_ASSET_ARCHIVE_INCOMPLETE")
        proof["guard"]()
        proof["route_guard"]()
        job = self._job(row)
        if proof["origin"] != self._origin(row, job):
            raise StaleSourceError("CREATIVE_TEXT_ASSET_OUTPUT_CHANGED")
        if proof["execution_receipt"] != self._execution_receipt(row, job, proof["origin"]):
            raise StaleSourceError("CREATIVE_TEXT_EXECUTION_RECEIPT_CHANGED")
        if row.get("graph_schema_version") == 3:
            if not self.service.asset_inputs.in_phase(row["novel_id"], row["scope"], row["created_by"]):
                raise StaleSourceError("CREATIVE_TEXT_ASSET_LEASE_REQUIRED")
            expected = proof["leased_asset"]
            asset = self.assets.get(expected["id"], branch_id=row["scope"].get("branch_id"), actor_id=row["created_by"])
            if (asset != expected or asset.get("_owner_actor_id") != row["created_by"]
                    or self.assets.content(asset["id"], branch_id=row["scope"].get("branch_id"),
                        actor_id=row["created_by"]) != job.output.encode()):
                raise StaleSourceError("CREATIVE_TEXT_ASSET_OUTPUT_CHANGED")
        output = row.get("typed_outputs", {}).get(self.runtime.node(row)["id"])
        if output is not None and output.get("draft", {}).get("text") != job.output:
            raise StaleSourceError("CREATIVE_TEXT_ASSET_OUTPUT_CHANGED")

    def has_authority(self, row):
        try:
            self.output_authority(row)
            return True
        except (StaleSourceError, FileNotFoundError, KeyError):
            return False

    def public_current(self, row):
        """A passive receipt from the same leased proof as the node outputs."""
        self.output_authority(row)
        proof = _phase.get()
        if row.get("graph_schema_version") != 3 or proof["leased_asset"] is None:
            raise StaleSourceError("CREATIVE_TEXT_ASSET_LEASE_REQUIRED")
        return self.projected(proof["leased_asset"], row, proof["origin"])

    def _decision(self, row, output_digest):
        snapshots = [*row["history"], row]
        if row.get("graph_schema_version") == 3:
            # A reviewed text proposal can precede additional media work. The
            # exact original human-review transition, rather than the later
            # whole-graph terminal state, owns this text review projection.
            model_node = self.runtime.node(row)["id"]
            descendants, queue = {model_node}, [model_node]
            while queue:
                source = queue.pop()
                for edge in row["typed_edges"]:
                    if (edge["source_node_id"] == source and edge["source_port"] == "draft"
                            and edge["target_port"] == "draft" and edge["target_node_id"] not in descendants):
                        descendants.add(edge["target_node_id"]); queue.append(edge["target_node_id"])
            for index, current in enumerate(snapshots[1:], 1):
                review = self.service.executor._review(snapshots[index - 1])
                if not review or review["node_id"] not in descendants:
                    continue
                draft = review["draft"]
                if (draft.get("origin") != "MODEL_PROPOSAL"
                        or sha256(draft.get("text", "").encode()).hexdigest() != output_digest
                        or review["output_digest"] != sha256(canonical([row["id"], review["node_id"],
                            row["graph_version"], draft]).encode()).hexdigest()):
                    raise StaleSourceError("CREATIVE_TEXT_ASSET_REVIEW_CHANGED")
                status = current.get("node_states", {}).get(review["node_id"], {}).get("status")
                if status not in {"SUCCEEDED", "REJECTED"}:
                    continue
                return "APPROVED" if status == "SUCCEEDED" else "REJECTED", {
                    "run_id": row["id"], "run_version": current["version"], "review_node_id": review["node_id"],
                    "output_digest": output_digest, "reviewed_output_digest": review["output_digest"],
                    "reviewed_by": current["updated_by"], "reviewed_at": current["updated_at"]}
            return "DRAFT", None
        for index, current in enumerate(snapshots):
            if index == 0:
                continue
            approved = current.get("status") == "SUCCEEDED" and current.get("reviewed") is True
            rejected = current.get("status") == "REJECTED"
            if not (approved or rejected):
                continue
            previous = snapshots[index - 1]
            review = self.service.executor._review(previous)
            if not review:
                continue
            return "APPROVED" if approved else "REJECTED", {"run_id": row["id"], "run_version": current["version"],
                "review_node_id": review["node_id"], "output_digest": output_digest,
                "reviewed_output_digest": review["output_digest"], "reviewed_by": current["updated_by"],
                "reviewed_at": current["updated_at"]}
        return "DRAFT", None

    def project(self, nid, scope, actor, rid, guard):
        asset, row, origin, route_guard = self.ensure(nid, scope, actor, rid, guard, create=False)
        status, decision = self._decision(row, origin["output_digest"])
        if decision is not None:
            with self._lease(nid, scope, actor, rid, guard) as current:
                if self._decision(current, origin["output_digest"]) != (status, decision):
                    raise StaleSourceError("CREATIVE_TEXT_ASSET_REVIEW_CHANGED")
                def before_review_commit():
                    guard(); route_guard()
                    live = self._source(nid, scope, actor, rid, guard)
                    if (live != current or self._origin(live, self._job(live)) != origin
                            or self._execution_receipt(live, self._job(live), origin) != asset.get(PRIVATE_FIELD)
                            or self._decision(live, origin["output_digest"]) != (status, decision)):
                        raise StaleSourceError("CREATIVE_TEXT_ASSET_REVIEW_CHANGED")
                asset = self.assets.review_text_result(asset["id"], actor_id=actor, branch_id=scope.get("branch_id"),
                    expected_version=asset["version"], output_digest=origin["output_digest"], status=status,
                    review_receipt=decision, guard=before_review_commit, execution_receipt=asset.get(PRIVATE_FIELD))
        guard()
        return self.projected(asset, row, origin)

    def projected(self, asset, row, origin):
        """Pure current receipt projection; no review or persistence action."""
        status, decision = self._decision(row, origin["output_digest"])
        if row.get("graph_schema_version") == 3:
            review = asset.get("_text_result_review", {})
            if review.get("status") != status or review.get("receipt") != decision:
                raise StaleSourceError("CREATIVE_TEXT_ASSET_REVIEW_PROJECTION_REQUIRED")
        return {"contract": CONTRACT, "state": status, "asset_id": asset["id"], "version": asset["version"],
            "sha256": asset["sha256"], "size": asset["size"], "kind": "text", "media_type": "text/plain",
            "created_at": asset["created_at"], "updated_at": asset["updated_at"], "source": origin,
            "provider_id": asset["provider_id"], "model_id": asset["model_id"], "parameters": deepcopy(asset["parameters"]),
            **({"execution_receipt": public_receipt(asset[PRIVATE_FIELD])} if PRIVATE_FIELD in asset else {}),
            "actor_private": True, "applied": False, "quality_verification": "NOT_RUN", "automatic_model_retry": False}

    @staticmethod
    def pending(state="PENDING", reason=None):
        return {"contract": CONTRACT, "state": state, "asset_id": None, "version": None,
            "actor_private": True, "applied": False, "quality_verification": "NOT_RUN",
            "automatic_model_retry": False, **({"reason": reason} if reason else {})}

    def masked(self, result, reason="ARCHIVE_RECONCILIATION_REQUIRED"):
        result = deepcopy(result)
        result.update(stale=True, review=None, asset_output=self.pending("INCOMPLETE", reason))
        for state in result["node_states"].values():
            state["output"] = None
        if result.get("model_runtime"):
            result["model_runtime"]["preview"] = None
        if result.get("media_runtime"):
            for node in result["media_runtime"]["nodes"]:
                node.update(status="STALE", preview=None)
                if node.get("execution"):
                    node["execution"]["job"] = None
        return result

    def decorate(self, nid, scope, actor, rid, guard, result):
        result["asset_output"] = self.project(nid, scope, actor, rid, guard)
        guard()
        return result

    def read(self, nid, scope, actor, rid, guard, *, reconcile=True):
        """One bounded convergence attempt during an already authorized read.

        Reopen after restart uses only a durable, settled completed result.
        Missing/uncertain execution stays pending, never restarts the worker.
        Failed attempts have a two-second cooldown (at most 100 keys).
        """
        row = self.service._owned(nid, scope, actor, self.service.RUNS, rid)
        result = self.service.executor.view(nid, scope, actor, row, guard)
        if not self.enabled(row):
            return result
        if row["status"] in {"CANCELLED", "FAILED"}:
            result["asset_output"] = self.pending("NO_ACCEPTED_RESULT")
            return result
        try:
            job = self.runtime.bound_job(row)
        except KeyError:
            return self.masked(result)
        if job.status in {"FAILED", "CANCELLED"} and row["status"] == "RUNNING" and reconcile:
            result = self.runtime.refresh(nid, scope, actor, rid, {"expected_version": row["version"]}, guard)
            result["asset_output"] = self.pending("NO_ACCEPTED_RESULT")
            return result
        if job.status == "COMPLETED" and job.terminal_hook_status != "COMPLETED":
            return self.masked(result, "TERMINAL_ACCOUNTING_RECONCILIATION_REQUIRED")
        if job.status != "COMPLETED":
            result["asset_output"] = self.pending()
            return result
        if not reconcile:
            result["asset_output"] = self.pending()
            return result
        key = (nid, self.service.store.key(nid, scope), actor, row[BINDING], rid)
        with self._cooldown_lock:
            if self._cooldowns.get(key, 0) > time.monotonic():
                return self.masked(result)
        try:
            if (row["status"] == "RUNNING" and (row.get("graph_schema_version") != 3
                    or row["node_states"][self.runtime.node(row)["id"]]["status"] != "SUCCEEDED")):
                result = self.runtime.refresh(nid, scope, actor, rid, {"expected_version": row["version"]}, guard)
            else:
                with self.phase(nid, scope, actor, rid, guard, create=False):
                    live = self.service._owned(nid, scope, actor, self.service.RUNS, rid)
                    result = self.service.executor.view(nid, scope, actor, live, guard)
                result = self.decorate(nid, scope, actor, rid, guard, result)
            with self._cooldown_lock:
                self._cooldowns.pop(key, None)
            return result
        except (ValueError, OSError, KeyError):
            guard()
            with self._cooldown_lock:
                self._cooldowns[key] = time.monotonic() + 2
                self._cooldowns.move_to_end(key)
                while len(self._cooldowns) > 100:
                    self._cooldowns.popitem(last=False)
            return self.masked(result)
