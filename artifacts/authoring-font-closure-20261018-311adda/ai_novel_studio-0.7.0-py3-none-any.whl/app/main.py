from __future__ import annotations
from fastapi import FastAPI, HTTPException, Request
from contextlib import asynccontextmanager
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from . import __version__
from .config import settings
from .dependencies import context_service,collaboration_read_service,collaboration_admin_service,packaged_bootstrap_registry,packaged_initial_workspace_provisioner,trusted_session_resolver,harness_process_service,model_center_service,local_ai_discovery
from .model_center.api import create_model_center_router
from .model_center.discovery_api import PRIVATE_HEADERS as DISCOVERY_PRIVATE_HEADERS, create_local_discovery_router
from .model_center.transfer_api import create_model_transfer_router
from .model_center.discovery_authority import resolve_discovery_authority
from .collaboration_api import create_collaboration_router
from .collaboration_admin import create_collaboration_admin_router
from .packaging.bootstrap_api import create_packaged_bootstrap_router
from .packaging.local_session_bootstrap import BootstrapDenied
from .packaging.static_frontend import mount_packaged_frontend
from .packaging.control_pipe import start_packaged_control_reader
from pathlib import Path
import os
import re
import uuid
import ipaddress

from .api import router as api_router


def _model_center_mutation_authorization(token: str | None) -> dict:
    if settings.enable_packaged_runtime:
        mode = "PACKAGED_BOOTSTRAP"
        manager = packaged_bootstrap_registry.current()
        try:
            if manager is None or not token:
                raise KeyError("missing packaged session")
            manager.resolve_issued_session(token)
            can_mutate = True
        except (BootstrapDenied, KeyError, ValueError):
            can_mutate = False
    else:
        mode = "TRUSTED_SESSION" if settings.enable_collaboration_runtime else "DEVELOPMENT_SESSION_REQUIRED"
        try:
            if not token:
                raise KeyError("missing trusted session")
            trusted_session_resolver.resolve(token)
            can_mutate = True
        except (KeyError, ValueError):
            can_mutate = False
    return {"can_mutate": can_mutate, "mutation_auth_mode": mode}


def _local_discovery_host_authority(request: Request, token: str | None):
    return resolve_discovery_authority(request, token,
        settings_getter=lambda: settings, resolver_getter=lambda: trusted_session_resolver,
        bootstrap_getter=lambda: packaged_bootstrap_registry.current())


@asynccontextmanager
async def app_lifespan(_app):
    from .dependencies import agent_job_service
    agent_job_service.recover_interrupted()
    from .dependencies import local_interop_host
    try:
        await local_interop_host.app_start()
    except Exception:  # noqa: BLE001 - optional bridge cannot block app startup
        # Optional bridge startup must never take down the writing application.
        local_interop_host.closed = True
    yield
    try:
        await local_interop_host.lifecycle.shutdown(timeout=1.0)
    except Exception:  # noqa: BLE001 - optional bridge cannot block app shutdown
        # Lifecycle failure does not stop the remaining product shutdown owners.
        local_interop_host.closed = True
    harness_process_service.stop()
    model_center_service.transfers.close()
    model_center_service.lifecycle.stop_all()

app=FastAPI(title="AI Novel Studio",version=__version__,lifespan=app_lifespan)
_packaged_control_reader = start_packaged_control_reader()

@app.middleware("http")
async def request_id_middleware(request: Request, call_next):
    request_id = request.headers.get("X-Request-ID") or str(uuid.uuid4())
    request.state.request_id = request_id
    response = await call_next(request)
    response.headers["X-Request-ID"] = request_id
    return response

from .revision_constraints import RevisionConstraintError


@app.exception_handler(RevisionConstraintError)
async def revision_constraint_error(request: Request, exc: RevisionConstraintError):
    return JSONResponse(status_code=409, content={"code": exc.code,
        "message": "段落已锁定或锁定依据已变化。请核对后明确解锁，再采用 AI 修改。",
        "details": {}, "request_id": getattr(request.state, "request_id", "")})


@app.exception_handler(HTTPException)
async def unified_http_error(request: Request, exc: HTTPException):
    detail = exc.detail
    if isinstance(detail, dict):
        code = str(detail.get("code") or f"HTTP_{exc.status_code}")
        message = str(detail.get("message") or detail.get("detail") or code)
        details = detail.get("details", detail)
    else:
        code = f"HTTP_{exc.status_code}"
        message = str(detail)
        details = {}
    request_id = getattr(request.state, "request_id", "")
    return JSONResponse(status_code=exc.status_code, content={"detail": detail, "code": code, "message": message, "details": details, "request_id": request_id}, headers={**{key: value for key, value in (exc.headers or {}).items() if key.lower() != "x-request-id"}, "X-Request-ID": request_id})

def _normalized_api_path(path: str) -> str:
    """Use the legacy path shape for middleware checks on the v1 alias."""
    return "/api" + path[len("/api/v1"):] if path.startswith("/api/v1/") else path

@app.middleware("http")
async def collaboration_fail_closed(request,call_next):
    packaged = bool(getattr(settings, "enable_packaged_runtime", False))
    collaboration = bool(getattr(settings, "enable_collaboration_runtime", False))
    normalized_request_path = _normalized_api_path(request.url.path)
    model_center_control = (
        request.method == "POST" and re.fullmatch(r"/api/model-center/runtimes/[^/]+/(?:validate|start|stop)", normalized_request_path) is not None
    ) or (
        request.method == "PUT" and re.fullmatch(r"/api/model-center/runtimes/[^/]+/configuration", normalized_request_path) is not None
    ) or (
        request.method == "GET" and re.fullmatch(r"/api/model-center/runtimes/[^/]+/(?:configuration|diagnostics|logs)", normalized_request_path) is not None
    )
    if model_center_control and not packaged and not collaboration:
        token = request.headers.get("X-Session-Token")
        if not token:
            return JSONResponse({"detail": {"code": "SESSION_REQUIRED"}}, status_code=401)
        try:
            trusted_session_resolver.resolve(token)
        except (KeyError, ValueError):
            return JSONResponse({"detail": {"code": "INVALID_SESSION"}}, status_code=401)
    if not packaged and not collaboration:
        remote_host=request.client.host if request.client else ''
        try: local_client=ipaddress.ip_address(remote_host).is_loopback
        except ValueError: local_client=remote_host=='testclient'
        if not local_client:
            return JSONResponse({"detail":{"code":"LOCAL_RUNTIME_LOOPBACK_REQUIRED"}},status_code=403)
    if packaged:
        path = request.url.path
        normalized_path = _normalized_api_path(path)
        method = request.method

        # The launcher performs this one POST before the WebView has a session.
        if normalized_path == "/api/packaged/bootstrap" and method == "POST":
            return await call_next(request)

        # Keep the packaged control namespace fail-closed for unsupported
        # methods and unknown endpoints; the browser-facing application API
        # below is handled by the session gate.
        if normalized_path.startswith("/api/packaged/") and normalized_path not in {
            "/api/packaged/bootstrap",
            "/api/packaged/initial-workspace",
        }:
            return JSONResponse({"detail": {"code": "COLLABORATION_ROUTE_NOT_ENABLED"}}, status_code=501)
        if normalized_path == "/api/packaged/bootstrap" and method != "POST":
            return JSONResponse({"detail": {"code": "COLLABORATION_ROUTE_NOT_ENABLED"}}, status_code=501)

        # A packaged process without the trusted collaboration boundary is a
        # misconfiguration. Keep the historical fail-closed response instead
        # of accidentally turning it into a development runtime.
        if not collaboration:
            return JSONResponse({"detail": {"code": "COLLABORATION_ROUTE_NOT_ENABLED"}}, status_code=501)

        # The local UI shell and health probes must be reachable before the
        # host has injected the opaque session header. All other routes,
        # including legacy top-level routes, are protected by the same gate.
        public = (
            (normalized_path in {"/health", "/api/health"} and method in {"GET", "HEAD"})
            or (method in {"GET", "HEAD"} and (path in {"/", "/index.html"} or path.startswith("/assets/")))
        )
        if not public:
            token = request.headers.get("X-Session-Token")
            if not token:
                return JSONResponse({"detail": {"code": "SESSION_REQUIRED"}}, status_code=401)
            manager = packaged_bootstrap_registry.current()
            try:
                # In packaged mode only the current launcher bootstrap may
                # mint sessions. This prevents development-session fallback.
                if manager is None:
                    raise BootstrapDenied("PACKAGED_SESSION_REQUIRED", "本地安全会话无效或已过期。")
                manager.resolve_issued_session(token)
            except (BootstrapDenied, KeyError, ValueError):
                return JSONResponse({"detail": {"code": "INVALID_SESSION"}}, status_code=401)
        return await call_next(request)

    if normalized_request_path.startswith("/api/local-interop/"):
        # Every interop endpoint independently requires a live trusted session,
        # IPv4 loopback, explicit opt-in and exact scoped project authority.
        return await call_next(request)
    if normalized_request_path.startswith("/api/model-center/local-ai"):
        # Every endpoint has the same trusted Host/session dependency; do not
        # make discovery anonymous via the legacy collaboration allowlist.
        return await call_next(request)
    if normalized_request_path == "/api/model-center/transfers" or normalized_request_path.startswith("/api/model-center/transfers/"):
        # Host-global V2 operations use the same independent current Host
        # resolver as discovery. This classification skips only the project
        # collaboration allowlist; every route still checks live Host/session,
        # direct origin/forwarded-header provenance and V2 feature admission.
        return await call_next(request)
    if collaboration:
        path=request.url.path; normalized_path=_normalized_api_path(path); method=request.method
        # V1 metadata capabilities are available to the collaboration runtime
        # only after resolving an opaque trusted session.  This keeps the
        # expanded allowlist from turning research/plugin/workflow records into
        # anonymous development endpoints.  Packaged mode has already applied
        # its stronger bootstrap-issued session gate above.
        if (re.fullmatch(r"/api/novels/[^/]+/visual-memory(?:/[^/]+)?", normalized_path)
                or normalized_path == "/api/memory"
                or re.fullmatch(r"/api/assets/[^/]+/derivatives", normalized_path)):
            return JSONResponse({"detail": {"code": "LEGACY_MEDIA_SCOPE_UNAVAILABLE", "message": "请使用当前分支的视觉参考与资产管理入口。"}}, status_code=501)
        capability_route = any(re.fullmatch(pattern, normalized_path) is not None for pattern in (
            r"/api/novels/[^/]+/overview",
            r"/api/novels/[^/]+/text-runtime-diagnostics",
            r"/api/novels/[^/]+/planning-runs(?:/[^/]+(?:/cancel|/candidates/[^/]+/save-draft)?)?",
            r"/api/novels/[^/]+/creation-reference-data",
            r"/api/novels/[^/]+/chapters/[^/]+/privacy",
            r"/api/workflows/recipes(?:/[^/]+)?",
            r"/api/workflow-runs/[^/]+/nodes/[^/]+/(?:approve|reject|trigger-agent)",
            r"/api/agent-queue(?:/[^/]+/[^/]+/(?:execute|sync))?",
            r"/api/plugin-packages/(?:install|[^/]+(?:/rollback)?)",
            r"/api/novels/[^/]+/screenplays/[^/]+/video-assemblies",
            r"/api/novels/[^/]+/screenplays/[^/]+/motion-tasks/[^/]+/privacy",
            r"/api/novels/[^/]+/image-jobs(?:/[^/]+/(?:execute|cancel|retry|accept))?",
            r"/api/novels/[^/]+/audiobook/chapters/[^/]+/(?:export|queue-segments)",
            r"/api/novels/[^/]+/asset-trash",
            r"/api/novels/[^/]+/assets/[^/]+/(?:restore|references)",
            r"/api/novels/[^/]+/visual-references(?:/[^/]+(?:/approve)?)?",
            r"/api/novels/[^/]+/visual-reference-search",
            r"/api/novels/[^/]+/(?:creation-records|review-threads)(?:/[^/]+(?:/[^/]+)?)?",
            r"/api/novels/[^/]+/research(?:/[^/]+)?",
            r"/api/research",
            r"/api/novels/[^/]+/continuity/scan-chapter",
            r"/api/novels/[^/]+/character-evolution(?:/[^/]+)?",
            r"/api/novels/[^/]+/characters/[^/]+/evolution",
            r"/api/novels/[^/]+/visual-memory(?:/[^/]+)?",
            r"/api/memory",
            r"/api/assets/[^/]+/derivatives",
            r"/api/novels/[^/]+/lore/(?:evidence|proposals(?:/[^/]+/(?:approve|reject|approve-memory))?)",
            r"/api/novels/[^/]+/(?:memories(?:/[^/]+/retract)?|characters/[^/]+/memories|memory-snapshots)",
            r"/api/plugins(?:/[^/]+(?:/(?:permissions|enable|disable|resources(?:/[^/]+)?))?)?",
            r"/api/workflows(?:/[^/]+(?:/runs)?)?",
            r"/api/workflow-runs/[^/]+(?:/(?:pause|resume|cancel|retry)|/nodes/[^/]+/approve)?",
            r"/api/release-gates(?:/[^/]+)?",
            r"/api/release/readiness",
            r"/api/audit",
            r"/api/model-center/(?:models(?:/[^/]+)?|runtimes(?:/[^/]+(?:/(?:validate|start|stop|configuration|diagnostics|logs|capabilities))?)?|pipelines|health)",
        ))
        capability_route = capability_route or (method == "GET" and normalized_path == "/api/model-center/provider-presets/bailian-text")
        if capability_route:
            token = request.headers.get("X-Session-Token")
            if not token:
                return JSONResponse({"detail": {"code": "SESSION_REQUIRED"}}, status_code=401)
            try:
                trusted_session_resolver.resolve(token)
            except (KeyError, ValueError):
                return JSONResponse({"detail": {"code": "INVALID_SESSION"}}, status_code=401)
        if normalized_path.startswith("/api/collaboration/admin/") and method not in {"GET","HEAD"}:
            token = request.headers.get("X-Session-Token")
            if not token:
                return JSONResponse({"detail": {"code": "SESSION_REQUIRED"}}, status_code=401)
            try:
                trusted_session_resolver.resolve(token)
            except (KeyError, ValueError):
                return JSONResponse({"detail": {"code": "INVALID_SESSION"}}, status_code=401)
        allowed=(normalized_path=="/health" and method=="GET") or (normalized_path.startswith("/api/") and (
            (method=="GET" and normalized_path in {"/api/health","/api/providers","/api/models","/api/text-models"}) or
            (normalized_path.startswith("/api/collaboration/admin/") and method in {"GET","POST","PATCH","DELETE"}) or
            (method=="GET" and normalized_path.startswith("/api/collaboration/")) or
            (method=="GET" and re.fullmatch(r"/api/novels/[^/]+/chapters/archived",normalized_path) is not None) or
            (method=="DELETE" and re.fullmatch(r"/api/novels/[^/]+",normalized_path) is not None) or
            (method=="POST" and re.fullmatch(r"/api/collaboration/workspaces/[^/]+/projects/[^/]+/storylines/[^/]+/branches/[^/]+/chapters",normalized_path) is not None) or
            re.fullmatch(r"/api/chapters/[^/]+(?:/history)?",normalized_path) is not None and method=="GET" or
            re.fullmatch(r"/api/chapters/[^/]+",normalized_path) is not None and method=="PUT" or
            re.fullmatch(r"/api/chapters/[^/]+",normalized_path) is not None and method=="DELETE" or
            re.fullmatch(r"/api/chapters/[^/]+/(?:rename|archive|restore-archive|history/\d+/restore)",normalized_path) is not None and method=="POST" or
            re.fullmatch(r"/api/generate/[^/]+(?:/variants)?",normalized_path) is not None and method=="POST" or
            re.fullmatch(r"/api/generation-groups/[^/]+",normalized_path) is not None and method=="GET" or
            normalized_path=="/api/agent/chat" and method=="POST" or
            normalized_path in {"/api/user-preferences","/api/user-preferences-enabled","/api/user-preferences-share-enabled","/api/harness-enabled"} and method in {"GET","PUT"} or
            normalized_path=="/api/harness/status" and method=="GET" or
            normalized_path=="/api/harness/launch-readiness" and method=="GET" or
            normalized_path in {"/api/harness/process","/api/harness/process/start","/api/harness/process/stop"} and method in {"GET","POST"} or
            re.fullmatch(r"/api/user-preferences/[^/]+",normalized_path) is not None and method in {"PUT","DELETE"} or
            re.fullmatch(r"/api/generation/[^/]+(?:/events)?",normalized_path) is not None and method=="GET" or
            re.fullmatch(r"/api/generation/[^/]+/(?:cancel|accept|reject|retry)",normalized_path) is not None and method=="POST" or
            re.fullmatch(r"/api/exports",normalized_path) is not None and method in {"GET", "POST"} or
            re.fullmatch(r"/api/exports/[^/]+/(?:cancel|retry)",normalized_path) is not None and method=="POST" or
            re.fullmatch(r"/api/exports/[^/]+(?:/download)?",normalized_path) is not None and method=="GET" or
            re.fullmatch(r"/api/novels/[^/]+/export",normalized_path) is not None and method=="GET" or
            re.fullmatch(r"/api/novels/[^/]+/assets",normalized_path) is not None and method in {"GET","POST"} or
            re.fullmatch(r"/api/assets/[^/]+(?:/download)?",normalized_path) is not None and method in {"GET","DELETE"} or
            normalized_path=="/api/asset-providers" and method=="GET" or
            re.fullmatch(r"/api/asset-providers/[^/]+",normalized_path) is not None and method in {"PUT","DELETE"} or
            normalized_path=="/api/audio/providers" and method=="GET" or
            re.fullmatch(r"/api/audio/providers/[^/]+",normalized_path) is not None and method in {"PUT","DELETE"} or
            normalized_path in {"/api/images/generate","/api/images/edits","/api/audio/generate","/api/vision/analyze","/api/speech/synthesize"} and method=="POST" or
            re.fullmatch(r"/api/novels/[^/]+/(?:image-generations|speech-generations)(?:/import)?",normalized_path) is not None and method in {"GET","POST"} or
            re.fullmatch(r"/api/novels/[^/]+/audio-production/settings",normalized_path) is not None and method in {"GET","PUT"} or
            re.fullmatch(r"/api/novels/[^/]+/audiobook/(?:manifest|mix-plan|jobs)",normalized_path) is not None and method=="GET" or
            re.fullmatch(r"/api/novels/[^/]+/media-tasks",normalized_path) is not None and method=="GET" or
            re.fullmatch(r"/api/novels/[^/]+/audiobook/chapters/[^/]+/queue",normalized_path) is not None and method=="POST" or
            re.fullmatch(r"/api/novels/[^/]+/audiobook/jobs/[^/]+/(?:execute|retry|cancel)",normalized_path) is not None and method=="POST" or
            re.fullmatch(r"/api/novels/[^/]+/audiobook/jobs/consume",normalized_path) is not None and method=="POST" or
            re.fullmatch(r"/api/novels/[^/]+/audiobook/jobs/[^/]+/subtitles\.(?:srt|vtt)",normalized_path) is not None and method=="GET" or
            re.fullmatch(r"/api/novels/[^/]+/screenplays/[^/]+/motion-tasks/[^/]+/(?:execute|cancel|retry)",normalized_path) is not None and method=="POST" or
            re.fullmatch(r"/api/novels/[^/]+/import/knowledge-base/review",normalized_path) is not None and method in {"GET","POST"} or
            re.fullmatch(r"/api/novels/[^/]+/import/knowledge-base/review/[^/]+",normalized_path) is not None and method in {"GET","PUT"} or
            re.fullmatch(r"/api/novels/[^/]+/import/knowledge-base/review/[^/]+/ai-analyze",normalized_path) is not None and method=="POST" or
            re.fullmatch(r"/api/novels/[^/]+/knowledge-base/review",normalized_path) is not None and method=="POST" or
            re.fullmatch(r"/api/novels/[^/]+/chapters/[^/]+/knowledge-base/review",normalized_path) is not None and method=="POST" or
            capability_route and method in {"GET","POST","PUT","PATCH","DELETE"}))
        # New routes are admitted only behind server-owned opt-in. Domain
        # routers still require exact project/branch authorization and flags.
        from .experimental.flags import enabled_flags
        experimental_path = re.fullmatch(r"/api/novels/[^/]+/experimental/.+", normalized_path) is not None
        if (normalized_path == "/api/experimental/features" and method == "GET") or (experimental_path and enabled_flags() and method in {"GET", "POST", "PUT", "PATCH", "DELETE"}):
            allowed = True
        first_use_route = ((normalized_path == "/api/experimental/first-use/sample" and method in {"GET", "POST"})
                           or (normalized_path == "/api/experimental/first-use/sample/recover" and method == "POST"))
        if first_use_route and 'workspace_tools_v2' in enabled_flags():
            allowed = True
        from .creative.workspace_api import is_independent_studio_route
        if 'narrative_production_v2' in enabled_flags() and is_independent_studio_route(method, normalized_path):
            allowed = True
        finding_review_route = (
            method == 'GET' and re.fullmatch(
                r'/api/projects/[^/]+/(?:continuity|narrative)/review-findings(?:/[^/]+(?:/(?:history|evidence))?)?',
                normalized_path) is not None
        ) or (
            method == 'POST' and re.fullmatch(
                r'/api/projects/[^/]+/(?:continuity|narrative)/(?:review-checks|review-findings/[^/]+/review)',
                normalized_path) is not None
        )
        if finding_review_route and 'finding_review_v1' in enabled_flags():
            allowed = True
        pending_canon_review_route = (
            method == 'GET' and re.fullmatch(r'/api/projects/[^/]+/pending-canon/review', normalized_path) is not None
        ) or (
            method == 'POST' and re.fullmatch(
                r'/api/projects/[^/]+/pending-canon/[^/]+/(?:preview|review|recover|cancel-recovery)', normalized_path) is not None
        )
        if pending_canon_review_route and 'finding_review_v1' in enabled_flags():
            allowed = True
        if not allowed:
            return JSONResponse({"detail":{"code":"COLLABORATION_ROUTE_NOT_ENABLED"}},status_code=501)
        public_metadata = (
            (normalized_path == "/health" and method in {"GET", "HEAD"})
            or (normalized_path in {"/api/health", "/api/providers", "/api/models", "/api/text-models"} and method in {"GET", "HEAD"})
        )
        if not public_metadata:
            token = request.headers.get("X-Session-Token")
            if not token:
                return JSONResponse({"detail": {"code": "SESSION_REQUIRED"}}, status_code=401)
            try:
                trusted_session_resolver.resolve(token)
            except (KeyError, ValueError):
                return JSONResponse({"detail": {"code": "INVALID_SESSION"}}, status_code=401)
    return await call_next(request)
app.add_middleware(CORSMiddleware,allow_origins=[settings.frontend_origin],allow_credentials=True,allow_methods=["*"],allow_headers=["*"])
app.include_router(api_router, prefix="/api")
app.include_router(api_router, prefix="/api/v1")
from .experimental.api import router as experimental_router
app.include_router(experimental_router, prefix="/api")
app.include_router(experimental_router, prefix="/api/v1")
app.include_router(create_model_center_router(model_center_service, mutation_authorization=_model_center_mutation_authorization))
app.include_router(create_model_center_router(model_center_service, prefix="/api/v1/model-center", mutation_authorization=_model_center_mutation_authorization))
app.include_router(create_model_transfer_router(model_center_service.transfers, host_authorization=_local_discovery_host_authority))
app.include_router(create_model_transfer_router(model_center_service.transfers, prefix="/api/v1/model-center/transfers", host_authorization=_local_discovery_host_authority))
@app.middleware("http")
async def local_discovery_private_cache(request: Request, call_next):
    response = await call_next(request)
    path = _normalized_api_path(request.url.path)
    if (path == "/api/model-center/local-ai" or path.startswith("/api/model-center/local-ai/")
            or path == "/api/model-center/transfers" or path.startswith("/api/model-center/transfers/")):
        response.headers.update(DISCOVERY_PRIVATE_HEADERS)
    return response


app.include_router(create_local_discovery_router(local_ai_discovery, host_authorization=_local_discovery_host_authority))
app.include_router(create_local_discovery_router(local_ai_discovery, prefix="/api/v1/model-center/local-ai", host_authorization=_local_discovery_host_authority))
app.include_router(create_collaboration_router(collaboration_read_service))
app.include_router(create_collaboration_router(collaboration_read_service, prefix="/api/v1/collaboration"))
app.include_router(create_collaboration_admin_router(collaboration_admin_service))
app.include_router(create_collaboration_admin_router(collaboration_admin_service, prefix="/api/v1/collaboration/admin"))
app.include_router(create_packaged_bootstrap_router(
    packaged_bootstrap_registry, enabled=lambda: getattr(settings,"enable_packaged_runtime",False),
    initial_workspace_provisioner=packaged_initial_workspace_provisioner,
))
app.include_router(create_packaged_bootstrap_router(
    packaged_bootstrap_registry, enabled=lambda: getattr(settings,"enable_packaged_runtime",False),
    initial_workspace_provisioner=packaged_initial_workspace_provisioner,
    prefix="/api/v1/packaged",
))
class ContextRequest(BaseModel): novel_id:str; chapter:int; instruction:str; cloud:bool=False; chapter_id:str|None=None

@app.get("/health")
def health(): return {"status":"ok","version":__version__,"profile":settings.profile}
@app.get("/novels")
def novels(request: Request):
    if settings.enable_collaboration_runtime or settings.enable_packaged_runtime:
        from .api import novels as authorized_novels
        return [{"id": row["id"]} for row in authorized_novels(request.headers.get("X-Session-Token"))]
    root=settings.data_path()/"novels"; return [{"id":p.name} for p in root.iterdir() if p.is_dir()] if root.exists() else []
@app.post("/context-packs")
def context_pack(req:ContextRequest, request: Request):
    from .api import _require_shared_project
    _require_shared_project(req.novel_id, request.headers.get("X-Session-Token"),
                            "domain.read", request.headers.get("X-Branch-ID"))
    try:
        if req.chapter_id is not None:
            return context_service.build(req.novel_id,req.chapter,req.instruction,req.cloud,chapter_id=req.chapter_id)
        return context_service.build(req.novel_id,req.chapter,req.instruction,req.cloud)
    except FileNotFoundError as exc: raise HTTPException(404 if req.chapter_id is not None else 400,str(exc)) from exc
    except Exception as exc: raise HTTPException(400,str(exc)) from exc

from .dependencies import local_interop_host
from .local_interop.api import create_local_interop_router
app.include_router(create_local_interop_router(local_interop_host))
app.include_router(create_local_interop_router(local_interop_host, prefix="/api/v1/local-interop"))

if settings.enable_packaged_runtime:
    mount_packaged_frontend(app, Path(os.environ.get("PACKAGED_FRONTEND_DIST", "")))
