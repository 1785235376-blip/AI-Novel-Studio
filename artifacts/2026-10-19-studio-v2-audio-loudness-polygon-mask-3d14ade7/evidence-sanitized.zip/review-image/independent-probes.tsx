// @vitest-environment jsdom
import {act,cleanup,fireEvent,render,screen} from '@testing-library/react';
import {afterEach,beforeEach,expect,it,vi} from 'vitest';
import {BinaryMaskDraft,type BinaryMaskPoint} from '../src/creative/studioBinaryMask';
import {StudioBinaryMaskCanvas} from '../src/creative/StudioBinaryMaskCanvas';
const points=(rows:number[][])=>rows.map(([x,y])=>({x,y}));
function inside(vertices:readonly BinaryMaskPoint[],x:number,y:number){
  // Independent winding-number oracle at doubled integer pixel centers.
  const p={x:2*x+1,y:2*y+1};let winding=0;
  for(let i=0;i<vertices.length;i++){
    const a={x:vertices[i].x*2,y:vertices[i].y*2},b={x:vertices[(i+1)%vertices.length].x*2,y:vertices[(i+1)%vertices.length].y*2};
    const c=(b.x-a.x)*(p.y-a.y)-(p.x-a.x)*(b.y-a.y);
    if(c===0&&p.x>=Math.min(a.x,b.x)&&p.x<=Math.max(a.x,b.x)&&p.y>=Math.min(a.y,b.y)&&p.y<=Math.max(a.y,b.y))return true;
    if(a.y<=p.y&&b.y>p.y&&c>0)winding++;if(a.y>p.y&&b.y<=p.y&&c<0)winding--;
  }return winding!==0;
}
beforeEach(()=>{
  vi.stubGlobal('fetch',vi.fn(()=>{throw new Error('No HTTP authorized by a local polygon edit');}));
  vi.stubGlobal('PointerEvent',class extends MouseEvent{pointerId:number;constructor(type:string,init:PointerEventInit={}){super(type,init);this.pointerId=init.pointerId??1;}});
  vi.spyOn(HTMLCanvasElement.prototype,'getContext').mockReturnValue({createImageData:(w:number,h:number)=>({data:new Uint8ClampedArray(w*h*4),width:w,height:h}),putImageData:vi.fn()} as unknown as CanvasRenderingContext2D);
});
afterEach(()=>{cleanup();vi.restoreAllMocks();vi.unstubAllGlobals();});
it('polygon1 rejects malformed/self-touching/degenerate/out-of-bounds polygons atomically without consuming original history',()=>{
  const mask=new BinaryMaskDraft(64,64),white=mask.snapshot();mask.rectangle(5,5,4,4,false);const before=mask.snapshot(),revision=mask.revision;
  const invalid:any[]=[[],points([[0,0],[40,40],[0,40],[40,0]]),points([[0,0],[20,0],[10,0],[10,20],[0,20]]),points([[0,0],[1,1],[2,2]]),
    points([[0,0],[20,0],[0,20],[0,0]]),points([[0,0],[65,0],[0,20]]),points([[-1,0],[20,0],[0,20]]),points([[0,0],[20.5,0],[0,20]]),
    [{x:0,y:0},{x:NaN,y:0},{x:0,y:20}],points(Array.from({length:33},(_,i)=>[i,0])),null];
  for(const value of invalid){expect(()=>mask.previewPolygon(value)).toThrow();expect(()=>mask.polygon(value,false)).toThrow();expect(mask.snapshot()).toEqual(before);expect(mask.revision).toBe(revision);}
  expect(mask.undo()).toBe(true);expect(mask.snapshot()).toEqual(white);expect(mask.canUndo).toBe(false);expect(fetch).not.toHaveBeenCalled();
});
it('polygon2 agrees at every pixel with an independent winding oracle including diagonal centers, reverse order and one-step undo',()=>{
  const shapes=[points([[0,0],[64,0],[0,64]]),points([[32,0],[64,32],[32,64],[0,32]]),points([[0,0],[64,0],[64,16],[32,16],[32,48],[0,48]])];
  for(const vertices of shapes)for(const shape of [vertices,[...vertices].reverse()]){
    const mask=new BinaryMaskDraft(64,64),white=mask.snapshot(),revision=mask.revision,preview=mask.previewPolygon(shape);
    let count=0;for(let y=0;y<64;y++)for(let x=0;x<64;x++)count+=Number(inside(shape,x,y));
    expect(preview.selected_pixels).toBe(count);expect(mask.snapshot()).toEqual(white);expect(mask.revision).toBe(revision);expect(mask.canUndo).toBe(false);
    expect(mask.polygon(preview.vertices,false)).toBe(true);
    for(let y=0;y<64;y++)for(let x=0;x<64;x++)expect(mask.get(x,y),`${x},${y}`).toBe(!inside(shape,x,y));
    expect(mask.serialize().remove_pixels).toBe(count);const applied=mask.revision;expect(mask.polygon(preview.vertices,false)).toBe(false);expect(mask.revision).toBe(applied);
    expect(mask.undo()).toBe(true);expect(mask.snapshot()).toEqual(white);expect(mask.canUndo).toBe(false);
    mask.clear(false);const black=mask.snapshot();expect(mask.polygon(preview.vertices,true)).toBe(true);expect(mask.serialize().keep_pixels).toBe(count);mask.undo();expect(mask.snapshot()).toEqual(black);
  }
  const triangle=new BinaryMaskDraft(64,64);expect(triangle.previewPolygon(shapes[0]).selected_pixels).toBe(2080);expect(fetch).not.toHaveBeenCalled();
});
const button=(name:string)=>screen.getByRole('button',{name}) as HTMLButtonElement;
const handlers=(element:Element)=>(element as any)[Object.keys(element).find(k=>k.startsWith('__reactProps'))!];
function add(x:number,y:number){fireEvent.change(screen.getByLabelText('多边形顶点 X'),{target:{value:String(x)}});fireEvent.change(screen.getByLabelText('多边形顶点 Y'),{target:{value:String(y)}});fireEvent.click(button('添加坐标顶点'));}
function preview(){add(4,4);add(20,4);add(4,20);fireEvent.click(button('预览多边形选区'));expect(button('填充选区为黑色 REMOVE').disabled).toBe(false);}
it('polygon3 retires all old polygon controls after source/authority/tool/revision changes and unmount; fresh selection works',()=>{
  for(const mode of ['sourceABA','readonlyABA','authorityABA','maskABA','toolABA','revision','synchronousAuthority','unmount']){
    let current=true;const mask=new BinaryMaskDraft(64,64),props={mask,sourceUrl:'blob:review-a',readOnly:false,isCurrent:()=>current,onChange:vi.fn()};
    const view=render(<StudioBinaryMaskCanvas {...props}/>);fireEvent.click(button('多边形选区'));preview();
    const oldApply=handlers(button('填充选区为黑色 REMOVE')).onClick,oldPreview=handlers(button('预览多边形选区')).onClick,oldAdd=handlers(button('添加坐标顶点')).onClick,oldRemove=handlers(button('移除顶点 1')).onClick;
    if(mode==='sourceABA'){view.rerender(<StudioBinaryMaskCanvas {...props} sourceUrl="blob:review-b"/>);view.rerender(<StudioBinaryMaskCanvas {...props}/>);}
    if(mode==='readonlyABA'){view.rerender(<StudioBinaryMaskCanvas {...props} readOnly/>);view.rerender(<StudioBinaryMaskCanvas {...props}/>);}
    if(mode==='authorityABA'){current=false;view.rerender(<StudioBinaryMaskCanvas {...props}/>);current=true;view.rerender(<StudioBinaryMaskCanvas {...props}/>);}
    if(mode==='maskABA'){view.rerender(<StudioBinaryMaskCanvas {...props} mask={new BinaryMaskDraft(64,64)}/>);view.rerender(<StudioBinaryMaskCanvas {...props}/>);}
    if(mode==='toolABA'){fireEvent.click(button('笔刷编辑'));fireEvent.click(button('多边形选区'));}
    if(mode==='revision')mask.paint(63,63,0,false);
    if(mode==='synchronousAuthority')current=false;
    if(mode==='unmount')view.unmount();
    const expected=mask.snapshot();act(()=>{oldApply();oldPreview();oldAdd();oldRemove();});expect(mask.snapshot(),mode).toEqual(expected);expect(props.onChange,mode).not.toHaveBeenCalled();
    if(mode!=='unmount'){
      current=true;view.rerender(<StudioBinaryMaskCanvas {...props}/>);expect(screen.getByRole('list',{name:'多边形顶点顺序'}).children).toHaveLength(0);preview();
      const apply=handlers(button('填充选区为黑色 REMOVE')).onClick;act(()=>{apply();apply();});expect(props.onChange,mode).toHaveBeenCalledTimes(1);
      expect(mask.serialize().remove_pixels).toBe(136+(mode==='revision'?1:0));fireEvent.click(button('撤销蒙版编辑'));expect(mask.snapshot()).toEqual(expected);view.unmount();
    }
    cleanup();
  }expect(fetch).not.toHaveBeenCalled();
});
