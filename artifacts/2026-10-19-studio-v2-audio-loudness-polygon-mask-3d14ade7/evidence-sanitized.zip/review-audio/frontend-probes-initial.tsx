// @vitest-environment jsdom
import { act,cleanup,fireEvent,render,screen,waitFor } from '@testing-library/react';
import { afterEach,beforeEach,expect,it,vi } from 'vitest';
import { webcrypto } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { useLocalHostSession } from '../src/localHostSession';
import { StudioMediaExecutionPanel } from '../src/creative/StudioMediaExecutionPanel';
import { studioProductionClient,type ProductionJob } from '../src/creative/studioProductionClient';
import { audioAssets,audioCommand,audioJob,audioPreview,audioProject } from '../src/creative/studioAudioWav.testFixtures';
import native from './native.json';
const label='目标综合响度（-30 至 -14 LUFS，可选）';
const reply=(value:unknown)=>new Response(JSON.stringify(value),{headers:{'Content-Type':'application/json'}});
const byteResponse=()=>new Response(new Uint8Array(readFileSync(new URL('./native.wav',import.meta.url))),{headers:{'Content-Type':'audio/wav'}});
let fetcher:ReturnType<typeof vi.fn>;
const calls=(suffix:string)=>fetcher.mock.calls.filter(([url])=>url.endsWith(suffix));
const button=(name:string)=>screen.getByRole('button',{name}) as HTMLButtonElement;
const change=(name:string,value:string)=>fireEvent.change(screen.getByLabelText(name),{target:{value}});
const retained=(element:HTMLElement)=>(element as any)[Object.keys(element).find(key=>key.startsWith('__reactProps'))!];
function deferred<T>(){let resolve!:(value:T)=>void;const promise=new Promise<T>(done=>{resolve=done;});return {promise,resolve};}
function mount(project=audioProject,assets=audioAssets(),job?:ProductionJob){
  const props={client:studioProductionClient(project,{sessionToken:''}),assets,canMutate:true,canReview:true,busy:false,isCurrent:()=>true,
    read:async<T,>(work:()=>Promise<T>)=>work(),mutate:async<T,>(work:()=>Promise<T>)=>work(),onDirtyChange:vi.fn(),onUnavailable:vi.fn(),externalJob:job};
  return {...render(<StudioMediaExecutionPanel {...props}/>),props};
}
async function choose(){await waitFor(()=>expect((screen.getByLabelText('操作') as HTMLSelectElement).disabled).toBe(false));change('操作','m8.audio.trim');fireEvent.click(screen.getByLabelText('source.wav · v2'));change('来源起点（毫秒）','500');change('来源终点（毫秒）','4500');change(label,'-23.5');}
async function reviewedPreview(){fireEvent.click(button('读取制作预览'));await screen.findByRole('region',{name:'制作预览确认'});fireEvent.click(screen.getByLabelText('已核对本次输入、来源和处理边界'));expect(button('仅创建任务并入队').disabled).toBe(false);}
beforeEach(()=>{
  vi.stubGlobal('crypto',webcrypto);useLocalHostSession.setState({token:'synthetic-independent-loudness',actorId:''});let urls=0;
  Object.defineProperty(URL,'createObjectURL',{configurable:true,value:vi.fn(()=>`blob:independent-${++urls}`)});Object.defineProperty(URL,'revokeObjectURL',{configurable:true,value:vi.fn()});
  fetcher=vi.fn(async(url:string,init?:RequestInit)=>{
    if(url.endsWith('/providers'))return reply({items:[],health_probed:false,credentials_read:false});
    if(url.endsWith('/preview'))return reply(audioPreview(JSON.parse(String(init!.body))));
    if(url.endsWith('/jobs')&&init?.method==='POST')return reply(audioJob('QUEUED',1,JSON.parse(String(init.body)).command));
    if(url.endsWith('/jobs'))return reply({items:[]});
    throw new Error('Unexpected independent request '+url);
  });vi.stubGlobal('fetch',fetcher);
});
afterEach(()=>{cleanup();vi.restoreAllMocks();vi.unstubAllGlobals();});
it('front4 decodes independently generated CPU receipt and rejects cross-layer hash/profile/interval/nonfinite corruption',async()=>{
  const api=studioProductionClient(native.executed.novel_id,{sessionToken:''});fetcher.mockResolvedValue(reply(native.executed));expect(await api.get('audio',native.executed.id)).toEqual(native.executed);
  for(const mutate of [
    (j:any)=>j.media_measurement.loudness_matching.source_version++, (j:any)=>j.media_measurement.loudness_matching.source_sha256='e'.repeat(64),
    (j:any)=>j.media_measurement.loudness_matching.in_ms++, (j:any)=>j.media_measurement.loudness_matching.output_frames++,
    (j:any)=>j.media_measurement.loudness_matching.output_sha256='e'.repeat(64), (j:any)=>j.media_measurement.loudness_matching.output_lufs=Infinity,
    (j:any)=>j.media_measurement.loudness_matching.output_true_peak_dbtp=0, (j:any)=>j.media_measurement.container='mp3',
    (j:any)=>j.execution_recipe.parameters.target_lufs=-20
  ]){const job=structuredClone(native.executed);mutate(job);fetcher.mockResolvedValue(reply(job));await expect(api.get('audio',job.id)).rejects.toBeTruthy();}
  fetcher.mockClear();
  for(const params of [{target_lufs:true},{target_lufs:null},{target_lufs:'-23'},{target_lufs:NaN},{target_lufs:-23,gain_db:1},{target_lufs:-23,output_format:'FLAC'},{target_lufs:-23,target_peak_dbfs:-6}]){
    const command=audioCommand('independent',{in_ms:500,out_ms:4500});Object.assign(command.parameters,params);await expect(studioProductionClient(audioProject,{sessionToken:''}).preview(command)).rejects.toBeTruthy();
  }
  expect(fetcher).not.toHaveBeenCalled();
});
it('front5 rejects late previews/candidates and old create/review callbacks after source/permission changes or unmount',async()=>{
  const f=mount();await choose();const late=deferred<Response>();fetcher.mockImplementationOnce(()=>late.promise);fireEvent.click(button('读取制作预览'));await waitFor(()=>expect(calls('/preview')).toHaveLength(1));
  const oldCommand=JSON.parse(String(calls('/preview')[0][1].body));f.rerender(<StudioMediaExecutionPanel {...f.props} assets={audioAssets().map(a=>({...a,version:3}))}/>);await act(async()=>late.resolve(reply(audioPreview(oldCommand))));
  expect(screen.queryByRole('region',{name:'制作预览确认'})).toBeNull();expect(calls('/jobs')).toHaveLength(0);
  f.rerender(<StudioMediaExecutionPanel {...f.props}/>);await reviewedPreview();let oldCreate=retained(button('仅创建任务并入队')).onClick;
  change(label,'-24');change(label,'-23.5');act(()=>oldCreate());expect(calls('/jobs')).toHaveLength(0);
  await reviewedPreview();oldCreate=retained(button('仅创建任务并入队')).onClick;
  f.rerender(<StudioMediaExecutionPanel {...f.props} assets={audioAssets().map(a=>({...a,version:3}))}/>);f.rerender(<StudioMediaExecutionPanel {...f.props}/>);act(()=>oldCreate());expect(calls('/jobs')).toHaveLength(0);
  f.unmount();act(()=>oldCreate());expect(calls('/jobs')).toHaveLength(0);cleanup();
  const source=native.executed.sources[0],assets=[{...audioAssets()[0],id:source.id,novel_id:native.executed.novel_id,version:source.version,sha256:source.digest}];
  const lateBytes=deferred<Response>();let delayed=true;
  fetcher.mockImplementation(async(url:string)=>{
    if(url.endsWith('/providers'))return reply({items:[],health_probed:false,credentials_read:false});
    if(url.endsWith('/candidate'))return delayed?lateBytes.promise:byteResponse();
    throw new Error('Unexpected candidate request '+url);
  });
  const g=mount(native.executed.novel_id,assets,native.executed as unknown as ProductionJob);await screen.findByRole('region',{name:'综合响度实测证据'});
  expect(button('明确审核并入素材库').disabled).toBe(true);fireEvent.click(button('读取并核对候选媒体'));await waitFor(()=>expect(calls('/candidate')).toHaveLength(1));
  g.rerender(<StudioMediaExecutionPanel {...g.props} assets={assets.map(a=>({...a,version:a.version+1}))}/>);await act(async()=>lateBytes.resolve(byteResponse()));
  expect(URL.createObjectURL).not.toHaveBeenCalled();expect(button('明确审核并入素材库').disabled).toBe(true);g.unmount();cleanup();
  delayed=false;const h=mount(native.executed.novel_id,assets,native.executed as unknown as ProductionJob);await screen.findByRole('region',{name:'综合响度实测证据'});fireEvent.click(button('读取并核对候选媒体'));
  await screen.findByLabelText('本任务的音频候选');fireEvent.click(screen.getByLabelText('已查看本次候选，确认采用当前任务版本与输出摘要'));expect(button('明确审核并入素材库').disabled).toBe(false);
  const oldReview=retained(button('明确审核并入素材库')).onClick;
  h.rerender(<StudioMediaExecutionPanel {...h.props} canReview={false}/>);act(()=>oldReview());h.rerender(<StudioMediaExecutionPanel {...h.props}/>);act(()=>oldReview());expect(calls('/review')).toHaveLength(0);expect(button('明确审核并入素材库').disabled).toBe(true);
  h.rerender(<StudioMediaExecutionPanel {...h.props} assets={assets.map(a=>({...a,version:a.version+1}))}/>);act(()=>oldReview());h.unmount();act(()=>oldReview());
  expect(calls('/review')).toHaveLength(0);expect(calls('/execute')).toHaveLength(0);expect(URL.revokeObjectURL).toHaveBeenCalledWith('blob:independent-1');
});
