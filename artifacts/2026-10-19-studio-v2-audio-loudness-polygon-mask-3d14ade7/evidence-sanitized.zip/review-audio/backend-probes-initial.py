from copy import deepcopy
import hashlib,io,json,math,os,struct,sys,wave
from pathlib import Path
import pytest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tests'))
from test_v2_independent_workspace import rig,reopened,import_asset
from test_v2_audio_wav_controls import production,command,snapshot,queue,run,get,review,action
from app.services.studio_audio_execution import StudioAudioExecution,_body
from app.services.audiobook_service import AudiobookError
from app.creative.production_execution_models import MediaCommand
from app.creative.graph_models import MediaNodeParameters
pytestmark=pytest.mark.parametrize('rig',['file'],indirect=True)
EVIDENCE=ROOT.parent

def encoded(raw,rate,channels):
    out=io.BytesIO()
    with wave.open(out,'wb') as w:w.setnchannels(channels);w.setsampwidth(2);w.setframerate(rate);w.writeframes(raw)
    return out.getvalue()
def prepare(e,label,spike=False):
    rate,channels=24000,2
    e.nid=e.create_project('Independent loudness '+label);e.scope={'mode':'local','novel_id':e.nid};e.service.activate(e.nid,e.scope,e.actor)
    values=[]
    for i in range(rate*6):
        t=i/rate
        a=round((1700*math.sin(2*math.pi*431*t)+650*math.sin(2*math.pi*1171*t))*(0.75+0.2*math.sin(2*math.pi*1.25*t)))
        if i<rate*3//4 or i>=rate*21//4:a=32767
        if spike and i==rate*3:a=30000
        values.extend([a,round(a*0.6)])
    raw=struct.pack('<'+'h'*len(values),*values);e.original=encoded(raw,rate,channels)
    e.selected=raw[rate*3//4*channels*2:rate*21//4*channels*2]
    e.source=import_asset(e,data=e.original,filename='independent-'+label+'.wav',kind='audio');e.production=production(e)
    e.command=command(snapshot(e.source),in_ms=750,out_ms=5250,sample_rate=rate,channels=channels,target_lufs=-24.3,request_id='unused')
    e.command['parameters'].pop('request_id');e.command['request_id']='independent-'+label
    return e

def test_cpu1_exact_measured_bytes_interval_and_rehashed_receipt_rejection(rig):
    e=prepare(rig,'exact');queued=queue(e);result=run(e,queued);assert result['status']=='AWAITING_REVIEW',result
    meta,data=e.production.candidate(e.nid,e.scope,e.actor,'audio',result['id'],lambda:None)
    with wave.open(io.BytesIO(data),'rb') as r:
        assert (r.getframerate(),r.getnchannels(),r.getsampwidth())==(24000,2,2)
        frames=r.getnframes();raw=r.readframes(frames)
    proof=result['media_measurement']['loudness_matching']
    assert frames==proof['selected_frames']==proof['output_frames']==108000
    assert proof['selected_pcm_sha256']==hashlib.sha256(e.selected).hexdigest()
    assert proof['output_pcm_sha256']==hashlib.sha256(raw).hexdigest()
    assert proof['output_sha256']==meta['sha256']==result['output_candidate']['digest']==hashlib.sha256(data).hexdigest()
    assert (proof['source_id'],proof['source_version'],proof['source_sha256'],proof['in_ms'],proof['out_ms'])==(e.source['id'],e.source['version'],hashlib.sha256(e.original).hexdigest(),750,5250)
    assert abs(proof['output_lufs']+24.3)<=0.2 and proof['output_true_peak_dbtp']<=-1
    scale=10**(proof['applied_gain_db']/20)
    error=max(abs(a[0]-b[0]*scale) for a,b in zip(struct.iter_unpack('<h',raw),struct.iter_unpack('<h',e.selected)))
    assert error<=1
    assert len(e.service.list_assets(e.nid,e.scope)['items'])==1
    with pytest.raises(FileNotFoundError):e.service.asset(e.nid,e.scope,result['output_candidate']['id'])
    (EVIDENCE/'independent-source.wav').write_bytes(e.original);(EVIDENCE/'independent-candidate.wav').write_bytes(data)
    (EVIDENCE/'independent-cpu-receipt.json').write_text(json.dumps({'command':e.command,'queued':queued,'executed':result,'sample_error_lsb':error},indent=2),encoding='utf-8')
    owner=e.production._audio(e.scope,e.actor);valid=deepcopy(owner.store.load(e.nid,include_studio=True))
    for key,bad in [('source_version',9),('in_ms',751),('output_frames',108001),('output_sha256','c'*64),('input_lufs',float('nan')),('output_true_peak_dbtp',0)]:
        state=deepcopy(valid);row=next(j for j in state['jobs'] if j['id']==result['id']);row['measured']['loudness_matching'][key]=bad
        StudioAudioExecution._receipt(row);owner.store.save(e.nid,state,include_studio=True)
        with pytest.raises(AudiobookError):get(e,result)
        with pytest.raises(AudiobookError):review(e,result)
    owner.store.save(e.nid,valid,include_studio=True)
    e.production=production(e,reopened(e));assert get(e,result)==result
    approved=review(e,result);assert approved['status']=='APPROVED' and approved['media_measurement']==result['media_measurement']
    assert len(e.production.workspace.list_assets(e.nid,e.scope)['items'])==2

def test_cpu2_strict_finite_mutual_contract_and_actual_clipping_rejection(rig):
    base=command(in_ms=750,out_ms=5250,target_lufs=-24.3,sample_rate=24000,channels=2)
    for change in [{'target_lufs':v} for v in [None,True,'-24.3',float('inf'),float('nan'),-31,-13]]+[
        {'target_peak_dbfs':-6},{'output_format':'FLAC'},{'output_format':'MP3'},{'gain_db':1},{'fade_in_ms':1},{'fade_out_ms':1},{'out_ms':3749}]:
        value=deepcopy(base);value['parameters'].update(change)
        with pytest.raises(ValueError):MediaCommand.model_validate(value)
        with pytest.raises(AudiobookError):_body({k:v for k,v in value.items() if k not in {'request_id','allow_cloud','license_note'}})
    with pytest.raises(ValueError):MediaNodeParameters.model_validate({'operation_id':'m8.audio.trim','parameters':base['parameters']})
    e=prepare(rig,'spike',spike=True);result=run(e,queue(e))
    assert result['status']=='FAILED' and result['error_code']=='STUDIO_AUDIO_LOUDNESS_TRUE_PEAK_HEADROOM_REQUIRED',result
    assert result['media_measurement'] is None and result['output_candidate'] is None
    assert len(e.service.list_assets(e.nid,e.scope)['items'])==1
    (EVIDENCE/'independent-rejected.json').write_text(json.dumps(result,indent=2),encoding='utf-8')

def test_cpu3_cancel_and_unknown_recovery_never_reencode_or_autoapprove(rig,monkeypatch):
    import app.services.studio_timeline_export as native
    e=prepare(rig,'cancel');queued=queue(e);original=native.run_guarded_process;calls=[]
    def cancelled(*a,**k):
        result=original(*a,**k);calls.append(1)
        if len(calls)==2:
            current=get(e,queued);e.production.cancel(e.nid,e.scope,e.actor,'audio',queued['id'],action(current),lambda:None)
        return result
    monkeypatch.setattr(native,'run_guarded_process',cancelled);result=run(e,queued)
    assert result['status']=='CANCELLED' and result['media_measurement'] is None and result['output_candidate'] is None,result
    assert len(e.service.list_assets(e.nid,e.scope)['items'])==1
    monkeypatch.setattr(native,'run_guarded_process',original)
    e=prepare(rig,'unknown');create=e.assets.create
    def lost(*a,**k):create(*a,**k);raise OSError('independent lost publication reply')
    monkeypatch.setattr(e.assets,'create',lost);unknown=run(e,queue(e));assert unknown['status']=='UNKNOWN' and unknown['media_measurement']['loudness_matching'],unknown
    monkeypatch.setattr(e.assets,'create',create)
    def forbidden(*a,**k):pytest.fail('UNKNOWN reconciliation must not measure, render or resend')
    monkeypatch.setattr(native,'run_guarded_process',forbidden)
    recovered=e.production.reconcile(e.nid,e.scope,e.actor,'audio',unknown['id'],action(unknown),lambda:None)
    assert recovered['status']=='AWAITING_REVIEW' and recovered['media_measurement']==unknown['media_measurement']
    assert len(e.service.list_assets(e.nid,e.scope)['items'])==1
    with pytest.raises((AudiobookError,ValueError)):e.production.review(e.nid,e.scope,e.actor,'audio',recovered['id'],{**action(recovered).model_dump(),'reviewed_output_digest':'f'*64},lambda:None)
    assert review(e,recovered)['status']=='APPROVED'
    (EVIDENCE/'independent-recovery.json').write_text(json.dumps({'cancelled':result,'unknown':unknown,'recovered':recovered},indent=2),encoding='utf-8')
