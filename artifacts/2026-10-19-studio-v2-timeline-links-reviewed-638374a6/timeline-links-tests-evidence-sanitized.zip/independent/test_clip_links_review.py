"""Two independent original File owner checks; no media render or model calls."""
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace
import hashlib,json,subprocess
import pytest
from test_v2_independent_workspace import rig as original_rig,import_asset,reopened,wav_bytes
from test_v2_audio_editing_pipeline import production,source,edit_body
from app.services.studio_timeline_render import normalize_studio_timeline,timeline_digest
from app.services.studio_timeline_edit import apply_timeline_edits
from app.services.v1_capability_service import CapabilityVersionConflict
from app.experimental.store import canonical
from app.experimental.common import StaleSourceError
ROOT=Path(__file__).resolve().parent
SOURCE=Path(r'<TASK_ROOT>\task-13\edit04-audio09')
@pytest.fixture
def file_rig(tmp_path,monkeypatch):yield from original_rig.__wrapped__(SimpleNamespace(param='file'),tmp_path,monkeypatch)
def record(name,value):(ROOT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
def snapshots(e):return {str(p.relative_to(e.root)):p.read_bytes() for p in e.root.rglob('*.json')}
def starts(t):return {clip['id']:clip['start_ms'] for track in t['tracks'] for clip in track['clips']}
def prepare(e):
 e.service.activate(e.nid,e.scope,e.actor)
 e.image=import_asset(e);e.audio=import_asset(e,data=wav_bytes(),kind='audio',filename='review-owned.wav');e.production=production(e)
 raw={'schema_version':2,'duration_ms':8000,'width':64,'height':64,'fps':25,'captions':[],
  'tracks':[{'id':'visual','kind':'VIDEO','order':0,'clips':[{'id':i,'source_snapshot':source(e.image),'start_ms':p,'in_ms':0,'out_ms':400} for i,p in [('v-a',1200),('v-b',3600)]]},
   {'id':'voice','kind':'AUDIO','order':1,'clips':[{'id':i,'source_snapshot':source(e.audio),'start_ms':p,'in_ms':0,'out_ms':100} for i,p in [('a-a',900),('a-b',3900)]]}]}
 e.saved=e.production.timeline_save(e.nid,e.scope,e.actor,None,{'title':'Independent two-pair link proof','timeline':raw,'expected_version':0},lambda:None)
 return e,raw
LINKS=[{'op':'clip.link','video_clip_id':'v-b','audio_clip_id':'a-b'},{'op':'clip.link','video_clip_id':'v-a','audio_clip_id':'a-a'}]
def edit(e,row,ops,key,guard=lambda:None):return e.production.timeline_edit(e.nid,e.scope,e.actor,row['id'],edit_body(row,ops,key),guard)


def test_link1_old_absence_exact_and_two_offsets_atomic_move_save_reopen_unlink(file_rig):
 e,raw=prepare(file_rig);initial=deepcopy(e.saved)
 parent_source=subprocess.run(['git','-C',str(SOURCE),'show','d9b2ea4b:app/services/studio_timeline_schema.py'],capture_output=True,text=True,encoding='utf-8',check=True).stdout
 namespace={'__name__':'app.services.review_old_schema','__package__':'app.services'};exec(compile(parent_source,'exact-parent-schema','exec'),namespace)
 old=namespace['normalize_timeline_v2'](deepcopy(raw));assert normalize_studio_timeline(raw)==old==initial['timeline']
 assert 'clip_links' not in initial['timeline'] and timeline_digest(old)==initial['timeline_digest']
 linked=edit(e,initial,LINKS,'review-link-both')
 assert linked['timeline']['clip_links']==[{'video_clip_id':'v-a','audio_clip_id':'a-a','offset_ms':-300},{'video_clip_id':'v-b','audio_clip_id':'a-b','offset_ms':300}]
 original=deepcopy(linked['timeline']);moved=edit(e,linked,[{'op':'clip.move','clip_id':'a-a','track_id':'voice','start_ms':1400},{'op':'clip.move','clip_id':'v-a','track_id':'visual','start_ms':1700}],'review-both-once')
 assert starts(moved['timeline'])=={'v-a':1700,'v-b':3600,'a-a':1400,'a-b':3900}
 moved2=edit(e,moved,[{'op':'clip.move','clip_id':'v-b','track_id':'visual','start_ms':4200}],'review-other-pair')
 assert starts(moved2['timeline'])=={'v-a':1700,'v-b':4200,'a-a':1400,'a-b':4500}
 assert moved2['timeline']['clip_links']==original['clip_links']
 fresh=production(e,reopened(e));assert fresh.timeline_get(e.nid,e.scope,e.actor,moved2['id'],lambda:None)==moved2
 changed=deepcopy(moved2['timeline'])
 for track in changed['tracks']:
  for clip in track['clips']:clip['start_ms']+=100
 saved=fresh.timeline_save(e.nid,e.scope,e.actor,moved2['id'],{'expected_version':moved2['version'],'title':moved2['title'],'timeline':changed},lambda:None)
 assert saved['version']==moved2['version']+1 and saved['timeline']['clip_links']==original['clip_links']
 unlinked=edit(e,saved,[{'op':'clip.unlink','clip_id':'a-a'}],'review-unlink-one')
 assert unlinked['timeline']['clip_links']==[original['clip_links'][1]]
 positions=starts(unlinked['timeline']);independent=edit(e,unlinked,[{'op':'clip.move','clip_id':'v-a','track_id':'visual','start_ms':positions['v-a']+75}],'review-after-unlink')
 assert starts(independent['timeline'])['a-a']==positions['a-a']
 final=edit(e,independent,[{'op':'clip.unlink','clip_id':'v-b'}],'review-unlink-last')
 assert 'clip_links' not in final['timeline']
 assert production(e,reopened(e)).timeline_get(e.nid,e.scope,e.actor,final['id'],lambda:None)==final
 history=fresh.timeline_history(e.nid,e.scope,e.actor,final['id'],lambda:None)['items']
 assert any(item['timeline']==initial['timeline'] for item in history)
 assert any(item['timeline'].get('clip_links')==original['clip_links'] for item in history)
 assert not e.production.list(e.nid,e.scope,e.actor,lambda:None)['items']
 record('case1-file.json',{'initial':initial,'linked':linked,'moved':moved,'whole_saved':saved,'unlinked':final,'assets':[e.image,e.audio],'history':history,'old_absent_digest':timeline_digest(old),'old_parent':'d9b2ea4b602af099f133e7ef7e954fb7618979ae','no_render_jobs':True,'physical_scope':str(e.raw_store.path(e.nid,e.scope)),'physical_sha256':hashlib.sha256(e.raw_store.path(e.nid,e.scope).read_bytes()).hexdigest()})


def test_link2_locked_bounds_stale_source_cas_and_late_guard_reject_whole_file_batch(file_rig,monkeypatch):
 e,_=prepare(file_rig);linked=edit(e,e.saved,LINKS,'review-link');observed=[]
 prefix={'op':'canvas.update','changes':{'width':80}}
 for label,ops in [('negative-partner',[prefix,{'op':'clip.move','clip_id':'v-a','track_id':'visual','start_ms':200}]),('overlap',[prefix,{'op':'clip.move','clip_id':'v-a','track_id':'visual','start_ms':3500}]),('unknown-op',[prefix,{'op':'clip.link.execute','video_clip_id':'v-a','audio_clip_id':'a-a'}]),('linked-trim',[prefix,{'op':'clip.trim','clip_id':'a-a','in_ms':0,'out_ms':80,'ripple':False}]),('linked-split',[prefix,{'op':'clip.split','clip_id':'v-a','at_ms':1400,'new_clip_id':'unsupported'}])]:
  before=snapshots(e)
  with pytest.raises(ValueError) as error:edit(e,linked,ops,'review-reject-'+label)
  assert snapshots(e)==before;observed.append({'case':label,'error':str(error.value),'writes':0})
 locked=edit(e,linked,[{'op':'track.update','track_id':'voice','changes':{'locked':True}}],'review-lock-partner')
 for label,ops in [('locked-move',[prefix,{'op':'clip.move','clip_id':'v-a','track_id':'visual','start_ms':1500}]),('locked-unlink',[prefix,{'op':'clip.unlink','clip_id':'v-a'}])]:
  before=snapshots(e)
  with pytest.raises(ValueError,match='TRACK_LOCKED'):edit(e,locked,ops,'review-'+label)
  assert snapshots(e)==before;observed.append({'case':label,'writes':0})
 current=edit(e,locked,[{'op':'track.update','track_id':'voice','changes':{'locked':False}}],'review-unlock')
 move=[prefix,{'op':'clip.move','clip_id':'v-a','track_id':'visual','start_ms':1700}];before=snapshots(e)
 with pytest.raises(StaleSourceError,match='STUDIO_TIMELINE_CHANGED'):edit(e,linked,move,'review-stale-cas')
 with pytest.raises(CapabilityVersionConflict):e.production.timeline_save(e.nid,e.scope,e.actor,current['id'],{'expected_version':linked['version'],'title':current['title'],'timeline':current['timeline']},lambda:None)
 assert snapshots(e)==before
 with pytest.raises(FileNotFoundError):e.production.timeline_edit(e.nid,e.scope,'foreign-author',current['id'],edit_body(current,move,'review-foreign'),lambda:None)
 assert snapshots(e)==before
 original=e.production._timeline_sources_current;revoked=False
 def source_then_revoke(*args,**kwargs):
  nonlocal revoked
  result=original(*args,**kwargs);revoked=True;return result
 def guard():
  if revoked:raise PermissionError('independent late permission revocation')
 monkeypatch.setattr(e.production,'_timeline_sources_current',source_then_revoke)
 with pytest.raises(PermissionError,match='late permission'):edit(e,current,move,'review-revoked',guard)
 assert revoked and snapshots(e)==before
 monkeypatch.setattr(e.production,'_timeline_sources_current',original)
 with e.service._asset_scope(e.nid,e.scope):e.assets.update_metadata(e.audio['id'],{'scene_id':'new-source-revision'},expected_version=e.audio['version'])
 before=snapshots(e)
 with pytest.raises((ValueError,FileNotFoundError)):edit(e,current,move,'review-stale-source')
 assert snapshots(e)==before
 assert e.production.timeline_get(e.nid,e.scope,e.actor,current['id'],lambda:None)['timeline']==current['timeline']
 record('case2-rejections.json',{'rejections':observed,'stale_CAS_rejected':True,'foreign_actor_rejected':True,'late_guard_observed':revoked,'stale_source_rejected':True,'all_JSON_file_bytes_unchanged_for_each_failed_batch':True,'unsupported_cross_track_or_exchange_not_accepted':True})
