import { act, cleanup, fireEvent, render, renderHook, screen, waitFor, within } from '@testing-library/react';
import { expect, it, vi } from 'vitest';
import { ApiError } from '<TASK_ROOT>/task-13/edit04-audio09/frontend/src/api';
import { StudioTimelineEditor } from '<TASK_ROOT>/task-13/edit04-audio09/frontend/src/creative/StudioTimelineEditor';
import { useStudioTimelineEditor, type StudioTimelineEditorProps } from '<TASK_ROOT>/task-13/edit04-audio09/frontend/src/creative/useStudioTimelineEditor';
import { checkedTimelineRow, cloneTimeline } from '<TASK_ROOT>/task-13/edit04-audio09/frontend/src/creative/studioTimelineTypes';
import type { StudioProductionClient } from '<TASK_ROOT>/task-13/edit04-audio09/frontend/src/creative/studioProductionClient';
import type { StudioAsset } from '<TASK_ROOT>/task-13/edit04-audio09/frontend/src/creative/studioClient';
import evidence from './case1-file.json';

const source = checkedTimelineRow(evidence.initial);
function setup(panel = false) {
  const client = { timelineList: vi.fn(async () => ({ items: [cloneTimeline(source)] })), timelineGet: vi.fn(async () => cloneTimeline(source)),
    timelineSave: vi.fn(), timelineRender: vi.fn(), timelineEdit: vi.fn() };
  const props: StudioTimelineEditorProps = { client: client as unknown as StudioProductionClient, assets: evidence.assets as unknown as StudioAsset[],
    canMutate: true, busy: false, projectId: evidence.initial.novel_id, isCurrent: () => true, read: work => work(), mutate: work => work(),
    onDirtyChange: vi.fn(), onJob: vi.fn(), onUnavailable: vi.fn() };
  const hook = panel ? undefined : renderHook((p: StudioTimelineEditorProps) => useStudioTimelineEditor(p), { initialProps: props });
  if (panel) render(<StudioTimelineEditor {...props} />);
  return { client, props, hook };
}
async function adopt(state: ReturnType<typeof setup>) {
  const h = state.hook!; await waitFor(() => expect(h.result.current.rows).toHaveLength(1));
  await act(async () => h.result.current.checkServer(source.id));
  act(() => h.result.current.setAdoptConfirmed(true)); act(() => h.result.current.adoptCandidate(false));
}
function assertNoExecution(state: ReturnType<typeof setup>) {
  expect(state.client.timelineRender).not.toHaveBeenCalled(); expect(state.client.timelineEdit).not.toHaveBeenCalled();
}

it('fences UNKNOWN/CAS, permission/draft ABA, and stale selection callbacks using real File receipt inputs', async () => {
  // One independent frontend check, with two terminal failures and independent callback-generation counterexamples.
  for (const [status, code, expected] of [[0, 'NETWORK_ERROR', 'UNKNOWN'], [409, 'CONFLICT', 'CONFLICT']] as const) {
    const state = setup(); await adopt(state); const h = state.hook!;
    act(() => expect(h.result.current.linkClips(['v-a', 'a-a'])).toBe(true));
    const before = cloneTimeline(h.result.current.draft), retiredUnlink = h.result.current.unlinkClips;
    state.client.timelineSave.mockRejectedValueOnce(new ApiError({ status, code, message: 'Independent lost response / CAS conflict' }));
    await act(async () => h.result.current.save()); expect(h.result.current.failure).toBe(expected);
    act(() => { expect(retiredUnlink(['a-a'])).toBe(false); expect(h.result.current.unlinkClips(['a-a'])).toBe(false);
      expect(h.result.current.linkClips(['v-b', 'a-b'])).toBe(false); expect(h.result.current.moveSelection(['v-a'], 100)).toBe(false); });
    expect(h.result.current.draft).toEqual(before); await act(async () => h.result.current.save());
    expect(state.client.timelineSave).toHaveBeenCalledTimes(1); assertNoExecution(state); cleanup();
  }
  const state = setup(); await adopt(state); const h = state.hook!, original = cloneTimeline(h.result.current.draft);
  const beforeEdit = h.result.current.linkClips;
  act(() => h.result.current.change(d => { d.title += ' temporary'; })); act(() => h.result.current.undo());
  expect(h.result.current.draft).toEqual(original); act(() => expect(beforeEdit(['v-a', 'a-a'])).toBe(false));
  const beforePermission = h.result.current.linkClips;
  h.rerender({ ...state.props, canMutate: false }); h.rerender(state.props);
  act(() => expect(beforePermission(['v-a', 'a-a'])).toBe(false)); expect(h.result.current.draft).toEqual(original);
  act(() => expect(h.result.current.linkClips(['v-a', 'a-a'])).toBe(true));
  expect(h.result.current.draft.timeline.clip_links).toEqual([{ video_clip_id: 'v-a', audio_clip_id: 'a-a', offset_ms: -300 }]);
  expect(state.client.timelineSave).not.toHaveBeenCalled(); assertNoExecution(state); cleanup();

  const ui = setup(true);
  await waitFor(() => expect(screen.getByLabelText('读取已保存时间线').querySelector(`option[value="${source.id}"]`)).toBeTruthy());
  fireEvent.change(screen.getByLabelText('读取已保存时间线'), { target: { value: source.id } });
  const review = await screen.findByLabelText('核对服务端时间线');
  fireEvent.click(within(review).getByLabelText('已核对服务端内容与本地输入，确认以下选择'));
  fireEvent.click(within(review).getByRole('button', { name: '采用服务端时间线' }));
  const tracks = screen.getByLabelText('轨道头');
  fireEvent.click(within(tracks).getByRole('button', { name: 'v-a' }));
  fireEvent.click(within(tracks).getByRole('button', { name: 'a-a' }), { ctrlKey: true });
  const panel = screen.getByRole('region', { name: '视频音频片段链接' });
  const button = within(panel).getByRole('button', { name: '链接所选视频与音频' });
  const reactProps = Object.keys(button).find(k => k.startsWith('__reactProps$'))!;
  const retiredClick = (button as unknown as Record<string, { onClick: () => void }>)[reactProps].onClick;
  fireEvent.click(within(tracks).getByRole('button', { name: 'a-a' }), { ctrlKey: true });
  fireEvent.click(within(tracks).getByRole('button', { name: 'a-a' }), { ctrlKey: true });
  act(() => retiredClick()); expect(within(panel).queryByText(/v-a ↔ a-a/)).toBeNull();
  fireEvent.click(within(panel).getByRole('button', { name: '链接所选视频与音频' }));
  expect(within(panel).getByText(/v-a ↔ a-a.*-300/)).toBeTruthy();
  expect(ui.client.timelineSave).not.toHaveBeenCalled(); assertNoExecution(ui); cleanup();
});
