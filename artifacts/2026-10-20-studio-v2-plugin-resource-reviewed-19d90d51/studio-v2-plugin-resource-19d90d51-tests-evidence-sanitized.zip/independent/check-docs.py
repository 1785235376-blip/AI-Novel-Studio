import json
from pathlib import Path, PurePosixPath
import re
import subprocess

root = Path(__file__).parent
repo = root.parent / 'ip'
feature = '15a4b52c07621ed1919a899aa75c26f003f9bd59'
docs = '19d90d51eed4a9683c4290592dd91495125e5fcf'
base = 'a8ac7dff36c94e3b58d2edc7116708ef4e42f742'
def git(*args): return subprocess.check_output(['git', *args], cwd=repo).decode('utf-8').strip()
assert git('show', '-s', '--format=%P', feature) == base
assert git('show', '-s', '--format=%P', docs) == feature
assert set(git('diff', '--name-only', feature, docs).splitlines()) == {'README.md', '.github/PULL_REQUEST_TEMPLATE.md'}
readme = git('show', docs + ':README.md')
section = readme.split('## 开发与贡献', 1)[1].split('\n## ', 1)[0]
relative = re.findall(r'\[[^\]]+\]\(([^)]+)\)', section)
assert relative == ['docs/development/README.md', 'docs/development/contribution-review.md']
links = []
for path in relative:
    git('cat-file', '-e', docs + ':' + path)
    links.append({'kind': 'README relative', 'path': path, 'exists_in_fixed_snapshot': True})
template = git('show', docs + ':.github/PULL_REQUEST_TEMPLATE.md')
urls = re.findall(r'https://github\.com/1785235376-blip/AI-Novel-Studio/blob/([a-f0-9]{40})/([^\s)]+)', template)
assert len(urls) == 2
for sha, path in urls:
    assert sha == base
    git('cat-file', '-e', sha + ':' + path)
    assert git('rev-parse', base + ':' + path) == git('rev-parse', docs + ':' + path)
    links.append({'kind': 'PR template fixed GitHub blob URL', 'sha': sha, 'path': path, 'exists_in_fixed_snapshot': True, 'http_checked': False})
for path in ['.github/workflows', '.github/ci']:
    assert git('rev-parse', base + ':' + path) == git('rev-parse', docs + ':' + path)
guide = git('show', docs + ':docs/development/contribution-review.md')
assert all(term in template for term in ['实际基线 SHA', 'owner', '契约', '恢复', '实际执行的命令', 'skip 和失败', '未运行', '历史回执'])
assert all(term in guide for term in ['实际基线', '最低检查', '恢复', '共享', 'skip', 'UNKNOWN'])
result = {'status': 'PASS_STATIC_ONLY', 'feature_commit': feature, 'docs_commit': docs, 'base': base,
    'links': links, 'template': 'Thin review fields agree with the unchanged existing contribution guide: baseline/trigger/behavior/files/owner/contracts/recovery/actual commands/environment/source/results/skip/failures/not-accepted scope; no new authority or CI rule.',
    'ci_and_workflow_trees_unchanged': True, 'public_http_link_availability_not_claimed': True}
(root / 'docs-static.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print('PASS: four new links resolve in their pinned Git snapshots; existing guides and CI/workflow trees unchanged.')
