// @vitest-environment jsdom
import { StrictMode } from 'react';
import { act, cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, expect, it, vi } from 'vitest';
import { api } from '../../../task-12/plugin-resource-detail/frontend/src/api';
import { PluginInspector } from '../../../task-12/plugin-resource-detail/frontend/src/novel/PluginInspector';
import { resourceBodyText, resourceDetailPin } from '../../../task-12/plugin-resource-detail/frontend/src/novel/pluginResourceDetailContract';

const inspection = { id: 'independent-readonly-pack', name: 'Independent resource review', version: '1.0.0', pluginVersion: '1.0.0', status: 'MANIFEST_ACTIVE', isolation: 'DENY_ALL' };
function fixture() {
  const resource = { plugin_id: inspection.id, resource_id: 'resources:review.json', kind: 'workflow_templates', name: 'Review text', schema_version: '1.0', sha256: 'a'.repeat(64), validated: true, execution_supported: false };
  const catalog = { plugin_id: inspection.id, status: 'MANIFEST_ACTIVE', items: [resource], total: 1, resource_count: 1, invalid_resource_count: 0,
    visible: true, validated: true, validation_status: 'VALIDATED', execution_supported: false, isolation: 'DENY_ALL' };
  return { resource, catalog, detail: { ...resource, data: { body: 'VALID_REVIEW_BODY' } } };
}
const read = () => screen.getByRole('button', { name: '读取 Review text 的资源正文' });
const body = () => screen.queryByLabelText('Review text 的资源正文');
const view = (value = inspection) => <StrictMode><PluginInspector inspection={value} /></StrictMode>;
async function setup() {
  const data = fixture(), catalog = vi.spyOn(api, 'pluginResources').mockResolvedValue(data.catalog), detail = vi.spyOn(api, 'pluginResource').mockResolvedValue(data.detail);
  const rendered = render(view()); await screen.findByRole('button', { name: '读取 Review text 的资源正文' });
  return { data, catalog, detail, rendered };
}
afterEach(() => { cleanup(); vi.restoreAllMocks(); });

it('group 1: disabled, identity and digest drift refuse text and remove a previously visible body', async () => {
  const f = fixture();
  for (const change of [{ status: 'DISABLED' }, { visible: false }, { plugin_id: 'another-plugin' }, { validation_status: 'DRIFT' }])
    expect(resourceDetailPin(inspection.id, { ...f.catalog, ...change }, f.resource)).toBeUndefined();
  const pin = resourceDetailPin(inspection.id, f.catalog, f.resource)!;
  for (const patch of [{ status: 'DISABLED' }, { plugin_id: 'another-plugin' }, { sha256: 'b'.repeat(64) }, { execution_supported: true }])
    expect(() => resourceBodyText({ ...f.detail, ...patch }, pin)).toThrow();
  const state = await setup();
  for (const patch of [{ status: 'DISABLED' }, { plugin_id: 'another-plugin' }, { sha256: 'b'.repeat(64) }]) {
    state.detail.mockResolvedValue(state.data.detail); fireEvent.click(read());
    await waitFor(() => expect(body()?.textContent).toContain('VALID_REVIEW_BODY'));
    state.detail.mockResolvedValue({ ...state.data.detail, ...patch, data: { private: 'REJECTED_BODY' } }); fireEvent.click(read());
    expect(body()).toBeNull(); await screen.findByRole('alert'); expect(screen.queryByText(/REJECTED_BODY/)).toBeNull();
  }
  state.rendered.rerender(view({ ...inspection, status: 'DISABLED' }));
  expect(screen.queryByRole('button', { name: '读取 Review text 的资源正文' })).toBeNull(); expect(body()).toBeNull();
});

it('group 2: version and plugin ABA discard late old replies and require a fresh explicit read', async () => {
  for (const change of ['version', 'pluginVersion', 'id'] as const) {
    const state = await setup(); let resolve!: (value: any) => void;
    state.detail.mockImplementationOnce(() => new Promise(done => { resolve = done; }));
    fireEvent.click(read()); fireEvent.click(read()); expect(state.detail).toHaveBeenCalledTimes(1);
    state.rendered.rerender(view({ ...inspection, [change]: change === 'id' ? 'different-plugin' : '2.0.0' }));
    state.rendered.rerender(view()); await screen.findByRole('button', { name: '读取 Review text 的资源正文' });
    await act(async () => resolve({ ...state.data.detail, data: { private: 'LATE_OLD_SELECTION' } }));
    expect(body()).toBeNull(); expect(screen.queryByText(/LATE_OLD_SELECTION/)).toBeNull();
    state.detail.mockResolvedValue({ ...state.data.detail, data: { body: 'FRESH_EXPLICIT_BODY' } }); fireEvent.click(read());
    await waitFor(() => expect(body()?.textContent).toContain('FRESH_EXPLICIT_BODY'));
    expect(state.detail).toHaveBeenCalledTimes(2); state.rendered.unmount(); vi.restoreAllMocks();
  }
});

it('group 3: JSON body stays literal selectable text with zero execution, URL fetching or mutation calls', async () => {
  const fetch = vi.spyOn(globalThis, 'fetch').mockRejectedValue(new Error('unexpected URL request'));
  const open = vi.spyOn(window, 'open').mockReturnValue(null);
  const names = Object.keys(api).filter(name => /^(install|register|enable|set|remove|execute|run|apply|create|save|update|delete|export|activate|start)/i.test(name) && typeof (api as any)[name] === 'function');
  const mutations = names.map(name => vi.spyOn(api as any, name));
  const state = await setup(), payload = { text: '<script>globalThis.__plugin_review_executed=true</script>', image: '<img src="https://untrusted.invalid/a" onerror="alert(1)">',
    link: '<a href="javascript:alert(1)">run</a>', reference: 'https://untrusted.invalid/model', command: 'execute-workflow', execution_supported: false };
  state.detail.mockResolvedValue({ ...state.data.detail, data: payload });
  expect(state.detail).not.toHaveBeenCalled(); fireEvent.click(read());
  await waitFor(() => expect(body()).not.toBeNull());
  expect(JSON.parse(body()!.textContent!)).toEqual(payload);
  expect(body()!.querySelector('script,img,a,iframe,object,embed')).toBeNull(); expect((globalThis as any).__plugin_review_executed).toBeUndefined();
  expect(body()!.getAttribute('tabindex')).toBe('0'); body()!.focus(); expect(document.activeElement).toBe(body());
  expect(fetch).not.toHaveBeenCalled(); expect(open).not.toHaveBeenCalled(); mutations.forEach(spy => expect(spy).not.toHaveBeenCalled());
  expect(state.detail.mock.calls).toEqual([[inspection.id, state.data.resource.resource_id]]);
});
