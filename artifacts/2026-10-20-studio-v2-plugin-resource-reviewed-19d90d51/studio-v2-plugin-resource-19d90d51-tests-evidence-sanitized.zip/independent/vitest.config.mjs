import fs from 'node:fs';
const root = '<TASK_ROOT>/task-10/ip/frontend';
const p = JSON.parse(fs.readFileSync(root + '/package.json', 'utf8'));
// Keep the read-only author's source imports on this review's one dependency runtime.
// The author removed its dependency junction during its own cleanup.
export default { root, resolve: { dedupe: Object.keys({ ...p.dependencies, ...p.devDependencies }) },
  esbuild: { jsx: 'automatic' }, test: { include: ['plugin-resource-independent.test.tsx'], environment: 'jsdom' } };
