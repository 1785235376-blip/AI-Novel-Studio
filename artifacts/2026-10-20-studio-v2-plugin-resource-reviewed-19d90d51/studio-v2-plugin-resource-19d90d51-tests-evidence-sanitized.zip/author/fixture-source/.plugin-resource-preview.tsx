import React from 'react';
import { createRoot } from 'react-dom/client';
import './src/ui/ui.css';
import './src/ui/fixture.css';
import './src/ui/desktop-craft.css';
import { AppShell } from './src/ui/AppShell';
import { PluginInspector } from './src/novel/PluginInspector';
import { api } from './src/api';
import payload from './.plugin-resource-preview.json';
api.pluginResources = async () => payload.catalog;
api.pluginResource = async () => payload.detail;
createRoot(document.getElementById('root')!).render(<AppShell module="NOVEL" onModuleChange={() => {}}
  scope={{ workspace: '测试工作区', project: '官方声明式资源', storyline: '主线', branch: '当前分支' }} actor="测试作者"
  sidebar={<div className="placeholder-sidebar"><h2>项目导航</h2><p>本地插件治理</p></div>}
  main={<div className="fixture-editor"><header><h1>声明式资源只读预览</h1></header><article><p>本地视觉夹具复用原 AppShell 和 PluginInspector。未安装、激活或执行插件。</p></article></div>}
  inspector={<PluginInspector inspection={payload.inspection} />} status="File · 资源正文只读检查" />);
