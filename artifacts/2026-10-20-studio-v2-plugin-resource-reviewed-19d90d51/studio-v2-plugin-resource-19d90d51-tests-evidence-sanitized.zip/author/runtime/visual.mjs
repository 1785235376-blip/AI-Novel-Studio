import { chromium } from '../../plugin-resource-detail/frontend/node_modules/@playwright/test/index.mjs';
import fs from 'node:fs/promises';
import path from 'node:path';
const output = path.resolve(import.meta.dirname, '..', 'visual');
await fs.mkdir(output, { recursive: true });
const browser = await chromium.launch({ headless: true });
const page = await browser.newPage({ locale: 'zh-CN', timezoneId: 'Asia/Shanghai', colorScheme: 'light', deviceScaleFactor: 1 });
const errors = [], external = [], results = [];
page.on('pageerror', e => errors.push(String(e)));
await page.route('**/*', route => {
  if (new URL(route.request().url()).hostname === '127.0.0.1') return route.continue();
  external.push(route.request().url()); return route.abort();
});
for (const viewport of [{ width: 1366, height: 768 }, { width: 1440, height: 900 }, { width: 1920, height: 1080 }]) {
  await page.setViewportSize(viewport);
  await page.goto('http://127.0.0.1:5332/.plugin-resource-preview.html');
  await page.evaluate(() => document.fonts.ready);
  const button = page.getByRole('button', { name: '读取 Character Continuity Audit 的资源正文' });
  await button.click();
  const body = page.getByLabel('Character Continuity Audit 的资源正文', { exact: true });
  await body.waitFor();
  await body.focus();
  const focused = await body.evaluate(el => el === document.activeElement);
  const geometry = await page.evaluate(() => {
    const rect = s => { const r = document.querySelector(s).getBoundingClientRect(); return { width: r.width, height: r.height }; };
    const inspector = document.querySelector('.workspace-inspector');
    return { header: rect('.global-header'), context: rect('.context-bar'), status: rect('.status-bar'),
      pageWidth: document.documentElement.scrollWidth, inspectorWidth: inspector.clientWidth,
      inspectorScrollWidth: inspector.scrollWidth, activeContent: document.querySelectorAll('.plugin-resource-detail img,.plugin-resource-detail a,.plugin-resource-detail script,.plugin-resource-detail iframe').length };
  });
  await page.screenshot({ path: path.join(output, `inspector-${viewport.width}x${viewport.height}.png`) });
  await page.locator('.plugin-resource-detail').screenshot({ path: path.join(output, `detail-${viewport.width}x${viewport.height}.png`) });
  const passed = focused && geometry.header.height === 56 && geometry.context.height === 44 && geometry.status.height === 32
    && geometry.pageWidth <= viewport.width && geometry.inspectorScrollWidth <= geometry.inspectorWidth + 1 && geometry.activeContent === 0;
  results.push({ viewport, geometry, keyboardFocusableBody: focused, status: passed ? 'PASS' : 'FAIL' });
}
await browser.close();
await fs.writeFile(path.join(output, 'receipt.json'), JSON.stringify({ mode: 'Local React fixture; original official resource JSON, no live host mutation', errors, external, results }, null, 2));
console.log(JSON.stringify({ errors, external, results }));
if (errors.length || external.length || results.some(r => r.status !== 'PASS')) process.exitCode = 1;
