import original from '../../plugin-resource-detail/frontend/vite.config';
export default { ...original, cacheDir: '<TASK_ROOT>/task-12/plugin-resource-detail-evidence/runtime/vite-cache' };
