"""Original File/HTTP Canvas result adoption with synthetic local provider bytes.

No production owner, graph invoker, authorization function or approval state is
patched. The process fixture returns one generated PNG through original A1111.
"""
from contextlib import ExitStack, contextmanager
from copy import deepcopy
from hashlib import sha256
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from io import BytesIO
from pathlib import Path
from threading import Thread
from types import SimpleNamespace
import base64
import json

import pytest
from PIL import Image

from test_studio_process_reopen_v2 import original_application


pytestmark = pytest.mark.file_backend_only


def record(e, label, response, status=200):
    try:
        body = response.json()
    except ValueError:
        body = {"byte_count": len(response.content), "sha256": sha256(response.content).hexdigest()}
    e.receipts.append({"label": label, "method": response.request.method,
                       "url": str(response.request.url), "status": response.status_code, "body": body})
    (e.run / "http-receipts.json").write_text(json.dumps(e.receipts, indent=2), encoding="utf-8")
    assert response.status_code == status, f"{label}: {response.status_code}: {response.text}"
    return body


@contextmanager
def synthetic_provider(run):
    image = BytesIO()
    Image.new("RGB", (64, 64), (37, 107, 173)).save(image, format="PNG")
    png = image.getvalue()
    calls = []
    encoded = base64.b64encode(png).decode("ascii")

    class Provider(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def reply(self, value):
            body = json.dumps(value).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            self.reply([{"title": "synthetic.safetensors"}])

        def do_POST(self):
            assert self.path == "/sdapi/v1/txt2img"
            calls.append(json.loads(self.rfile.read(int(self.headers["Content-Length"]))))
            (run / "provider-calls.json").write_text(json.dumps(calls, indent=2), encoding="utf-8")
            self.reply({"images": [encoded]})

    server = ThreadingHTTPServer(("127.0.0.1", 0), Provider)
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    config = run / "providers.json"
    config.write_text(json.dumps({"automatic1111": {
        "endpoint": f"http://127.0.0.1:{server.server_port}",
        "default_model": "synthetic.safetensors", "api_style": "automatic1111",
        "local": True, "enabled": True, "requires_credential": False}}), encoding="utf-8")
    try:
        yield config, png, calls
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)


@pytest.fixture(params=["/api", "/api/v1"])
def approved_node(tmp_path, request):
    root = Path(__file__).resolve().parents[1]
    run = tmp_path / "original-canvas-process"
    run.mkdir()
    e = SimpleNamespace(root=root, run=run, prefix=request.param, receipts=[])
    with synthetic_provider(run) as (config, png, calls):
        e.config, e.png, e.calls = config, png, calls
        with ExitStack() as app_stack:
            client = app_stack.enter_context(original_application(root, run, config, "first-process.log"))
            e.stop_application = app_stack.close
            e.client = client
            project = record(e, "novel.create", client.post(e.prefix + "/novels",
                json={"title": "Synthetic original canvas image adoption"}), 201)
            e.nid = project["id"]
            e.base = f"{e.prefix}/projects/{e.nid}/studio"
            record(e, "studio.activate", client.post(e.base + "/activate"))
            overview = record(e, "studio.overview", client.get(e.base))
            e.incarnation = overview["project"]["incarnation"]
            e.target = record(e, "canvas.create", client.post(e.base + "/canvas-views", json={
                "request_id": "original-node-empty-target", "expected_version": 0,
                "definition": {"schema_version": 1, "title": "Original explicit image node", "cards": [],
                               "viewport": {"x": 0, "y": 0, "zoom": 1}}}), 201)
            e.canvas_url = e.base + "/canvas-views/" + e.target["id"]
            prompt = "Synthetic image node: one blue square, no model inference"
            e.binding = {"contract": "studio-canvas-image-node/1", "project_id": e.nid,
                "scope": {"mode": "local", "novel_id": e.nid}, "incarnation": e.incarnation,
                "canvas_id": e.target["id"], "canvas_version": e.target["version"],
                "canvas_digest": e.target["definition_digest"], "node_id": "generation-node-one",
                "title": "Original explicit image node", "position": {"x": 48, "y": 80},
                "prompt_digest": sha256(prompt.encode("utf-8")).hexdigest()}
            command = {"operation_id": "m5.image.t2i", "request_id": "original-node-generation",
                "provider_id": "automatic1111", "model_id": "synthetic.safetensors", "prompt": prompt,
                "parameters": {"width": 64, "height": 64, "steps": 1, "seed": 42},
                "source_snapshots": [], "allow_cloud": False,
                "license_note": "Self-created synthetic PNG; local Mock provider only",
                "canvas_image_node": e.binding}
            preview = record(e, "production.preview", client.post(e.base + "/production/preview", json=command))
            assert preview["automatic_dispatch"] is False and calls == []
            queued = record(e, "production.create", client.post(e.base + "/production/jobs", json={
                "command": command, "reviewed_preview_digest": preview["preview_digest"]}), 201)
            assert queued["status"] == "QUEUED" and calls == []
            e.job_url = e.base + "/production/jobs/image/" + queued["id"]
            candidate = record(e, "production.execute", client.post(e.job_url + "/execute", json={
                "expected_version": queued["version"], "expected_request_digest": queued["request_digest"]}))
            assert candidate["status"] == "AWAITING_REVIEW" and len(calls) == 1
            binary = client.get(e.job_url + "/candidate")
            record(e, "production.candidate", binary)
            assert binary.content == png
            assert sha256(png).hexdigest() == candidate["output_candidate"]["digest"]
            e.job = record(e, "production.review", client.post(e.job_url + "/review", json={
                "expected_version": candidate["version"], "expected_request_digest": candidate["request_digest"],
                "reviewed_output_digest": candidate["output_candidate"]["digest"]}))
            assert e.job["status"] == "APPROVED" and len(calls) == 1
            e.pin = {"asset_id": e.job["output_candidate"]["id"], "version": e.job["approved_asset_version"],
                     "digest": e.job["output_candidate"]["digest"], "kind": "image"}
            e.asset_url = e.base + "/assets/" + e.pin["asset_id"]
            e.asset = record(e, "asset.formal", client.get(e.asset_url))
            assert (e.asset["id"], e.asset["version"], e.asset["sha256"]) == (
                e.pin["asset_id"], e.pin["version"], e.pin["digest"])
            e.body = {"confirmed": True, "expected_incarnation": e.incarnation,
                "expected_version": e.target["version"], "expected_definition_digest": e.target["definition_digest"],
                "job_id": e.job["id"], "job_version": e.job["version"],
                "job_request_digest": e.job["request_digest"], "asset": e.pin}
            yield e


def snapshot(e, label):
    return {"canvas": record(e, label + ".canvas", e.client.get(e.canvas_url)),
            "history": record(e, label + ".history", e.client.get(e.canvas_url + "/history")),
            "job": record(e, label + ".job", e.client.get(e.job_url)),
            "asset": record(e, label + ".asset", e.client.get(e.asset_url))}


def test_original_approved_image_first_backfill_and_reopen(approved_node):
    e = approved_node
    before = snapshot(e, "before")
    response = e.client.post(e.canvas_url + "/image-node-result", json=e.body)
    # Capture refusal evidence before the positive assertion, including unchanged
    # original durable owners. A baseline403 remains a real failing acceptance.
    if response.status_code != 200:
        record(e, "image-node-result.rejected", response, response.status_code)
        assert snapshot(e, "after-refusal") == before
        assert len(e.calls) == 1
    saved = record(e, "image-node-result.accepted", response)
    assert saved["version"] == e.target["version"] + 1
    assert saved["definition"]["cards"] == [{"id": e.binding["node_id"],
        "position": e.binding["position"], "asset": e.pin}]
    assert saved["definition"]["image_node_origin"] == {
        "contract": "studio-canvas-image-node-result/1", "target": e.binding,
        "job_id": e.job["id"], "job_version": e.job["version"],
        "job_request_digest": e.job["request_digest"], "asset": e.pin}
    after = snapshot(e, "after")
    replay = record(e, "image-node-result.exact-replay",
        e.client.post(e.canvas_url + "/image-node-result", json=e.body))
    assert replay == saved and snapshot(e, "after-replay") == after
    # End the original child process before opening the same durable state.
    e.stop_application()
    with original_application(e.root, e.run, e.config, "reopened-process.log") as reopened:
        assert record(e, "reopen.canvas", reopened.get(e.canvas_url)) == saved
        assert record(e, "reopen.job", reopened.get(e.job_url)) == e.job
        assert record(e, "reopen.asset", reopened.get(e.asset_url)) == e.asset
        alias = "/api/v1" if e.prefix == "/api" else "/api"
        assert record(e, "reopen.alias", reopened.get(alias + e.canvas_url[len(e.prefix):])) == saved
    assert len(e.calls) == 1


@pytest.mark.parametrize("field", ["expected_version", "expected_definition_digest", "expected_incarnation",
    "job_version", "job_request_digest", "asset_id", "asset_version", "asset_digest"])
def test_original_approved_image_rejects_changed_source_pin(approved_node, field):
    e = approved_node
    body = deepcopy(e.body)
    if field == "asset_id":
        body["asset"]["asset_id"] = "another-original-asset"
    elif field == "asset_version":
        body["asset"]["version"] += 1
    elif field == "asset_digest":
        body["asset"]["digest"] = "f" * 64
    elif field in {"expected_version", "job_version"}:
        body[field] += 1
    elif field == "expected_incarnation":
        body[field] = "file:00000000-0000-4000-8000-000000000000"
    else:
        body[field] = "f" * 64
    before = snapshot(e, "before-negative")
    record(e, "image-node-result.changed-" + field,
        e.client.post(e.canvas_url + "/image-node-result", json=body), 409)
    assert snapshot(e, "after-negative") == before
    assert len(e.calls) == 1
