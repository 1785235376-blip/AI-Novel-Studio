from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import time

import httpx


ROOT = Path(r'D:\PoemSeed-Unified-20261027-94f1c72e\layout-verification')
OUT = Path(r'D:\PoemSeed-Unified-20261027-94f1c72e\evidence\m5-layout-8612b1d0')
CHROME = Path(r'D:\PoemSeed-Unified-20261027-94f1c72e\browsers\chromium-1234\chrome-win64\chrome.exe')
NODE = r'C:\Program Files\nodejs\node.exe'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, encoding='utf-8').strip()


def hashes():
    paths = git('ls-files', '--', 'app', 'frontend', 'tests', 'scripts', 'contracts', 'config', 'pyproject.toml').splitlines()
    return {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in paths if (ROOT / p).is_file()}


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    before = hashes()
    assert git('status', '--porcelain') == ''
    receipt = {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
               'source_root': str(ROOT), 'started_utc': datetime.now(timezone.utc).isoformat(),
               'kind': 'real frontend and Chromium; synthetic read-only browser-mocked API, no product execution acceptance',
               'commands': [], 'cases': []}
    (OUT / 'source-before.json').write_text(json.dumps(before, indent=2), encoding='utf-8')
    with socket.socket() as probe:
        probe.bind(('127.0.0.1', 0))
        port = probe.getsockname()[1]
    env = os.environ.copy()
    env.update(PLAYWRIGHT_BROWSERS_PATH=str(CHROME.parents[2]), CHROME=str(CHROME),
               BASE=f'http://127.0.0.1:{port}/', PHASE='after')
    command = [NODE, 'node_modules/vite/bin/vite.js', '--host', '127.0.0.1', '--port', str(port), '--strictPort']
    receipt['vite_command'] = command
    try:
        with (OUT / 'vite.log').open('w', encoding='utf-8') as log:
            server = subprocess.Popen(command, cwd=ROOT / 'frontend', env=env, stdout=log, stderr=subprocess.STDOUT)
            receipt['vite_pid'] = server.pid
            try:
                deadline = time.monotonic() + 40
                with httpx.Client(trust_env=False) as client:
                    while True:
                        assert server.poll() is None, 'Vite terminated before readiness'
                        try:
                            if client.get(env['BASE'], timeout=1).status_code == 200:
                                break
                        except httpx.TransportError:
                            pass
                        assert time.monotonic() < deadline
                        time.sleep(.05)
                for widths, height in [('1366,1024', 768), ('1440', 900), ('1920', 1080)]:
                    label = f'{widths.replace(",", "-")}x{height}'
                    case = OUT / label
                    case.mkdir(exist_ok=True)
                    current_env = {**env, 'WS': widths, 'HEIGHT': str(height),
                                   'OUT': str(case / 'results.json'), 'SHOTS': str(case / 'shots')}
                    argv = [NODE, 'tests/m5/themeDualCanvas.browser.mjs']
                    started = time.monotonic()
                    with (case / 'stdout.log').open('w', encoding='utf-8') as output:
                        result = subprocess.run(argv, cwd=ROOT / 'frontend', env=current_env,
                                                stdout=output, stderr=subprocess.STDOUT, timeout=900)
                    payload = json.loads((case / 'results.json').read_text(encoding='utf-8')) if (case / 'results.json').exists() else None
                    row = {'label': label, 'argv': argv, 'viewport_widths': widths, 'viewport_height': height,
                           'exit_code': result.returncode, 'elapsed_seconds': time.monotonic()-started,
                           'rows': len(payload['rows']) if payload else None,
                           'failures': payload['fails'] if payload else ['No results file']}
                    receipt['cases'].append(row)
                    print(json.dumps(row), flush=True)
            finally:
                server.terminate()
                try:
                    server.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    server.kill(); server.wait(timeout=10)
    finally:
        after = hashes()
        (OUT / 'source-after.json').write_text(json.dumps(after, indent=2), encoding='utf-8')
        receipt.update(source_unchanged=before == after, final_status=git('status', '--porcelain'),
                       ended_utc=datetime.now(timezone.utc).isoformat())
        receipt['passed'] = len(receipt['cases']) == 3 and all(c['exit_code'] == 0 and not c['failures'] for c in receipt['cases']) and receipt['source_unchanged'] and not receipt['final_status']
        (OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
    return 0 if receipt['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
