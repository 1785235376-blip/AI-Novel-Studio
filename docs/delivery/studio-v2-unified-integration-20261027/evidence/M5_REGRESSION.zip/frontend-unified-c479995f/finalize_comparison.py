import collections,hashlib,json,pathlib,re,subprocess
base=pathlib.Path(r'D:\PoemSeed-Unified-20261027-94f1c72e')
out=base/'evidence/frontend-unified-c479995f'
c={x['id']:x for x in json.loads((base/'evidence/frontend-baseline-C/failure-identities.json').read_text(encoding='utf-8'))['failed']}
i={x['id']:x for x in json.loads((out/'failure-identities.json').read_text(encoding='utf-8'))['failed']}
comparison=json.loads((out/'comparison.json').read_text(encoding='utf-8'))
def stackless(s):return '\n'.join(l for l in s.splitlines() if not l.strip().startswith('at '))
def nodeids(s):return re.sub(r'node_[a-f0-9]{16,40}', 'node_<generated-id>', s)
rows=[]
for change in comparison['changed_failure_signatures']:
    key=change['id']; a,b=c[key]['normalized_error'],i[key]['normalized_error']
    category='UNCLASSIFIED'
    if not change['same_headline']:category='A-retained test selector mismatch with C current overflow UI'
    elif stackless(a)==stackless(b):category='async stack frames only'
    elif nodeids(a)==nodeids(b):category='generated node IDs only'
    elif nodeids(stackless(a))==nodeids(stackless(b)):category='generated node IDs plus async stack frames only'
    rows.append({**change,'category':category})
paths=['frontend/src/workspace/state/u1.purge.host.test.tsx','frontend/src/workspace/UnifiedWorkspacePreview.tsx','frontend/src/workspace/state/projectPurge.ts','frontend/src/workspace/state/identityBootstrap.tsx','frontend/src/workspace/panels/novelPreviewPanels.tsx','frontend/src/store.ts','frontend/src/api.ts','frontend/pnpm-lock.yaml','frontend/package.json','frontend/vite.config.ts','frontend/vitest.setup.ts']
refs={'C':'fe4f55412299fadfada0354725b3ca46e418c46a','integrated':'c479995fb976044782eac200775e3990083f3902'}
blobs={p:{k:subprocess.check_output(['git','-C',str(base/'repository'),'rev-parse',ref+':'+p],text=True).strip() for k,ref in refs.items()} for p in paths}
report={'signature_changes':rows,'signature_categories':dict(collections.Counter(x['category'] for x in rows)),'resolved_by_file':dict(collections.Counter(x['id'].split(' :: ',1)[0] for x in comparison['no_longer_failed'])),'purge_source_blobs':blobs,'purge_conclusion':{'status':'OPEN existing C observation-coalescing window; newly observed failure in integrated full run','original_focused':{'C':'PASS','integrated':'FAIL'},'transparent_instrumentation_v2':{'C':'FAIL','integrated':'PASS'},'failing_C_success_observations':[{'dataUpdatedAt':1793171848850,'dataUpdateCount':2},{'dataUpdatedAt':1793171848851,'dataUpdateCount':3}],'failing_C_ProjectPresence_observe':['n1,n2 -> []','n1 -> []'],'cause':'Both successful fetch results reached QueryCache, but the React effect observed only the final render. Distinct millisecond timestamps establish that this observed failure does not require timestamp collision. Only one missing-list confirmation was counted.','fix_suggestion':'Observe each success at the QueryCache completion boundary using query identity/dataUpdateCount, not only the final rendered dataUpdatedAt. Preserve first sighting, nonempty consecutive evidence, failed/empty response rules, and actor reset. No production fix applied.'}}
(out/'independent-findings.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'signature_categories':report['signature_categories'],'resolved_by_file':report['resolved_by_file'],'all_purge_blobs_equal':all(v['C']==v['integrated'] for v in blobs.values())},ensure_ascii=False,indent=2))
for folder in [base/'evidence/frontend-baseline-C',out]:
    hashes={}
    def walk(path):
        for child in path.iterdir():
            if child.name=='node_modules' or child.name=='artifact-hashes.json':continue
            if child.is_dir():walk(child)
            elif child.is_file():hashes[child.relative_to(folder).as_posix()]=hashlib.sha256(child.read_bytes()).hexdigest()
    walk(folder)
    (folder/'artifact-hashes.json').write_text(json.dumps(hashes,indent=2),encoding='utf-8')
