import datetime,json,pathlib,subprocess,time
base=pathlib.Path(r'D:\PoemSeed-Unified-20261027-94f1c72e')
out=base/'evidence/frontend-unified-c479995f'
prefix=[r'C:\Program Files\nodejs\node.exe',r'C:\Program Files\nodejs\node_modules\npm\bin\npm-cli.js','exec','--yes','--package=pnpm@10.6.5','--','pnpm','exec','vitest','run','src/workspace/state/u1.purge.host.test.tsx','--maxWorkers=2','--minWorkers=1','--reporter=default','--reporter=json']
for checkout,label in [('baseline-C','C'),('m3-verification','integrated')]:
    command=prefix+['--outputFile='+str(out/('purge-focused-'+label+'.json'))]
    started=datetime.datetime.now(datetime.timezone.utc).isoformat(); t=time.monotonic()
    with (out/('purge-focused-'+label+'.stdout.log')).open('wb') as stdout,(out/('purge-focused-'+label+'.stderr.log')).open('wb') as stderr:
        p=subprocess.run(command,cwd=base/checkout/'frontend',stdout=stdout,stderr=stderr)
    result={'argv':command,'cwd':str(base/checkout/'frontend'),'started_utc':started,'exit_code':p.returncode,'duration_seconds':time.monotonic()-t}
    (out/('purge-focused-'+label+'.result.json')).write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result),flush=True)
