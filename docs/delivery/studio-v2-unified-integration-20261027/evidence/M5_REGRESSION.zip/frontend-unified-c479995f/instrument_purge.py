import json,pathlib,subprocess,time
base=pathlib.Path(r'D:\PoemSeed-Unified-20261027-94f1c72e')
out=base/'evidence/frontend-unified-c479995f'
prefix=[r'C:\Program Files\nodejs\node.exe',r'C:\Program Files\nodejs\node_modules\npm\bin\npm-cli.js','exec','--yes','--package=pnpm@10.6.5','--','pnpm','exec','vitest','run','--maxWorkers=2','--minWorkers=1','--reporter=default','--reporter=json']
for checkout,label in [('baseline-C','C'),('m3-verification','integrated')]:
    front=base/checkout/'frontend'; target=out/('purge-instrumented-'+label); target.mkdir(exist_ok=True)
    link=target/'node_modules'
    if not link.exists():
        subprocess.run(['powershell','-NoProfile','-Command',"New-Item -ItemType Junction -Path '"+str(link)+"' -Target '"+str(front/'node_modules')+"' | Out-Null"],check=True)
    source=(front/'src/workspace/state/u1.purge.host.test.tsx').read_text(encoding='utf-8')
    for relative,real in [('./identityBootstrap',front/'src/workspace/state/identityBootstrap'),('../../store',front/'src/store'),('./viewPreferences',front/'src/workspace/state/viewPreferences'),('../layout/persistence',front/'src/workspace/layout/persistence')]:
        source=source.replace("from '"+relative+"'", "from '"+real.as_posix()+"'")
    source="import {ProjectPresence} from '"+(front/'src/workspace/state/projectPurge').as_posix()+"';\nconst traces: any[] = [];\n"+source
    source=source.replace('beforeEach(() => {','beforeEach(() => {\n  const originalObserve = ProjectPresence.prototype.observe;\n  vi.spyOn(ProjectPresence.prototype, "observe").mockImplementation(function(ids) { const result = originalObserve.call(this, ids); traces.push({kind:"observe", ids:[...ids], gone:result, at:Date.now()}); return result; });')
    source=source.replace('afterEach(() => { cleanup();','afterEach(() => { console.log("PURGE_TRACE=" + JSON.stringify(traces)); cleanup();')
    source=source.replace('const qc = new QueryClient({defaultOptions: {queries: {retry: false}}});','const qc = new QueryClient({defaultOptions: {queries: {retry: false}}});\n  qc.getQueryCache().subscribe(event => { if (event.query.queryKey[0] === "novels") traces.push({kind:"cache", event:event.type, action:(event as any).action?.type, key:event.query.queryKey, dataUpdatedAt:event.query.state.dataUpdatedAt, updateCount:event.query.state.dataUpdateCount, fetchStatus:event.query.state.fetchStatus, ids:(event.query.state.data as any[])?.map(n => n.id)}); });')
    (target/'purge.test.tsx').write_text(source,encoding='utf-8')
    config="import original from '"+(front/'vite.config.ts').as_posix()+"';\nexport default {...original, root:"+json.dumps(target.as_posix())+",test:{...original.test,setupFiles:["+json.dumps((front/'vitest.setup.ts').as_posix())+"], include:['purge.test.tsx']}};\n"
    (target/'vitest.config.ts').write_text(config,encoding='utf-8')
    command=prefix+['--config='+str(target/'vitest.config.ts'),'--outputFile='+str(target/'vitest.json')]
    start=time.monotonic()
    with (target/'stdout.log').open('wb') as stdout,(target/'stderr.log').open('wb') as stderr:
        p=subprocess.run(command,cwd=front,stdout=stdout,stderr=stderr)
    (target/'result.json').write_text(json.dumps({'argv':command,'cwd':str(front),'exit_code':p.returncode,'seconds':time.monotonic()-start},indent=2),encoding='utf-8')
    print(label, 'exit',p.returncode,flush=True)
    for line in (target/'stdout.log').read_text(encoding='utf-8').splitlines():
        if line.startswith('PURGE_TRACE='): print(line,flush=True)
