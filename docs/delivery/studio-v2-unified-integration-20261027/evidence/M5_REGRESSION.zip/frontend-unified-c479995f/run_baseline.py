import datetime
import hashlib
import json
import pathlib
import subprocess
import time

BASE = pathlib.Path(r'D:\PoemSeed-Unified-20261027-94f1c72e')
REPO = BASE / 'm3-verification'
OUT = BASE / 'evidence' / 'frontend-unified-c479995f'
FRONTEND = REPO / 'frontend'
NODE = pathlib.Path(r'C:\Program Files\nodejs\node.exe')
NPM = NODE.parent / 'node_modules' / 'npm' / 'bin' / 'npm-cli.js'
PREFIX = [str(NODE), str(NPM), 'exec', '--yes', '--package=pnpm@10.6.5', '--', 'pnpm']
OUT.mkdir(parents=True, exist_ok=True)

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args]).decode('utf-8').strip()

def snapshot(label):
    paths = subprocess.check_output(['git', '-C', str(REPO), 'ls-files', '-z']).decode('utf-8').split('\0')
    rows = []
    for path in paths:
        if not path:
            continue
        file = REPO / path
        rows.append({'path': path, 'sha256': hashlib.sha256(file.read_bytes()).hexdigest() if file.is_file() else None})
    payload = {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'), 'git_status': git('status', '--porcelain'), 'files': rows}
    data = json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2).encode('utf-8')
    (OUT / (label + '.json')).write_bytes(data)
    return payload

def run(label, command):
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    begin = time.monotonic()
    record = {'stage': label, 'cwd': str(FRONTEND), 'argv': command, 'started_utc': started, 'status': 'RUNNING'}
    (OUT / 'current.json').write_text(json.dumps(record, indent=2), encoding='utf-8')
    print('START ' + label, flush=True)
    with (OUT / (label + '.stdout.log')).open('wb') as stdout, (OUT / (label + '.stderr.log')).open('wb') as stderr:
        process = subprocess.run(command, cwd=FRONTEND, stdout=stdout, stderr=stderr)
    record.update(status='COMPLETED', exit_code=process.returncode, duration_seconds=time.monotonic()-begin, ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    (OUT / (label + '.result.json')).write_text(json.dumps(record, indent=2), encoding='utf-8')
    print('END ' + label + ' exit=' + str(process.returncode) + ' seconds=' + str(round(record['duration_seconds'], 2)), flush=True)
    return record

assert NPM.is_file(), str(NPM)
assert git('rev-parse', 'HEAD') == 'c479995fb976044782eac200775e3990083f3902'
before = snapshot('source-before')
results = [run('dependency-install', PREFIX + ['install', '--frozen-lockfile'])]
if results[-1]['exit_code'] == 0:
    results.append(run('build', PREFIX + ['build']))
    results.append(run('vitest', PREFIX + ['exec', 'vitest', 'run', '--maxWorkers=2', '--minWorkers=1', '--reporter=default', '--reporter=json', '--outputFile=' + str(OUT / 'vitest.json')]))
after = snapshot('source-after')
summary = {'head': before['head'], 'tree': before['tree'], 'results': results, 'tracked_source_unchanged': before['files'] == after['files'], 'before_status': before['git_status'], 'after_status': after['git_status']}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
(OUT / 'current.json').write_text(json.dumps({'status':'COMPLETED'}, indent=2), encoding='utf-8')
print(json.dumps(summary, indent=2), flush=True)
