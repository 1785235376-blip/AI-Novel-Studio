import original from 'D:/PoemSeed-Unified-20261027-94f1c72e/m3-verification/frontend/vite.config.ts';
export default {...original, root:"D:/PoemSeed-Unified-20261027-94f1c72e/evidence/frontend-unified-c479995f/purge-instrumented-integrated",test:{...original.test,setupFiles:["D:/PoemSeed-Unified-20261027-94f1c72e/m3-verification/frontend/vitest.setup.ts"], include:['purge.test.tsx']}};
