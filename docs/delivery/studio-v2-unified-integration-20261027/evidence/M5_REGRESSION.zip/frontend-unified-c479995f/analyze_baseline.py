import collections
import hashlib
import json
import pathlib

OUT = pathlib.Path(r'D:\PoemSeed-Unified-20261027-94f1c72e\evidence\frontend-unified-c479995f')
report = json.loads((OUT / 'vitest.json').read_text(encoding='utf-8'))
results = []
suites = []
for suite in report.get('testResults', []):
    assertions = suite.get('assertionResults', [])
    status_counts = dict(collections.Counter(case.get('status') for case in assertions))
    suites.append({'file': suite.get('name'), 'status': suite.get('status'), 'assertion_counts': status_counts, 'message': suite.get('message'), 'startTime': suite.get('startTime'), 'endTime': suite.get('endTime')})
    for case in assertions:
        if case.get('status') != 'passed':
            results.append({'file': suite.get('name'), 'fullName': case.get('fullName'), 'status': case.get('status'), 'failureMessages': case.get('failureMessages'), 'duration': case.get('duration')})
summary = {key: value for key, value in report.items() if key != 'testResults'}
summary['reported_file_count'] = len(suites)
summary['file_statuses'] = dict(collections.Counter(item['status'] for item in suites))
summary['assertion_statuses'] = dict(collections.Counter(case.get('status') for suite in report.get('testResults', []) for case in suite.get('assertionResults', [])))
summary['failed_files'] = [item for item in suites if item['status'] != 'passed']
summary['nonpassed_assertions'] = results
for label in ['source-before', 'source-after']:
    snap = json.loads((OUT / (label + '.json')).read_text(encoding='utf-8'))
    payload = json.dumps(snap['files'], ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')
    summary[label] = {'head':snap['head'], 'tree':snap['tree'], 'tracked_file_count':len(snap['files']), 'tracked_sha256_manifest_digest':hashlib.sha256(payload).hexdigest(), 'git_status':snap['git_status']}
(OUT / 'analysis.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
hashes = {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in OUT.iterdir() if path.is_file() and path.name != 'artifact-hashes.json'}
(OUT / 'artifact-hashes.json').write_text(json.dumps(hashes, indent=2), encoding='utf-8')
print(json.dumps({key:value for key,value in summary.items() if key not in ('nonpassed_assertions','failed_files')}, ensure_ascii=False, indent=2))
print('Failed files:')
for item in summary['failed_files']:
    print(item['file'], item['assertion_counts'])

