import original from 'D:/PoemSeed-Unified-20261027-94f1c72e/baseline-C/frontend/vite.config.ts';
export default {...original, root:"D:/PoemSeed-Unified-20261027-94f1c72e/evidence/frontend-unified-c479995f/purge-observed-v2-C",test:{...original.test,setupFiles:["D:/PoemSeed-Unified-20261027-94f1c72e/baseline-C/frontend/vitest.setup.ts"], include:['purge.test.tsx']}};
