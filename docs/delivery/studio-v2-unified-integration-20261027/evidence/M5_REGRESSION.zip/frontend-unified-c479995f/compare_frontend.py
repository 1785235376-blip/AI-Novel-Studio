import collections
import hashlib
import json
import pathlib
import re
import subprocess

BASE = pathlib.Path(r'D:\PoemSeed-Unified-20261027-94f1c72e')
COUT = BASE / 'evidence/frontend-baseline-C'
IOUT = BASE / 'evidence/frontend-unified-c479995f'
REPO = BASE / 'repository'
REFS = {'A': '457ea4a5a45ab13f351980665e053c5c77d15c82', 'C': 'fe4f55412299fadfada0354725b3ca46e418c46a', 'integrated': 'c479995fb976044782eac200775e3990083f3902'}

def norm(text):
    text = re.sub(r'\x1b\[[0-9;]*m', '', text or '').replace('\\', '/')
    for checkout in ['baseline-C', 'm3-verification']:
        text = text.replace(str(BASE / checkout).replace('\\', '/'), '<checkout>')
    return text

def rel(path):
    return path.replace('\\', '/').split('/frontend/', 1)[-1]

def digest(text):
    return hashlib.sha256(text.encode('utf-8')).hexdigest()

def load(out):
    report = json.loads((out / 'vitest.json').read_text(encoding='utf-8'))
    cases, suites, duplicates = {}, {}, []
    for suite in report['testResults']:
        file = rel(suite['name'])
        assertions = suite.get('assertionResults', [])
        suites[file] = {'file': file, 'status': suite['status'], 'assertions': len(assertions), 'message': norm(suite.get('message', '')), 'status_counts': dict(collections.Counter(a['status'] for a in assertions))}
        counts = collections.Counter()
        for case in assertions:
            plain_id = file + ' :: ' + case['fullName']
            counts[plain_id] += 1
            uid = plain_id if counts[plain_id] == 1 else plain_id + ' [duplicate occurrence ' + str(counts[plain_id]) + ']'
            if counts[plain_id] > 1:
                duplicates.append(uid)
            error = norm('\n'.join(case.get('failureMessages', [])))
            lines = [line.strip() for line in error.splitlines() if line.strip()]
            cases[uid] = {'id': uid, 'file': file, 'fullName': case['fullName'], 'status': case['status'], 'error_headline': lines[0] if lines else '', 'error_signature_sha256': digest(error), 'normalized_error': error}
    output = {'counts': {k: report.get(k) for k in ['numTotalTests', 'numPassedTests', 'numFailedTests', 'numPendingTests']}, 'duplicate_fullNames': duplicates, 'failed': [v for v in cases.values() if v['status'] == 'failed'], 'skipped_or_pending': [v for v in cases.values() if v['status'] not in ['passed', 'failed']], 'collection_errors': [v for v in suites.values() if v['status'] == 'failed' and not v['assertions']], 'suites': list(suites.values())}
    (out / 'failure-identities.json').write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding='utf-8')
    return cases, suites, output

def blob(ref, file):
    p = subprocess.run(['git', '-C', str(REPO), 'rev-parse', '--verify', ref + ':frontend/' + file], capture_output=True, text=True)
    return p.stdout.strip() if p.returncode == 0 else None

c, cs, co = load(COUT)
if not (IOUT / 'vitest.json').exists():
    print(json.dumps({'C_counts': co['counts'], 'C_collection_errors': co['collection_errors'], 'C_unique_failed': len(co['failed']), 'C_duplicate_fullNames': co['duplicate_fullNames']}, indent=2))
    raise SystemExit(0)
i, ins, io = load(IOUT)
cf, inf = {k for k,v in c.items() if v['status'] == 'failed'}, {k for k,v in i.items() if v['status'] == 'failed'}
new_failing = [i[k] for k in sorted(inf-cf)]
changed = [{'id': k, 'file': i[k]['file'], 'same_headline': c[k]['error_headline'] == i[k]['error_headline'], 'C_headline': c[k]['error_headline'], 'integrated_headline': i[k]['error_headline'], 'C_signature': c[k]['error_signature_sha256'], 'integrated_signature': i[k]['error_signature_sha256']} for k in sorted(cf & inf) if c[k]['error_signature_sha256'] != i[k]['error_signature_sha256']]
provenance = {file: {name: blob(ref, file) for name,ref in REFS.items()} for file in sorted({item['file'] for item in new_failing} | (set(ins)-set(cs)))}
comparison = {'normalization': 'Strip ANSI SGR and replace only the two checkout roots; preserve line numbers, DOM, values and error text. ID is relative frontend file plus fullName, with occurrence ordinal for duplicate fullNames.', 'counts': {'C_failed':len(cf), 'integrated_failed':len(inf), 'common_failed':len(cf & inf), 'new_failed':len(inf-cf), 'no_longer_failed':len(cf-inf), 'common_failed_changed_signature':len(changed), 'common_failed_same_signature':len(cf & inf)-len(changed)}, 'new_failures': new_failing, 'no_longer_failed': [{'id': k, 'integrated_status':i.get(k, {}).get('status', 'NOT_COLLECTED')} for k in sorted(cf-inf)], 'changed_failure_signatures': changed, 'new_test_ids': sorted(set(i)-set(c)), 'missing_test_ids': sorted(set(c)-set(i)), 'new_suites': sorted(set(ins)-set(cs)), 'missing_suites': sorted(set(cs)-set(ins)), 'C_collection_errors':co['collection_errors'], 'integrated_collection_errors':io['collection_errors'], 'new_suite_or_failure_source_blobs':provenance}
(IOUT / 'comparison.json').write_text(json.dumps(comparison, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({k:comparison[k] for k in ['counts', 'new_suites', 'missing_suites', 'C_collection_errors', 'integrated_collection_errors', 'new_suite_or_failure_source_blobs']}, ensure_ascii=False, indent=2))
