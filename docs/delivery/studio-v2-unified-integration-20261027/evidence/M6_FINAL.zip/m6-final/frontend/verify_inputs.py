import hashlib,json,pathlib,subprocess
base=pathlib.Path(r'D:\PoemSeed-Unified-20261027-94f1c72e')
out=base/'evidence/m6-final/frontend'
repo=base/'final-verification-5eec654b'
old=json.loads((base/'evidence/frontend-unified-c479995f/source-after.json').read_text(encoding='utf-8'))
new=json.loads((out/'source-before.json').read_text(encoding='utf-8'))
oldfiles={x['path']:x['sha256'] for x in old['files']}
newfiles={x['path']:x['sha256'] for x in new['files']}
excluded={'frontend/scripts/pw_unified_image_loop.mjs','frontend/tests/m5/themeDualCanvas.browser.mjs'}
paths=sorted(p for p in oldfiles.keys() | newfiles.keys() if p.startswith('frontend/') and p not in excluded)
fixtures=sorted(p for p in oldfiles.keys() | newfiles.keys() if p.startswith('tests/fixtures/'))
rows=[{'path':p,'c479_sha256':oldfiles.get(p),'final_sha256':newfiles.get(p),'equal':oldfiles.get(p)==newfiles.get(p)} for p in paths+fixtures]
def git(*args):return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
versions={name:json.loads((repo/'frontend/node_modules'/name/'package.json').read_text(encoding='utf-8'))['version'] for name in ['vite','vitest','typescript','react','@tanstack/react-query','@playwright/test']}
versions['node']=subprocess.check_output([r'C:\Program Files\nodejs\node.exe','--version'],text=True).strip()
report={'baseline_head':old['head'],'baseline_tree':old['tree'],'final_head':new['head'],'final_tree':new['tree'],'frontend_files_compared':len(paths),'shared_fixture_files_compared':len(fixtures),'all_compared_bytes_identical':all(x['equal'] for x in rows),'differences':[x for x in rows if not x['equal']],'excluded_browser_harness_files':[{'path':p,'c479_sha256':oldfiles.get(p),'final_sha256':newfiles.get(p)} for p in sorted(excluded)],'frontend_and_scripts_git_diff':git('diff','--name-status',old['head'],new['head'],'--','frontend','scripts','tests/fixtures'),'file_manifest':rows,'versions':versions,'boundary':'This proves tracked direct frontend source/tests/config/lock and shared fixture byte identity, excluding two browser harness files outside Vitest discovery. It does not assert every cross-language input is identical: apiErrorWhitelist.test.ts invokes python3 to scan app/, and app/creative/canvas_views.py changed in final. The full-suite 297 failures are the actual c479 run and are not a claimed new final full-suite execution.'}
(out/'input-equivalence.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k not in ['file_manifest']},ensure_ascii=False,indent=2))
