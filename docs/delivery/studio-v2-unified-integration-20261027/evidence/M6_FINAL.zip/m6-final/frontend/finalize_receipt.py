import collections,hashlib,json,pathlib
out=pathlib.Path(r'D:\PoemSeed-Unified-20261027-94f1c72e\evidence\m6-final\frontend')
summary=json.loads((out/'summary.json').read_text(encoding='utf-8'))
tests=json.loads((out/'vitest.json').read_text(encoding='utf-8'))
equivalence=json.loads((out/'input-equivalence.json').read_text(encoding='utf-8'))
receipt={**summary,'validation_scope':'standard frontend build plus one selected affected group; NOT a final full-suite run','tests':{k:tests.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','numTodoTests']},'test_files':[],'input_equivalence':{k:v for k,v in equivalence.items() if k!='file_manifest'}}
for suite in tests['testResults']:
    receipt['test_files'].append({'file':suite['name'].replace('\\','/').split('/frontend/',1)[-1],'status':suite['status'],'assertions':dict(collections.Counter(t['status'] for t in suite['assertionResults'])),'collection_error':suite.get('message') if not suite['assertionResults'] else None})
for label in ['source-before','source-after']:
    source=json.loads((out/(label+'.json')).read_text(encoding='utf-8'))
    raw=json.dumps(source['files'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')
    receipt[label]={'head':source['head'],'tree':source['tree'],'tracked_count':len(source['files']),'tracked_manifest_sha256':hashlib.sha256(raw).hexdigest(),'git_status':source['git_status']}
receipt['passed_selected_scope']=all(x['exit_code']==0 for x in summary['results']) and summary['tracked_source_unchanged'] and not summary['before_status'] and not summary['after_status'] and tests['numFailedTests']==0 and len(tests['testResults'])==10
(out/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file() and p.name!='artifact-hashes.json'}
(out/'artifact-hashes.json').write_text(json.dumps(hashes,indent=2),encoding='utf-8')
print(json.dumps({k:receipt[k] for k in ['tests','test_files','source-before','source-after','passed_selected_scope']},ensure_ascii=False,indent=2))
