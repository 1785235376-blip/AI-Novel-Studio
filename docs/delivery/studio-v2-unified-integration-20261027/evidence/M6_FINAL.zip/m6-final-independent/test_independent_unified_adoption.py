"""Independent adversarial acceptance against the selected immutable checkout.

Uses original mounted app, authorities, approved Job and actual Asset owner.
The change_row hook injects a same-thread reentrant owner write: it does not
claim a second HTTP writer can bypass the original cross-thread asset lease.
"""
from copy import deepcopy
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
from hashlib import sha256
from threading import Barrier, Event, Thread
import json

import pytest

from conftest import restore_global_settings
from test_studio_asset_query import rig
from test_unified_canvas_image_result import shared_approved_node, shared_owner_bytes


pytestmark = pytest.mark.file_backend_only


def test_original_asset_metadata_change_in_commit_window_is_not_adopted(
    shared_approved_node, monkeypatch
):
    from app.creative import canvas_views

    e = shared_approved_node
    before = shared_owner_bytes(e)
    request_body = deepcopy(e.body)
    original_change = canvas_views.change_row
    changed = []

    def change_asset_after_original_canvas_change(row, *args, **kwargs):
        result = original_change(row, *args, **kwargs)
        assert row['id'] == e.target['id']
        assert row['definition']['image_node_origin']['asset'] == e.pin
        assert not changed
        metadata = e.rig.assets.get(e.pin['asset_id'], branch_id=e.scope['branch_id'], actor_id='reader')
        assert metadata['version'] == e.pin['version']
        parameters = deepcopy(metadata.get('parameters', {}))
        parameters['independent_commit_window_note'] = 'original-owner-reentrant-write'
        updated = e.rig.assets.update_metadata(
            e.pin['asset_id'], {'parameters': parameters},
            branch_id=e.scope['branch_id'], actor_id='reader',
            expected_version=e.pin['version'],
        )
        assert updated['version'] == e.pin['version'] + 1
        changed.append(deepcopy(updated))
        return result

    monkeypatch.setattr(canvas_views, 'change_row', change_asset_after_original_canvas_change)
    response = e.client.post(e.canvas_url + '/image-node-result', json=request_body)
    after = shared_owner_bytes(e)
    evidence = {
        'case': 'original-asset-owner-reentrant-commit-window',
        'boundary': 'same-thread original owner API; no external-thread lease bypass claim',
        'http_status': response.status_code,
        'response': response.json(),
        'request': request_body,
        'original_asset_version': e.pin['version'],
        'updated_asset_version': changed[0]['version'] if changed else None,
        'canvas_before': json.loads(before[0]),
        'canvas_after': json.loads(after[0]),
        'owner_sha256_before': [sha256(x.encode() if isinstance(x, str) else x).hexdigest() for x in before],
        'owner_sha256_after': [sha256(x.encode() if isinstance(x, str) else x).hexdigest() for x in after],
    }
    (e.run / 'independent-asset-commit-window.json').write_text(json.dumps(evidence, indent=2), encoding='utf-8')
    assert len(changed) == 1, 'original metadata writer did not reach its CAS'
    assert e.body == request_body, 'test must not mutate request pins'
    assert after[1] == before[1] and after[3] == before[3], 'Job or asset binary changed'
    assert json.loads(after[2])['version'] == e.pin['version'] + 1
    assert json.loads(after[2])['parameters']['independent_commit_window_note'] == 'original-owner-reentrant-write'
    assert len(e.calls) == 1
    assert after[0] == before[0], f'Canvas committed despite changed asset; HTTP {response.status_code}'
    assert response.status_code in {404, 409}, response.text


def _canvas(e):
    state = json.loads(shared_owner_bytes(e)[0])
    return state['collections']['creative_canvas_views_v2'][e.target['id']]


def test_concurrent_original_adoptions_append_exactly_one_history(shared_approved_node):
    from fastapi.testclient import TestClient
    from app.main import app

    e = shared_approved_node
    before = shared_owner_bytes(e)
    old = _canvas(e)
    start = Barrier(2)

    def submit():
        client = TestClient(app)
        client.headers.update(dict(e.client.headers))
        try:
            start.wait(timeout=15)
            return client.post(e.canvas_url + '/image-node-result', json=deepcopy(e.body))
        finally:
            client.close()

    with ThreadPoolExecutor(max_workers=2) as pool:
        futures = [pool.submit(submit) for _ in range(2)]
        responses = [future.result(timeout=40) for future in futures]
    saved = _canvas(e)
    statuses = [response.status_code for response in responses]
    (e.run / 'independent-concurrent-adoption.json').write_text(json.dumps({
        'statuses': statuses, 'responses': [r.json() for r in responses],
        'canvas_before': old, 'canvas_after': saved,
    }, indent=2), encoding='utf-8')
    assert 200 in statuses and set(statuses) <= {200, 409}, statuses
    assert saved['version'] == old['version'] + 1
    assert len(saved['history']) == len(old['history']) + 1
    assert len(saved['definition']['cards']) == 1
    assert saved['definition']['cards'][0]['asset'] == e.pin
    assert saved['definition']['image_node_origin']['asset'] == e.pin
    after = shared_owner_bytes(e)
    assert after[1:] == before[1:]
    replay = e.client.post(e.canvas_url + '/image-node-result', json=deepcopy(e.body))
    assert replay.status_code == 200, replay.text
    assert shared_owner_bytes(e) == after
    assert len(e.calls) == 1


def test_original_asset_writer_on_other_thread_waits_for_asset_lease(shared_approved_node, monkeypatch):
    from app.creative import canvas_views

    e = shared_approved_node
    old = _canvas(e)
    original_change = canvas_views.change_row
    probed, done = Event(), Event()
    observations, failures, threads = [], [], []

    def writer():
        try:
            acquired = e.rig.assets._lock.acquire(blocking=False)
            if acquired:
                e.rig.assets._lock.release()
            observations.append({'asset_lock_acquired_before_commit': acquired})
            probed.set()
            with e.rig.workspace._asset_scope(e.nid, e.scope):
                result = e.rig.assets.update_metadata(e.pin['asset_id'],
                    {'parameters': {'independent_external_writer': 'serialized'}},
                    branch_id=e.scope['branch_id'], actor_id='reader', expected_version=e.pin['version'])
            observations.append({'updated_version': result['version']})
        except BaseException as exc:
            failures.append(repr(exc))
        finally:
            done.set()

    def start_external_writer(row, *args, **kwargs):
        result = original_change(row, *args, **kwargs)
        assert row['id'] == e.target['id']
        thread = Thread(target=writer, daemon=True)
        threads.append(thread)
        thread.start()
        assert probed.wait(10), 'writer did not probe original asset lease'
        assert observations == [{'asset_lock_acquired_before_commit': False}]
        assert not done.is_set(), 'external owner writer completed inside the lease'
        return result

    monkeypatch.setattr(canvas_views, 'change_row', start_external_writer)
    response = e.client.post(e.canvas_url + '/image-node-result', json=deepcopy(e.body))
    for thread in threads:
        thread.join(timeout=15)
    saved = _canvas(e)
    (e.run / 'independent-asset-thread-lease.json').write_text(json.dumps({
        'http_status': response.status_code, 'response': response.json(),
        'observations': observations, 'failures': failures,
        'canvas_before': old, 'canvas_after': saved,
    }, indent=2), encoding='utf-8')
    assert done.is_set() and not failures, failures
    assert observations == [{'asset_lock_acquired_before_commit': False}, {'updated_version': e.pin['version'] + 1}]
    assert saved['version'] == old['version'] + 1
    assert len(saved['history']) == len(old['history']) + 1
    assert saved['definition']['cards'][0]['asset'] == e.pin
    assert response.status_code in {200, 409}, response.text


@pytest.mark.parametrize('timing', ['before', 'commit'])
def test_real_session_actor_switch_prevents_adoption(shared_approved_node, monkeypatch, timing):
    from app.creative import canvas_views

    e = shared_approved_node
    before = shared_owner_bytes(e)
    actor_context = e.rig.sessions.resolve(e.token)
    switched = []

    def switch():
        e.rig.sessions.register(e.token, replace(actor_context.session, actor_id='independent-other-author'))
        switched.append(True)

    if timing == 'before':
        switch()
    else:
        original_change = canvas_views.change_row

        def change_actor_after_original_change(row, *args, **kwargs):
            result = original_change(row, *args, **kwargs)
            assert row['id'] == e.target['id']
            switch()
            return result

        monkeypatch.setattr(canvas_views, 'change_row', change_actor_after_original_change)
    response = e.client.post(e.canvas_url + '/image-node-result', json=deepcopy(e.body))
    assert switched == [True]
    assert shared_owner_bytes(e) == before
    assert response.status_code in {401, 403}, response.text
    assert len(e.calls) == 1
