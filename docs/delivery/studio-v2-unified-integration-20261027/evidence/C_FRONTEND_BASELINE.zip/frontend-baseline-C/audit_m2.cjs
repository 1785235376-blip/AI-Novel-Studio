const fs = require('fs');
const cp = require('child_process');
const crypto = require('crypto');
const ts = require('D:/PoemSeed-Unified-20261027-94f1c72e/baseline-C/frontend/node_modules/typescript/lib/typescript.js');
const repo = 'D:/PoemSeed-Unified-20261027-94f1c72e/repository';
const output = 'D:/PoemSeed-Unified-20261027-94f1c72e/evidence/frontend-baseline-C/m2-static-review.json';
const A = '457ea4a5a45ab13f351980665e053c5c77d15c82';
const C = 'fe4f55412299fadfada0354725b3ca46e418c46a';
const M = '9c01565800931bd1ef49e9949a65e130f754b349';
const source = (ref, file) => cp.execFileSync('git', ['-C',repo,'show',`${ref}:${file}`], {encoding:'utf8'});
function entries(ref,file){
  const body = source(ref,file), sf = ts.createSourceFile(file,body,ts.ScriptTarget.Latest,true);
  const out = {};
  function visit(node){
    if ((ts.isFunctionDeclaration(node)||ts.isMethodDeclaration(node)||ts.isVariableDeclaration(node))&&node.name){
      const name = node.name.getText(sf);
      (out[name]??=[]).push(node.getText(sf));
    }
    ts.forEachChild(node,visit);
  }
  visit(sf);return out;
}
const selections = {
  'frontend/src/creative/studioProductionClient.ts':['resolveImageNodeCreate','observeImageNodeTarget','readImageNodeTargetView','observeImageNodeJob','discardImageNodeJob','checkedImageNodeJobProjection','studioImageNodeJobProjection','checkedStudioImageNodeJobDiscard'],
  'frontend/src/rebuild/canvas/RebuildCanvas.tsx':['sourceCurrent','readSourceCurrent','formalSourceCurrent','active','removedNodes','promptRevisions','positionRevisions','selectionEpoch'],
  'frontend/src/taskcenter/StudioProductionTasks.tsx':['inspectTarget','inspectImageNodeJob','prepareImageNodeDiscard','hasCanvasTarget','discardEligible','begin','valid'],
  'frontend/src/rebuild/image/ImageRebuild.tsx':['openCanvasTask','renderCanvasTask','canvasTaskDrawer']
};
const rows = [];
for(const [file,names] of Object.entries(selections)){
  const a=entries(A,file), m=entries(M,file);
  for(const name of names)rows.push({file,name,A_count:a[name]?.length??0,M_count:m[name]?.length??0,exact_ast_text:JSON.stringify(a[name])===JSON.stringify(m[name])});
}
const equalFiles=['frontend/src/App.tsx','frontend/src/api.ts','frontend/src/creative/studioProductionClient.ts','frontend/src/rebuild/canvas/RebuildCanvas.tsx','frontend/src/rebuild/image/CanvasImageQueue.test.tsx','frontend/src/rebuild/canvas/DualStack.tsx','frontend/src/rebuild/canvas/DualStack.test.tsx','frontend/tests/m5/themeDualCanvas.browser.mjs'];
const fileRows=[];
for(const file of equalFiles){try{const c=source(C,file), m=source(M,file);fileRows.push({file,equal_to_C:c===m,sha256:crypto.createHash('sha256').update(m).digest('hex')});}catch(error){fileRows.push({file,error:String(error.message)});}}
const result={scope:'Static fixed-commit read only. No tests or app execution. Comments and declaration-order-only differences reviewed manually.',A,C,M,A_guard_comparisons:rows,C_file_comparisons:fileRows};
fs.writeFileSync(output,JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
