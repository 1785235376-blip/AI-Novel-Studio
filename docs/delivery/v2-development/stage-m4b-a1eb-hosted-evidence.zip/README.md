# a1eb536 compact hosted CI evidence

Five original runs reached natural terminal states: 29 jobs, 17 success, 12 failure, 0 cancelled. Both additive browser suites were 16 passed / 1 failed. The new M4-B case passed on both events; the original M4 case failed. Shared R123 successfully reproduced RED on its fixed historical c6f2126 source; it is not current-source security approval.

This compact packet contains all 29 decoded job logs, final run/jobs/source metadata, all 33 verified artifact hashes, all six original failed collection receipts, exact trace/network text components and first-failure screenshots, both M4-B owner receipts and twelve original screenshots, and key original JUnit/native/RED evidence. No screenshot, log or trace component was resized, truncated or rewritten. ZIP compression is lossless.

This is not a complete playable Playwright trace or a full-artifact archive. Trace screenshot/resource bodies and the original full ZIPs are omitted here. Full original trace ZIPs remain in the full evidence packet's independent-media artifact ZIPs. Their original sizes and SHA256 values are recorded in metadata/trace-sources.json.

source-byte-verification.json binds each copied original file/component to its archived source. SHA256SUMS and member-sha256.json cover payload members; the external a1eb-terminal-summary.json additionally records every ZIP member's SHA256, including the manifest files, plus the ZIP hash.

Fixture-local tokens in original trace text are synthetic, ephemeral localhost test-session evidence. No user account credentials, private temporary download URLs, internal publication ledger or orchestration notes are included. No current-product pass, real-model run, user Windows acceptance or independent security audit is inferred.
