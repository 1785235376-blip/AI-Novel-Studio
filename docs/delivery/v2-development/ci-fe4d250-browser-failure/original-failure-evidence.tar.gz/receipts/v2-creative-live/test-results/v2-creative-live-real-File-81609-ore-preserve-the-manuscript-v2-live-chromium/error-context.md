# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: v2-creative-live.spec.ts >> real File V2 authoring: reviewed direction, ordered storyboard, production history and restore preserve the manuscript
- Location: tests/e2e/v2-creative-live.spec.ts:72:1

# Error details

```
Test timeout of 180000ms exceeded.
```

```
Error: locator.click: Test timeout of 180000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: '打开 V2 创作工作台', exact: true })
    - locator resolved to <button class="ui-button ui-button--secondary">打开 V2 创作工作台</button>
  - attempting click action
    2 × waiting for element to be visible, enabled and stable
      - element is visible, enabled and stable
      - scrolling into view if needed
      - done scrolling
      - <button type="button" aria-label="打开功能导航" aria-expanded="false" aria-controls="feature-launcher-overlay" class="ui-button ui-button--ghost  feature-launcher__toggle">…</button> from <div class="feature-launcher">…</div> subtree intercepts pointer events
    - retrying click action
    - waiting 20ms
    2 × waiting for element to be visible, enabled and stable
      - element is visible, enabled and stable
      - scrolling into view if needed
      - done scrolling
      - <button type="button" aria-label="打开功能导航" aria-expanded="false" aria-controls="feature-launcher-overlay" class="ui-button ui-button--ghost  feature-launcher__toggle">…</button> from <div class="feature-launcher">…</div> subtree intercepts pointer events
    - retrying click action
      - waiting 100ms
    343 × waiting for element to be visible, enabled and stable
        - element is visible, enabled and stable
        - scrolling into view if needed
        - done scrolling
        - <button type="button" aria-label="打开功能导航" aria-expanded="false" aria-controls="feature-launcher-overlay" class="ui-button ui-button--ghost  feature-launcher__toggle">…</button> from <div class="feature-launcher">…</div> subtree intercepts pointer events
      - retrying click action
        - waiting 500ms

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - generic "AI Novel Studio" [ref=e5]:
      - generic [ref=e9]:
        - strong [ref=e10]: AI Novel
        - generic [ref=e11]: Studio
    - tablist "创作模块" [ref=e12]:
      - tab "小说" [selected] [ref=e13] [cursor=pointer]
      - tab "图片" [ref=e17] [cursor=pointer]
      - tab "视频" [ref=e23] [cursor=pointer]
      - tab "资产" [ref=e28] [cursor=pointer]
      - tab "声音" [ref=e32] [cursor=pointer]
      - tab "主控" [ref=e38] [cursor=pointer]
      - tab "插件" [ref=e52] [cursor=pointer]
      - tab "工作流" [ref=e56] [cursor=pointer]
    - button "打开全局命令" [ref=e62] [cursor=pointer]:
      - generic [ref=e66]: 搜索作品、章节与素材
      - generic [ref=e67]: Ctrl K
    - generic [ref=e68]:
      - generic [ref=e69]: 本
      - generic [ref=e70]: 本机作者
  - navigation "当前创作范围" [ref=e71]:
    - generic [ref=e72]: 创作空间：本机作品
    - generic [ref=e73]: /
    - generic [ref=e74]: 小说：V2 浏览器合成验收 1791529315683
    - generic [ref=e75]: /
    - generic [ref=e76]: 故事线：默认故事线
    - generic [ref=e77]: /
    - generic [ref=e78]: 创作分支：主线
  - main [ref=e79]:
    - complementary [ref=e80]:
      - generic [ref=e81]:
        - generic [ref=e82]:
          - generic [ref=e83]: 小说结构
          - strong [ref=e84]: 章节导航
        - generic [ref=e86]:
          - generic [ref=e87]:
            - heading "作品结构" [level=2] [ref=e88]
            - button "新建章节" [ref=e89] [cursor=pointer]
          - navigation "章节列表" [ref=e90]:
            - list [ref=e91]:
              - listitem [ref=e92]:
                - generic [ref=e93]:
                  - generic "拖拽调整章节顺序" [ref=e94]
                  - button "1. 第一章 合成海港 已保存" [ref=e102] [cursor=pointer]:
                    - generic "第一章 合成海港" [ref=e103]: 1. 第一章 合成海港
                    - generic [ref=e104]: 已保存
                  - generic [ref=e105]:
                    - button "重命名第一章 合成海港" [ref=e106] [cursor=pointer]
                    - button "更多章节操作第一章 合成海港" [ref=e110] [cursor=pointer]
          - region [ref=e115]:
            - heading "已移出章节" [level=3] [ref=e116]
            - paragraph [ref=e117]: 目前没有已移出章节。
        - generic [ref=e118]:
          - generic [ref=e119]: 工作区
          - strong [ref=e120]: 创作工具
        - button "打开 V2 创作工作台" [ref=e121] [cursor=pointer]
        - generic [ref=e123]:
          - button "打开功能导航" [ref=e125] [cursor=pointer]: 功能导航
          - tooltip "打开功能导航"
    - generic [ref=e130]:
      - generic [ref=e132]:
        - generic [ref=e133]:
          - generic [ref=e134]:
            - generic [ref=e135]: 当前章节
            - generic [ref=e136]: 合成验收正文：林默走到云港。她说：“下一幕由我们自己决定。”
          - generic [ref=e137]: 32 字
          - generic "写作目标进度" [ref=e138]:
            - generic [ref=e139]: 目标 31 / 0 字
            - generic [ref=e140]: 第 1 / 0 章
            - progressbar [ref=e141]
            - strong [ref=e142]: 0%
        - generic [ref=e143]:
          - status [ref=e144]: 已保存
          - button "保存" [ref=e148] [cursor=pointer]
      - textbox "章节正文" [ref=e151]:
        - heading "合成验收正文：林默走到云港。她说：“下一幕由我们自己决定。”" [level=1] [ref=e152]
      - generic [ref=e153]:
        - heading "版本记录" [level=2] [ref=e155]
        - generic [ref=e156]:
          - navigation "版本记录时间线" [ref=e157]:
            - list [ref=e158]:
              - listitem [ref=e159]:
                - button "版本 1 手动保存 local-user · 2026/10/9 07:01:57" [ref=e160] [cursor=pointer]:
                  - strong [ref=e162]: 版本 1
                  - generic [ref=e163]: 手动保存
                  - generic [ref=e164]: local-user · 2026/10/9 07:01:57
          - region "版本详情" [ref=e165]:
            - status [ref=e166]:
              - strong [ref=e167]: 选择一个历史版本
              - paragraph [ref=e168]: 查看它与当前内容的差异，并预览恢复结果。
    - button "收起侧栏" [expanded] [ref=e169] [cursor=pointer]
    - complementary [ref=e173]:
      - separator "调整检查面板宽度" [ref=e174]
      - generic [ref=e175]:
        - generic [ref=e176]: 创作辅助
        - button "收起侧栏" [ref=e177] [cursor=pointer]
      - generic [ref=e181]:
        - region "当前写作上下文" [ref=e182]:
          - generic [ref=e183]: 当前章节
          - strong [ref=e184]: 合成验收正文：林默走到云港。她说：“下一幕由我们自己决定。”
          - generic [ref=e185]: 第 1 章 · 版本 2
        - generic [ref=e186]:
          - heading "项目概览" [level=2] [ref=e187]
          - paragraph [ref=e188]: 设置本小说的创作目标，进度会同步显示在编辑器顶部。
          - generic [ref=e189]:
            - text: 目标字数
            - spinbutton "目标字数" [ref=e190]: "0"
          - generic [ref=e191]:
            - text: 目标章节
            - spinbutton "目标章节" [ref=e192]: "0"
          - generic [ref=e193]:
            - text: 截止日期
            - textbox "截止日期" [ref=e194]
          - button "保存写作目标" [disabled] [ref=e195]
        - region "正文外发策略" [ref=e196]:
          - group [ref=e197]:
            - generic "正文隐私：仅本地或尚未确认" [ref=e198]
            - option "仅本地" [selected]
            - option "允许我选定的云模型接收此版本"
        - generic [ref=e199]:
          - heading "AI 写作助手" [level=2] [ref=e201]
          - tablist "AI 写作方式" [ref=e202]:
            - tab "创作下一章" [selected] [ref=e203] [cursor=pointer]
            - tab "改写" [ref=e204] [cursor=pointer]
            - tab "润色" [ref=e205] [cursor=pointer]
            - tab "头脑风暴" [ref=e206] [cursor=pointer]
          - generic [ref=e207]:
            - text: 文本模型
            - combobox "文本模型" [ref=e208]:
              - option "尚未选择文本模型" [selected]
              - option "DeepSeek Chat [模拟测试，未调用真实模型]"
              - option "DeepSeek Reasoner [模拟测试，未调用真实模型]"
              - option "qwen2.5:7b-instruct-q4_K_M（不可用）" [disabled]
          - region [ref=e209]:
            - generic [ref=e210]:
              - strong [ref=e211]: 当前模型
              - generic [ref=e212]: 尚未选择模型
            - status [ref=e213]: 选择模型后可查看是否能够开始写作。
          - group "候选方案数量" [ref=e214]:
            - generic [ref=e215]: 候选方案
            - button "1" [pressed] [ref=e216] [cursor=pointer]
            - button "2" [ref=e217] [cursor=pointer]
            - button "3" [ref=e218] [cursor=pointer]
          - generic [ref=e219]:
            - text: 附加要求（可选）
            - textbox "附加要求（可选）" [ref=e220]:
              - /placeholder: 例如：保持紧张节奏，突出人物犹豫。
          - generic [ref=e221]:
            - text: 写作风格（可选）
            - textbox "写作风格（可选）" [ref=e222]:
              - /placeholder: 例如：克制、冷峻、短句为主
          - generic "写作风格预设" [ref=e223]:
            - button "克制冷峻 · 短句为主" [ref=e224] [cursor=pointer]
            - button "细腻抒情 · 强化感官" [ref=e225] [cursor=pointer]
            - button "紧张悬疑 · 加快节奏" [ref=e226] [cursor=pointer]
            - button "轻松幽默 · 对话自然" [ref=e227] [cursor=pointer]
          - region [ref=e228]:
            - generic [ref=e229]:
              - generic [ref=e230]:
                - heading "AI Context Preview" [level=3] [ref=e231]
                - paragraph [ref=e232]: 角色上下文资料检查。它与写作生成的请求构造不同，不是最终发送预览。
              - generic [ref=e233]: 资料检查
            - generic [ref=e234]:
              - generic [ref=e235]:
                - text: 上下文目标
                - combobox "上下文目标" [ref=e236]:
                  - option "本地上下文" [selected]
                  - option "云端安全上下文"
              - button "刷新上下文" [ref=e237] [cursor=pointer]
            - status [ref=e238]: 点击“刷新上下文”，读取当前写作方式对应的 Context Service 数据。
          - button "生成创作下一章草稿" [disabled] [ref=e240]
          - region [ref=e241]:
            - generic [ref=e243]:
              - strong [ref=e244]: 生成流程
              - generic [ref=e245]: 上下文 → 计划 → 草稿 → 审核
            - list [ref=e246]:
              - listitem [ref=e247]:
                - generic [ref=e251]:
                  - generic [ref=e252]:
                    - strong [ref=e253]: 读取创作上下文
                    - generic [ref=e254]: 等待
                  - generic [ref=e255]: 开始生成后读取
              - listitem [ref=e256]:
                - generic [ref=e260]:
                  - generic [ref=e261]:
                    - strong [ref=e262]: 建立生成计划
                    - generic [ref=e263]: 等待
                  - generic [ref=e264]: 等待任务创建
              - listitem [ref=e265]:
                - generic [ref=e269]:
                  - generic [ref=e270]:
                    - strong [ref=e271]: 生成章节草稿
                    - generic [ref=e272]: 等待
                  - generic [ref=e273]: 等待生成
              - listitem [ref=e274]:
                - generic [ref=e278]:
                  - generic [ref=e279]:
                    - strong [ref=e280]: 作者审核
                    - generic [ref=e281]: 等待
                  - generic [ref=e282]: 等待可审核草稿
          - status [ref=e283]:
            - strong [ref=e284]: 尚未生成草稿
            - paragraph [ref=e285]: 选择写作方式并生成后，可在这里预览、比较和决定是否采用。
  - contentinfo [ref=e286]:
    - text: 保存：已保存 · 连接：本机 · AI 任务：无运行任务
    - button "问助手" [ref=e288] [cursor=pointer]
```

# Test source

```ts
  1   | import { test, expect, type APIRequestContext, type Locator, type Page, type TestInfo } from '@playwright/test';
  2   | 
  3   | type Row = Record<string, any>;
  4   | const manuscript = '合成验收正文：林默走到云港。她说：“下一幕由我们自己决定。”';
  5   | const creative = (novelId: string) => `/api/novels/${novelId}/experimental/creative`;
  6   | const canvas = (page: Page) => page.getByRole('region', { name: '创作画布', exact: true });
  7   | const stage = (page: Page, name: string) => page.getByRole('tablist', { name: '创作模式', exact: true }).getByRole('tab', { name: new RegExp(`^${name}`) });
  8   | 
  9   | async function read(request: APIRequestContext, url: string): Promise<Row> {
  10  |   const response = await request.get(url);
  11  |   expect(response.ok(), `${url}: ${response.status()} ${await response.text()}`).toBeTruthy();
  12  |   return response.json();
  13  | }
  14  | async function write(request: APIRequestContext, url: string, data: Row): Promise<Row> {
  15  |   const response = await request.post(url, { data });
  16  |   expect(response.ok(), `${url}: ${response.status()} ${await response.text()}`).toBeTruthy();
  17  |   return response.json();
  18  | }
  19  | async function fixture(page: Page, request: APIRequestContext) {
  20  |   await page.goto('/');
  21  |   await page.getByPlaceholder('小说名称').fill(`V2 浏览器合成验收 ${Date.now()}`);
  22  |   const creating = page.waitForResponse(response => response.url().endsWith('/api/novels') && response.request().method() === 'POST');
  23  |   await page.getByRole('button', { name: '创建小说', exact: true }).click();
  24  |   const novel = await (await creating).json();
  25  |   await page.getByRole('button', { name: '新建章节', exact: true }).click();
  26  |   await page.getByLabel('章节标题', { exact: true }).fill('第一章 合成海港');
  27  |   await page.getByRole('button', { name: '创建章节', exact: true }).click();
  28  |   await page.locator('.ProseMirror').fill(manuscript);
  29  |   await page.getByRole('button', { name: '保存', exact: true }).click();
  30  |   await expect(page.locator('.editorbar')).toContainText('已保存');
  31  |   const chapters = await read(request, `/api/novels/${novel.id}/chapters`);
  32  |   const chapter = await read(request, `/api/chapters/${chapters[0].id}`);
> 33  |   await page.getByRole('button', { name: '打开 V2 创作工作台', exact: true }).click();
      |                                                                        ^ Error: locator.click: Test timeout of 180000ms exceeded.
  34  |   await expect(stage(page, '小说')).toHaveAttribute('aria-selected', 'true');
  35  |   await stage(page, '剧本').click();
  36  |   await expect(canvas(page).getByLabel('文档标题', { exact: true })).toBeEnabled();
  37  |   return { novel, chapter, base: creative(novel.id) };
  38  | }
  39  | async function clickTwice(locator: Locator) {
  40  |   // Native browser double-click: two actual click events while the mutation guard is active.
  41  |   await locator.dblclick({ delay: 10 });
  42  | }
  43  | async function mutate(page: Page, url: string, method: string, action: () => Promise<void>) {
  44  |   const pending = page.waitForResponse(response => new URL(response.url()).pathname === url && response.request().method() === method);
  45  |   await action();
  46  |   const response = await pending;
  47  |   expect(response.ok(), `${method} ${url}: ${response.status()} ${await response.text()}`).toBeTruthy();
  48  |   return response.json() as Promise<Row>;
  49  | }
  50  | async function save(page: Page, base: string, document?: Row, repeat = false) {
  51  |   return mutate(page, `${base}/documents${document ? `/${document.id}` : ''}`, document ? 'PUT' : 'POST',
  52  |     () => repeat ? clickTwice(canvas(page).getByRole('button', { name: '保存草稿', exact: true })) : canvas(page).getByRole('button', { name: '保存草稿', exact: true }).click());
  53  | }
  54  | async function screenplay(page: Page, base: string) {
  55  |   await canvas(page).getByLabel('文档标题', { exact: true }).fill('云港 · 合成剧本');
  56  |   await page.getByRole('button', { name: '从当前已保存章节建立场景底稿', exact: true }).click();
  57  |   await canvas(page).getByLabel('场景标题', { exact: true }).fill('EXT. 云港 · 清晨');
  58  |   await canvas(page).getByLabel('场景地点', { exact: true }).fill('云港码头');
  59  |   await canvas(page).getByRole('button', { name: '添加对白', exact: true }).click();
  60  |   await canvas(page).getByLabel('对白 1 人物', { exact: true }).fill('林默');
  61  |   await canvas(page).getByLabel('对白 1 内容', { exact: true }).fill('下一幕由我们自己决定。');
  62  |   await canvas(page).getByRole('button', { name: '添加场景', exact: true }).click();
  63  |   await canvas(page).getByLabel('场景标题', { exact: true }).fill('INT. 灯塔 · 日');
  64  |   await canvas(page).getByLabel('动作与叙事', { exact: true }).fill('她在窗边整理航海图。');
  65  |   return save(page, base, undefined, true);
  66  | }
  67  | async function capture(page: Page, info: TestInfo, name: string) {
  68  |   await page.screenshot({ path: info.outputPath(`${name}.png`), fullPage: true });
  69  |   await info.attach(name, { path: info.outputPath(`${name}.png`), contentType: 'image/png' });
  70  | }
  71  | 
  72  | test('real File V2 authoring: reviewed direction, ordered storyboard, production history and restore preserve the manuscript', async ({ page, request }, info) => {
  73  |   test.info().annotations.push({ type: 'verification', description: 'Real uvicorn + File persistence + Vite + Chromium; synthetic manuscript; rule-assisted direction; no model inference or paid provider calls.' });
  74  |   const errors: string[] = [], requests: Row[] = [];
  75  |   page.on('pageerror', error => errors.push(error.message));
  76  |   page.on('request', req => { if (req.url().includes('/experimental/creative') && req.method() !== 'GET') requests.push({ path: new URL(req.url()).pathname, method: req.method() }); });
  77  |   const { novel, chapter, base } = await fixture(page, request);
  78  |   const source = await screenplay(page, base);
  79  |   expect(source.version).toBe(1);
  80  |   expect(source.source_chapter_ids).toEqual([chapter.id]);
  81  |   expect(source.scenes).toHaveLength(2);
  82  |   expect((await read(request, `${base}/documents`)).items).toHaveLength(1);
  83  |   expect(requests.filter(row => row.path === `${base}/documents` && row.method === 'POST')).toHaveLength(1);
  84  |   await expect(canvas(page)).toContainText('已保存 · v1');
  85  |   await capture(page, info, 'screenplay-saved');
  86  | 
  87  |   const proposal = await mutate(page, `${base}/director-proposals`, 'POST', () => clickTwice(page.getByRole('button', { name: '准备待审导演建议', exact: true })));
  88  |   expect(proposal.status).toBe('NEEDS_REVIEW');
  89  |   expect(proposal.provenance.model_called).toBe(false);
  90  |   await expect(page.getByRole('button', { name: '审核并采用', exact: true })).toBeDisabled();
  91  |   expect((await read(request, `${base}/documents`)).items).toHaveLength(1);
  92  |   const review = page.getByRole('region', { name: '导演建议审核', exact: true });
  93  |   await review.getByText('场景调度 1', { exact: true }).click();
  94  |   await review.getByLabel('建议 1 表演指导', { exact: true }).fill('人工确认：停顿后看向窗外。');
  95  |   await review.getByLabel('采用后的导演文档标题', { exact: true }).fill('云港 · 人工审核导演稿');
  96  |   await review.getByRole('checkbox', { name: '已核对来源、场面调度与导演建议；创建独立导演文档', exact: true }).check();
  97  |   const approved = await mutate(page, `${base}/director-proposals/${proposal.id}/review`, 'POST', () => clickTwice(review.getByRole('button', { name: '审核并采用', exact: true })));
  98  |   const director = approved.document;
  99  |   expect(approved.proposal.status).toBe('APPROVED');
  100 |   expect(director.director_notes[0].performance).toBe('人工确认：停顿后看向窗外。');
  101 |   expect(director.source_documents[source.id].version).toBe(1);
  102 |   await expect(stage(page, '导演')).toHaveAttribute('aria-selected', 'true');
  103 |   expect((await read(request, `${base}/documents`)).items).toHaveLength(2);
  104 |   expect(requests.filter(row => row.path.endsWith('/review'))).toHaveLength(1);
  105 |   await capture(page, info, 'director-human-reviewed');
  106 | 
  107 |   const board = await mutate(page, `${base}/documents/${director.id}/derive`, 'POST', () => clickTwice(canvas(page).getByRole('button', { name: '建立分镜草稿', exact: true })));
  108 |   await expect(stage(page, '分镜')).toHaveAttribute('aria-selected', 'true');
  109 |   expect(board.shots).toHaveLength(2);
  110 |   expect(board.provenance.model_called).toBe(false);
  111 |   await canvas(page).getByRole('button', { name: '前移镜头 2', exact: true }).click();
  112 |   await canvas(page).getByLabel('画面描述', { exact: true }).fill('海港窗框里的人工镜头构图');
  113 |   await canvas(page).getByLabel('镜头与焦距', { exact: true }).fill('50mm');
  114 |   const editedBoard = await save(page, base, board);
  115 |   expect(editedBoard.version).toBe(2);
  116 |   expect(editedBoard.shots.map((shot: Row) => shot.id)).toEqual([...board.shots].reverse().map((shot: Row) => shot.id));
  117 |   expect(editedBoard.shots.some((shot: Row) => shot.lens === '50mm')).toBe(true);
  118 |   const production = await mutate(page, `${base}/documents/${board.id}/derive`, 'POST', () => clickTwice(canvas(page).getByRole('button', { name: '建立制作计划', exact: true })));
  119 |   await expect(stage(page, '制作')).toHaveAttribute('aria-selected', 'true');
  120 |   expect(production.video_plan.segments.map((row: Row) => row.shot_id)).toEqual(editedBoard.shots.map((row: Row) => row.id));
  121 |   await page.getByRole('button', { name: '后移第 1 段', exact: true }).click();
  122 |   await page.getByLabel('第 1 段时长', { exact: true }).fill('9');
  123 |   await page.getByLabel('制作备注', { exact: true }).fill('人工排序，仅结构化计划，未渲染媒体。');
  124 |   const editedProduction = await save(page, base, production);
  125 |   expect(editedProduction.version).toBe(2);
  126 |   expect(editedProduction.video_plan.segments[0].shot_id).toBe(production.video_plan.segments[1].shot_id);
  127 |   expect(editedProduction.video_plan.segments[0].duration_seconds).toBe(9);
  128 |   for (const [width, height] of [[1366, 768], [1440, 900], [1920, 1080]]) {
  129 |     await page.setViewportSize({ width, height });
  130 |     const geometry = await page.locator('.creative-workspace').evaluate(element => ({ client: element.clientWidth, scroll: element.scrollWidth, body: document.documentElement.scrollWidth, viewport: innerWidth }));
  131 |     expect(geometry.scroll).toBeLessThanOrEqual(geometry.client + 1);
  132 |     expect(geometry.body).toBeLessThanOrEqual(geometry.viewport + 1);
  133 |     await capture(page, info, `production-${width}x${height}`);
```