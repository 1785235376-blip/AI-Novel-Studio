M4 first publication a880c22509091e1f085a06ad6ef0360cedce57c5, all five workflows/29 jobs terminal.
23 successful jobs; six failed jobs; no cancellations. Attempt 1 only.
Official connector decoded job logs are archived exactly as received and UTF-8 encoded, retaining BOM where returned.
These are decoded-log bytes, not a claim of a downloaded GitHub raw-log ZIP byte identity.
PR strict File/PostgreSQL joins are complete; push joins fail their successful-execution prerequisite.
Original R123 artifact 11663926647 ZIP is retained with its verified upload-log SHA256.
No signed download URLs, credentials, private publication ledgers or denied artifacts are included.
Do not substitute one event/source/profile for another, or claim real-model/quality/Windows-user acceptance.
